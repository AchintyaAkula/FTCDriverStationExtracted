package com.qualcomm.robotcore.util;

public class Version {
    public static final String LIBRARY_VERSION = "25.08.27";

    public static String getLibraryVersion() {
        return LIBRARY_VERSION;
    }
}

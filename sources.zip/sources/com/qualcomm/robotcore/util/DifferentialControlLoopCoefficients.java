package com.qualcomm.robotcore.util;

import com.qualcomm.hardware.lynx.LynxServoController;

public class DifferentialControlLoopCoefficients {
    public double d;
    public double i;
    public double p;

    public DifferentialControlLoopCoefficients() {
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
    }

    public DifferentialControlLoopCoefficients(double d2, double d3, double d4) {
        this.p = d2;
        this.i = d3;
        this.d = d4;
    }
}

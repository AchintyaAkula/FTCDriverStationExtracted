package com.qualcomm.robotcore.util;

import com.qualcomm.robotcore.exception.RobotCoreException;

public class RunShellCommand {
    private static int BUFFER_SIZE = 524288;
    private boolean logging = false;
    private Process process = null;

    public void enableLogging(boolean z) {
        this.logging = z;
    }

    public ProcessResult run(String str) {
        return runCommand(str, false);
    }

    public ProcessResult runAsRoot(String str) {
        return runCommand(str, true);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0069, code lost:
        if (r11 != null) goto L_0x006b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x006b, code lost:
        r11.destroy();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x007a, code lost:
        if (r11 == null) goto L_0x0086;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0083, code lost:
        if (r11 == null) goto L_0x0086;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x008c, code lost:
        return new com.qualcomm.robotcore.util.RunShellCommand.ProcessResult(r9, r8, (com.qualcomm.robotcore.util.RunShellCommand.AnonymousClass1) null);
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0071 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private com.qualcomm.robotcore.util.RunShellCommand.ProcessResult runCommand(java.lang.String r11, boolean r12) {
        /*
            r10 = this;
            java.lang.String r0 = "Done running "
            java.lang.ProcessBuilder r1 = new java.lang.ProcessBuilder
            r2 = 0
            java.lang.String[] r3 = new java.lang.String[r2]
            r1.<init>(r3)
            int r3 = BUFFER_SIZE
            byte[] r3 = new byte[r3]
            r4 = 2
            java.lang.String r5 = "-c"
            r6 = 3
            r7 = 1
            java.lang.String r8 = ""
            r9 = -1
            if (r12 == 0) goto L_0x002a
            java.lang.String[] r12 = new java.lang.String[r6]     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.String r6 = "su"
            r12[r2] = r6     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12[r7] = r5     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12[r4] = r11     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.ProcessBuilder r12 = r1.command(r12)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12.redirectErrorStream(r7)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            goto L_0x003b
        L_0x002a:
            java.lang.String[] r12 = new java.lang.String[r6]     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.String r6 = "sh"
            r12[r2] = r6     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12[r7] = r5     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12[r4] = r11     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.ProcessBuilder r12 = r1.command(r12)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12.redirectErrorStream(r7)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
        L_0x003b:
            java.lang.Process r12 = r1.start()     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r10.process = r12     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            int r9 = r12.waitFor()     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12.<init>(r0)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.StringBuilder r11 = r12.append(r11)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.String r11 = r11.toString()     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            com.qualcomm.robotcore.util.RobotLog.i(r11)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.lang.Process r11 = r10.process     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            java.io.InputStream r11 = r11.getInputStream()     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            int r11 = r11.read(r3)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            if (r11 <= 0) goto L_0x0067
            java.lang.String r12 = new java.lang.String     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r12.<init>(r3, r2, r11)     // Catch:{ IOException -> 0x007d, InterruptedException -> 0x0071 }
            r8 = r12
        L_0x0067:
            java.lang.Process r11 = r10.process
            if (r11 == 0) goto L_0x0086
        L_0x006b:
            r11.destroy()
            goto L_0x0086
        L_0x006f:
            r11 = move-exception
            goto L_0x008d
        L_0x0071:
            java.lang.Thread r11 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x006f }
            r11.interrupt()     // Catch:{ all -> 0x006f }
            java.lang.Process r11 = r10.process
            if (r11 == 0) goto L_0x0086
            goto L_0x006b
        L_0x007d:
            r11 = move-exception
            com.qualcomm.robotcore.util.RobotLog.logStackTrace(r11)     // Catch:{ all -> 0x006f }
            java.lang.Process r11 = r10.process
            if (r11 == 0) goto L_0x0086
            goto L_0x006b
        L_0x0086:
            com.qualcomm.robotcore.util.RunShellCommand$ProcessResult r11 = new com.qualcomm.robotcore.util.RunShellCommand$ProcessResult
            r12 = 0
            r11.<init>(r9, r8)
            return r11
        L_0x008d:
            java.lang.Process r12 = r10.process
            if (r12 == 0) goto L_0x0094
            r12.destroy()
        L_0x0094:
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.util.RunShellCommand.runCommand(java.lang.String, boolean):com.qualcomm.robotcore.util.RunShellCommand$ProcessResult");
    }

    public void commitSeppuku() {
        Process process2 = this.process;
        if (process2 != null) {
            process2.destroy();
            try {
                this.process.waitFor();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void killSpawnedProcess(String str, String str2) throws RobotCoreException {
        try {
            int spawnedProcessPid = getSpawnedProcessPid(str, str2);
            while (spawnedProcessPid != -1) {
                RobotLog.v("Killing PID " + spawnedProcessPid);
                new RunShellCommand().run(String.format("kill %d", new Object[]{Integer.valueOf(spawnedProcessPid)}));
                spawnedProcessPid = getSpawnedProcessPid(str, str2);
            }
        } catch (Exception unused) {
            throw new RobotCoreException(String.format("Failed to kill %s instances started by this app", new Object[]{str}));
        }
    }

    public static int getSpawnedProcessPid(String str, String str2) {
        String str3;
        String access$100 = new RunShellCommand().runCommand("ps", false).output;
        String[] split = access$100.split("\n");
        int length = split.length;
        int i = 0;
        while (true) {
            if (i >= length) {
                str3 = "invalid";
                break;
            }
            String str4 = split[i];
            if (str4.contains(str2)) {
                str3 = str4.split("\\s+")[0];
                break;
            }
            i++;
        }
        for (String str5 : access$100.split("\n")) {
            if (str5.contains(str) && str5.contains(str3)) {
                return Integer.parseInt(str5.split("\\s+")[1]);
            }
        }
        return -1;
    }

    public static final class ProcessResult {
        /* access modifiers changed from: private */
        public final String output;
        private final int returnCode;

        private ProcessResult(int i, String str) {
            this.returnCode = i;
            this.output = str;
        }

        public int getReturnCode() {
            return this.returnCode;
        }

        public String getOutput() {
            return this.output;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            ProcessResult processResult = (ProcessResult) obj;
            if (this.returnCode != processResult.returnCode) {
                return false;
            }
            String str = this.output;
            String str2 = processResult.output;
            if (str != null) {
                return str.equals(str2);
            }
            if (str2 == null) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            int i = this.returnCode * 31;
            String str = this.output;
            return i + (str != null ? str.hashCode() : 0);
        }
    }
}

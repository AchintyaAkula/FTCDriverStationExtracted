package com.qualcomm.robotcore.util;

public enum SortOrder {
    ASCENDING,
    DESCENDING
}

package com.qualcomm.robotcore.util;

public class AndroidSerialNumberNotFoundException extends Exception {
}

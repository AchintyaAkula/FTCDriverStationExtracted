package com.qualcomm.robotcore;

public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.qualcomm.robotcore";
    public static final String SDK_BUILD_TIME = "2025-08-27T11:01:34.310-0700";
    public static final int SDK_MAJOR_VERSION = 11;
    public static final int SDK_MINOR_VERSION = 0;
    public static final int SDK_POINT_VERSION = 0;
}

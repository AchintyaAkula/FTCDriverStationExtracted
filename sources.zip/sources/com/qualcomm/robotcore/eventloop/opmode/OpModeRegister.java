package com.qualcomm.robotcore.eventloop.opmode;

public interface OpModeRegister {
    void register(OpModeManager opModeManager);
}

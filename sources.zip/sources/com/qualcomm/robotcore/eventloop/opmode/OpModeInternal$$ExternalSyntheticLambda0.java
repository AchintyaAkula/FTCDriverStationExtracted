package com.qualcomm.robotcore.eventloop.opmode;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class OpModeInternal$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ OpModeInternal f$0;

    public /* synthetic */ OpModeInternal$$ExternalSyntheticLambda0(OpModeInternal opModeInternal) {
        this.f$0 = opModeInternal;
    }

    public final void run() {
        this.f$0.m26lambda$internalInit$1$comqualcommrobotcoreeventloopopmodeOpModeInternal();
    }
}

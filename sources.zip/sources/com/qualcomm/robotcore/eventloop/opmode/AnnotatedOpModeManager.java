package com.qualcomm.robotcore.eventloop.opmode;

public interface AnnotatedOpModeManager extends OpModeManager {
    void register(Class cls);
}

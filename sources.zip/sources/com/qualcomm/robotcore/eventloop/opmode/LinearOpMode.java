package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.util.RobotLog;
import org.firstinspires.ftc.robotcore.internal.opmode.TelemetryInternal;
import org.firstinspires.ftc.robotcore.internal.system.Assert;

public abstract class LinearOpMode extends OpMode {
    private final Object runningNotifier = new Object();
    private volatile boolean userMethodReturned = false;
    private volatile boolean userMonitoredForStart = false;

    public final void init() {
    }

    public final void init_loop() {
    }

    public final void loop() {
    }

    public abstract void runOpMode() throws InterruptedException;

    public final void start() {
    }

    public final void stop() {
    }

    public void waitForStart() {
        while (!isStarted()) {
            synchronized (this.runningNotifier) {
                try {
                    this.runningNotifier.wait();
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                    return;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    public final void idle() {
        Thread.yield();
    }

    public final void sleep(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    public final boolean opModeIsActive() {
        boolean z = !isStopRequested() && isStarted();
        if (z) {
            idle();
        }
        return z;
    }

    public final boolean opModeInInit() {
        return !isStarted() && !isStopRequested();
    }

    public final boolean isStarted() {
        if (this.isStarted) {
            this.userMonitoredForStart = true;
        }
        if (this.isStarted || Thread.currentThread().isInterrupted()) {
            return true;
        }
        return false;
    }

    public final boolean isStopRequested() {
        return this.stopRequested || Thread.currentThread().isInterrupted();
    }

    /* access modifiers changed from: package-private */
    public final void internalRunOpMode() throws InterruptedException {
        this.userMethodReturned = false;
        this.userMonitoredForStart = false;
        runOpMode();
        this.userMethodReturned = true;
        RobotLog.d("User runOpModeMethod exited");
        requestOpModeStop();
    }

    /* access modifiers changed from: package-private */
    public final void internalOnStart() {
        synchronized (this.runningNotifier) {
            this.runningNotifier.notifyAll();
        }
    }

    /* access modifiers changed from: package-private */
    public final void internalOnEventLoopIteration() {
        this.time = getRuntime();
        synchronized (this.runningNotifier) {
            this.runningNotifier.notifyAll();
        }
        if (this.telemetry instanceof TelemetryInternal) {
            ((TelemetryInternal) this.telemetry).tryUpdateIfDirty();
        }
    }

    /* access modifiers changed from: package-private */
    public final void internalOnStopRequested() {
        if (!this.userMonitoredForStart && this.userMethodReturned) {
            RobotLog.addGlobalWarningMessage("The OpMode which was just initialized ended prematurely as a result of not monitoring for the start condition. Did you forget to call waitForStart()?");
        }
        Assert.assertTrue(this.executorService != null);
        this.executorService.shutdownNow();
    }

    /* access modifiers changed from: package-private */
    public void newGamepadDataAvailable(Gamepad gamepad, Gamepad gamepad2) {
        this.gamepad1.copy(gamepad);
        this.gamepad2.copy(gamepad2);
    }
}

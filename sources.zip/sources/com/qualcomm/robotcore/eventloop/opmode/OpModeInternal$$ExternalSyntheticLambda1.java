package com.qualcomm.robotcore.eventloop.opmode;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class OpModeInternal$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ OpModeInternal f$0;

    public /* synthetic */ OpModeInternal$$ExternalSyntheticLambda1(OpModeInternal opModeInternal) {
        this.f$0 = opModeInternal;
    }

    public final void run() {
        this.f$0.m27lambda$internalInit$2$comqualcommrobotcoreeventloopopmodeOpModeInternal();
    }
}

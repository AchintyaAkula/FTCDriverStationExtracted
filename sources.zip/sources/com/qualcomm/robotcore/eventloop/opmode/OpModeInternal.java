package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.I2cWarningManager;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.ThreadPool;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.internal.opmode.OpModeServices;
import org.firstinspires.ftc.robotcore.internal.opmode.TelemetryImpl;
import org.firstinspires.ftc.robotcore.internal.opmode.TelemetryInternal;
import org.firstinspires.ftc.robotcore.internal.system.Assert;

abstract class OpModeInternal {
    private static final String EXECUTOR_NAME = "OpModeExecutor";
    public static final int MS_BEFORE_FORCE_STOP_AFTER_STOP_REQUESTED = 900;
    volatile RuntimeException exception = null;
    volatile ExecutorService executorService = null;
    public volatile Gamepad gamepad1 = null;
    public volatile Gamepad gamepad2 = null;
    public volatile HardwareMap hardwareMap = null;
    volatile OpModeServices internalOpModeServices = null;
    volatile boolean isStarted = false;
    @Deprecated
    public int msStuckDetectStop = 900;
    volatile NoClassDefFoundError noClassDefFoundError = null;
    volatile boolean opModeThreadFinished = false;
    Gamepad previousGamepad1Data = new Gamepad();
    Gamepad previousGamepad2Data = new Gamepad();
    volatile boolean stopRequested = false;
    public Telemetry telemetry = new TelemetryImpl((OpMode) this);

    /* access modifiers changed from: package-private */
    public void internalOnEventLoopIteration() {
    }

    /* access modifiers changed from: package-private */
    public void internalOnStart() {
    }

    /* access modifiers changed from: package-private */
    public void internalOnStopRequested() {
    }

    /* access modifiers changed from: package-private */
    public abstract void internalRunOpMode() throws InterruptedException;

    /* access modifiers changed from: package-private */
    public abstract void newGamepadDataAvailable(Gamepad gamepad, Gamepad gamepad3);

    OpModeInternal() {
    }

    public final void requestOpModeStop() {
        this.internalOpModeServices.requestOpModeStop((OpMode) this);
    }

    /* access modifiers changed from: package-private */
    public final void internalInit() {
        this.executorService = ThreadPool.newSingleThreadExecutor(EXECUTOR_NAME);
        this.exception = null;
        this.noClassDefFoundError = null;
        this.isStarted = false;
        this.stopRequested = false;
        this.opModeThreadFinished = false;
        Telemetry telemetry2 = this.telemetry;
        if (telemetry2 instanceof TelemetryInternal) {
            ((TelemetryInternal) telemetry2).resetTelemetryForOpMode();
        }
        this.gamepad1.resetEdgeDetection();
        this.gamepad2.resetEdgeDetection();
        this.executorService.execute(new OpModeInternal$$ExternalSyntheticLambda1(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$internalInit$2$com-qualcomm-robotcore-eventloop-opmode-OpModeInternal  reason: not valid java name */
    public /* synthetic */ void m27lambda$internalInit$2$comqualcommrobotcoreeventloopopmodeOpModeInternal() {
        ThreadPool.logThreadLifeCycle("OpModeThread", new OpModeInternal$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$internalInit$1$com-qualcomm-robotcore-eventloop-opmode-OpModeInternal  reason: not valid java name */
    public /* synthetic */ void m26lambda$internalInit$1$comqualcommrobotcoreeventloopopmodeOpModeInternal() {
        OpModeInternal$$ExternalSyntheticLambda2 opModeInternal$$ExternalSyntheticLambda2;
        try {
            internalRunOpMode();
            opModeInternal$$ExternalSyntheticLambda2 = new OpModeInternal$$ExternalSyntheticLambda2(this);
        } catch (InterruptedException unused) {
            RobotLog.d("OpMode received an InterruptedException; shutting down");
            requestOpModeStop();
            opModeInternal$$ExternalSyntheticLambda2 = new OpModeInternal$$ExternalSyntheticLambda2(this);
        } catch (CancellationException unused2) {
            RobotLog.d("OpMode received a CancellationException; shutting down");
            requestOpModeStop();
            opModeInternal$$ExternalSyntheticLambda2 = new OpModeInternal$$ExternalSyntheticLambda2(this);
        } catch (RuntimeException e) {
            this.exception = e;
            opModeInternal$$ExternalSyntheticLambda2 = new OpModeInternal$$ExternalSyntheticLambda2(this);
        } catch (NoClassDefFoundError e2) {
            this.noClassDefFoundError = e2;
            opModeInternal$$ExternalSyntheticLambda2 = new OpModeInternal$$ExternalSyntheticLambda2(this);
        } catch (Throwable th) {
            I2cWarningManager.suppressNewProblemDeviceWarningsWhile(new OpModeInternal$$ExternalSyntheticLambda2(this));
            this.opModeThreadFinished = true;
            throw th;
        }
        I2cWarningManager.suppressNewProblemDeviceWarningsWhile(opModeInternal$$ExternalSyntheticLambda2);
        this.opModeThreadFinished = true;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$internalInit$0$com-qualcomm-robotcore-eventloop-opmode-OpModeInternal  reason: not valid java name */
    public /* synthetic */ void m25lambda$internalInit$0$comqualcommrobotcoreeventloopopmodeOpModeInternal() {
        Telemetry telemetry2 = this.telemetry;
        if (telemetry2 instanceof TelemetryInternal) {
            telemetry2.setMsTransmissionInterval(0);
            ((TelemetryInternal) this.telemetry).tryUpdateIfDirty();
        }
    }

    /* access modifiers changed from: package-private */
    public final void internalStart() {
        this.gamepad1.resetEdgeDetection();
        this.gamepad2.resetEdgeDetection();
        this.stopRequested = false;
        this.isStarted = true;
        internalOnStart();
    }

    /* access modifiers changed from: package-private */
    public final void internalThrowOpModeExceptionIfPresent() {
        if (this.exception != null) {
            throw this.exception;
        } else if (this.noClassDefFoundError != null) {
            throw this.noClassDefFoundError;
        }
    }

    /* access modifiers changed from: package-private */
    public final void internalStop() {
        if (!this.stopRequested) {
            boolean z = true;
            this.stopRequested = z;
            try {
                internalOnStopRequested();
                while (!this.opModeThreadFinished) {
                    try {
                        Thread.sleep(5);
                    } catch (InterruptedException unused) {
                    }
                }
            } finally {
                if (this.executorService == null) {
                    z = false;
                }
                Assert.assertTrue(z);
                this.executorService.shutdownNow();
                this.executorService = null;
            }
        }
    }
}

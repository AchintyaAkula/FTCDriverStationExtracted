package com.qualcomm.robotcore.eventloop.opmode;

@Deprecated
public class AnnotatedOpModeRegistrar {
    @Deprecated
    public static void register(OpModeManager opModeManager) {
    }
}

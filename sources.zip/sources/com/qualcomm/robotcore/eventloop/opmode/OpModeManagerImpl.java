package com.qualcomm.robotcore.eventloop.opmode;

import android.app.Activity;
import android.content.Context;
import android.os.Debug;
import android.util.Log;
import com.google.blocks.ftcrobotcontroller.runtime.BlocksOpMode$BlocksOpModeAccess$$ExternalSyntheticBackportWithForwarding0;
import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.R;
import com.qualcomm.robotcore.eventloop.EventLoopManager;
import com.qualcomm.robotcore.eventloop.opmode.OpModeManagerNotifier;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.LightSensor;
import com.qualcomm.robotcore.hardware.RobotCoreLynxController;
import com.qualcomm.robotcore.hardware.RobotCoreLynxModule;
import com.qualcomm.robotcore.hardware.RobotCoreLynxUsbDevice;
import com.qualcomm.robotcore.hardware.ServoController;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.robocol.TelemetryMessage;
import com.qualcomm.robotcore.robot.RobotState;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.ThreadPool;
import com.qualcomm.robotcore.util.WeakReferenceSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.opmode.OpModeMeta;
import org.firstinspires.ftc.robotcore.internal.opmode.OpModeServices;
import org.firstinspires.ftc.robotcore.internal.opmode.RegisteredOpModes;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.ui.GamepadUser;
import org.firstinspires.ftc.robotcore.internal.ui.UILocation;
import org.firstinspires.inspection.InspectionState;

public class OpModeManagerImpl implements OpModeServices, OpModeManagerNotifier {
    public static final String DEFAULT_OP_MODE_NAME = "$Stop$Robot$";
    public static final String TAG = "OpModeManager";
    protected static final WeakHashMap<Activity, OpModeManagerImpl> mapActivityToOpModeManager = new WeakHashMap<>();
    protected static int matchNumber = 0;
    protected static volatile boolean preventDangerousHardwareAccess = false;
    protected OpModeInternal activeOpMode = null;
    protected String activeOpModeName = "$Stop$Robot$";
    protected boolean callToInitNeeded = false;
    protected boolean callToStartNeeded = false;
    protected Context context;
    protected EventLoopManager eventLoopManager = null;
    protected boolean gamepadResetNeeded = false;
    protected HardwareMap hardwareMap = null;
    protected final WeakReferenceSet<OpModeManagerNotifier.Notifications> listeners = new WeakReferenceSet<>();
    protected AtomicReference<OpModeStateTransition> nextOpModeState = new AtomicReference<>((Object) null);
    protected OpModeState opModeState = OpModeState.INIT;
    protected boolean opModeSwapNeeded = false;
    protected boolean peerWasConnected = NetworkConnectionHandler.getInstance().isPeerConnected();
    protected OpModeMeta queuedOpModeMetadata = RegisteredOpModes.DEFAULT_OP_MODE_METADATA;
    protected OpModeStuckCodeMonitor stuckMonitor = null;
    protected boolean telemetryClearNeeded = false;

    public static class ForceStopException extends RuntimeException {
    }

    protected enum OpModeState {
        INIT,
        LOOPING
    }

    class OpModeStateTransition {
        Boolean callToInitNeeded = null;
        Boolean callToStartNeeded = null;
        Boolean gamepadResetNeeded = null;
        Boolean onlyTransitionIfDefaultOpModeIsRunning = null;
        Boolean opModeSwapNeeded = null;
        OpModeMeta queuedOpModeMetadata = null;
        Boolean telemetryClearNeeded = null;

        OpModeStateTransition() {
        }

        /* access modifiers changed from: package-private */
        public void apply() {
            Boolean bool = this.onlyTransitionIfDefaultOpModeIsRunning;
            if (bool == null || !bool.booleanValue() || OpModeManagerImpl.this.getActiveOpModeName().equals("$Stop$Robot$")) {
                OpModeMeta opModeMeta = this.queuedOpModeMetadata;
                if (opModeMeta != null) {
                    OpModeManagerImpl.this.queuedOpModeMetadata = opModeMeta;
                }
                Boolean bool2 = this.opModeSwapNeeded;
                if (bool2 != null) {
                    OpModeManagerImpl.this.opModeSwapNeeded = bool2.booleanValue();
                }
                Boolean bool3 = this.callToInitNeeded;
                if (bool3 != null) {
                    OpModeManagerImpl.this.callToInitNeeded = bool3.booleanValue();
                }
                Boolean bool4 = this.gamepadResetNeeded;
                if (bool4 != null) {
                    OpModeManagerImpl.this.gamepadResetNeeded = bool4.booleanValue();
                }
                Boolean bool5 = this.telemetryClearNeeded;
                if (bool5 != null) {
                    OpModeManagerImpl.this.telemetryClearNeeded = bool5.booleanValue();
                }
                Boolean bool6 = this.callToStartNeeded;
                if (bool6 != null) {
                    OpModeManagerImpl.this.callToStartNeeded = bool6.booleanValue();
                }
            }
        }

        /* access modifiers changed from: package-private */
        public OpModeStateTransition copy() {
            OpModeStateTransition opModeStateTransition = new OpModeStateTransition();
            opModeStateTransition.queuedOpModeMetadata = this.queuedOpModeMetadata;
            opModeStateTransition.opModeSwapNeeded = this.opModeSwapNeeded;
            opModeStateTransition.callToInitNeeded = this.callToInitNeeded;
            opModeStateTransition.gamepadResetNeeded = this.gamepadResetNeeded;
            opModeStateTransition.telemetryClearNeeded = this.telemetryClearNeeded;
            opModeStateTransition.callToStartNeeded = this.callToStartNeeded;
            opModeStateTransition.onlyTransitionIfDefaultOpModeIsRunning = this.onlyTransitionIfDefaultOpModeIsRunning;
            return opModeStateTransition;
        }
    }

    public static boolean shouldPreventDangerousHardwareAccess() {
        return preventDangerousHardwareAccess;
    }

    public OpModeManagerImpl(Activity activity, HardwareMap hardwareMap2) {
        this.hardwareMap = hardwareMap2;
        initOpMode("$Stop$Robot$");
        this.context = activity;
        WeakHashMap<Activity, OpModeManagerImpl> weakHashMap = mapActivityToOpModeManager;
        synchronized (weakHashMap) {
            weakHashMap.put(activity, this);
        }
    }

    public static OpModeManagerImpl getOpModeManagerOfActivity(Activity activity) {
        OpModeManagerImpl opModeManagerImpl;
        WeakHashMap<Activity, OpModeManagerImpl> weakHashMap = mapActivityToOpModeManager;
        synchronized (weakHashMap) {
            opModeManagerImpl = weakHashMap.get(activity);
        }
        return opModeManagerImpl;
    }

    public void init(EventLoopManager eventLoopManager2) {
        this.stuckMonitor = new OpModeStuckCodeMonitor();
        this.eventLoopManager = eventLoopManager2;
    }

    public void teardown() {
        this.stuckMonitor.shutdown();
    }

    public OpMode registerListener(OpModeManagerNotifier.Notifications notifications) {
        OpMode opMode;
        synchronized (this.listeners) {
            this.listeners.add(notifications);
            opMode = (OpMode) this.activeOpMode;
        }
        return opMode;
    }

    public void unregisterListener(OpModeManagerNotifier.Notifications notifications) {
        synchronized (this.listeners) {
            this.listeners.remove(notifications);
        }
    }

    /* access modifiers changed from: protected */
    public void setActiveOpMode(OpMode opMode, String str) {
        synchronized (this.listeners) {
            this.activeOpMode = opMode;
            this.activeOpModeName = str;
        }
    }

    public void setHardwareMap(HardwareMap hardwareMap2) {
        this.hardwareMap = hardwareMap2;
    }

    public HardwareMap getHardwareMap() {
        return this.hardwareMap;
    }

    public RobotState getRobotState() {
        EventLoopManager eventLoopManager2 = this.eventLoopManager;
        if (eventLoopManager2 != null) {
            return eventLoopManager2.state;
        }
        return RobotState.UNKNOWN;
    }

    public String getActiveOpModeName() {
        return this.activeOpModeName;
    }

    public OpMode getActiveOpMode() {
        return (OpMode) this.activeOpMode;
    }

    /* access modifiers changed from: protected */
    public void doMatchLoggingWork(String str, boolean z) {
        if (z) {
            RobotLog.stopMatchLogging();
            return;
        }
        try {
            RobotLog.startMatchLogging(this.context, str, matchNumber);
        } catch (RobotCoreException e) {
            RobotLog.ee(TAG, "Could not start match logging");
            e.printStackTrace();
        }
    }

    public void setMatchNumber(int i) {
        matchNumber = i;
    }

    public void initOpMode(String str) {
        initOpMode(str, false);
    }

    public void initOpMode(String str, boolean z) {
        OpModeMeta opModeMeta;
        boolean equals = str.equals("$Stop$Robot$");
        preventDangerousHardwareAccess = equals;
        if (equals) {
            opModeMeta = RegisteredOpModes.DEFAULT_OP_MODE_METADATA;
        } else {
            opModeMeta = RegisteredOpModes.getInstance().getOpModeMetadata(str);
        }
        if (opModeMeta == null) {
            RobotLog.ee(TAG, "initOpMode(): Was unable to find metadata for OpMode %s", str);
            return;
        }
        boolean z2 = opModeMeta.flavor == OpModeMeta.Flavor.SYSTEM;
        OpModeStateTransition opModeStateTransition = new OpModeStateTransition();
        opModeStateTransition.queuedOpModeMetadata = opModeMeta;
        opModeStateTransition.opModeSwapNeeded = true;
        opModeStateTransition.callToInitNeeded = true;
        opModeStateTransition.gamepadResetNeeded = true;
        opModeStateTransition.telemetryClearNeeded = Boolean.valueOf(!equals);
        opModeStateTransition.callToStartNeeded = Boolean.valueOf(z2);
        opModeStateTransition.onlyTransitionIfDefaultOpModeIsRunning = Boolean.valueOf(z);
        this.nextOpModeState.set(opModeStateTransition);
    }

    public void startActiveOpMode() {
        OpModeStateTransition opModeStateTransition;
        OpModeStateTransition opModeStateTransition2 = null;
        while (true) {
            if (opModeStateTransition2 != null) {
                opModeStateTransition = opModeStateTransition2.copy();
            } else {
                opModeStateTransition = new OpModeStateTransition();
            }
            opModeStateTransition.callToStartNeeded = true;
            if (!BlocksOpMode$BlocksOpModeAccess$$ExternalSyntheticBackportWithForwarding0.m(this.nextOpModeState, opModeStateTransition2, opModeStateTransition)) {
                Thread.yield();
                opModeStateTransition2 = this.nextOpModeState.get();
            } else {
                return;
            }
        }
    }

    public void stopActiveOpMode() {
        callActiveOpModeStop();
        RobotLog.stopMatchLogging();
        initOpMode("$Stop$Robot$");
    }

    public void runActiveOpMode(Gamepad[] gamepadArr, Gamepad gamepad, Gamepad gamepad2) {
        OpModeInternal opModeInternal;
        OpModeStateTransition andSet = this.nextOpModeState.getAndSet((Object) null);
        if (andSet != null) {
            andSet.apply();
        }
        OpModeInternal opModeInternal2 = this.activeOpMode;
        if (opModeInternal2 != null) {
            opModeInternal2.gamepad1 = gamepadArr[0];
            this.activeOpMode.gamepad2 = gamepadArr[1];
            if (!gamepad.equals(this.activeOpMode.previousGamepad1Data) || !gamepad2.equals(this.activeOpMode.previousGamepad2Data)) {
                this.activeOpMode.newGamepadDataAvailable(gamepad, gamepad2);
                this.activeOpMode.previousGamepad1Data = gamepad;
                this.activeOpMode.previousGamepad2Data = gamepad2;
            }
        }
        if (this.gamepadResetNeeded) {
            gamepadArr[0].reset();
            gamepadArr[1].reset();
            gamepadArr[0].setUserForEffects(GamepadUser.ONE.id);
            gamepadArr[1].setUserForEffects(GamepadUser.TWO.id);
            this.gamepadResetNeeded = false;
        }
        if (this.telemetryClearNeeded && this.eventLoopManager != null) {
            TelemetryMessage telemetryMessage = new TelemetryMessage();
            telemetryMessage.addData("\u0000", InspectionState.NO_VERSION);
            this.eventLoopManager.sendTelemetryData(telemetryMessage);
            this.telemetryClearNeeded = false;
            RobotLog.clearGlobalErrorMsg();
            RobotLog.clearGlobalWarningMsg();
        }
        if (this.opModeSwapNeeded) {
            callActiveOpModeStop();
            checkOnActiveOpMode();
            if (performOpModeSwap()) {
                this.opModeSwapNeeded = false;
            } else {
                failedToSwapOpMode();
                return;
            }
        }
        boolean z = this.callToInitNeeded;
        String str = RobotCoreCommandList.CMD_NOTIFY_INIT_OP_MODE;
        if (z && (opModeInternal = this.activeOpMode) != null) {
            opModeInternal.gamepad1 = gamepadArr[0];
            this.activeOpMode.gamepad2 = gamepadArr[1];
            this.activeOpMode.hardwareMap = this.hardwareMap;
            this.activeOpMode.internalOpModeServices = this;
            boolean z2 = this.activeOpMode instanceof DefaultOpMode;
            preventDangerousHardwareAccess = z2;
            if (!z2) {
                resetHardwareForOpMode();
            }
            ((OpMode) this.activeOpMode).resetRuntime();
            callActiveOpModeInit();
            this.opModeState = OpModeState.INIT;
            this.callToInitNeeded = false;
            NetworkConnectionHandler.getInstance().sendCommand(new Command(str, this.activeOpModeName));
        } else if (this.callToStartNeeded) {
            callActiveOpModeStart();
            this.opModeState = OpModeState.LOOPING;
            this.callToStartNeeded = false;
            NetworkConnectionHandler.getInstance().sendCommand(new Command(RobotCoreCommandList.CMD_NOTIFY_RUN_OP_MODE, this.activeOpModeName));
        } else if (this.opModeState == OpModeState.INIT || this.opModeState == OpModeState.LOOPING) {
            checkOnActiveOpMode();
            boolean isPeerConnected = NetworkConnectionHandler.getInstance().isPeerConnected();
            if (isPeerConnected && !this.peerWasConnected) {
                if (this.opModeState != OpModeState.INIT) {
                    str = RobotCoreCommandList.CMD_NOTIFY_RUN_OP_MODE;
                }
                NetworkConnectionHandler.getInstance().sendCommand(new Command(str, this.activeOpModeName));
            }
            this.peerWasConnected = isPeerConnected;
        }
    }

    /* access modifiers changed from: protected */
    public void resetHardwareForOpMode() {
        HashSet<HardwareDevice> hashSet = new HashSet<>();
        hashSet.addAll(this.hardwareMap.getAll(RobotCoreLynxModule.class));
        hashSet.addAll(this.hardwareMap.getAll(RobotCoreLynxController.class));
        for (HardwareDevice resetDeviceConfigurationForOpMode : hashSet) {
            resetDeviceConfigurationForOpMode.resetDeviceConfigurationForOpMode();
        }
        for (HardwareDevice next : this.hardwareMap.unsafeIterable()) {
            if (!hashSet.contains(next)) {
                next.resetDeviceConfigurationForOpMode();
            }
        }
    }

    private boolean performOpModeSwap() {
        String str = this.queuedOpModeMetadata.name;
        RobotLog.i("Attempting to switch to OpMode " + str);
        OpMode opMode = RegisteredOpModes.getInstance().getOpMode(str);
        boolean z = false;
        if (opMode == null) {
            return false;
        }
        setActiveOpMode(opMode, str);
        if (this.queuedOpModeMetadata.flavor == OpModeMeta.Flavor.SYSTEM) {
            z = true;
        }
        doMatchLoggingWork(str, z);
        return true;
    }

    private void failedToSwapOpMode() {
        RobotLog.ee(TAG, "Unable to start OpMode " + this.queuedOpModeMetadata.name);
        initOpMode("$Stop$Robot$");
    }

    /* access modifiers changed from: protected */
    public void callActiveOpModeStop() {
        if (this.activeOpMode != null) {
            preventDangerousHardwareAccess = true;
            for (RobotCoreLynxModule attemptFailSafeAndIgnoreErrors : this.hardwareMap.getAll(RobotCoreLynxModule.class)) {
                attemptFailSafeAndIgnoreErrors.attemptFailSafeAndIgnoreErrors();
            }
            try {
                detectStuck(900, "stop()", new Runnable() {
                    public void run() {
                        OpModeManagerImpl.this.activeOpMode.internalStop();
                    }
                });
            } catch (ForceStopException unused) {
            }
            synchronized (this.listeners) {
                Iterator<OpModeManagerNotifier.Notifications> it = this.listeners.iterator();
                while (it.hasNext()) {
                    it.next().onOpModePostStop((OpMode) this.activeOpMode);
                }
            }
            for (HardwareDevice next : this.hardwareMap.unsafeIterable()) {
                if (next instanceof OpModeManagerNotifier.Notifications) {
                    ((OpModeManagerNotifier.Notifications) next).onOpModePostStop((OpMode) this.activeOpMode);
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void detectStuck(int i, String str, Runnable runnable) {
        detectStuck(i, str, runnable, false);
    }

    /* access modifiers changed from: protected */
    public void detectStuck(int i, String str, Runnable runnable, boolean z) {
        this.stuckMonitor.startMonitoring(i, str, z);
        try {
            runnable.run();
        } finally {
            this.stuckMonitor.stopMonitoring();
            try {
                this.stuckMonitor.acquired.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
            }
        }
    }

    protected class OpModeStuckCodeMonitor {
        CountDownLatch acquired = null;
        boolean debuggerDetected = false;
        ExecutorService executorService = ThreadPool.newSingleThreadExecutor("OpModeStuckCodeMonitor");
        String method;
        int msTimeout;
        Semaphore stopped = new Semaphore(0);

        protected OpModeStuckCodeMonitor() {
        }

        public void startMonitoring(int i, String str, boolean z) {
            CountDownLatch countDownLatch = this.acquired;
            if (countDownLatch != null) {
                try {
                    countDownLatch.await();
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                }
            }
            this.msTimeout = i;
            this.method = str;
            this.stopped.drainPermits();
            this.acquired = new CountDownLatch(1);
            this.executorService.execute(new Runner());
            if (z) {
                this.debuggerDetected = false;
            }
        }

        public void stopMonitoring() {
            this.stopped.release();
        }

        public void shutdown() {
            this.executorService.shutdownNow();
        }

        /* access modifiers changed from: protected */
        public boolean checkForDebugger() {
            boolean z = this.debuggerDetected || Debug.isDebuggerConnected();
            this.debuggerDetected = z;
            return z;
        }

        protected class Runner implements Runnable {
            static final String msgForceStoppedCommon = "User OpMode was stuck in %s, but was able to be force stopped without restarting the app. ";
            static final String msgForceStoppedPopupIterative = "User OpMode was stuck in %s, but was able to be force stopped without restarting the app. It appears this was an iterative OpMode; make sure you aren't using your own loops.";
            static final String msgForceStoppedPopupLinear = "User OpMode was stuck in %s, but was able to be force stopped without restarting the app. It appears this was a linear OpMode; make sure you are calling opModeIsActive() in any loops.";

            protected Runner() {
            }

            public void run() {
                String str;
                boolean z = false;
                try {
                    if (!OpModeStuckCodeMonitor.this.checkForDebugger()) {
                        if (!OpModeStuckCodeMonitor.this.stopped.tryAcquire((long) OpModeStuckCodeMonitor.this.msTimeout, TimeUnit.MILLISECONDS)) {
                            for (RobotCoreLynxUsbDevice throwOnNetworkLockAcquisition : OpModeManagerImpl.this.hardwareMap.getAll(RobotCoreLynxUsbDevice.class)) {
                                throwOnNetworkLockAcquisition.setThrowOnNetworkLockAcquisition(true);
                            }
                            if (OpModeStuckCodeMonitor.this.stopped.tryAcquire(100, TimeUnit.MILLISECONDS)) {
                                if (OpModeManagerImpl.this.activeOpMode instanceof LinearOpMode) {
                                    str = msgForceStoppedPopupLinear;
                                } else {
                                    str = msgForceStoppedPopupIterative;
                                }
                                AppUtil.getInstance().showAlertDialog(UILocation.BOTH, "OpMode Force-Stopped", String.format(str, new Object[]{OpModeStuckCodeMonitor.this.method}));
                                for (RobotCoreLynxUsbDevice throwOnNetworkLockAcquisition2 : OpModeManagerImpl.this.hardwareMap.getAll(RobotCoreLynxUsbDevice.class)) {
                                    throwOnNetworkLockAcquisition2.setThrowOnNetworkLockAcquisition(false);
                                }
                            } else {
                                for (RobotCoreLynxUsbDevice throwOnNetworkLockAcquisition3 : OpModeManagerImpl.this.hardwareMap.getAll(RobotCoreLynxUsbDevice.class)) {
                                    throwOnNetworkLockAcquisition3.setThrowOnNetworkLockAcquisition(false);
                                }
                                String format = String.format(OpModeManagerImpl.this.context.getString(R.string.errorOpModeStuck), new Object[]{OpModeManagerImpl.this.activeOpModeName, OpModeStuckCodeMonitor.this.method});
                                z = RobotLog.setGlobalErrorMsg(format);
                                RobotLog.e(format);
                                try {
                                    final CountDownLatch countDownLatch = new CountDownLatch(1);
                                    new Thread(new Runnable() {
                                        public void run() {
                                            for (RobotCoreLynxUsbDevice next : OpModeManagerImpl.this.hardwareMap.getAll(RobotCoreLynxUsbDevice.class)) {
                                                next.lockNetworkLockAcquisitions();
                                                next.failSafe();
                                            }
                                            countDownLatch.countDown();
                                        }
                                    }).start();
                                    if (countDownLatch.await(250, TimeUnit.MILLISECONDS)) {
                                        RobotLog.e("Successfully sent failsafe commands to Lynx modules before app restart");
                                    } else {
                                        RobotLog.e("Timed out while sending failsafe commands to Lynx modules before app restart");
                                    }
                                } catch (Exception unused) {
                                }
                                RobotLog.e("Begin thread dump");
                                for (Map.Entry next : Thread.getAllStackTraces().entrySet()) {
                                    RobotLog.logStackTrace((Thread) next.getKey(), (StackTraceElement[]) next.getValue());
                                }
                                AppUtil.getInstance().showToast(UILocation.BOTH, String.format(OpModeManagerImpl.this.context.getString(R.string.toastOpModeStuck), new Object[]{OpModeStuckCodeMonitor.this.method}));
                                Thread.sleep(1000);
                                AppUtil.getInstance().restartApp(-1);
                            }
                        }
                        OpModeStuckCodeMonitor.this.acquired.countDown();
                        return;
                    }
                    OpModeStuckCodeMonitor.this.acquired.countDown();
                } catch (InterruptedException unused2) {
                    if (z) {
                        RobotLog.clearGlobalErrorMsg();
                    }
                } catch (Throwable th) {
                    OpModeStuckCodeMonitor.this.acquired.countDown();
                    throw th;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void callActiveOpModeInit() {
        if (this.activeOpMode != null) {
            synchronized (this.listeners) {
                Iterator<OpModeManagerNotifier.Notifications> it = this.listeners.iterator();
                while (it.hasNext()) {
                    it.next().onOpModePreInit((OpMode) this.activeOpMode);
                }
            }
            for (HardwareDevice next : this.hardwareMap.unsafeIterable()) {
                if (next instanceof OpModeManagerNotifier.Notifications) {
                    ((OpModeManagerNotifier.Notifications) next).onOpModePreInit((OpMode) this.activeOpMode);
                }
            }
            this.activeOpMode.internalInit();
        }
    }

    /* access modifiers changed from: protected */
    public void callActiveOpModeStart() {
        if (this.activeOpMode != null) {
            synchronized (this.listeners) {
                Iterator<OpModeManagerNotifier.Notifications> it = this.listeners.iterator();
                while (it.hasNext()) {
                    it.next().onOpModePreStart((OpMode) this.activeOpMode);
                }
            }
            for (HardwareDevice next : this.hardwareMap.unsafeIterable()) {
                if (next instanceof OpModeManagerNotifier.Notifications) {
                    ((OpModeManagerNotifier.Notifications) next).onOpModePreStart((OpMode) this.activeOpMode);
                }
            }
            try {
                this.activeOpMode.internalThrowOpModeExceptionIfPresent();
            } catch (ForceStopException unused) {
                initOpMode("$Stop$Robot$");
            } catch (Exception e) {
                initOpMode("$Stop$Robot$");
                handleUserCodeException(e);
            }
            this.activeOpMode.internalStart();
        }
    }

    /* access modifiers changed from: protected */
    public void checkOnActiveOpMode() {
        OpModeInternal opModeInternal = this.activeOpMode;
        if (opModeInternal != null) {
            try {
                opModeInternal.internalThrowOpModeExceptionIfPresent();
            } catch (ForceStopException unused) {
                initOpMode("$Stop$Robot$");
            } catch (Exception e) {
                initOpMode("$Stop$Robot$");
                handleUserCodeException(e);
            }
            this.activeOpMode.internalOnEventLoopIteration();
        }
    }

    /* access modifiers changed from: protected */
    public void handleUserCodeException(Exception exc) {
        RobotLog.ee(TAG, (Throwable) exc, "User code threw an uncaught exception");
        handleSendStacktrace(exc);
    }

    /* access modifiers changed from: protected */
    public void handleSendStacktrace(Exception exc) {
        String[] split = Log.getStackTraceString(exc).split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(split.length, 15); i++) {
            sb.append(split[i]).append("\n");
        }
        NetworkConnectionHandler.getInstance().sendCommand(new Command(RobotCoreCommandList.CMD_SHOW_STACKTRACE, sb.toString()));
    }

    public static void updateTelemetryNow(OpMode opMode, TelemetryMessage telemetryMessage) {
        opMode.internalUpdateTelemetryNow(telemetryMessage);
    }

    public void refreshUserTelemetry(TelemetryMessage telemetryMessage, double d) {
        this.eventLoopManager.getEventLoop().refreshUserTelemetry(telemetryMessage, d);
    }

    public void requestOpModeStop(OpMode opMode) {
        this.eventLoopManager.getEventLoop().requestOpModeStop(opMode);
    }

    public static class DefaultOpMode extends OpMode {
        private static final long SAFE_WAIT_NANOS = 100000000;
        private ElapsedTime blinkerTimer;
        private boolean firstTimeRun;
        private long nanoNextSafe;

        public void stop() {
        }

        public DefaultOpMode() {
            this.firstTimeRun = true;
            this.blinkerTimer = new ElapsedTime();
            this.firstTimeRun = true;
        }

        public void init() {
            startSafe();
            this.telemetry.addData("Status", (Object) "Robot is stopping");
        }

        public void init_loop() {
            staySafe();
            this.telemetry.addData("Status", (Object) "Robot is stopped");
        }

        public void loop() {
            staySafe();
            this.telemetry.addData("Status", (Object) "Robot is stopped");
        }

        private boolean isLynxDevice(HardwareDevice hardwareDevice) {
            return hardwareDevice.getManufacturer() == HardwareDevice.Manufacturer.Lynx;
        }

        private boolean isLynxDevice(Object obj) {
            return isLynxDevice((HardwareDevice) obj);
        }

        private void startSafe() {
            for (DcMotorSimple next : this.hardwareMap.getAll(DcMotorSimple.class)) {
                if (next.getPower() != LynxServoController.apiPositionFirst) {
                    next.setPower(LynxServoController.apiPositionFirst);
                }
            }
            if (this.firstTimeRun) {
                this.firstTimeRun = false;
                this.nanoNextSafe = System.nanoTime();
                this.blinkerTimer.reset();
                return;
            }
            this.nanoNextSafe = System.nanoTime() + SAFE_WAIT_NANOS;
        }

        private void staySafe() {
            if (System.nanoTime() > this.nanoNextSafe) {
                for (RobotCoreLynxUsbDevice failSafe : this.hardwareMap.getAll(RobotCoreLynxUsbDevice.class)) {
                    failSafe.failSafe();
                }
                for (ServoController next : this.hardwareMap.getAll(ServoController.class)) {
                    if (!isLynxDevice((HardwareDevice) next)) {
                        next.pwmDisable();
                    }
                }
                for (DcMotor next2 : this.hardwareMap.getAll(DcMotor.class)) {
                    if (!isLynxDevice((HardwareDevice) next2)) {
                        next2.setPower(LynxServoController.apiPositionFirst);
                        next2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
                    }
                }
                for (LightSensor enableLed : this.hardwareMap.getAll(LightSensor.class)) {
                    enableLed.enableLed(false);
                }
                this.nanoNextSafe = System.nanoTime() + SAFE_WAIT_NANOS;
            }
        }
    }
}

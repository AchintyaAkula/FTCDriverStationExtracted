package com.qualcomm.robotcore.eventloop.opmode;

import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.eventloop.opmode.OpModeManagerImpl;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.robocol.TelemetryMessage;
import fi.iki.elonen.NanoHTTPD;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.firstinspires.ftc.robotcore.external.Telemetry;

public abstract class OpMode extends OpModeInternal {
    public static final HashMap<String, Object> blackboard = new HashMap<>();
    private volatile Gamepad latestGamepad1Data;
    private volatile Gamepad latestGamepad2Data;
    @Deprecated
    public int msStuckDetectInit;
    @Deprecated
    public int msStuckDetectInitLoop;
    @Deprecated
    public int msStuckDetectLoop;
    @Deprecated
    public int msStuckDetectStart;
    private volatile long startTime;
    public volatile double time;

    public abstract void init();

    public void init_loop() {
    }

    @Deprecated
    public void internalPostInitLoop() {
    }

    @Deprecated
    public void internalPostLoop() {
    }

    @Deprecated
    public void internalPreInit() {
    }

    public abstract void loop();

    public void start() {
    }

    public void stop() {
    }

    public OpMode() {
        this.time = LynxServoController.apiPositionFirst;
        this.startTime = 0;
        this.latestGamepad1Data = new Gamepad();
        this.latestGamepad2Data = new Gamepad();
        this.msStuckDetectInit = NanoHTTPD.SOCKET_READ_TIMEOUT;
        this.msStuckDetectInitLoop = NanoHTTPD.SOCKET_READ_TIMEOUT;
        this.msStuckDetectStart = NanoHTTPD.SOCKET_READ_TIMEOUT;
        this.msStuckDetectLoop = NanoHTTPD.SOCKET_READ_TIMEOUT;
        this.startTime = System.nanoTime();
    }

    public final void terminateOpModeNow() {
        throw new OpModeManagerImpl.ForceStopException();
    }

    public double getRuntime() {
        return ((double) (System.nanoTime() - this.startTime)) / ((double) TimeUnit.SECONDS.toNanos(1));
    }

    public void resetRuntime() {
        this.startTime = System.nanoTime();
    }

    public void updateTelemetry(Telemetry telemetry) {
        telemetry.update();
    }

    /* access modifiers changed from: package-private */
    public void internalRunOpMode() throws InterruptedException {
        internalPreInit();
        init();
        while (!this.isStarted && !this.stopRequested) {
            internalPreUserCode();
            init_loop();
            internalPostUserCode();
            internalPostInitLoop();
            Thread.sleep(1);
        }
        if (this.isStarted) {
            internalPreUserCode();
            start();
            internalPostUserCode();
            while (!this.stopRequested) {
                internalPreUserCode();
                loop();
                internalPostUserCode();
                internalPostLoop();
                Thread.sleep(1);
            }
        }
        internalPreUserCode();
        stop();
        internalPostUserCode();
    }

    /* access modifiers changed from: package-private */
    public void newGamepadDataAvailable(Gamepad gamepad, Gamepad gamepad2) {
        this.latestGamepad1Data = gamepad;
        this.latestGamepad2Data = gamepad2;
    }

    public final void internalUpdateTelemetryNow(TelemetryMessage telemetryMessage) {
        this.internalOpModeServices.refreshUserTelemetry(telemetryMessage, LynxServoController.apiPositionFirst);
    }

    private void internalPreUserCode() {
        this.time = getRuntime();
        this.gamepad1.copy(this.latestGamepad1Data);
        this.gamepad2.copy(this.latestGamepad2Data);
    }

    private void internalPostUserCode() {
        this.telemetry.update();
    }
}

package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.util.RobotLog;
import org.firstinspires.ftc.robotcore.external.function.ThrowingSupplier;
import org.firstinspires.ftc.robotcore.external.matrices.VectorF;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;

public class QuaternionBasedImuHelper {
    private ImuOrientationOnRobot imuOrientationOnRobot;
    private Quaternion lastRobotOrientationWithoutYawOffset = Quaternion.identityQuaternion();
    private Quaternion yawOffsetQuaternion = Quaternion.identityQuaternion();

    public static class FailedToRetrieveQuaternionException extends Exception {
    }

    public static Quaternion quaternionFromZAxisRotation(float f, AngleUnit angleUnit) {
        double radians = ((double) angleUnit.toRadians(f)) * 0.5d;
        return new Quaternion((float) Math.cos(radians), 0.0f, 0.0f, (float) Math.sin(radians), 0);
    }

    public QuaternionBasedImuHelper(ImuOrientationOnRobot imuOrientationOnRobot2) {
        setImuOrientationOnRobot(imuOrientationOnRobot2);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:6|7|(2:19|9)) */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0015, code lost:
        r9 = null;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:6:0x000c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void resetYaw(java.lang.String r8, org.firstinspires.ftc.robotcore.external.function.ThrowingSupplier<org.firstinspires.ftc.robotcore.external.navigation.Quaternion, com.qualcomm.robotcore.hardware.QuaternionBasedImuHelper.FailedToRetrieveQuaternionException> r9, int r10) {
        /*
            r7 = this;
            monitor-enter(r7)
            com.qualcomm.robotcore.util.ElapsedTime r0 = new com.qualcomm.robotcore.util.ElapsedTime     // Catch:{ all -> 0x0036 }
            r0.<init>()     // Catch:{ all -> 0x0036 }
        L_0x0006:
            r1 = 0
            org.firstinspires.ftc.robotcore.external.navigation.Quaternion r9 = r7.getRobotOrientationAsQuaternionOrThrow(r9, r1)     // Catch:{ FailedToRetrieveQuaternionException -> 0x000c }
            goto L_0x0016
        L_0x000c:
            double r1 = r0.milliseconds()     // Catch:{ all -> 0x0036 }
            double r3 = (double) r10     // Catch:{ all -> 0x0036 }
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 < 0) goto L_0x0006
            r9 = 0
        L_0x0016:
            if (r9 != 0) goto L_0x001f
            java.lang.String r9 = "Failed to retrieve valid quaternion for resetYaw(). Using stale orientation to compute yaw offset."
            com.qualcomm.robotcore.util.RobotLog.ww(r8, r9)     // Catch:{ all -> 0x0036 }
            org.firstinspires.ftc.robotcore.external.navigation.Quaternion r9 = r7.lastRobotOrientationWithoutYawOffset     // Catch:{ all -> 0x0036 }
        L_0x001f:
            org.firstinspires.ftc.robotcore.external.navigation.Quaternion r8 = new org.firstinspires.ftc.robotcore.external.navigation.Quaternion     // Catch:{ all -> 0x0036 }
            float r1 = r9.w     // Catch:{ all -> 0x0036 }
            float r9 = r9.z     // Catch:{ all -> 0x0036 }
            float r4 = -r9
            r5 = 0
            r2 = 0
            r3 = 0
            r0 = r8
            r0.<init>(r1, r2, r3, r4, r5)     // Catch:{ all -> 0x0036 }
            org.firstinspires.ftc.robotcore.external.navigation.Quaternion r8 = r8.normalized()     // Catch:{ all -> 0x0036 }
            r7.yawOffsetQuaternion = r8     // Catch:{ all -> 0x0036 }
            monitor-exit(r7)
            return
        L_0x0036:
            r8 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x0036 }
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.QuaternionBasedImuHelper.resetYaw(java.lang.String, org.firstinspires.ftc.robotcore.external.function.ThrowingSupplier, int):void");
    }

    public synchronized Quaternion getRobotOrientationAsQuaternionOrThrow(ThrowingSupplier<Quaternion, FailedToRetrieveQuaternionException> throwingSupplier, boolean z) throws FailedToRetrieveQuaternionException {
        Quaternion normalized;
        Quaternion quaternion = throwingSupplier.get();
        Quaternion imuCoordinateSystemOrientationFromPerspectiveOfRobot = this.imuOrientationOnRobot.imuCoordinateSystemOrientationFromPerspectiveOfRobot();
        long j = quaternion.acquisitionTime;
        normalized = imuCoordinateSystemOrientationFromPerspectiveOfRobot.multiply(quaternion.multiply(imuCoordinateSystemOrientationFromPerspectiveOfRobot.inverse(), j).normalized(), j).normalized().multiply(this.imuOrientationOnRobot.imuRotationOffset(), j).normalized();
        this.lastRobotOrientationWithoutYawOffset = new Quaternion(normalized.w, normalized.x, normalized.y, normalized.z, normalized.acquisitionTime);
        if (z) {
            normalized = this.yawOffsetQuaternion.multiply(normalized, j);
        }
        return normalized;
    }

    public synchronized Quaternion getRobotOrientationAsQuaternion(String str, ThrowingSupplier<Quaternion, FailedToRetrieveQuaternionException> throwingSupplier, boolean z) {
        try {
        } catch (FailedToRetrieveQuaternionException unused) {
            RobotLog.ww(str, "getRobotOrientationAsQuaternion(): Failed to retrieve valid quaternion from IMU. Returning the identity quaternion.");
            return Quaternion.identityQuaternion();
        }
        return getRobotOrientationAsQuaternionOrThrow(throwingSupplier, z);
    }

    public synchronized YawPitchRollAngles getRobotYawPitchRollAngles(String str, ThrowingSupplier<Quaternion, FailedToRetrieveQuaternionException> throwingSupplier) {
        Orientation robotOrientation;
        robotOrientation = getRobotOrientation(str, throwingSupplier, AxesReference.INTRINSIC, AxesOrder.ZXY, AngleUnit.DEGREES);
        return new YawPitchRollAngles(AngleUnit.DEGREES, (double) robotOrientation.firstAngle, (double) robotOrientation.secondAngle, (double) robotOrientation.thirdAngle, robotOrientation.acquisitionTime);
    }

    public synchronized Orientation getRobotOrientation(String str, ThrowingSupplier<Quaternion, FailedToRetrieveQuaternionException> throwingSupplier, AxesReference axesReference, AxesOrder axesOrder, AngleUnit angleUnit) {
        return getRobotOrientationAsQuaternion(str, throwingSupplier, true).toOrientation(axesReference, axesOrder, angleUnit);
    }

    public synchronized AngularVelocity getRobotAngularVelocity(AngularVelocity angularVelocity, AngleUnit angleUnit) {
        AngularVelocity angleUnit2;
        VectorF applyToVector;
        angleUnit2 = angularVelocity.toAngleUnit(angleUnit);
        applyToVector = this.imuOrientationOnRobot.angularVelocityTransform().applyToVector(new VectorF(angleUnit2.xRotationRate, angleUnit2.yRotationRate, angleUnit2.zRotationRate));
        return new AngularVelocity(angleUnit, applyToVector.get(0), applyToVector.get(1), applyToVector.get(2), angleUnit2.acquisitionTime);
    }

    public synchronized void setImuOrientationOnRobot(ImuOrientationOnRobot imuOrientationOnRobot2) {
        this.imuOrientationOnRobot = imuOrientationOnRobot2;
    }
}

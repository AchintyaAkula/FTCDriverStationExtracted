package com.qualcomm.robotcore.hardware;

public interface HardwareDeviceCloseOnTearDown {
    void close();
}

package com.qualcomm.robotcore.hardware;

public interface I2cAddrConfig extends I2cAddressableDevice {
    void setI2cAddress(I2cAddr i2cAddr);
}

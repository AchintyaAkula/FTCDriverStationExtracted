package com.qualcomm.robotcore.hardware;

public enum MotorControlAlgorithm {
    Unknown,
    LegacyPID,
    PIDF
}

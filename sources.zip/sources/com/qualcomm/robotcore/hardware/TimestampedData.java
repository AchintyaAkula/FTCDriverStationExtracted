package com.qualcomm.robotcore.hardware;

public class TimestampedData {
    public byte[] data;
    public long nanoTime;
}

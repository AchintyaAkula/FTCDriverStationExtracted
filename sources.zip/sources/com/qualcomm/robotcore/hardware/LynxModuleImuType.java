package com.qualcomm.robotcore.hardware;

import androidx.core.os.EnvironmentCompat;

public enum LynxModuleImuType {
    UNKNOWN(EnvironmentCompat.MEDIA_UNKNOWN),
    NONE("none"),
    BNO055("BNO055"),
    BHI260("BHI260AP");
    
    private final String name;

    private LynxModuleImuType(String str) {
        this.name = str;
    }

    public String toString() {
        return this.name;
    }
}

package com.qualcomm.robotcore.hardware;

public interface IntegratingGyroscope extends Gyroscope, OrientationSensor {
}

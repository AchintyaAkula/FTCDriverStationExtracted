package com.qualcomm.robotcore.hardware;

public enum I2cWaitControl {
    NONE,
    ATOMIC,
    WRITTEN
}

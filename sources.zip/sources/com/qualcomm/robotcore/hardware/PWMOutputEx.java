package com.qualcomm.robotcore.hardware;

public interface PWMOutputEx {
    boolean isPwmEnabled();

    void setPwmDisable();

    void setPwmEnable();
}

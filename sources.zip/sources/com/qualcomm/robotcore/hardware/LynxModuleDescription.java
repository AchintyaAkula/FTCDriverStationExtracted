package com.qualcomm.robotcore.hardware;

public class LynxModuleDescription {
    public final int address;
    public final boolean isParent;
    public final boolean isSystemSynthetic;
    public final boolean isUserModule;

    private LynxModuleDescription(int i, boolean z, boolean z2, boolean z3) {
        this.address = i;
        this.isParent = z;
        this.isUserModule = z2;
        this.isSystemSynthetic = z3;
    }

    public static class Builder {
        private final int address;
        private final boolean isParent;
        private boolean isSystemSynthetic = false;
        private boolean isUserModule = false;

        public Builder(int i, boolean z) {
            this.address = i;
            this.isParent = z;
        }

        public Builder setUserModule() {
            this.isUserModule = true;
            return this;
        }

        public Builder setSystemSynthetic() {
            this.isSystemSynthetic = true;
            return this;
        }

        public LynxModuleDescription build() {
            return new LynxModuleDescription(this.address, this.isParent, this.isUserModule, this.isSystemSynthetic);
        }
    }
}

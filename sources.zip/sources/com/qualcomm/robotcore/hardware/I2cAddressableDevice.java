package com.qualcomm.robotcore.hardware;

public interface I2cAddressableDevice {
    I2cAddr getI2cAddress();
}

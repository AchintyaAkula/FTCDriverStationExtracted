package com.qualcomm.robotcore.hardware.configuration;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.typeadapters.RuntimeTypeAdapterFactory;
import com.qualcomm.robotcore.hardware.ControlSystem;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.annotations.AnalogSensorType;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.DevicesProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.DigitalIoDeviceType;
import com.qualcomm.robotcore.hardware.configuration.annotations.ExpansionHubPIDFPositionParams;
import com.qualcomm.robotcore.hardware.configuration.annotations.ExpansionHubPIDFVelocityParams;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.hardware.configuration.annotations.MotorType;
import com.qualcomm.robotcore.hardware.configuration.annotations.ServoType;
import com.qualcomm.robotcore.hardware.configuration.annotations.ServoTypes;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.AnalogSensorConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.DigitalIoDeviceConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.I2cDeviceConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.InstantiableUserConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.ServoConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.UserConfigurationType;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.util.ClassUtil;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.Util;
import java.lang.annotation.Annotation;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import org.firstinspires.ftc.robotcore.external.Predicate;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.opmode.ClassFilter;
import org.firstinspires.ftc.robotcore.internal.opmode.OnBotJavaDeterminer;

public final class ConfigurationTypeManager implements ClassFilter {
    public static boolean DEBUG = true;
    public static String LEGACY_HD_HEX_MOTOR_TAG = "RevRoboticsHDHexMotor";
    public static String NEW_HD_HEX_MOTOR_40_TAG = "RevRobotics40HDHexMotor";
    public static final String TAG = "UserDeviceTypeManager";
    private static final String standardServoTypeXmlTag = getXmlTag(Servo.class);
    private static final ConfigurationTypeManager theInstance = new ConfigurationTypeManager();
    private static final Class[] typeAnnotationsArray;
    private static final List<Class> typeAnnotationsList;
    private static final String unspecifiedMotorTypeXmlTag = getXmlTag(UnspecifiedMotor.class);
    private final Comparator<? super ConfigurationType> configTypeComparator = new Comparator<ConfigurationType>() {
        public int compare(ConfigurationType configurationType, ConfigurationType configurationType2) {
            if (configurationType != BuiltInConfigurationType.NOTHING && configurationType2 != BuiltInConfigurationType.NOTHING) {
                return configurationType.getName().compareTo(configurationType2.getName());
            }
            if (configurationType == configurationType2) {
                return 0;
            }
            return configurationType == BuiltInConfigurationType.NOTHING ? -1 : 1;
        }
    };
    private final Map<ConfigurationType.DeviceFlavor, Map<String, String>> displayNamesMap = new HashMap();
    private final Gson gson = newGson();
    private final Map<String, ConfigurationType> mapTagToConfigurationType = new HashMap();

    public enum ClassSource {
        APK,
        ONBOTJAVA,
        EXTERNAL_LIB
    }

    public void filterAllClassesComplete() {
    }

    public void filterExternalLibrariesClassesComplete() {
    }

    public void filterOnBotJavaClassesComplete() {
    }

    public static ConfigurationTypeManager getInstance() {
        return theInstance;
    }

    static {
        Class[] clsArr = {ServoTypes.class, ServoType.class, AnalogSensorType.class, DigitalIoDeviceType.class, I2cDeviceType.class, MotorType.class};
        typeAnnotationsArray = clsArr;
        typeAnnotationsList = Arrays.asList(clsArr);
    }

    public ConfigurationTypeManager() {
        for (ConfigurationType.DeviceFlavor put : ConfigurationType.DeviceFlavor.values()) {
            this.displayNamesMap.put(put, new HashMap());
        }
        addBuiltinConfigurationTypes();
    }

    public MotorConfigurationType getUnspecifiedMotorType() {
        return (MotorConfigurationType) configurationTypeFromTag(unspecifiedMotorTypeXmlTag);
    }

    public ServoConfigurationType getStandardServoType() {
        return (ServoConfigurationType) configurationTypeFromTag(standardServoTypeXmlTag);
    }

    public ConfigurationType configurationTypeFromTag(String str) {
        ConfigurationType configurationType = this.mapTagToConfigurationType.get(str);
        return configurationType == null ? BuiltInConfigurationType.UNKNOWN : configurationType;
    }

    public UserConfigurationType userTypeFromClass(ConfigurationType.DeviceFlavor deviceFlavor, Class<?> cls) {
        MotorType motorType;
        DeviceProperties deviceProperties = (DeviceProperties) cls.getAnnotation(DeviceProperties.class);
        String xmlTag = deviceProperties != null ? getXmlTag(deviceProperties) : null;
        if (xmlTag == null) {
            int i = AnonymousClass5.$SwitchMap$com$qualcomm$robotcore$hardware$configuration$ConfigurationType$DeviceFlavor[deviceFlavor.ordinal()];
            if (i == 1) {
                I2cSensor i2cSensor = (I2cSensor) cls.getAnnotation(I2cSensor.class);
                if (i2cSensor != null) {
                    xmlTag = getXmlTag(i2cSensor);
                }
            } else if (i == 2 && (motorType = (MotorType) cls.getAnnotation(MotorType.class)) != null) {
                xmlTag = getXmlTag(motorType);
            }
        }
        if (xmlTag == null) {
            return null;
        }
        return (UserConfigurationType) configurationTypeFromTag(xmlTag);
    }

    /* renamed from: com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager$5  reason: invalid class name */
    static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$configuration$ConfigurationType$DeviceFlavor;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                com.qualcomm.robotcore.hardware.configuration.ConfigurationType$DeviceFlavor[] r0 = com.qualcomm.robotcore.hardware.configuration.ConfigurationType.DeviceFlavor.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$com$qualcomm$robotcore$hardware$configuration$ConfigurationType$DeviceFlavor = r0
                com.qualcomm.robotcore.hardware.configuration.ConfigurationType$DeviceFlavor r1 = com.qualcomm.robotcore.hardware.configuration.ConfigurationType.DeviceFlavor.I2C     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$ConfigurationType$DeviceFlavor     // Catch:{ NoSuchFieldError -> 0x001d }
                com.qualcomm.robotcore.hardware.configuration.ConfigurationType$DeviceFlavor r1 = com.qualcomm.robotcore.hardware.configuration.ConfigurationType.DeviceFlavor.MOTOR     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager.AnonymousClass5.<clinit>():void");
        }
    }

    public SortedSet<ConfigurationType> getApplicableConfigTypes(ConfigurationType.DeviceFlavor deviceFlavor, ControlSystem controlSystem, boolean z, int i) {
        TreeSet treeSet = new TreeSet(this.configTypeComparator);
        for (ConfigurationType next : this.mapTagToConfigurationType.values()) {
            if (next.getDeviceFlavor() == deviceFlavor && ((controlSystem == null || next.isCompatibleWith(controlSystem)) && (next != I2cDeviceConfigurationType.getLynxEmbeddedBNO055ImuType() || controlSystem == null || (controlSystem == ControlSystem.REV_HUB && i == 0)))) {
                if (next != I2cDeviceConfigurationType.getLynxEmbeddedBHI260APImuType() || (z && i == 0)) {
                    treeSet.add(next);
                }
            }
        }
        treeSet.add(BuiltInConfigurationType.NOTHING);
        return treeSet;
    }

    public SortedSet<ConfigurationType> getApplicableConfigTypes(ConfigurationType.DeviceFlavor deviceFlavor, ControlSystem controlSystem, boolean z) {
        return getApplicableConfigTypes(deviceFlavor, controlSystem, z, 0);
    }

    public Gson getGson() {
        return this.gson;
    }

    public void sendUserDeviceTypes() {
        NetworkConnectionHandler.getInstance().sendCommand(new Command(RobotCoreCommandList.CMD_NOTIFY_USER_DEVICE_LIST, serializeUserDeviceTypes()));
    }

    public void deserializeUserDeviceTypes(String str) {
        clearAllUserTypes();
        ArrayList<ConfigurationType> arrayList = new ArrayList<>(Arrays.asList((ConfigurationType[]) this.gson.fromJson(str, ConfigurationType[].class)));
        Iterator it = arrayList.iterator();
        boolean z = false;
        while (it.hasNext()) {
            if (NEW_HD_HEX_MOTOR_40_TAG.equals(((ConfigurationType) it.next()).getXmlTag())) {
                if (z) {
                    it.remove();
                }
                z = true;
            }
        }
        for (ConfigurationType configurationType : arrayList) {
            if (!configurationType.isDeviceFlavor(ConfigurationType.DeviceFlavor.BUILT_IN)) {
                add((UserConfigurationType) configurationType);
            }
        }
        if (DEBUG) {
            for (Map.Entry next : this.mapTagToConfigurationType.entrySet()) {
                if (!(next.getValue() instanceof BuiltInConfigurationType)) {
                    RobotLog.vv(TAG, "deserialized: xmltag=%s name=%s class=%s", ((ConfigurationType) next.getValue()).getXmlTag(), ((ConfigurationType) next.getValue()).getName(), ((ConfigurationType) next.getValue()).getClass().getSimpleName());
                }
            }
        }
    }

    private Gson newGson() {
        return new GsonBuilder().excludeFieldsWithoutExposeAnnotation().registerTypeAdapter(BuiltInConfigurationType.class, new BuiltInConfigurationTypeJsonAdapter()).registerTypeAdapterFactory(RuntimeTypeAdapterFactory.of(ConfigurationType.class, "flavor").registerSubtype(BuiltInConfigurationType.class, ConfigurationType.DeviceFlavor.BUILT_IN.toString()).registerSubtype(I2cDeviceConfigurationType.class, ConfigurationType.DeviceFlavor.I2C.toString()).registerSubtype(MotorConfigurationType.class, ConfigurationType.DeviceFlavor.MOTOR.toString()).registerSubtype(ServoConfigurationType.class, ConfigurationType.DeviceFlavor.SERVO.toString()).registerSubtype(AnalogSensorConfigurationType.class, ConfigurationType.DeviceFlavor.ANALOG_SENSOR.toString()).registerSubtype(DigitalIoDeviceConfigurationType.class, ConfigurationType.DeviceFlavor.DIGITAL_IO.toString())).create();
    }

    private String serializeUserDeviceTypes() {
        return this.gson.toJson((Object) new HashSet(this.mapTagToConfigurationType.values()));
    }

    private void addBuiltinConfigurationTypes() {
        for (BuiltInConfigurationType builtInConfigurationType : BuiltInConfigurationType.values()) {
            this.mapTagToConfigurationType.put(builtInConfigurationType.getXmlTag(), builtInConfigurationType);
            this.displayNamesMap.get(builtInConfigurationType.getDeviceFlavor()).put(builtInConfigurationType.getName(), builtInConfigurationType.getXmlTag());
        }
    }

    private void add(UserConfigurationType userConfigurationType) {
        ConfigurationType configurationType = this.mapTagToConfigurationType.get(userConfigurationType.getXmlTag());
        if (configurationType == null) {
            this.mapTagToConfigurationType.put(userConfigurationType.getXmlTag(), userConfigurationType);
            this.displayNamesMap.get(userConfigurationType.getDeviceFlavor()).put(userConfigurationType.getName(), userConfigurationType.getXmlTag());
        } else {
            String name = configurationType.getName();
            boolean equals = name.equals(userConfigurationType.getName());
            ((InstantiableUserConfigurationType) configurationType).addAdditionalTypeToInstantiate((InstantiableUserConfigurationType) userConfigurationType);
            if (!equals) {
                RobotLog.addGlobalWarningMessage("XML tag %s has multiple display names associated with it: \"%s\" and \"%s\". Ignoring \"%s\".", userConfigurationType.getXmlTag(), name, userConfigurationType.getName(), name.equals(configurationType.getName()) ? userConfigurationType.getName() : name);
            }
            this.displayNamesMap.get(userConfigurationType.getDeviceFlavor()).put(userConfigurationType.getName(), userConfigurationType.getXmlTag());
        }
        if (userConfigurationType.getXmlTag().equals(NEW_HD_HEX_MOTOR_40_TAG)) {
            this.mapTagToConfigurationType.put(LEGACY_HD_HEX_MOTOR_TAG, userConfigurationType);
        }
    }

    private void clearAllUserTypes() {
        this.mapTagToConfigurationType.clear();
        for (Map<String, String> clear : this.displayNamesMap.values()) {
            clear.clear();
        }
        addBuiltinConfigurationTypes();
    }

    private void clearUserTypesFromSource(ClassSource classSource) {
        for (ConfigurationType configurationType : new ArrayList(this.mapTagToConfigurationType.values())) {
            if (configurationType instanceof InstantiableUserConfigurationType) {
                InstantiableUserConfigurationType.ClearTypesFromSourceResult clearTypesFromSource = ((InstantiableUserConfigurationType) configurationType).clearTypesFromSource(classSource);
                for (String remove : clearTypesFromSource.freedDisplayNames) {
                    this.displayNamesMap.get(configurationType.getDeviceFlavor()).remove(remove);
                }
                if (clearTypesFromSource.newTopLevelType == null) {
                    this.mapTagToConfigurationType.remove(configurationType.getXmlTag());
                } else {
                    this.mapTagToConfigurationType.put(configurationType.getXmlTag(), clearTypesFromSource.newTopLevelType);
                }
            } else if (configurationType.getClassSource() == classSource && !(configurationType instanceof BuiltInConfigurationType)) {
                this.mapTagToConfigurationType.remove(configurationType.getXmlTag());
                this.displayNamesMap.get(configurationType.getDeviceFlavor()).remove(configurationType.getName());
            }
        }
    }

    public void filterAllClassesStart() {
        clearAllUserTypes();
    }

    public void filterOnBotJavaClassesStart() {
        clearUserTypesFromSource(ClassSource.ONBOTJAVA);
    }

    public void filterExternalLibrariesClassesStart() {
        clearUserTypesFromSource(ClassSource.EXTERNAL_LIB);
    }

    public void filterClass(Class cls) {
        ClassSource classSource = ClassSource.APK;
        if (OnBotJavaDeterminer.isOnBotJava(cls)) {
            classSource = ClassSource.ONBOTJAVA;
        } else if (OnBotJavaDeterminer.isExternalLibraries(cls)) {
            classSource = ClassSource.EXTERNAL_LIB;
        }
        filterClass(cls, classSource);
    }

    public void filterOnBotJavaClass(Class cls) {
        filterClass(cls, ClassSource.ONBOTJAVA);
    }

    public void filterExternalLibrariesClass(Class cls) {
        filterClass(cls, ClassSource.EXTERNAL_LIB);
    }

    private void addConfigurationType(Annotation annotation, DeviceProperties deviceProperties, Class<?> cls, ClassSource classSource) {
        UserConfigurationType createAppropriateConfigurationType = createAppropriateConfigurationType(annotation, deviceProperties, cls, classSource);
        createAppropriateConfigurationType.processAnnotation(deviceProperties);
        createAppropriateConfigurationType.finishedAnnotations(cls);
        if (cls.isInterface() || !createAppropriateConfigurationType.annotatedClassIsInstantiable()) {
            if (checkAnnotationParameterConstraints(createAppropriateConfigurationType)) {
                add(createAppropriateConfigurationType);
            }
        } else if (checkInstantiableTypeConstraints((InstantiableUserConfigurationType) createAppropriateConfigurationType)) {
            add(createAppropriateConfigurationType);
        }
    }

    private ServoType findPairedServoAnnotation(ServoType[] servoTypeArr, String str) {
        for (ServoType servoType : servoTypeArr) {
            if (servoType.xmlTag().equals(str)) {
                return servoType;
            }
        }
        return null;
    }

    private void handleRepeatedAnnotation(Class<?> cls, ClassSource classSource, Annotation annotation, DevicesProperties devicesProperties) {
        for (DeviceProperties deviceProperties : devicesProperties.value()) {
            if (annotation instanceof ServoTypes) {
                ServoType findPairedServoAnnotation = findPairedServoAnnotation(((ServoTypes) annotation).value(), getXmlTag(deviceProperties));
                if (findPairedServoAnnotation == null) {
                    RobotLog.ee(RobotLog.TAG, "Could not find paired @ServoType annotation for repeated annotation type with tag: %s", getXmlTag(deviceProperties));
                    return;
                }
                addConfigurationType(findPairedServoAnnotation, deviceProperties, cls, classSource);
            } else {
                RobotLog.ee(RobotLog.TAG, "Unsupported repeated annotation type: %s", annotation);
            }
        }
    }

    private void filterClass(Class<?> cls, ClassSource classSource) {
        Annotation typeAnnotation;
        if (!addMotorTypeFromDeprecatedAnnotation(cls, classSource) && !addI2cTypeFromDeprecatedAnnotation(cls, classSource) && (typeAnnotation = getTypeAnnotation(cls)) != null) {
            DevicesProperties devicesProperties = (DevicesProperties) cls.getAnnotation(DevicesProperties.class);
            if (devicesProperties != null) {
                handleRepeatedAnnotation(cls, classSource, typeAnnotation, devicesProperties);
                return;
            }
            DeviceProperties deviceProperties = (DeviceProperties) cls.getAnnotation(DeviceProperties.class);
            if (deviceProperties == null) {
                reportConfigurationError("Class " + cls.getSimpleName() + " annotated with " + typeAnnotation + " is missing @DeviceProperties annotation.", new Object[0]);
            } else {
                addConfigurationType(typeAnnotation, deviceProperties, cls, classSource);
            }
        }
    }

    private UserConfigurationType createAppropriateConfigurationType(Annotation annotation, DeviceProperties deviceProperties, Class cls, ClassSource classSource) {
        if (annotation instanceof ServoType) {
            ServoConfigurationType servoConfigurationType = new ServoConfigurationType(cls, getXmlTag(deviceProperties), classSource);
            ServoConfigurationType servoConfigurationType2 = servoConfigurationType;
            servoConfigurationType.processAnnotation((ServoType) annotation);
            return servoConfigurationType;
        } else if (annotation instanceof MotorType) {
            MotorConfigurationType motorConfigurationType = new MotorConfigurationType(cls, getXmlTag(deviceProperties), classSource);
            MotorConfigurationType motorConfigurationType2 = motorConfigurationType;
            processMotorSupportAnnotations(cls, motorConfigurationType);
            motorConfigurationType.processAnnotation((MotorType) annotation);
            return motorConfigurationType;
        } else if (annotation instanceof AnalogSensorType) {
            return new AnalogSensorConfigurationType(cls, getXmlTag(deviceProperties), classSource);
        } else {
            if (annotation instanceof DigitalIoDeviceType) {
                return new DigitalIoDeviceConfigurationType(cls, getXmlTag(deviceProperties), classSource);
            }
            if (annotation instanceof I2cDeviceType) {
                return new I2cDeviceConfigurationType(cls, getXmlTag(deviceProperties), classSource);
            }
            return null;
        }
    }

    private boolean addMotorTypeFromDeprecatedAnnotation(Class<?> cls, ClassSource classSource) {
        if (!cls.isAnnotationPresent(MotorType.class)) {
            return false;
        }
        MotorType motorType = (MotorType) cls.getAnnotation(MotorType.class);
        MotorConfigurationType motorConfigurationType = new MotorConfigurationType(cls, getXmlTag(motorType), classSource);
        motorConfigurationType.processAnnotation(motorType);
        processMotorSupportAnnotations(cls, motorConfigurationType);
        motorConfigurationType.finishedAnnotations(cls);
        if (!checkAnnotationParameterConstraints(motorConfigurationType)) {
            return false;
        }
        add(motorConfigurationType);
        return true;
    }

    private boolean addI2cTypeFromDeprecatedAnnotation(Class<?> cls, ClassSource classSource) {
        if (!isHardwareDevice(cls) || !cls.isAnnotationPresent(I2cSensor.class)) {
            return false;
        }
        I2cSensor i2cSensor = (I2cSensor) cls.getAnnotation(I2cSensor.class);
        I2cDeviceConfigurationType i2cDeviceConfigurationType = new I2cDeviceConfigurationType(cls, getXmlTag(i2cSensor), classSource);
        i2cDeviceConfigurationType.processAnnotation(i2cSensor);
        i2cDeviceConfigurationType.finishedAnnotations(cls);
        if (!checkInstantiableTypeConstraints(i2cDeviceConfigurationType)) {
            return false;
        }
        add(i2cDeviceConfigurationType);
        return true;
    }

    private void processMotorSupportAnnotations(Class<?> cls, MotorConfigurationType motorConfigurationType) {
        motorConfigurationType.processAnnotation((DistributorInfo) findAnnotation(cls, DistributorInfo.class));
        processNewOldAnnotations(motorConfigurationType, cls, ExpansionHubPIDFVelocityParams.class, ExpansionHubMotorControllerVelocityParams.class);
        processNewOldAnnotations(motorConfigurationType, cls, ExpansionHubPIDFPositionParams.class, ExpansionHubMotorControllerPositionParams.class);
    }

    /* access modifiers changed from: protected */
    public <NewType extends Annotation, OldType extends Annotation> void processNewOldAnnotations(final MotorConfigurationType motorConfigurationType, final Class<?> cls, final Class<NewType> cls2, final Class<OldType> cls3) {
        if (!ClassUtil.searchInheritance(cls, new Predicate<Class<?>>() {
            public boolean test(Class<?> cls) {
                return ConfigurationTypeManager.this.processAnnotationIfPresent(motorConfigurationType, cls, cls2);
            }
        })) {
            ClassUtil.searchInheritance(cls, new Predicate<Class<?>>() {
                public boolean test(Class<?> cls) {
                    return ConfigurationTypeManager.this.processAnnotationIfPresent(motorConfigurationType, cls, cls3);
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    public <A extends Annotation> boolean processAnnotationIfPresent(MotorConfigurationType motorConfigurationType, Class<?> cls, Class<A> cls2) {
        Annotation annotation = cls.getAnnotation(cls2);
        if (annotation == null) {
            return false;
        }
        motorConfigurationType.processAnnotation((Object) annotation);
        return true;
    }

    private Annotation getTypeAnnotation(Class cls) {
        for (Annotation annotation : cls.getAnnotations()) {
            if (typeAnnotationsList.contains(annotation.annotationType())) {
                return annotation;
            }
        }
        return null;
    }

    private <A extends Annotation> A findAnnotation(Class<?> cls, final Class<A> cls2) {
        final ArrayList arrayList = new ArrayList(1);
        arrayList.add((Object) null);
        ClassUtil.searchInheritance(cls, new Predicate<Class<?>>() {
            public boolean test(Class<?> cls) {
                Annotation annotation = cls.getAnnotation(cls2);
                if (annotation == null) {
                    return false;
                }
                arrayList.set(0, annotation);
                return true;
            }
        });
        return (Annotation) arrayList.get(0);
    }

    private boolean checkAnnotationParameterConstraints(UserConfigurationType userConfigurationType) {
        String xmlTag = userConfigurationType.getXmlTag();
        ConfigurationType.DeviceFlavor deviceFlavor = userConfigurationType.getDeviceFlavor();
        if (!isLegalDeviceTypeName(userConfigurationType.getName())) {
            reportConfigurationError("\"%s\" is not a legal device type name", userConfigurationType.getName());
            return false;
        } else if (!isLegalXmlTag(xmlTag)) {
            reportConfigurationError("\"%s\" is not a legal XML tag for the device type \"%s\"", xmlTag, userConfigurationType.getName());
            return false;
        } else if (userConfigurationType.annotatedClassIsInstantiable()) {
            ConfigurationType configurationType = this.mapTagToConfigurationType.get(xmlTag);
            if (configurationType != null) {
                if (!configurationType.annotatedClassIsInstantiable()) {
                    reportConfigurationError("the XML tag \"%s\" is already defined by a non-instantiable type", xmlTag);
                    return false;
                } else if (!configurationType.isDeviceFlavor(deviceFlavor)) {
                    reportConfigurationError("the XML tag \"%s\" cannot be registered as a %s device, because it is already registered as a %s device.", xmlTag, deviceFlavor, configurationType.getDeviceFlavor());
                    return false;
                }
            }
            String str = (String) this.displayNamesMap.get(deviceFlavor).get(userConfigurationType.getName());
            if (str == null || xmlTag.equals(str)) {
                return true;
            }
            reportConfigurationError("the display name \"%s\" is already registered with the XML tag \"%s\", and cannot be registered with the XML tag \"%s\"", new Object[0]);
            return true;
        } else if (this.displayNamesMap.get(deviceFlavor).containsKey(userConfigurationType.getName())) {
            reportConfigurationError("the device type \"%s\" is already defined", userConfigurationType.getName());
            return false;
        } else if (!this.mapTagToConfigurationType.containsKey(xmlTag)) {
            return true;
        } else {
            reportConfigurationError("the XML tag \"%s\" is already defined", xmlTag);
            return false;
        }
    }

    private boolean checkInstantiableTypeConstraints(InstantiableUserConfigurationType instantiableUserConfigurationType) {
        if (!checkAnnotationParameterConstraints(instantiableUserConfigurationType)) {
            return false;
        }
        if (!isHardwareDevice(instantiableUserConfigurationType.getClazz())) {
            reportConfigurationError("'%s' class doesn't inherit from the class 'HardwareDevice'", instantiableUserConfigurationType.getClazz().getSimpleName());
            return false;
        } else if (!Modifier.isPublic(instantiableUserConfigurationType.getClazz().getModifiers())) {
            reportConfigurationError("'%s' class is not declared 'public'", instantiableUserConfigurationType.getClazz().getSimpleName());
            return false;
        } else if (instantiableUserConfigurationType.hasConstructors()) {
            return true;
        } else {
            reportConfigurationError("'%s' class lacks necessary constructor", instantiableUserConfigurationType.getClazz().getSimpleName());
            return false;
        }
    }

    private boolean isLegalDeviceTypeName(String str) {
        return Util.isGoodString(str);
    }

    public static String getXmlTag(Class cls) {
        DeviceProperties deviceProperties = (DeviceProperties) cls.getAnnotation(DeviceProperties.class);
        if (deviceProperties != null) {
            return getXmlTag(deviceProperties);
        }
        DeviceProperties[] value = ((DevicesProperties) cls.getAnnotation(DevicesProperties.class)).value();
        for (DeviceProperties deviceProperties2 : value) {
            if (deviceProperties2.defaultDevice()) {
                return getXmlTag(deviceProperties2);
            }
        }
        return getXmlTag(value[0]);
    }

    private void reportConfigurationError(String str, Object... objArr) {
        String format = String.format(str, objArr);
        RobotLog.ee(TAG, String.format("configuration error: %s", new Object[]{format}));
        RobotLog.setGlobalErrorMsg(format);
    }

    private boolean isHardwareDevice(Class cls) {
        return ClassUtil.inheritsFrom(cls, HardwareDevice.class);
    }

    private boolean isLegalXmlTag(String str) {
        if (!Util.isGoodString(str)) {
            return false;
        }
        return str.matches("^[\\p{Alpha}_:][\\p{Alpha}_:0-9\\-\\.]*$");
    }

    private static String getXmlTag(I2cSensor i2cSensor) {
        return ClassUtil.decodeStringRes(i2cSensor.xmlTag().trim());
    }

    private static String getXmlTag(MotorType motorType) {
        return ClassUtil.decodeStringRes(motorType.xmlTag().trim());
    }

    private static String getXmlTag(DeviceProperties deviceProperties) {
        return ClassUtil.decodeStringRes(deviceProperties.xmlTag().trim());
    }
}

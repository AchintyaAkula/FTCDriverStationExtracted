package com.qualcomm.robotcore.hardware.configuration;

import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.util.SerialNumber;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import org.firstinspires.inspection.InspectionState;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class ServoHubConfiguration extends RhspModuleConfiguration {
    public static final String TAG = "ServoHubConfiguration";
    private List<DeviceConfiguration> servos;

    public boolean isParent() {
        return false;
    }

    public ServoHubConfiguration() {
        this(InspectionState.NO_VERSION);
    }

    public ServoHubConfiguration(String str) {
        super(str, new ArrayList(), SerialNumber.createFake(), BuiltInConfigurationType.SERVO_HUB);
        this.servos = new LinkedList();
        this.servos = ConfigurationUtility.buildEmptyServos(0, 6);
    }

    public List<DeviceConfiguration> getServos() {
        return this.servos;
    }

    public void setServos(List<DeviceConfiguration> list) {
        this.servos = list;
    }

    /* access modifiers changed from: protected */
    public void deserializeChildElement(ConfigurationType configurationType, XmlPullParser xmlPullParser, ReadXMLFileHandler readXMLFileHandler) throws IOException, XmlPullParserException, RobotCoreException {
        super.deserializeChildElement(configurationType, xmlPullParser, readXMLFileHandler);
        if (configurationType.isDeviceFlavor(ConfigurationType.DeviceFlavor.SERVO)) {
            DeviceConfiguration deviceConfiguration = new DeviceConfiguration();
            deviceConfiguration.deserialize(xmlPullParser, readXMLFileHandler);
            getServos().set(deviceConfiguration.getPort(), deviceConfiguration);
        }
    }

    /* access modifiers changed from: protected */
    public void deserializeAttributes(XmlPullParser xmlPullParser) {
        super.deserializeAttributes(xmlPullParser);
        setModuleAddress(getPort());
    }
}

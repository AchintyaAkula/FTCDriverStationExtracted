package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.qualcomm.robotcore.hardware.ServoControllerEx;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.function.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ServoConfigurationType$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ ServoConfigurationType f$0;
    public final /* synthetic */ ServoControllerEx f$1;
    public final /* synthetic */ int f$2;
    public final /* synthetic */ List f$3;

    public /* synthetic */ ServoConfigurationType$$ExternalSyntheticLambda0(ServoConfigurationType servoConfigurationType, ServoControllerEx servoControllerEx, int i, List list) {
        this.f$0 = servoConfigurationType;
        this.f$1 = servoControllerEx;
        this.f$2 = i;
        this.f$3 = list;
    }

    public final void accept(Object obj) {
        this.f$0.m31lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersServoConfigurationType(this.f$1, this.f$2, this.f$3, (InstantiableUserConfigurationType) obj);
    }
}

package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.google.gson.annotations.Expose;
import com.qualcomm.robotcore.hardware.ControlSystem;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.util.ClassUtil;
import com.qualcomm.robotcore.util.RobotLog;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import org.firstinspires.inspection.InspectionState;

public abstract class UserConfigurationType implements ConfigurationType, Serializable {
    @Expose
    private boolean builtIn = false;
    @Expose
    private ConfigurationTypeManager.ClassSource classSource;
    @Expose
    private ControlSystem[] compatibleControlSystems = {ControlSystem.REV_HUB};
    @Expose
    protected String description;
    @Expose
    private final ConfigurationType.DeviceFlavor flavor;
    @Expose
    private boolean isDeprecated;
    @Expose
    @Deprecated
    private boolean isExternalLibraries;
    @Expose
    @Deprecated
    private boolean isOnBotJava;
    @Expose
    protected String name = InspectionState.NO_VERSION;
    /* access modifiers changed from: private */
    @Expose
    public String xmlTag;
    @Expose
    @Deprecated
    private String[] xmlTagAliases = new String[0];

    public boolean annotatedClassIsInstantiable() {
        return false;
    }

    public UserConfigurationType(Class<?> cls, ConfigurationType.DeviceFlavor deviceFlavor, String str, ConfigurationTypeManager.ClassSource classSource2) {
        this.flavor = deviceFlavor;
        this.xmlTag = str;
        this.classSource = classSource2;
        this.isOnBotJava = classSource2 == ConfigurationTypeManager.ClassSource.ONBOTJAVA;
        this.isExternalLibraries = classSource2 == ConfigurationTypeManager.ClassSource.EXTERNAL_LIB;
        this.isDeprecated = cls.isAnnotationPresent(Deprecated.class);
        if (str.equals(ConfigurationTypeManager.NEW_HD_HEX_MOTOR_40_TAG)) {
            this.xmlTagAliases = new String[]{ConfigurationTypeManager.LEGACY_HD_HEX_MOTOR_TAG};
        }
    }

    protected UserConfigurationType(ConfigurationType.DeviceFlavor deviceFlavor) {
        this.flavor = deviceFlavor;
        this.xmlTag = InspectionState.NO_VERSION;
    }

    public void processAnnotation(DeviceProperties deviceProperties) {
        this.description = ClassUtil.decodeStringRes(deviceProperties.description());
        this.builtIn = deviceProperties.builtIn();
        this.compatibleControlSystems = deviceProperties.compatibleControlSystems();
        if (!deviceProperties.name().isEmpty()) {
            this.name = ClassUtil.decodeStringRes(deviceProperties.name().trim());
        }
        for (String str : deviceProperties.xmlTagAliases()) {
            if (!this.xmlTag.equals(str)) {
                RobotLog.addGlobalWarningMessage("xmlTagAliases has been deprecated. %s will NOT be respected as an alias for the %s XML tag.", str, this.xmlTag);
            }
        }
    }

    public void finishedAnnotations(Class cls) {
        if (this.name.isEmpty()) {
            this.name = cls.getSimpleName();
        }
    }

    public boolean isCompatibleWith(ControlSystem controlSystem) {
        for (ControlSystem controlSystem2 : this.compatibleControlSystems) {
            if (controlSystem == controlSystem2) {
                return true;
            }
        }
        return false;
    }

    protected static class SerializationProxy implements Serializable {
        protected String xmlTag;

        public SerializationProxy(UserConfigurationType userConfigurationType) {
            this.xmlTag = userConfigurationType.xmlTag;
        }

        private Object readResolve() {
            return ConfigurationTypeManager.getInstance().configurationTypeFromTag(this.xmlTag);
        }
    }

    private Object writeReplace() {
        return new SerializationProxy(this);
    }

    private void readObject(ObjectInputStream objectInputStream) throws InvalidObjectException {
        throw new InvalidObjectException("proxy required");
    }

    public ConfigurationType.DeviceFlavor getDeviceFlavor() {
        return this.flavor;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public ConfigurationTypeManager.ClassSource getClassSource() {
        ConfigurationTypeManager.ClassSource classSource2 = this.classSource;
        return classSource2 == null ? ConfigurationTypeManager.ClassSource.APK : classSource2;
    }

    public boolean isBuiltIn() {
        return this.builtIn;
    }

    public String getXmlTag() {
        return this.xmlTag;
    }

    public DeviceManager.UsbDeviceType toUSBDeviceType() {
        return DeviceManager.UsbDeviceType.FTDI_USB_UNKNOWN_DEVICE;
    }

    public boolean isDeviceFlavor(ConfigurationType.DeviceFlavor deviceFlavor) {
        return this.flavor == deviceFlavor;
    }

    public boolean isDeprecated() {
        return this.isDeprecated;
    }
}

package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.hardware.configuration.ConstructorPrototype;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.UserConfigurationType;
import com.qualcomm.robotcore.util.ClassUtil;
import com.qualcomm.robotcore.util.RobotLog;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.firstinspires.ftc.robotcore.external.function.Consumer;
import org.firstinspires.ftc.robotcore.external.function.Function;

public abstract class InstantiableUserConfigurationType extends UserConfigurationType {
    protected final Set<InstantiableUserConfigurationType> additionalTypesToInstantiate = new HashSet();
    private Class<? extends HardwareDevice> clazz;
    private List<Constructor> constructors;
    private String originalName;

    enum DisplayNamePriority {
        BUILT_IN,
        EXTERNAL_LIB,
        APK,
        ONBOTJAVA
    }

    public boolean annotatedClassIsInstantiable() {
        return true;
    }

    protected InstantiableUserConfigurationType(Class cls, ConfigurationType.DeviceFlavor deviceFlavor, String str, ConstructorPrototype[] constructorPrototypeArr, ConfigurationTypeManager.ClassSource classSource) {
        super(cls, deviceFlavor, str, classSource);
        this.clazz = cls;
        this.constructors = findUsableConstructors(constructorPrototypeArr);
    }

    protected InstantiableUserConfigurationType(ConfigurationType.DeviceFlavor deviceFlavor) {
        super(deviceFlavor);
    }

    public void processAnnotation(DeviceProperties deviceProperties) {
        super.processAnnotation(deviceProperties);
        this.originalName = getName();
    }

    private List<Constructor> findUsableConstructors(ConstructorPrototype[] constructorPrototypeArr) {
        LinkedList linkedList = new LinkedList();
        for (Constructor next : ClassUtil.getDeclaredConstructors(getClazz())) {
            if ((next.getModifiers() & 1) == 1) {
                int length = constructorPrototypeArr.length;
                int i = 0;
                while (true) {
                    if (i >= length) {
                        break;
                    } else if (constructorPrototypeArr[i].matches(next)) {
                        linkedList.add(next);
                        break;
                    } else {
                        i++;
                    }
                }
            }
        }
        return linkedList;
    }

    /* access modifiers changed from: protected */
    public final Constructor<HardwareDevice> findMatch(ConstructorPrototype constructorPrototype) {
        for (Constructor<HardwareDevice> next : this.constructors) {
            if (constructorPrototype.matches(next)) {
                return next;
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void forThisAndAllAdditionalTypes(Consumer<InstantiableUserConfigurationType> consumer) {
        consumer.accept(this);
        for (InstantiableUserConfigurationType accept : this.additionalTypesToInstantiate) {
            consumer.accept(accept);
        }
    }

    /* access modifiers changed from: protected */
    public boolean checkThisAndAllAdditionalTypes(Function<InstantiableUserConfigurationType, Boolean> function) {
        AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        forThisAndAllAdditionalTypes(new InstantiableUserConfigurationType$$ExternalSyntheticLambda1(function, atomicBoolean));
        return atomicBoolean.get();
    }

    static /* synthetic */ void lambda$checkThisAndAllAdditionalTypes$0(Function function, AtomicBoolean atomicBoolean, InstantiableUserConfigurationType instantiableUserConfigurationType) {
        if (((Boolean) function.apply(instantiableUserConfigurationType)).booleanValue()) {
            atomicBoolean.set(true);
        }
    }

    public final boolean hasConstructors() {
        return this.constructors.size() > 0;
    }

    public final Class<? extends HardwareDevice> getClazz() {
        return this.clazz;
    }

    public void addAdditionalTypeToInstantiate(InstantiableUserConfigurationType instantiableUserConfigurationType) {
        if (instantiableUserConfigurationType.getTopLevelDisplayNamePriority().compareTo(getDisplayNamePriorityIncludingAdditionalTypes()) < 0) {
            this.name = instantiableUserConfigurationType.originalName;
        }
        this.additionalTypesToInstantiate.add(instantiableUserConfigurationType);
    }

    public static class ClearTypesFromSourceResult {
        public final Set<String> freedDisplayNames;
        public final InstantiableUserConfigurationType newTopLevelType;

        public ClearTypesFromSourceResult(InstantiableUserConfigurationType instantiableUserConfigurationType, Set<String> set) {
            this.newTopLevelType = instantiableUserConfigurationType;
            this.freedDisplayNames = set;
        }
    }

    public ClearTypesFromSourceResult clearTypesFromSource(ConfigurationTypeManager.ClassSource classSource) {
        InstantiableUserConfigurationType instantiableUserConfigurationType;
        HashSet<String> hashSet = new HashSet<>();
        for (InstantiableUserConfigurationType instantiableUserConfigurationType2 : new ArrayList(this.additionalTypesToInstantiate)) {
            if (instantiableUserConfigurationType2.getClassSource() == classSource) {
                hashSet.add(instantiableUserConfigurationType2.originalName);
                this.additionalTypesToInstantiate.remove(instantiableUserConfigurationType2);
            }
        }
        if (getClassSource() == classSource) {
            hashSet.add(getName());
            if (this.additionalTypesToInstantiate.size() > 0) {
                instantiableUserConfigurationType = this.additionalTypesToInstantiate.iterator().next();
                this.additionalTypesToInstantiate.remove(instantiableUserConfigurationType);
                for (InstantiableUserConfigurationType addAdditionalTypeToInstantiate : this.additionalTypesToInstantiate) {
                    instantiableUserConfigurationType.addAdditionalTypeToInstantiate(addAdditionalTypeToInstantiate);
                }
            } else {
                instantiableUserConfigurationType = null;
            }
        } else {
            instantiableUserConfigurationType = this;
        }
        HashSet hashSet2 = new HashSet();
        if (instantiableUserConfigurationType != null) {
            for (String str : hashSet) {
                if (!instantiableUserConfigurationType.checkThisAndAllAdditionalTypes(new InstantiableUserConfigurationType$$ExternalSyntheticLambda0(str))) {
                    hashSet2.add(str);
                }
            }
            if (hashSet2.contains(instantiableUserConfigurationType.getName())) {
                instantiableUserConfigurationType.name = instantiableUserConfigurationType.originalName;
                for (InstantiableUserConfigurationType next : instantiableUserConfigurationType.additionalTypesToInstantiate) {
                    if (next.getTopLevelDisplayNamePriority().compareTo(instantiableUserConfigurationType.getTopLevelDisplayNamePriority()) < 0) {
                        instantiableUserConfigurationType.name = next.originalName;
                    }
                }
            }
            hashSet = hashSet2;
        }
        return new ClearTypesFromSourceResult(instantiableUserConfigurationType, Collections.unmodifiableSet(hashSet));
    }

    /* access modifiers changed from: protected */
    public final void handleConstructorExceptions(Exception exc, Class<?> cls) {
        RobotLog.e("Creating instance of user device %s failed: ", cls.getName());
        RobotLog.logStackTrace(exc);
        if (exc instanceof InvocationTargetException) {
            Throwable targetException = ((InvocationTargetException) exc).getTargetException();
            if (!isBuiltIn()) {
                RobotLog.setGlobalErrorMsg("Constructor of device class " + cls.getName() + " threw %s. See log.", targetException.getClass().getSimpleName());
            }
        }
        if (!isBuiltIn()) {
            RobotLog.setGlobalErrorMsg("Internal error while creating instance of device class " + cls.getName() + ". See log.");
        }
    }

    private Object writeReplace() {
        return new UserConfigurationType.SerializationProxy(this);
    }

    private DisplayNamePriority getDisplayNamePriorityIncludingAdditionalTypes() {
        if (checkThisAndAllAdditionalTypes(new InstantiableUserConfigurationType$$ExternalSyntheticLambda2())) {
            return DisplayNamePriority.BUILT_IN;
        }
        if (checkThisAndAllAdditionalTypes(new InstantiableUserConfigurationType$$ExternalSyntheticLambda3())) {
            return DisplayNamePriority.EXTERNAL_LIB;
        }
        if (checkThisAndAllAdditionalTypes(new InstantiableUserConfigurationType$$ExternalSyntheticLambda4())) {
            return DisplayNamePriority.APK;
        }
        if (checkThisAndAllAdditionalTypes(new InstantiableUserConfigurationType$$ExternalSyntheticLambda5())) {
            return DisplayNamePriority.ONBOTJAVA;
        }
        RobotLog.ww(ConfigurationTypeManager.TAG, "Unable to determine display name priority for %s", this.clazz.getName());
        return DisplayNamePriority.ONBOTJAVA;
    }

    static /* synthetic */ Boolean lambda$getDisplayNamePriorityIncludingAdditionalTypes$2(InstantiableUserConfigurationType instantiableUserConfigurationType) {
        return Boolean.valueOf(instantiableUserConfigurationType.getClassSource() == ConfigurationTypeManager.ClassSource.EXTERNAL_LIB);
    }

    static /* synthetic */ Boolean lambda$getDisplayNamePriorityIncludingAdditionalTypes$3(InstantiableUserConfigurationType instantiableUserConfigurationType) {
        return Boolean.valueOf(instantiableUserConfigurationType.getClassSource() == ConfigurationTypeManager.ClassSource.APK);
    }

    static /* synthetic */ Boolean lambda$getDisplayNamePriorityIncludingAdditionalTypes$4(InstantiableUserConfigurationType instantiableUserConfigurationType) {
        return Boolean.valueOf(instantiableUserConfigurationType.getClassSource() == ConfigurationTypeManager.ClassSource.ONBOTJAVA);
    }

    private DisplayNamePriority getTopLevelDisplayNamePriority() {
        if (isBuiltIn()) {
            return DisplayNamePriority.BUILT_IN;
        }
        if (getClassSource() == ConfigurationTypeManager.ClassSource.EXTERNAL_LIB) {
            return DisplayNamePriority.EXTERNAL_LIB;
        }
        if (getClassSource() == ConfigurationTypeManager.ClassSource.APK) {
            return DisplayNamePriority.APK;
        }
        if (getClassSource() == ConfigurationTypeManager.ClassSource.ONBOTJAVA) {
            return DisplayNamePriority.ONBOTJAVA;
        }
        RobotLog.ww(ConfigurationTypeManager.TAG, "Unable to determine display name priority for %s", this.clazz.getName());
        return DisplayNamePriority.ONBOTJAVA;
    }
}

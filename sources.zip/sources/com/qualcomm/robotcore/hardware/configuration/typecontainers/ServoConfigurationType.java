package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.google.gson.annotations.Expose;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.ServoController;
import com.qualcomm.robotcore.hardware.ServoControllerEx;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.hardware.configuration.ConstructorPrototype;
import com.qualcomm.robotcore.hardware.configuration.ServoFlavor;
import com.qualcomm.robotcore.hardware.configuration.annotations.ServoType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.UserConfigurationType;
import com.qualcomm.robotcore.util.RobotLog;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public final class ServoConfigurationType extends InstantiableUserConfigurationType {
    private static final ConstructorPrototype ctorServo = new ConstructorPrototype(ServoController.class, Integer.TYPE);
    private static final ConstructorPrototype ctorServoEx = new ConstructorPrototype(ServoControllerEx.class, Integer.TYPE);
    @Expose
    private ServoFlavor servoFlavor;
    private double usFrame;
    private double usPulseLower;
    private double usPulseUpper;

    public ServoConfigurationType(Class<? extends HardwareDevice> cls, String str, ConfigurationTypeManager.ClassSource classSource) {
        super(cls, ConfigurationType.DeviceFlavor.SERVO, str, new ConstructorPrototype[]{ctorServo, ctorServoEx}, classSource);
    }

    public ServoConfigurationType() {
        super(ConfigurationType.DeviceFlavor.SERVO);
    }

    public static ServoConfigurationType getStandardServoType() {
        return ConfigurationTypeManager.getInstance().getStandardServoType();
    }

    public void processAnnotation(ServoType servoType) {
        if (servoType != null) {
            this.servoFlavor = servoType.flavor();
            this.usPulseLower = servoType.usPulseLower();
            this.usPulseUpper = servoType.usPulseUpper();
            this.usFrame = servoType.usPulseFrameRate();
        }
    }

    public ServoFlavor getServoFlavor() {
        return this.servoFlavor;
    }

    public double getUsPulseLower() {
        return this.usPulseLower;
    }

    public double getUsPulseUpper() {
        return this.usPulseUpper;
    }

    public double getUsFrame() {
        return this.usFrame;
    }

    public boolean annotatedClassIsInstantiable() {
        return this.servoFlavor == ServoFlavor.CUSTOM;
    }

    public List<HardwareDevice> createInstances(ServoControllerEx servoControllerEx, int i) {
        if (this.servoFlavor == ServoFlavor.CUSTOM) {
            ArrayList arrayList = new ArrayList(this.additionalTypesToInstantiate.size() + 1);
            forThisAndAllAdditionalTypes(new ServoConfigurationType$$ExternalSyntheticLambda0(this, servoControllerEx, i, arrayList));
            return arrayList;
        }
        throw new RuntimeException("Can't create instance of non-instantiable servo type " + this.name);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$createInstances$0$com-qualcomm-robotcore-hardware-configuration-typecontainers-ServoConfigurationType  reason: not valid java name */
    public /* synthetic */ void m31lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersServoConfigurationType(ServoControllerEx servoControllerEx, int i, List list, InstantiableUserConfigurationType instantiableUserConfigurationType) {
        try {
            Constructor<HardwareDevice> findMatch = instantiableUserConfigurationType.findMatch(ctorServoEx);
            if (findMatch != null) {
                servoControllerEx.setServoType(i, this);
                list.add(findMatch.newInstance(new Object[]{servoControllerEx, Integer.valueOf(i)}));
                return;
            }
            Constructor<HardwareDevice> findMatch2 = instantiableUserConfigurationType.findMatch(ctorServo);
            if (findMatch2 != null) {
                servoControllerEx.setServoType(i, this);
                list.add(findMatch2.newInstance(new Object[]{servoControllerEx, Integer.valueOf(i)}));
                return;
            }
            RobotLog.e("Unable to locate constructor for device class " + instantiableUserConfigurationType.getClazz().getName());
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            handleConstructorExceptions(e, instantiableUserConfigurationType.getClazz());
        }
    }

    private Object writeReplace() {
        return new UserConfigurationType.SerializationProxy(this);
    }
}

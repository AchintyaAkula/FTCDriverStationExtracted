package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.qualcomm.robotcore.hardware.AnalogInputController;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.function.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AnalogSensorConfigurationType$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ AnalogSensorConfigurationType f$0;
    public final /* synthetic */ List f$1;
    public final /* synthetic */ AnalogInputController f$2;
    public final /* synthetic */ int f$3;

    public /* synthetic */ AnalogSensorConfigurationType$$ExternalSyntheticLambda0(AnalogSensorConfigurationType analogSensorConfigurationType, List list, AnalogInputController analogInputController, int i) {
        this.f$0 = analogSensorConfigurationType;
        this.f$1 = list;
        this.f$2 = analogInputController;
        this.f$3 = i;
    }

    public final void accept(Object obj) {
        this.f$0.m28lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersAnalogSensorConfigurationType(this.f$1, this.f$2, this.f$3, (InstantiableUserConfigurationType) obj);
    }
}

package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.qualcomm.robotcore.hardware.AnalogInputController;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.hardware.configuration.ConstructorPrototype;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.UserConfigurationType;
import com.qualcomm.robotcore.util.RobotLog;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public final class AnalogSensorConfigurationType extends InstantiableUserConfigurationType {
    private static final ConstructorPrototype ctorAnalogSensor = new ConstructorPrototype(AnalogInputController.class, Integer.TYPE);

    public AnalogSensorConfigurationType(Class<? extends HardwareDevice> cls, String str, ConfigurationTypeManager.ClassSource classSource) {
        super(cls, ConfigurationType.DeviceFlavor.ANALOG_SENSOR, str, new ConstructorPrototype[]{ctorAnalogSensor}, classSource);
    }

    public AnalogSensorConfigurationType() {
        super(ConfigurationType.DeviceFlavor.ANALOG_SENSOR);
    }

    public List<HardwareDevice> createInstances(AnalogInputController analogInputController, int i) {
        ArrayList arrayList = new ArrayList(this.additionalTypesToInstantiate.size() + 1);
        forThisAndAllAdditionalTypes(new AnalogSensorConfigurationType$$ExternalSyntheticLambda0(this, arrayList, analogInputController, i));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$createInstances$0$com-qualcomm-robotcore-hardware-configuration-typecontainers-AnalogSensorConfigurationType  reason: not valid java name */
    public /* synthetic */ void m28lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersAnalogSensorConfigurationType(List list, AnalogInputController analogInputController, int i, InstantiableUserConfigurationType instantiableUserConfigurationType) {
        try {
            Constructor<HardwareDevice> findMatch = instantiableUserConfigurationType.findMatch(ctorAnalogSensor);
            if (findMatch == null) {
                RobotLog.e("unable to locate constructor for device class " + instantiableUserConfigurationType.getClazz().getName());
            } else {
                list.add(findMatch.newInstance(new Object[]{analogInputController, Integer.valueOf(i)}));
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            handleConstructorExceptions(e, instantiableUserConfigurationType.getClazz());
        }
    }

    private Object writeReplace() {
        return new UserConfigurationType.SerializationProxy(this);
    }
}

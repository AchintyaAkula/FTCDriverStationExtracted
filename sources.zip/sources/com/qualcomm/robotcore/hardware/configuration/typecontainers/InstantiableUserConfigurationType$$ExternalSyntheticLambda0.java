package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import org.firstinspires.ftc.robotcore.external.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class InstantiableUserConfigurationType$$ExternalSyntheticLambda0 implements Function {
    public final /* synthetic */ String f$0;

    public /* synthetic */ InstantiableUserConfigurationType$$ExternalSyntheticLambda0(String str) {
        this.f$0 = str;
    }

    public final Object apply(Object obj) {
        return Boolean.valueOf(((InstantiableUserConfigurationType) obj).originalName.equals(this.f$0));
    }
}

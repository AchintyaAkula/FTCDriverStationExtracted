package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import org.firstinspires.ftc.robotcore.external.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class InstantiableUserConfigurationType$$ExternalSyntheticLambda4 implements Function {
    public final Object apply(Object obj) {
        return InstantiableUserConfigurationType.lambda$getDisplayNamePriorityIncludingAdditionalTypes$3((InstantiableUserConfigurationType) obj);
    }
}

package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.qualcomm.robotcore.hardware.DigitalChannelController;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.function.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class DigitalIoDeviceConfigurationType$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ DigitalIoDeviceConfigurationType f$0;
    public final /* synthetic */ List f$1;
    public final /* synthetic */ DigitalChannelController f$2;
    public final /* synthetic */ int f$3;

    public /* synthetic */ DigitalIoDeviceConfigurationType$$ExternalSyntheticLambda0(DigitalIoDeviceConfigurationType digitalIoDeviceConfigurationType, List list, DigitalChannelController digitalChannelController, int i) {
        this.f$0 = digitalIoDeviceConfigurationType;
        this.f$1 = list;
        this.f$2 = digitalChannelController;
        this.f$3 = i;
    }

    public final void accept(Object obj) {
        this.f$0.m29lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersDigitalIoDeviceConfigurationType(this.f$1, this.f$2, this.f$3, (InstantiableUserConfigurationType) obj);
    }
}

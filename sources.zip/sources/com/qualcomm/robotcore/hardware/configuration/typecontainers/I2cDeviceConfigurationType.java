package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import com.google.blocks.ftcrobotcontroller.runtime.BlocksOpMode$BlocksOpModeAccess$$ExternalSyntheticBackportWithForwarding0;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynch;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchImplOnSimple;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.hardware.configuration.ConstructorPrototype;
import com.qualcomm.robotcore.hardware.configuration.I2cSensor;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.UserConfigurationType;
import com.qualcomm.robotcore.util.ClassUtil;
import com.qualcomm.robotcore.util.RobotLog;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.firstinspires.ftc.robotcore.external.Func;

public final class I2cDeviceConfigurationType extends InstantiableUserConfigurationType {
    private static final ConstructorPrototype[] allowableConstructorPrototypes;
    private static final ConstructorPrototype ctorI2cDeviceSynch;
    private static final ConstructorPrototype ctorI2cDeviceSynchDeprecated;
    private static final ConstructorPrototype ctorI2cDeviceSynchSimple;
    private static final ConstructorPrototype ctorI2cDeviceSynchSimpleDeprecated;

    static {
        ConstructorPrototype constructorPrototype = new ConstructorPrototype(I2cDeviceSynchSimple.class, Boolean.TYPE);
        ctorI2cDeviceSynchSimple = constructorPrototype;
        ConstructorPrototype constructorPrototype2 = new ConstructorPrototype(I2cDeviceSynch.class, Boolean.TYPE);
        ctorI2cDeviceSynch = constructorPrototype2;
        ConstructorPrototype constructorPrototype3 = new ConstructorPrototype(I2cDeviceSynchSimple.class);
        ctorI2cDeviceSynchSimpleDeprecated = constructorPrototype3;
        ConstructorPrototype constructorPrototype4 = new ConstructorPrototype(I2cDeviceSynch.class);
        ctorI2cDeviceSynchDeprecated = constructorPrototype4;
        allowableConstructorPrototypes = new ConstructorPrototype[]{constructorPrototype, constructorPrototype2, constructorPrototype3, constructorPrototype4};
    }

    public I2cDeviceConfigurationType(Class<? extends HardwareDevice> cls, String str, ConfigurationTypeManager.ClassSource classSource) {
        super(cls, ConfigurationType.DeviceFlavor.I2C, str, allowableConstructorPrototypes, classSource);
    }

    public static I2cDeviceConfigurationType getLynxEmbeddedBNO055ImuType() {
        return (I2cDeviceConfigurationType) ConfigurationTypeManager.getInstance().configurationTypeFromTag(LynxConstants.EMBEDDED_BNO055_IMU_XML_TAG);
    }

    public static I2cDeviceConfigurationType getLynxEmbeddedBHI260APImuType() {
        return (I2cDeviceConfigurationType) ConfigurationTypeManager.getInstance().configurationTypeFromTag(LynxConstants.EMBEDDED_BHI260AP_IMU_XML_TAG);
    }

    public I2cDeviceConfigurationType() {
        super(ConfigurationType.DeviceFlavor.I2C);
    }

    public void processAnnotation(I2cSensor i2cSensor) {
        if (i2cSensor != null) {
            if (this.name.isEmpty()) {
                this.name = ClassUtil.decodeStringRes(i2cSensor.name().trim());
            }
            this.description = ClassUtil.decodeStringRes(i2cSensor.description());
        }
    }

    public List<HardwareDevice> createInstances(Func<I2cDeviceSynchSimple> func) {
        ArrayList arrayList = new ArrayList(this.additionalTypesToInstantiate.size() + 1);
        forThisAndAllAdditionalTypes(new I2cDeviceConfigurationType$$ExternalSyntheticLambda0(this, new AtomicReference(), func, arrayList, this.additionalTypesToInstantiate.size() == 0));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$createInstances$0$com-qualcomm-robotcore-hardware-configuration-typecontainers-I2cDeviceConfigurationType  reason: not valid java name */
    public /* synthetic */ void m30lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersI2cDeviceConfigurationType(AtomicReference atomicReference, Func func, List list, boolean z, InstantiableUserConfigurationType instantiableUserConfigurationType) {
        try {
            Constructor<HardwareDevice> findMatch = instantiableUserConfigurationType.findMatch(ctorI2cDeviceSynchSimple);
            if (findMatch != null) {
                BlocksOpMode$BlocksOpModeAccess$$ExternalSyntheticBackportWithForwarding0.m(atomicReference, (Object) null, (I2cDeviceSynchSimple) func.value());
                list.add(findMatch.newInstance(new Object[]{atomicReference.get(), Boolean.valueOf(z)}));
                return;
            }
            Constructor<HardwareDevice> findMatch2 = instantiableUserConfigurationType.findMatch(ctorI2cDeviceSynch);
            if (findMatch2 != null) {
                BlocksOpMode$BlocksOpModeAccess$$ExternalSyntheticBackportWithForwarding0.m(atomicReference, (Object) null, (I2cDeviceSynchSimple) func.value());
                list.add(findMatch2.newInstance(new Object[]{getI2cDeviceSynchFromSimple((I2cDeviceSynchSimple) atomicReference.get(), z), Boolean.valueOf(z)}));
                return;
            }
            Constructor<HardwareDevice> findMatch3 = instantiableUserConfigurationType.findMatch(ctorI2cDeviceSynchSimpleDeprecated);
            if (findMatch3 != null) {
                warnAboutDeprecatedConstructor(instantiableUserConfigurationType.getClazz());
                list.add(findMatch3.newInstance(new Object[]{func.value()}));
                return;
            }
            Constructor<HardwareDevice> findMatch4 = instantiableUserConfigurationType.findMatch(ctorI2cDeviceSynchDeprecated);
            if (findMatch4 != null) {
                warnAboutDeprecatedConstructor(instantiableUserConfigurationType.getClazz());
                list.add(findMatch4.newInstance(new Object[]{getI2cDeviceSynchFromSimple((I2cDeviceSynchSimple) func.value(), true)}));
                return;
            }
            RobotLog.e("unable to locate constructor for device class " + instantiableUserConfigurationType.getClazz().getName());
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            handleConstructorExceptions(e, instantiableUserConfigurationType.getClazz());
        }
    }

    private static I2cDeviceSynch getI2cDeviceSynchFromSimple(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        if (i2cDeviceSynchSimple instanceof I2cDeviceSynch) {
            return (I2cDeviceSynch) i2cDeviceSynchSimple;
        }
        return new I2cDeviceSynchImplOnSimple(i2cDeviceSynchSimple, z);
    }

    private static void warnAboutDeprecatedConstructor(Class<?> cls) {
        Class<I2cDeviceType> cls2 = I2cDeviceType.class;
        RobotLog.ww("I2cDeviceType", "%s only has deprecated constructors. For best results, add an additional constructor that accepts an additional \"deviceClientIsOwned\" boolean parameter and passes it to the I2cDeviceSynchDevice or I2cDeviceSynchDeviceWithParameters constructor.", cls.getName());
    }

    private Object writeReplace() {
        return new UserConfigurationType.SerializationProxy(this);
    }
}

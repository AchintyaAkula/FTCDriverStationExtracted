package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import java.util.concurrent.atomic.AtomicBoolean;
import org.firstinspires.ftc.robotcore.external.function.Consumer;
import org.firstinspires.ftc.robotcore.external.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class InstantiableUserConfigurationType$$ExternalSyntheticLambda1 implements Consumer {
    public final /* synthetic */ Function f$0;
    public final /* synthetic */ AtomicBoolean f$1;

    public /* synthetic */ InstantiableUserConfigurationType$$ExternalSyntheticLambda1(Function function, AtomicBoolean atomicBoolean) {
        this.f$0 = function;
        this.f$1 = atomicBoolean;
    }

    public final void accept(Object obj) {
        InstantiableUserConfigurationType.lambda$checkThisAndAllAdditionalTypes$0(this.f$0, this.f$1, (InstantiableUserConfigurationType) obj);
    }
}

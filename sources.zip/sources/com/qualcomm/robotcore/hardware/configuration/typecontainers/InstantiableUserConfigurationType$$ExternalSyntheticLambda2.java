package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import org.firstinspires.ftc.robotcore.external.function.Function;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class InstantiableUserConfigurationType$$ExternalSyntheticLambda2 implements Function {
    public final Object apply(Object obj) {
        return Boolean.valueOf(((InstantiableUserConfigurationType) obj).isBuiltIn());
    }
}

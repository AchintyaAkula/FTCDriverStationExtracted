package com.qualcomm.robotcore.hardware.configuration.typecontainers;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.firstinspires.ftc.robotcore.external.Func;
import org.firstinspires.ftc.robotcore.external.function.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class I2cDeviceConfigurationType$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ I2cDeviceConfigurationType f$0;
    public final /* synthetic */ AtomicReference f$1;
    public final /* synthetic */ Func f$2;
    public final /* synthetic */ List f$3;
    public final /* synthetic */ boolean f$4;

    public /* synthetic */ I2cDeviceConfigurationType$$ExternalSyntheticLambda0(I2cDeviceConfigurationType i2cDeviceConfigurationType, AtomicReference atomicReference, Func func, List list, boolean z) {
        this.f$0 = i2cDeviceConfigurationType;
        this.f$1 = atomicReference;
        this.f$2 = func;
        this.f$3 = list;
        this.f$4 = z;
    }

    public final void accept(Object obj) {
        this.f$0.m30lambda$createInstances$0$comqualcommrobotcorehardwareconfigurationtypecontainersI2cDeviceConfigurationType(this.f$1, this.f$2, this.f$3, this.f$4, (InstantiableUserConfigurationType) obj);
    }
}

package com.qualcomm.robotcore.hardware.configuration;

import com.google.gson.annotations.Expose;
import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.MotorControlAlgorithm;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.configuration.annotations.ExpansionHubPIDFPositionParams;
import com.qualcomm.robotcore.hardware.configuration.annotations.ExpansionHubPIDFVelocityParams;
import java.io.Serializable;
import org.firstinspires.ftc.robotcore.internal.system.Assert;
import org.firstinspires.ftc.robotcore.internal.system.Misc;

public class ExpansionHubMotorControllerParamsState implements Serializable, Cloneable {
    @Expose
    public MotorControlAlgorithm algorithm;
    @Expose
    public double d;
    @Expose
    public double f;
    @Expose
    public double i;
    @Expose
    public DcMotor.RunMode mode;
    @Expose
    public double p;

    public ExpansionHubMotorControllerParamsState() {
        this.mode = null;
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        Assert.assertTrue(isDefault());
    }

    public ExpansionHubMotorControllerParamsState(DcMotor.RunMode runMode, PIDFCoefficients pIDFCoefficients) {
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        this.mode = runMode;
        this.p = pIDFCoefficients.p;
        this.i = pIDFCoefficients.i;
        this.d = pIDFCoefficients.d;
        this.f = pIDFCoefficients.f;
        this.algorithm = pIDFCoefficients.algorithm;
    }

    public ExpansionHubMotorControllerParamsState(ExpansionHubMotorControllerPositionParams expansionHubMotorControllerPositionParams) {
        this.mode = null;
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        this.mode = DcMotor.RunMode.RUN_TO_POSITION;
        this.p = expansionHubMotorControllerPositionParams.P();
        this.i = expansionHubMotorControllerPositionParams.I();
        this.d = expansionHubMotorControllerPositionParams.D();
        this.f = LynxServoController.apiPositionFirst;
        this.algorithm = MotorControlAlgorithm.LegacyPID;
    }

    public ExpansionHubMotorControllerParamsState(ExpansionHubPIDFPositionParams expansionHubPIDFPositionParams) {
        this.mode = null;
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        this.mode = DcMotor.RunMode.RUN_TO_POSITION;
        this.p = expansionHubPIDFPositionParams.P();
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        this.algorithm = expansionHubPIDFPositionParams.algorithm();
    }

    public ExpansionHubMotorControllerParamsState(ExpansionHubMotorControllerVelocityParams expansionHubMotorControllerVelocityParams) {
        this.mode = null;
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        this.mode = DcMotor.RunMode.RUN_USING_ENCODER;
        this.p = expansionHubMotorControllerVelocityParams.P();
        this.i = expansionHubMotorControllerVelocityParams.I();
        this.d = expansionHubMotorControllerVelocityParams.D();
        this.f = LynxServoController.apiPositionFirst;
        this.algorithm = MotorControlAlgorithm.LegacyPID;
    }

    public ExpansionHubMotorControllerParamsState(ExpansionHubPIDFVelocityParams expansionHubPIDFVelocityParams) {
        this.mode = null;
        this.p = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.f = LynxServoController.apiPositionFirst;
        this.mode = DcMotor.RunMode.RUN_USING_ENCODER;
        this.p = expansionHubPIDFVelocityParams.P();
        this.i = expansionHubPIDFVelocityParams.I();
        this.d = expansionHubPIDFVelocityParams.D();
        this.f = expansionHubPIDFVelocityParams.F();
        this.algorithm = expansionHubPIDFVelocityParams.algorithm();
    }

    public PIDFCoefficients getPidfCoefficients() {
        return new PIDFCoefficients(this.p, this.i, this.d, this.f, this.algorithm);
    }

    public ExpansionHubMotorControllerParamsState clone() {
        try {
            return (ExpansionHubMotorControllerParamsState) super.clone();
        } catch (CloneNotSupportedException unused) {
            throw new RuntimeException("internal error: Parameters not cloneable");
        }
    }

    public boolean isDefault() {
        return this.mode == null;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ExpansionHubMotorControllerParamsState)) {
            return false;
        }
        ExpansionHubMotorControllerParamsState expansionHubMotorControllerParamsState = (ExpansionHubMotorControllerParamsState) obj;
        if (this.mode == expansionHubMotorControllerParamsState.mode && this.p == expansionHubMotorControllerParamsState.p && this.i == expansionHubMotorControllerParamsState.i && this.d == expansionHubMotorControllerParamsState.d && this.f == expansionHubMotorControllerParamsState.f && this.algorithm == expansionHubMotorControllerParamsState.algorithm) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return ((((this.mode.hashCode() ^ (hash(this.p) << 3)) ^ (hash(this.i) << 6)) ^ (hash(this.d) << 9)) ^ (hash(this.f) << 12)) ^ -860998516;
    }

    /* access modifiers changed from: protected */
    public int hash(double d2) {
        return Double.valueOf(d2).hashCode();
    }

    public String toString() {
        return Misc.formatForUser("mode=%s,p=%f,i=%f,d=%f,f=%f", this.mode, Double.valueOf(this.p), Double.valueOf(this.i), Double.valueOf(this.d), Double.valueOf(this.f));
    }
}

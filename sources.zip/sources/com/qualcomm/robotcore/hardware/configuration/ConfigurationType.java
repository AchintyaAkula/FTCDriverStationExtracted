package com.qualcomm.robotcore.hardware.configuration;

import com.qualcomm.robotcore.hardware.ControlSystem;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;

public interface ConfigurationType {

    public enum DeviceFlavor {
        BUILT_IN,
        I2C,
        MOTOR,
        ANALOG_SENSOR,
        SERVO,
        DIGITAL_IO,
        ANALOG_OUTPUT,
        ETHERNET_OVER_USB
    }

    boolean annotatedClassIsInstantiable();

    ConfigurationTypeManager.ClassSource getClassSource();

    DeviceFlavor getDeviceFlavor();

    String getName();

    String getXmlTag();

    boolean isCompatibleWith(ControlSystem controlSystem);

    boolean isDeprecated();

    boolean isDeviceFlavor(DeviceFlavor deviceFlavor);

    DeviceManager.UsbDeviceType toUSBDeviceType();
}

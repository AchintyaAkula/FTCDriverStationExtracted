package com.qualcomm.robotcore.hardware.configuration;

import com.qualcomm.robotcore.R;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.EmbeddedControlHubModule;
import com.qualcomm.robotcore.hardware.LynxModuleImuType;
import com.qualcomm.robotcore.hardware.LynxModuleMeta;
import com.qualcomm.robotcore.hardware.LynxModuleMetaList;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.I2cDeviceConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.ServoConfigurationType;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.firstinspires.ftc.robotcore.external.function.Supplier;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.Assert;
import org.firstinspires.ftc.robotcore.internal.system.Misc;
import org.firstinspires.ftc.robotcore.internal.usb.EthernetOverUsbSerialNumber;

public class ConfigurationUtility {
    public static final String TAG = "ConfigurationUtility";
    public static final int firstNamedDeviceNumber = 1;
    protected Set<String> existingNames;

    public ConfigurationUtility() {
        resetNameUniquifiers();
    }

    public void resetNameUniquifiers() {
        this.existingNames = new HashSet();
    }

    public Set<String> getExistingNames(ConfigurationType configurationType) {
        return this.existingNames;
    }

    public void noteExistingName(ConfigurationType configurationType, String str) {
        getExistingNames(configurationType).add(str);
    }

    /* access modifiers changed from: protected */
    public String createUniqueName(ConfigurationType configurationType, int i) {
        return createUniqueName(configurationType, AppUtil.getDefContext().getString(i), 1);
    }

    /* access modifiers changed from: protected */
    public String createUniqueName(ConfigurationType configurationType, int i, int i2) {
        return createUniqueName(configurationType, AppUtil.getDefContext().getString(i), i2);
    }

    /* access modifiers changed from: protected */
    public String createUniqueName(ConfigurationType configurationType, String str, int i) {
        return createUniqueName(configurationType, (String) null, str, i);
    }

    /* access modifiers changed from: protected */
    public String createUniqueName(ConfigurationType configurationType, int i, int i2, int i3) {
        return createUniqueName(configurationType, AppUtil.getDefContext().getString(i), AppUtil.getDefContext().getString(i2), i3);
    }

    private String createUniqueName(ConfigurationType configurationType, String str, String str2, int i) {
        Set<String> existingNames2 = getExistingNames(configurationType);
        if (str == null || existingNames2.contains(str)) {
            String formatForUser = Misc.formatForUser(str2, Integer.valueOf(i));
            if (!existingNames2.contains(formatForUser)) {
                noteExistingName(configurationType, formatForUser);
                return formatForUser;
            }
            int i2 = 1;
            while (true) {
                String formatForUser2 = Misc.formatForUser(str2, Integer.valueOf(i2));
                if (!existingNames2.contains(formatForUser2)) {
                    noteExistingName(configurationType, formatForUser2);
                    return formatForUser2;
                }
                i2++;
            }
        } else {
            noteExistingName(configurationType, str);
            return str;
        }
    }

    /* renamed from: com.qualcomm.robotcore.hardware.configuration.ConfigurationUtility$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType[] r0 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType = r0
                com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r1 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.WEBCAM     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = $SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType     // Catch:{ NoSuchFieldError -> 0x001d }
                com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r1 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.LYNX_USB_DEVICE     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.configuration.ConfigurationUtility.AnonymousClass1.<clinit>():void");
        }
    }

    public ControllerConfiguration buildNewControllerConfiguration(SerialNumber serialNumber, DeviceManager.UsbDeviceType usbDeviceType, Supplier<LynxModuleMetaList> supplier) {
        int i = AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType[usbDeviceType.ordinal()];
        if (i == 1) {
            return buildNewWebcam(serialNumber);
        }
        if (i != 2) {
            return null;
        }
        return buildNewLynxUsbDevice(serialNumber, supplier);
    }

    public ControllerConfiguration buildNewEthernetOverUsbControllerConfiguration(SerialNumber serialNumber) {
        return new EthernetOverUsbConfiguration("Ethernet Device", serialNumber, ((EthernetOverUsbSerialNumber) serialNumber).getIpAddress());
    }

    public WebcamConfiguration buildNewWebcam(SerialNumber serialNumber) {
        WebcamConfiguration webcamConfiguration = new WebcamConfiguration(createUniqueName(BuiltInConfigurationType.WEBCAM, R.string.counted_camera_name), serialNumber);
        webcamConfiguration.setEnabled(true);
        return webcamConfiguration;
    }

    public LynxUsbDeviceConfiguration buildNewLynxUsbDevice(SerialNumber serialNumber, Supplier<LynxModuleMetaList> supplier) {
        return buildNewLynxUsbDevice(serialNumber, supplier.get());
    }

    /* JADX WARNING: Removed duplicated region for block: B:38:0x009d A[Catch:{ all -> 0x001d }] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00a2 A[Catch:{ all -> 0x001d }] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00aa A[Catch:{ all -> 0x001d }] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00be A[Catch:{ all -> 0x001d }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.qualcomm.robotcore.hardware.configuration.LynxUsbDeviceConfiguration buildNewLynxUsbDevice(com.qualcomm.robotcore.util.SerialNumber r18, com.qualcomm.robotcore.hardware.LynxModuleMetaList r19) {
        /*
            r17 = this;
            r7 = r17
            r8 = r18
            java.lang.String r0 = "buildNewLynxUsbDevice(%s)..."
            java.lang.Object[] r1 = new java.lang.Object[]{r18}
            java.lang.String r9 = "ConfigurationUtility"
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r9, (java.lang.String) r0, (java.lang.Object[]) r1)
            boolean r0 = r18.isEmbedded()
            java.lang.String r10 = "...buildNewLynxUsbDevice(%s): "
            if (r19 != 0) goto L_0x0020
            com.qualcomm.robotcore.hardware.LynxModuleMetaList r1 = new com.qualcomm.robotcore.hardware.LynxModuleMetaList     // Catch:{ all -> 0x001d }
            r1.<init>(r8)     // Catch:{ all -> 0x001d }
            goto L_0x0022
        L_0x001d:
            r0 = move-exception
            goto L_0x011a
        L_0x0020:
            r1 = r19
        L_0x0022:
            java.lang.String r2 = "buildLynxUsbDevice(): lynx modules: %s"
            java.lang.Object[] r3 = new java.lang.Object[]{r1}     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r9, (java.lang.String) r2, (java.lang.Object[]) r3)     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleMeta r11 = r1.getParent()     // Catch:{ all -> 0x001d }
            if (r11 != 0) goto L_0x0035
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = com.qualcomm.robotcore.hardware.LynxModuleImuType.NONE     // Catch:{ all -> 0x001d }
        L_0x0033:
            r12 = r2
            goto L_0x0049
        L_0x0035:
            com.qualcomm.robotcore.hardware.LynxModuleMeta r2 = r1.getParent()     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = r2.imuType()     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleImuType r3 = com.qualcomm.robotcore.hardware.LynxModuleImuType.UNKNOWN     // Catch:{ all -> 0x001d }
            if (r2 != r3) goto L_0x0033
            java.lang.String r2 = "parent IMU type was UNKNOWN in buildNewLynxDevice()"
            com.qualcomm.robotcore.util.RobotLog.ww(r9, r2)     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = com.qualcomm.robotcore.hardware.LynxModuleImuType.NONE     // Catch:{ all -> 0x001d }
            goto L_0x0033
        L_0x0049:
            java.util.LinkedList r13 = new java.util.LinkedList     // Catch:{ all -> 0x001d }
            r13.<init>()     // Catch:{ all -> 0x001d }
            java.util.Iterator r14 = r1.iterator()     // Catch:{ all -> 0x001d }
        L_0x0052:
            boolean r1 = r14.hasNext()     // Catch:{ all -> 0x001d }
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L_0x00e1
            java.lang.Object r1 = r14.next()     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleMeta r1 = (com.qualcomm.robotcore.hardware.LynxModuleMeta) r1     // Catch:{ all -> 0x001d }
            r4 = 3215698(0x311152, float:4.506153E-39)
            if (r0 == 0) goto L_0x007b
            int r5 = r1.revProductNumber()     // Catch:{ all -> 0x001d }
            if (r5 != r4) goto L_0x007b
            boolean r5 = r1.isParent()     // Catch:{ all -> 0x001d }
            if (r5 == 0) goto L_0x007b
            int r5 = r1.getModuleAddress()     // Catch:{ all -> 0x001d }
            r6 = 173(0xad, float:2.42E-43)
            if (r5 != r6) goto L_0x007b
            r6 = r3
            goto L_0x007c
        L_0x007b:
            r6 = r2
        L_0x007c:
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = com.qualcomm.robotcore.hardware.LynxModuleImuType.NONE     // Catch:{ all -> 0x001d }
            if (r12 == r2) goto L_0x008b
            boolean r2 = r1.isParent()     // Catch:{ all -> 0x001d }
            if (r2 == 0) goto L_0x0088
            r5 = r12
            goto L_0x009b
        L_0x0088:
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = com.qualcomm.robotcore.hardware.LynxModuleImuType.NONE     // Catch:{ all -> 0x001d }
            goto L_0x009a
        L_0x008b:
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = r1.imuType()     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleImuType r5 = com.qualcomm.robotcore.hardware.LynxModuleImuType.UNKNOWN     // Catch:{ all -> 0x001d }
            if (r2 != r5) goto L_0x009a
            java.lang.String r2 = "module IMU type was UNKNOWN in buildNewLynxDevice()"
            com.qualcomm.robotcore.util.RobotLog.ww(r9, r2)     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.LynxModuleImuType r2 = com.qualcomm.robotcore.hardware.LynxModuleImuType.NONE     // Catch:{ all -> 0x001d }
        L_0x009a:
            r5 = r2
        L_0x009b:
            if (r11 == 0) goto L_0x00a2
            int r2 = r11.getModuleAddress()     // Catch:{ all -> 0x001d }
            goto L_0x00a3
        L_0x00a2:
            r2 = -1
        L_0x00a3:
            r15 = r2
            int r2 = r1.revProductNumber()     // Catch:{ all -> 0x001d }
            if (r2 != r4) goto L_0x00be
            int r2 = r1.getModuleAddress()     // Catch:{ all -> 0x001d }
            r16 = 1
            r1 = r17
            r3 = r15
            r4 = r5
            r5 = r16
            com.qualcomm.robotcore.hardware.configuration.LynxModuleConfiguration r1 = r1.buildNewLynxModule(r2, r3, r4, r5, r6)     // Catch:{ all -> 0x001d }
            r13.add(r1)     // Catch:{ all -> 0x001d }
            goto L_0x0052
        L_0x00be:
            int r2 = r1.revProductNumber()     // Catch:{ all -> 0x001d }
            r4 = 1120341(0x111855, float:1.569932E-39)
            if (r2 != r4) goto L_0x00d4
            int r1 = r1.getModuleAddress()     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.hardware.configuration.ServoHubConfiguration r1 = r7.buildNewServoHub(r1, r15, r3)     // Catch:{ all -> 0x001d }
            r13.add(r1)     // Catch:{ all -> 0x001d }
            goto L_0x0052
        L_0x00d4:
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r1 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance()     // Catch:{ all -> 0x001d }
            org.firstinspires.ftc.robotcore.internal.ui.UILocation r2 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH     // Catch:{ all -> 0x001d }
            java.lang.String r4 = "Found unknown REV Hub device"
            r1.showToast((org.firstinspires.ftc.robotcore.internal.ui.UILocation) r2, (java.lang.String) r4, (int) r3)     // Catch:{ all -> 0x001d }
            goto L_0x0052
        L_0x00e1:
            com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration.sortByName(r13)     // Catch:{ all -> 0x001d }
            java.lang.String r1 = "buildNewLynxUsbDevice(%s): %d modules"
            int r4 = r13.size()     // Catch:{ all -> 0x001d }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ all -> 0x001d }
            java.lang.Object[] r4 = new java.lang.Object[]{r8, r4}     // Catch:{ all -> 0x001d }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r9, (java.lang.String) r1, (java.lang.Object[]) r4)     // Catch:{ all -> 0x001d }
            if (r0 == 0) goto L_0x0102
            com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r0 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.LYNX_USB_DEVICE     // Catch:{ all -> 0x001d }
            int r1 = com.qualcomm.robotcore.R.string.control_hub_usb_device_name     // Catch:{ all -> 0x001d }
            int r4 = com.qualcomm.robotcore.R.string.counted_lynx_usb_device_name     // Catch:{ all -> 0x001d }
            java.lang.String r0 = r7.createUniqueName((com.qualcomm.robotcore.hardware.configuration.ConfigurationType) r0, (int) r1, (int) r4, (int) r2)     // Catch:{ all -> 0x001d }
            goto L_0x010a
        L_0x0102:
            com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r0 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.LYNX_USB_DEVICE     // Catch:{ all -> 0x001d }
            int r1 = com.qualcomm.robotcore.R.string.counted_lynx_usb_device_name     // Catch:{ all -> 0x001d }
            java.lang.String r0 = r7.createUniqueName(r0, r1)     // Catch:{ all -> 0x001d }
        L_0x010a:
            com.qualcomm.robotcore.hardware.configuration.LynxUsbDeviceConfiguration r1 = new com.qualcomm.robotcore.hardware.configuration.LynxUsbDeviceConfiguration     // Catch:{ all -> 0x001d }
            r1.<init>(r0, r13, r8)     // Catch:{ all -> 0x001d }
            r1.setEnabled(r3)     // Catch:{ all -> 0x001d }
            java.lang.Object[] r0 = new java.lang.Object[]{r18}
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r9, (java.lang.String) r10, (java.lang.Object[]) r0)
            return r1
        L_0x011a:
            java.lang.Object[] r1 = new java.lang.Object[]{r18}
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r9, (java.lang.String) r10, (java.lang.Object[]) r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.configuration.ConfigurationUtility.buildNewLynxUsbDevice(com.qualcomm.robotcore.util.SerialNumber, com.qualcomm.robotcore.hardware.LynxModuleMetaList):com.qualcomm.robotcore.hardware.configuration.LynxUsbDeviceConfiguration");
    }

    public LynxModuleConfiguration buildNewLynxModule(int i, int i2, LynxModuleImuType lynxModuleImuType, boolean z, boolean z2) {
        String str;
        I2cDeviceConfigurationType i2cDeviceConfigurationType;
        if (z2) {
            str = createUniqueName((ConfigurationType) BuiltInConfigurationType.LYNX_MODULE, R.string.control_hub_module_name, R.string.counted_lynx_module_name, 0);
        } else {
            str = createUniqueName((ConfigurationType) BuiltInConfigurationType.LYNX_MODULE, R.string.counted_lynx_module_name, i);
        }
        LynxModuleConfiguration buildEmptyLynxModule = buildEmptyLynxModule(str, i, i2, z);
        if (!(lynxModuleImuType == LynxModuleImuType.NONE || lynxModuleImuType == LynxModuleImuType.UNKNOWN)) {
            if (lynxModuleImuType == LynxModuleImuType.BNO055) {
                i2cDeviceConfigurationType = I2cDeviceConfigurationType.getLynxEmbeddedBNO055ImuType();
            } else if (lynxModuleImuType == LynxModuleImuType.BHI260) {
                i2cDeviceConfigurationType = I2cDeviceConfigurationType.getLynxEmbeddedBHI260APImuType();
            } else {
                throw new RuntimeException("Unrecognized embedded IMU type");
            }
            Assert.assertTrue(i2cDeviceConfigurationType != null && i2cDeviceConfigurationType.isDeviceFlavor(ConfigurationType.DeviceFlavor.I2C));
            String createUniqueName = createUniqueName((ConfigurationType) i2cDeviceConfigurationType, R.string.preferred_imu_name, R.string.counted_imu_name, 1);
            LynxI2cDeviceConfiguration lynxI2cDeviceConfiguration = new LynxI2cDeviceConfiguration();
            lynxI2cDeviceConfiguration.setConfigurationType(i2cDeviceConfigurationType);
            lynxI2cDeviceConfiguration.setName(createUniqueName);
            lynxI2cDeviceConfiguration.setEnabled(true);
            lynxI2cDeviceConfiguration.setBus(0);
            buildEmptyLynxModule.getI2cDevices().add(lynxI2cDeviceConfiguration);
        }
        return buildEmptyLynxModule;
    }

    public ServoHubConfiguration buildNewServoHub(int i, int i2, boolean z) {
        return buildEmptyServoHub(createUniqueName((ConfigurationType) BuiltInConfigurationType.SERVO_HUB, R.string.counted_servo_hub_name, i), i, i2, z);
    }

    /* access modifiers changed from: protected */
    public LynxUsbDeviceConfiguration buildNewEmbeddedLynxUsbDevice(DeviceManager deviceManager) {
        LynxModuleMeta lynxModuleMeta = new LynxModuleMeta(LynxConstants.CH_EMBEDDED_MODULE_ADDRESS, true);
        lynxModuleMeta.setRevProductNumber(LynxConstants.EXPANSION_HUB_PRODUCT_NUMBER);
        lynxModuleMeta.setImuType(EmbeddedControlHubModule.getImuType());
        LynxUsbDeviceConfiguration buildNewLynxUsbDevice = buildNewLynxUsbDevice(LynxConstants.SERIAL_NUMBER_EMBEDDED, new LynxModuleMetaList(LynxConstants.SERIAL_NUMBER_EMBEDDED, (Collection<LynxModuleMeta>) Collections.singletonList(lynxModuleMeta)));
        buildNewLynxUsbDevice.setEnabled(true);
        buildNewLynxUsbDevice.setSystemSynthetic(true);
        for (RhspModuleConfiguration systemSynthetic : buildNewLynxUsbDevice.getModules()) {
            systemSynthetic.setSystemSynthetic(true);
        }
        return buildNewLynxUsbDevice;
    }

    protected static List<DeviceConfiguration> buildEmptyDevices(int i, int i2, ConfigurationType configurationType) {
        ArrayList arrayList = new ArrayList();
        for (int i3 = 0; i3 < i2; i3++) {
            arrayList.add(new DeviceConfiguration(i3 + i, configurationType, DeviceConfiguration.DISABLED_DEVICE_NAME, false));
        }
        return arrayList;
    }

    public static List<DeviceConfiguration> buildEmptyMotors(int i, int i2) {
        return buildEmptyDevices(i, i2, MotorConfigurationType.getUnspecifiedMotorType());
    }

    public static List<DeviceConfiguration> buildEmptyServos(int i, int i2) {
        return buildEmptyDevices(i, i2, ServoConfigurationType.getStandardServoType());
    }

    /* access modifiers changed from: protected */
    public LynxModuleConfiguration buildEmptyLynxModule(String str, int i, int i2, boolean z) {
        RobotLog.vv(TAG, "buildEmptyLynxModule() mod#=%d...", Integer.valueOf(i));
        noteExistingName(BuiltInConfigurationType.LYNX_MODULE, str);
        LynxModuleConfiguration lynxModuleConfiguration = new LynxModuleConfiguration(str);
        lynxModuleConfiguration.setModuleAddress(i);
        lynxModuleConfiguration.setParentModuleAddress(i2);
        lynxModuleConfiguration.setEnabled(z);
        RobotLog.vv(TAG, "...buildEmptyLynxModule() mod#=%d", Integer.valueOf(i));
        return lynxModuleConfiguration;
    }

    /* access modifiers changed from: protected */
    public ServoHubConfiguration buildEmptyServoHub(String str, int i, int i2, boolean z) {
        RobotLog.vv(TAG, "buildEmptyServoHub() mod#=%d...", Integer.valueOf(i));
        noteExistingName(BuiltInConfigurationType.SERVO_HUB, str);
        ServoHubConfiguration servoHubConfiguration = new ServoHubConfiguration(str);
        servoHubConfiguration.setModuleAddress(i);
        servoHubConfiguration.setParentModuleAddress(i2);
        servoHubConfiguration.setEnabled(z);
        RobotLog.vv(TAG, "...buildEmptyServoHub() mod#=%d", Integer.valueOf(i));
        return servoHubConfiguration;
    }
}

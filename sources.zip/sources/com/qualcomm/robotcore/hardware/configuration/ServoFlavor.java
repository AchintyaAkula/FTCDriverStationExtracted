package com.qualcomm.robotcore.hardware.configuration;

public enum ServoFlavor {
    STANDARD,
    CONTINUOUS,
    CUSTOM
}

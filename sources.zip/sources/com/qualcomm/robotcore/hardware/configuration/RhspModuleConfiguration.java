package com.qualcomm.robotcore.hardware.configuration;

import com.qualcomm.robotcore.util.SerialNumber;
import java.util.List;
import org.firstinspires.ftc.robotcore.internal.usb.LynxModuleSerialNumber;

public abstract class RhspModuleConfiguration extends ControllerConfiguration<DeviceConfiguration> {
    private int parentModuleAddress;
    private SerialNumber usbDeviceSerialNumber = SerialNumber.createFake();

    public abstract boolean isParent();

    public RhspModuleConfiguration(String str, List<DeviceConfiguration> list, SerialNumber serialNumber, ConfigurationType configurationType) {
        super(str, list, serialNumber, configurationType);
    }

    public void setModuleAddress(int i) {
        setPort(i);
    }

    public int getModuleAddress() {
        return getPort();
    }

    public void setParentModuleAddress(int i) {
        this.parentModuleAddress = i;
    }

    public int getParentModuleAddress() {
        return this.parentModuleAddress;
    }

    public void setPort(int i) {
        super.setPort(i);
        setSerialNumber(new LynxModuleSerialNumber(this.usbDeviceSerialNumber, i));
    }

    public void setUsbDeviceSerialNumber(SerialNumber serialNumber) {
        this.usbDeviceSerialNumber = serialNumber;
        setSerialNumber(new LynxModuleSerialNumber(serialNumber, getModuleAddress()));
    }

    public void setSerialNumber(SerialNumber serialNumber) {
        super.setSerialNumber(serialNumber);
    }

    public SerialNumber getUsbDeviceSerialNumber() {
        return this.usbDeviceSerialNumber;
    }

    public SerialNumber getModuleSerialNumber() {
        return getSerialNumber();
    }
}

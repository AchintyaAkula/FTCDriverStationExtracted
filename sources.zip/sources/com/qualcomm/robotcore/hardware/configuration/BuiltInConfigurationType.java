package com.qualcomm.robotcore.hardware.configuration;

import android.content.Context;
import com.qualcomm.ftccommon.configuration.RobotConfigResFilter;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.R;
import com.qualcomm.robotcore.hardware.ControlSystem;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.util.RobotLog;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;

public enum BuiltInConfigurationType implements ConfigurationType {
    GYRO("Gyro", ConfigurationType.DeviceFlavor.I2C),
    COMPASS("Compass", (int) null),
    IR_SEEKER("IrSeeker", (int) null),
    LIGHT_SENSOR("LightSensor", (int) null),
    ACCELEROMETER("Accelerometer", (int) null),
    PULSE_WIDTH_DEVICE("PulseWidthDevice", (int) null),
    IR_SEEKER_V3("IrSeekerV3", ConfigurationType.DeviceFlavor.I2C),
    ULTRASONIC_SENSOR("UltrasonicSensor", (int) null),
    ADAFRUIT_COLOR_SENSOR("AdafruitColorSensor", ConfigurationType.DeviceFlavor.I2C),
    COLOR_SENSOR("ColorSensor", ConfigurationType.DeviceFlavor.I2C),
    LYNX_COLOR_SENSOR("LynxColorSensor", ConfigurationType.DeviceFlavor.I2C),
    LYNX_USB_DEVICE("LynxUsbDevice", (int) null),
    LYNX_MODULE(LynxModule.TAG, (int) null),
    SERVO_HUB("ServoHub", (int) null),
    WEBCAM("Webcam", (int) null),
    ETHERNET_OVER_USB_DEVICE("EthernetDevice", (int) null),
    ROBOT(RobotConfigResFilter.robotConfigRootTag, (int) null),
    NOTHING("Nothing", (int) null),
    UNKNOWN("<unknown>", (int) null);
    
    private static final List<BuiltInConfigurationType> valuesCache = null;
    private final Context context;
    private final ConfigurationType.DeviceFlavor deviceFlavor;
    private final String xmlTag;

    public boolean annotatedClassIsInstantiable() {
        return false;
    }

    public boolean isCompatibleWith(ControlSystem controlSystem) {
        return true;
    }

    static {
        valuesCache = Collections.unmodifiableList(Arrays.asList(values()));
    }

    private BuiltInConfigurationType(String str, ConfigurationType.DeviceFlavor deviceFlavor2) {
        this.context = AppUtil.getDefContext();
        this.xmlTag = str;
        this.deviceFlavor = deviceFlavor2;
    }

    public static BuiltInConfigurationType fromXmlTag(String str) {
        for (BuiltInConfigurationType next : valuesCache) {
            if (str.equalsIgnoreCase(next.xmlTag)) {
                return next;
            }
        }
        return UNKNOWN;
    }

    public static ConfigurationType fromString(String str) {
        for (ConfigurationType next : valuesCache) {
            if (str.equalsIgnoreCase(next.toString())) {
                return next;
            }
        }
        return UNKNOWN;
    }

    public static ConfigurationType fromUSBDeviceType(DeviceManager.UsbDeviceType usbDeviceType) {
        int i = AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType[usbDeviceType.ordinal()];
        if (i == 1) {
            return LYNX_USB_DEVICE;
        }
        if (i != 2) {
            return UNKNOWN;
        }
        return WEBCAM;
    }

    public boolean isDeviceFlavor(ConfigurationType.DeviceFlavor deviceFlavor2) {
        if (deviceFlavor2 == ConfigurationType.DeviceFlavor.BUILT_IN || deviceFlavor2 == this.deviceFlavor) {
            return true;
        }
        return false;
    }

    public ConfigurationType.DeviceFlavor getDeviceFlavor() {
        ConfigurationType.DeviceFlavor deviceFlavor2 = this.deviceFlavor;
        if (deviceFlavor2 != null) {
            return deviceFlavor2;
        }
        return ConfigurationType.DeviceFlavor.BUILT_IN;
    }

    /* renamed from: com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType = null;
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType = null;

        /* JADX WARNING: Can't wrap try/catch for region: R(26:0|(2:1|2)|3|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|(2:23|24)|25|27|28|(3:29|30|32)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(27:0|1|2|3|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|(2:23|24)|25|27|28|(3:29|30|32)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(30:0|1|2|3|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|27|28|29|30|32) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0033 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0054 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x0060 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x006c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0078 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x0095 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x0028 */
        static {
            /*
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType[] r0 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType = r0
                r1 = 1
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r2 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.LYNX_USB_DEVICE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x001d }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.WEBCAM     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.PULSE_WIDTH_DEVICE     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r4 = 3
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.IR_SEEKER_V3     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r4 = 4
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x003e }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.ADAFRUIT_COLOR_SENSOR     // Catch:{ NoSuchFieldError -> 0x003e }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r4 = 5
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0049 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.LYNX_COLOR_SENSOR     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r4 = 6
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0054 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.LYNX_MODULE     // Catch:{ NoSuchFieldError -> 0x0054 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0054 }
                r4 = 7
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0060 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.NOTHING     // Catch:{ NoSuchFieldError -> 0x0060 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0060 }
                r4 = 8
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0060 }
            L_0x0060:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x006c }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.GYRO     // Catch:{ NoSuchFieldError -> 0x006c }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x006c }
                r4 = 9
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x006c }
            L_0x006c:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0078 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.COLOR_SENSOR     // Catch:{ NoSuchFieldError -> 0x0078 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0078 }
                r4 = 10
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0078 }
            L_0x0078:
                int[] r2 = $SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType     // Catch:{ NoSuchFieldError -> 0x0084 }
                com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType r3 = com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.UNKNOWN     // Catch:{ NoSuchFieldError -> 0x0084 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0084 }
                r4 = 11
                r2[r3] = r4     // Catch:{ NoSuchFieldError -> 0x0084 }
            L_0x0084:
                com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType[] r2 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.values()
                int r2 = r2.length
                int[] r2 = new int[r2]
                $SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType = r2
                com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r3 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.LYNX_USB_DEVICE     // Catch:{ NoSuchFieldError -> 0x0095 }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x0095 }
                r2[r3] = r1     // Catch:{ NoSuchFieldError -> 0x0095 }
            L_0x0095:
                int[] r1 = $SwitchMap$com$qualcomm$robotcore$hardware$DeviceManager$UsbDeviceType     // Catch:{ NoSuchFieldError -> 0x009f }
                com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r2 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.WEBCAM     // Catch:{ NoSuchFieldError -> 0x009f }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x009f }
                r1[r2] = r0     // Catch:{ NoSuchFieldError -> 0x009f }
            L_0x009f:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType.AnonymousClass1.<clinit>():void");
        }
    }

    public DeviceManager.UsbDeviceType toUSBDeviceType() {
        int i = AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType[ordinal()];
        if (i == 1) {
            return DeviceManager.UsbDeviceType.LYNX_USB_DEVICE;
        }
        if (i != 2) {
            return DeviceManager.UsbDeviceType.FTDI_USB_UNKNOWN_DEVICE;
        }
        return DeviceManager.UsbDeviceType.WEBCAM;
    }

    public String getName() {
        switch (AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$configuration$BuiltInConfigurationType[ordinal()]) {
            case 1:
                return this.context.getString(R.string.configTypeLynxUSBDevice);
            case 2:
                return this.context.getString(R.string.configTypeWebcam);
            case 3:
                return this.context.getString(R.string.configTypePulseWidthDevice);
            case 4:
                return this.context.getString(R.string.configTypeIrSeekerV3);
            case 5:
                return this.context.getString(R.string.configTypeAdafruitColorSensor);
            case 6:
                return this.context.getString(R.string.configTypeLynxColorSensor);
            case 7:
                return this.context.getString(R.string.configTypeLynxModule);
            case 8:
                return this.context.getString(R.string.configTypeNothing);
            case 9:
                return this.context.getString(R.string.configTypeMRGyro);
            case 10:
                return this.context.getString(R.string.configTypeMRColorSensor);
            default:
                return this.context.getString(R.string.configTypeUnknown);
        }
    }

    public boolean isDeprecated() {
        try {
            return BuiltInConfigurationType.class.getField(toString()).isAnnotationPresent(Deprecated.class);
        } catch (NoSuchFieldException e) {
            RobotLog.logStackTrace(e);
            return false;
        }
    }

    public ConfigurationTypeManager.ClassSource getClassSource() {
        return ConfigurationTypeManager.ClassSource.APK;
    }

    public String getXmlTag() {
        return this.xmlTag;
    }
}

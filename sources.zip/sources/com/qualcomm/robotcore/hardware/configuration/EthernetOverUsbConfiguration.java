package com.qualcomm.robotcore.hardware.configuration;

import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.LinkedList;
import org.firstinspires.inspection.InspectionState;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlSerializer;

public class EthernetOverUsbConfiguration extends ControllerConfiguration<DeviceConfiguration> {
    private static final int LIMELIGHT_DEFAULT_INDEX = 1;
    public static final String TAG = "EthernetOverUsbConfiguration";
    public static final String XMLATTR_IPADDRESS = "ipAddress";
    protected InetAddress ipAddress;

    public EthernetOverUsbConfiguration() {
        this(InspectionState.NO_VERSION, SerialNumber.createFake(), "172.0.0.1");
    }

    public EthernetOverUsbConfiguration(String str, SerialNumber serialNumber, String str2) {
        super(str, new LinkedList(), serialNumber, BuiltInConfigurationType.ETHERNET_OVER_USB_DEVICE);
        setKnownToBeAttached(true);
        try {
            this.ipAddress = swapFourthOctet(InetAddress.getByName(str2), 1);
        } catch (UnknownHostException e) {
            RobotLog.ee(TAG, "Invalid IP address: ", e.getMessage());
        }
    }

    private static InetAddress swapFourthOctet(InetAddress inetAddress, int i) throws UnknownHostException {
        if (i < 1 || i > 16) {
            throw new IllegalArgumentException("X must be between 1 and 16.");
        }
        byte[] address = inetAddress.getAddress();
        if (address.length == 4) {
            address[3] = (byte) i;
            return InetAddress.getByAddress(address);
        }
        throw new IllegalArgumentException("Invalid IP address format.");
    }

    public InetAddress getIpAddress() {
        return this.ipAddress;
    }

    public void setIpAddress(InetAddress inetAddress) {
        this.ipAddress = inetAddress;
    }

    public void serializeXmlAttributes(XmlSerializer xmlSerializer) {
        try {
            super.serializeXmlAttributes(xmlSerializer);
            xmlSerializer.attribute(InspectionState.NO_VERSION, XMLATTR_IPADDRESS, getIpAddress().getHostAddress());
        } catch (Exception e) {
            RobotLog.ee(TAG, (Throwable) e, "exception serializing");
            throw new RuntimeException(e);
        }
    }

    public void deserializeAttributes(XmlPullParser xmlPullParser) {
        super.deserializeAttributes(xmlPullParser);
        try {
            setIpAddress(InetAddress.getByName(xmlPullParser.getAttributeValue((String) null, XMLATTR_IPADDRESS)));
        } catch (UnknownHostException e) {
            RobotLog.ee(TAG, "Invalid IP address: ", e.getMessage());
        }
    }
}

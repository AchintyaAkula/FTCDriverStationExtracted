package com.qualcomm.robotcore.hardware.configuration;

import android.util.Xml;
import com.qualcomm.ftccommon.configuration.RobotConfigResFilter;
import com.qualcomm.robotcore.exception.DuplicateNameException;
import com.qualcomm.robotcore.exception.RobotCoreException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.function.ThrowingRunnable;
import org.firstinspires.inspection.InspectionState;
import org.xmlpull.v1.XmlSerializer;

public class WriteXMLFileHandler {
    private List<String> duplicates = new ArrayList();
    private int indent = 0;
    private String[] indentation = {"    ", "        ", "            "};
    private HashSet<String> names = new HashSet<>();
    /* access modifiers changed from: private */
    public XmlSerializer serializer = Xml.newSerializer();

    public String toXml(Collection<ControllerConfiguration> collection, boolean z) {
        return toXml(collection, (String) null, (String) null, z);
    }

    public String toXml(Collection<ControllerConfiguration> collection, String str, String str2, boolean z) {
        this.duplicates = new ArrayList();
        this.names = new HashSet<>();
        StringWriter stringWriter = new StringWriter();
        try {
            this.serializer.setOutput(stringWriter);
            this.serializer.startDocument("UTF-8", true);
            this.serializer.ignorableWhitespace("\n");
            this.serializer.startTag(InspectionState.NO_VERSION, RobotConfigResFilter.robotConfigRootTag);
            if (str != null) {
                this.serializer.attribute(InspectionState.NO_VERSION, str, str2);
            }
            this.serializer.ignorableWhitespace("\n");
            for (ControllerConfiguration next : collection) {
                ConfigurationType configurationType = next.getConfigurationType();
                if (configurationType == BuiltInConfigurationType.LYNX_USB_DEVICE) {
                    writeLynxUSBDevice((LynxUsbDeviceConfiguration) next);
                } else if (configurationType == BuiltInConfigurationType.WEBCAM) {
                    writeWebcam((WebcamConfiguration) next);
                } else if (configurationType == BuiltInConfigurationType.ETHERNET_OVER_USB_DEVICE) {
                    writeEthernetOverUsbDevice((EthernetOverUsbConfiguration) next);
                }
            }
            this.serializer.endTag(InspectionState.NO_VERSION, RobotConfigResFilter.robotConfigRootTag);
            this.serializer.ignorableWhitespace("\n");
            this.serializer.endDocument();
            if (!z) {
                if (!this.duplicates.isEmpty()) {
                    throw new DuplicateNameException("duplicate names: " + this.duplicates);
                }
            }
            return stringWriter.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void checkForDuplicates(DeviceConfiguration deviceConfiguration) {
        if (deviceConfiguration.isEnabled()) {
            String name = deviceConfiguration.getName();
            if (this.names.contains(name)) {
                this.duplicates.add(name);
            } else {
                this.names.add(name);
            }
        }
    }

    private void writeWebcam(final WebcamConfiguration webcamConfiguration) throws IOException {
        writeUsbController(webcamConfiguration, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                if (webcamConfiguration.getAutoOpen()) {
                    WriteXMLFileHandler.this.serializer.attribute(InspectionState.NO_VERSION, WebcamConfiguration.XMLATTR_AUTO_OPEN_CAMERA, String.valueOf(webcamConfiguration.getAutoOpen()));
                }
            }
        }, (ThrowingRunnable<IOException>) null);
    }

    private void writeEthernetOverUsbDevice(final EthernetOverUsbConfiguration ethernetOverUsbConfiguration) throws IOException {
        writeUsbController(ethernetOverUsbConfiguration, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                ethernetOverUsbConfiguration.serializeXmlAttributes(WriteXMLFileHandler.this.serializer);
            }
        }, (ThrowingRunnable<IOException>) null);
    }

    private void writeLynxUSBDevice(final LynxUsbDeviceConfiguration lynxUsbDeviceConfiguration) throws IOException {
        writeUsbController(lynxUsbDeviceConfiguration, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                WriteXMLFileHandler.this.serializer.attribute(InspectionState.NO_VERSION, LynxUsbDeviceConfiguration.XMLATTR_PARENT_MODULE_ADDRESS, Integer.toString(lynxUsbDeviceConfiguration.getParentModuleAddress()));
            }
        }, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                for (DeviceConfiguration deviceConfiguration : lynxUsbDeviceConfiguration.getDevices()) {
                    ConfigurationType configurationType = deviceConfiguration.getConfigurationType();
                    if (configurationType == BuiltInConfigurationType.LYNX_MODULE) {
                        WriteXMLFileHandler.this.writeController((LynxModuleConfiguration) deviceConfiguration, false);
                    } else if (configurationType == BuiltInConfigurationType.SERVO_HUB) {
                        WriteXMLFileHandler.this.writeController((ServoHubConfiguration) deviceConfiguration, false);
                    } else {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(deviceConfiguration);
                    }
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public <CONTROLLER_T extends ControllerConfiguration<? extends DeviceConfiguration>> void writeController(final CONTROLLER_T controller_t, final boolean z) throws IOException {
        writeNamedController(controller_t, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                if (z) {
                    WriteXMLFileHandler.this.serializer.attribute(InspectionState.NO_VERSION, "serialNumber", controller_t.getSerialNumber().getString());
                } else {
                    WriteXMLFileHandler.this.serializer.attribute(InspectionState.NO_VERSION, DeviceConfiguration.XMLATTR_PORT, String.valueOf(controller_t.getPort()));
                }
            }
        }, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                if (controller_t.getConfigurationType() == BuiltInConfigurationType.LYNX_MODULE) {
                    LynxModuleConfiguration lynxModuleConfiguration = (LynxModuleConfiguration) controller_t;
                    for (DeviceConfiguration access$200 : lynxModuleConfiguration.getMotors()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$200);
                    }
                    for (DeviceConfiguration access$2002 : lynxModuleConfiguration.getServos()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2002);
                    }
                    for (DeviceConfiguration access$2003 : lynxModuleConfiguration.getAnalogInputs()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2003);
                    }
                    for (DeviceConfiguration access$2004 : lynxModuleConfiguration.getPwmOutputs()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2004);
                    }
                    for (DeviceConfiguration access$2005 : lynxModuleConfiguration.getDigitalDevices()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2005);
                    }
                    for (LynxI2cDeviceConfiguration access$2006 : lynxModuleConfiguration.getI2cDevices()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2006);
                    }
                } else if (controller_t.getConfigurationType() == BuiltInConfigurationType.SERVO_HUB) {
                    for (DeviceConfiguration access$2007 : ((ServoHubConfiguration) controller_t).getServos()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2007);
                    }
                } else {
                    for (DeviceConfiguration access$2008 : controller_t.getDevices()) {
                        WriteXMLFileHandler.this.writeDeviceNameAndPort(access$2008);
                    }
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public void writeDeviceNameAndPort(final DeviceConfiguration deviceConfiguration) throws IOException {
        if (deviceConfiguration.isEnabled()) {
            writeDevice(deviceConfiguration, new ThrowingRunnable<IOException>() {
                public void run() throws IOException {
                    deviceConfiguration.serializeXmlAttributes(WriteXMLFileHandler.this.serializer);
                }
            }, (ThrowingRunnable<IOException>) null);
        }
    }

    private void writeUsbController(final ControllerConfiguration controllerConfiguration, final ThrowingRunnable<IOException> throwingRunnable, ThrowingRunnable<IOException> throwingRunnable2) throws IOException {
        writeNamedController(controllerConfiguration, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                WriteXMLFileHandler.this.serializer.attribute(InspectionState.NO_VERSION, "serialNumber", controllerConfiguration.getSerialNumber().getString());
                ThrowingRunnable throwingRunnable = throwingRunnable;
                if (throwingRunnable != null) {
                    throwingRunnable.run();
                }
            }
        }, throwingRunnable2);
    }

    private void writeNamedController(final ControllerConfiguration controllerConfiguration, final ThrowingRunnable<IOException> throwingRunnable, ThrowingRunnable<IOException> throwingRunnable2) throws IOException {
        writeDevice(controllerConfiguration, new ThrowingRunnable<IOException>() {
            public void run() throws IOException {
                WriteXMLFileHandler.this.serializer.attribute(InspectionState.NO_VERSION, "name", controllerConfiguration.getName());
                ThrowingRunnable throwingRunnable = throwingRunnable;
                if (throwingRunnable != null) {
                    throwingRunnable.run();
                }
            }
        }, throwingRunnable2);
    }

    private void writeDevice(DeviceConfiguration deviceConfiguration, ThrowingRunnable<IOException> throwingRunnable, ThrowingRunnable<IOException> throwingRunnable2) throws IOException {
        this.serializer.ignorableWhitespace(this.indentation[this.indent]);
        this.serializer.startTag(InspectionState.NO_VERSION, conform(deviceConfiguration.getConfigurationType()));
        checkForDuplicates(deviceConfiguration);
        if (throwingRunnable != null) {
            throwingRunnable.run();
        }
        if (throwingRunnable2 != null) {
            this.serializer.ignorableWhitespace("\n");
            this.indent++;
            throwingRunnable2.run();
            int i = this.indent - 1;
            this.indent = i;
            this.serializer.ignorableWhitespace(this.indentation[i]);
        }
        this.serializer.endTag(InspectionState.NO_VERSION, conform(deviceConfiguration.getConfigurationType()));
        this.serializer.ignorableWhitespace("\n");
    }

    public void writeToFile(String str, File file, String str2) throws RobotCoreException, IOException {
        if (!file.exists() ? file.mkdir() : true) {
            FileOutputStream fileOutputStream = new FileOutputStream(new File(file, str2));
            try {
                fileOutputStream.write(str.getBytes());
                fileOutputStream.close();
                return;
            } catch (Throwable th) {
                th.addSuppressed(th);
            }
        } else {
            throw new RobotCoreException("Unable to create directory");
        }
        throw th;
    }

    private String conform(ConfigurationType configurationType) {
        return configurationType.getXmlTag();
    }
}

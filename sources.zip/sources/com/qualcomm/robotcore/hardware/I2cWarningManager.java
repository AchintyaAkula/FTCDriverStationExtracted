package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.util.GlobalWarningSource;
import com.qualcomm.robotcore.util.RobotLog;
import java.util.HashSet;

public class I2cWarningManager implements GlobalWarningSource {
    private static final I2cWarningManager instance;
    private static final Object lock = new Object();
    private static int newProblemDeviceSuppressionCount = 0;
    private final HashSet<I2cDeviceSynchSimple> problemDevices = new HashSet<>();
    private int warningSourceSuppressionCount = 0;

    public void setGlobalWarning(String str) {
    }

    public boolean shouldTriggerWarningSound() {
        return true;
    }

    static {
        I2cWarningManager i2cWarningManager = new I2cWarningManager();
        instance = i2cWarningManager;
        RobotLog.registerGlobalWarningSource(i2cWarningManager);
    }

    public static void notifyProblemI2cDevice(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        if (i2cDeviceSynchSimple instanceof I2cDeviceSynchImplOnSimple) {
            notifyProblemI2cDevice(((I2cDeviceSynchImplOnSimple) i2cDeviceSynchSimple).i2cDeviceSynchSimple);
            return;
        }
        synchronized (lock) {
            if (newProblemDeviceSuppressionCount == 0) {
                instance.problemDevices.add(i2cDeviceSynchSimple);
            }
        }
    }

    public static void removeProblemI2cDevice(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        if (i2cDeviceSynchSimple instanceof I2cDeviceSynchImplOnSimple) {
            removeProblemI2cDevice(((I2cDeviceSynchImplOnSimple) i2cDeviceSynchSimple).i2cDeviceSynchSimple);
            return;
        }
        synchronized (lock) {
            I2cWarningManager i2cWarningManager = instance;
            if (!i2cWarningManager.problemDevices.isEmpty()) {
                i2cWarningManager.problemDevices.remove(i2cDeviceSynchSimple);
            }
        }
    }

    public static void suppressNewProblemDeviceWarningsWhile(Runnable runnable) {
        Object obj = lock;
        synchronized (obj) {
            newProblemDeviceSuppressionCount++;
        }
        try {
            runnable.run();
            synchronized (obj) {
                newProblemDeviceSuppressionCount--;
            }
        } catch (Throwable th) {
            synchronized (lock) {
                newProblemDeviceSuppressionCount--;
                throw th;
            }
        }
    }

    public static void suppressNewProblemDeviceWarnings(boolean z) {
        synchronized (lock) {
            if (z) {
                newProblemDeviceSuppressionCount++;
            } else {
                newProblemDeviceSuppressionCount--;
            }
        }
    }

    public static void clearI2cWarnings() {
        instance.clearGlobalWarning();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x006c, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String getGlobalWarning() {
        /*
            r5 = this;
            java.lang.Object r0 = lock
            monitor-enter(r0)
            java.util.HashSet<com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple> r1 = r5.problemDevices     // Catch:{ all -> 0x006e }
            boolean r1 = r1.isEmpty()     // Catch:{ all -> 0x006e }
            if (r1 != 0) goto L_0x006b
            int r1 = r5.warningSourceSuppressionCount     // Catch:{ all -> 0x006e }
            if (r1 <= 0) goto L_0x0010
            goto L_0x006b
        L_0x0010:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x006e }
            r1.<init>()     // Catch:{ all -> 0x006e }
            android.app.Application r2 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getDefContext()     // Catch:{ all -> 0x006e }
            int r3 = com.qualcomm.robotcore.R.string.warningI2cCommError     // Catch:{ all -> 0x006e }
            java.lang.String r2 = r2.getString(r3)     // Catch:{ all -> 0x006e }
            r1.append(r2)     // Catch:{ all -> 0x006e }
            java.lang.String r2 = " "
            r1.append(r2)     // Catch:{ all -> 0x006e }
            java.util.HashSet<com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple> r2 = r5.problemDevices     // Catch:{ all -> 0x006e }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ all -> 0x006e }
        L_0x002d:
            boolean r3 = r2.hasNext()     // Catch:{ all -> 0x006e }
            if (r3 == 0) goto L_0x0060
            java.lang.Object r3 = r2.next()     // Catch:{ all -> 0x006e }
            com.qualcomm.robotcore.hardware.HardwareDevice r3 = (com.qualcomm.robotcore.hardware.HardwareDevice) r3     // Catch:{ all -> 0x006e }
            com.qualcomm.robotcore.hardware.RobotConfigNameable r3 = (com.qualcomm.robotcore.hardware.RobotConfigNameable) r3     // Catch:{ all -> 0x006e }
            java.lang.String r3 = r3.getUserConfiguredName()     // Catch:{ all -> 0x006e }
            if (r3 == 0) goto L_0x004e
            java.lang.String r4 = "'"
            r1.append(r4)     // Catch:{ all -> 0x006e }
            r1.append(r3)     // Catch:{ all -> 0x006e }
            java.lang.String r3 = "'"
            r1.append(r3)     // Catch:{ all -> 0x006e }
        L_0x004e:
            boolean r3 = r2.hasNext()     // Catch:{ all -> 0x006e }
            if (r3 == 0) goto L_0x005a
            java.lang.String r3 = ", "
            r1.append(r3)     // Catch:{ all -> 0x006e }
            goto L_0x002d
        L_0x005a:
            java.lang.String r3 = ". "
            r1.append(r3)     // Catch:{ all -> 0x006e }
            goto L_0x002d
        L_0x0060:
            java.lang.String r2 = "Check your wiring and configuration."
            r1.append(r2)     // Catch:{ all -> 0x006e }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x006e }
            monitor-exit(r0)     // Catch:{ all -> 0x006e }
            return r1
        L_0x006b:
            monitor-exit(r0)     // Catch:{ all -> 0x006e }
            r0 = 0
            return r0
        L_0x006e:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x006e }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.I2cWarningManager.getGlobalWarning():java.lang.String");
    }

    public void suppressGlobalWarning(boolean z) {
        synchronized (lock) {
            if (z) {
                this.warningSourceSuppressionCount++;
            } else {
                this.warningSourceSuppressionCount--;
            }
        }
    }

    public void clearGlobalWarning() {
        synchronized (lock) {
            this.problemDevices.clear();
        }
    }
}

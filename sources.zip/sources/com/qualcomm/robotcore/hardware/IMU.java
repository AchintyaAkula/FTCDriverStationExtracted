package com.qualcomm.robotcore.hardware;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;

public interface IMU extends HardwareDevice {
    AngularVelocity getRobotAngularVelocity(AngleUnit angleUnit);

    Orientation getRobotOrientation(AxesReference axesReference, AxesOrder axesOrder, AngleUnit angleUnit);

    Quaternion getRobotOrientationAsQuaternion();

    YawPitchRollAngles getRobotYawPitchRollAngles();

    boolean initialize(Parameters parameters);

    void resetYaw();

    public static class Parameters {
        public ImuOrientationOnRobot imuOrientationOnRobot;

        public Parameters(ImuOrientationOnRobot imuOrientationOnRobot2) {
            this.imuOrientationOnRobot = imuOrientationOnRobot2;
        }

        public Parameters copy() {
            return new Parameters(this.imuOrientationOnRobot);
        }
    }
}

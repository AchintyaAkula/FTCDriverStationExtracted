package com.qualcomm.robotcore.hardware;

public interface SwitchableLight extends Light {
    void enableLight(boolean z);
}

package com.qualcomm.robotcore.hardware;

public interface VisuallyIdentifiableHardwareDevice {
    void visuallyIdentify(boolean z);
}

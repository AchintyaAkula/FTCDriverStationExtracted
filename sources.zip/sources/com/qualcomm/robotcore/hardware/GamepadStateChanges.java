package com.qualcomm.robotcore.hardware;

class GamepadStateChanges {
    protected ButtonStateMonitor a = new ButtonStateMonitor();
    protected ButtonStateMonitor b = new ButtonStateMonitor();
    protected ButtonStateMonitor back = new ButtonStateMonitor();
    protected ButtonStateMonitor circle = new ButtonStateMonitor();
    protected ButtonStateMonitor cross = new ButtonStateMonitor();
    protected ButtonStateMonitor dpadDown = new ButtonStateMonitor();
    protected ButtonStateMonitor dpadLeft = new ButtonStateMonitor();
    protected ButtonStateMonitor dpadRight = new ButtonStateMonitor();
    protected ButtonStateMonitor dpadUp = new ButtonStateMonitor();
    protected ButtonStateMonitor guide = new ButtonStateMonitor();
    protected ButtonStateMonitor leftBumper = new ButtonStateMonitor();
    protected ButtonStateMonitor leftStickButton = new ButtonStateMonitor();
    protected ButtonStateMonitor options = new ButtonStateMonitor();
    protected ButtonStateMonitor ps = new ButtonStateMonitor();
    protected ButtonStateMonitor rightBumper = new ButtonStateMonitor();
    protected ButtonStateMonitor rightStickButton = new ButtonStateMonitor();
    protected ButtonStateMonitor share = new ButtonStateMonitor();
    protected ButtonStateMonitor square = new ButtonStateMonitor();
    protected ButtonStateMonitor start = new ButtonStateMonitor();
    protected ButtonStateMonitor touchpad = new ButtonStateMonitor();
    protected ButtonStateMonitor triangle = new ButtonStateMonitor();
    protected ButtonStateMonitor x = new ButtonStateMonitor();
    protected ButtonStateMonitor y = new ButtonStateMonitor();

    GamepadStateChanges() {
    }

    protected class ButtonStateMonitor {
        private boolean lastPressed = false;
        private boolean pressNotify = false;
        private boolean releaseNotify = false;

        protected ButtonStateMonitor() {
        }

        /* access modifiers changed from: private */
        public void update(boolean z) {
            boolean z2 = this.lastPressed;
            if (!z2 && z) {
                this.pressNotify = true;
            }
            if (z2 && !z) {
                this.releaseNotify = true;
            }
            this.lastPressed = z;
        }

        /* access modifiers changed from: protected */
        public boolean wasPressed() {
            boolean z = this.pressNotify;
            this.pressNotify = false;
            return z;
        }

        /* access modifiers changed from: protected */
        public boolean wasReleased() {
            boolean z = this.releaseNotify;
            this.releaseNotify = false;
            return z;
        }
    }

    /* access modifiers changed from: protected */
    public void updateAllButtons(Gamepad gamepad) {
        this.dpadUp.update(gamepad.dpad_up);
        this.dpadDown.update(gamepad.dpad_down);
        this.dpadLeft.update(gamepad.dpad_left);
        this.dpadRight.update(gamepad.dpad_right);
        this.a.update(gamepad.a);
        this.b.update(gamepad.b);
        this.x.update(gamepad.x);
        this.y.update(gamepad.y);
        this.guide.update(gamepad.guide);
        this.start.update(gamepad.start);
        this.back.update(gamepad.back);
        this.leftBumper.update(gamepad.left_bumper);
        this.rightBumper.update(gamepad.right_bumper);
        this.leftStickButton.update(gamepad.left_stick_button);
        this.rightStickButton.update(gamepad.right_stick_button);
        this.circle.update(gamepad.circle);
        this.cross.update(gamepad.cross);
        this.triangle.update(gamepad.triangle);
        this.square.update(gamepad.square);
        this.share.update(gamepad.share);
        this.options.update(gamepad.options);
        this.touchpad.update(gamepad.touchpad);
        this.ps.update(gamepad.ps);
    }
}

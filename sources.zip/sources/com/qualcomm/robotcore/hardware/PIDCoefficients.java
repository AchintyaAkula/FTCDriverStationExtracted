package com.qualcomm.robotcore.hardware;

import com.qualcomm.hardware.lynx.LynxServoController;
import org.firstinspires.ftc.robotcore.internal.system.Misc;

public class PIDCoefficients {
    public double d;
    public double i;
    public double p;

    public String toString() {
        return Misc.formatForUser("%s(p=%f i=%f d=%f)", getClass().getSimpleName(), Double.valueOf(this.p), Double.valueOf(this.i), Double.valueOf(this.d));
    }

    public PIDCoefficients() {
        this.d = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.p = LynxServoController.apiPositionFirst;
    }

    public PIDCoefficients(double d2, double d3, double d4) {
        this.p = d2;
        this.i = d3;
        this.d = d4;
    }
}

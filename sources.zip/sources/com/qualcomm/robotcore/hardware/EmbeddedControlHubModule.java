package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.util.RobotLog;

public class EmbeddedControlHubModule {
    public static final String TAG = "EmbeddedControlHubModule";
    protected static volatile LynxModuleImuType embeddedImuType = LynxModuleImuType.UNKNOWN;
    protected static volatile RobotCoreLynxModule embeddedLynxModule;

    public static RobotCoreLynxModule get() {
        return embeddedLynxModule;
    }

    public static void set(RobotCoreLynxModule robotCoreLynxModule) {
        RobotLog.vv(TAG, "setting embedded module");
        embeddedLynxModule = robotCoreLynxModule;
    }

    public static LynxModuleImuType getImuType() {
        return embeddedImuType;
    }

    public static void setImuType(LynxModuleImuType lynxModuleImuType) {
        RobotLog.vv(TAG, "setting embedded IMU type");
        embeddedImuType = lynxModuleImuType;
    }

    public static void clear() {
        RobotLog.vv(TAG, "clearing embedded module");
        embeddedLynxModule = null;
    }
}

package com.qualcomm.robotcore.hardware;

import android.content.Context;
import com.qualcomm.robotcore.R;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpModeManagerNotifier;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.Assert;

public class HardwareMap implements Iterable<HardwareDevice> {
    private static final String LOG_FORMAT = "%-50s %-30s %s";
    private static final String TAG = "HardwareMap";
    private static final Class<I2cDeviceSynchDevice> i2cDriverBaseClass = I2cDeviceSynchDevice.class;
    public DeviceMapping<AccelerationSensor> accelerationSensor = new DeviceMapping<>(AccelerationSensor.class);
    public final List<DeviceMapping<? extends HardwareDevice>> allDeviceMappings;
    protected List<HardwareDevice> allDevicesList = null;
    protected Map<String, List<HardwareDevice>> allDevicesMap = new HashMap();
    public DeviceMapping<AnalogInput> analogInput = new DeviceMapping<>(AnalogInput.class);
    public final Context appContext;
    public DeviceMapping<ColorSensor> colorSensor = new DeviceMapping<>(ColorSensor.class);
    public DeviceMapping<CompassSensor> compassSensor = new DeviceMapping<>(CompassSensor.class);
    public DeviceMapping<CRServo> crservo = new DeviceMapping<>(CRServo.class);
    public DeviceMapping<DcMotor> dcMotor = new DeviceMapping<>(DcMotor.class);
    public DeviceMapping<DcMotorController> dcMotorController = new DeviceMapping<>(DcMotorController.class);
    protected Map<HardwareDevice, Set<String>> deviceNames = new HashMap();
    protected Map<String, List<DeviceInstancesFromSingleConfigEntry>> devicesWithMultipleDriversMap = new HashMap();
    public DeviceMapping<DigitalChannel> digitalChannel = new DeviceMapping<>(DigitalChannel.class);
    public DeviceMapping<GyroSensor> gyroSensor = new DeviceMapping<>(GyroSensor.class);
    public DeviceMapping<I2cDevice> i2cDevice = new DeviceMapping<>(I2cDevice.class);
    public DeviceMapping<I2cDeviceSynch> i2cDeviceSynch = new DeviceMapping<>(I2cDeviceSynch.class);
    public DeviceMapping<IrSeekerSensor> irSeekerSensor = new DeviceMapping<>(IrSeekerSensor.class);
    public DeviceMapping<LED> led = new DeviceMapping<>(LED.class);
    public DeviceMapping<LightSensor> lightSensor = new DeviceMapping<>(LightSensor.class);
    protected final Object lock = new Object();
    private final OpModeManagerNotifier.Notifications opModeNotifications;
    public DeviceMapping<OpticalDistanceSensor> opticalDistanceSensor = new DeviceMapping<>(OpticalDistanceSensor.class);
    public DeviceMapping<PWMOutput> pwmOutput = new DeviceMapping<>(PWMOutput.class);
    protected Map<SerialNumber, HardwareDevice> serialNumberMap = new HashMap();
    public DeviceMapping<Servo> servo = new DeviceMapping<>(Servo.class);
    public DeviceMapping<ServoController> servoController = new DeviceMapping<>(ServoController.class);
    public DeviceMapping<TouchSensor> touchSensor = new DeviceMapping<>(TouchSensor.class);
    public DeviceMapping<TouchSensorMultiplexer> touchSensorMultiplexer = new DeviceMapping<>(TouchSensorMultiplexer.class);
    public DeviceMapping<UltrasonicSensor> ultrasonicSensor = new DeviceMapping<>(UltrasonicSensor.class);
    public DeviceMapping<VoltageSensor> voltageSensor = new DeviceMapping<>(VoltageSensor.class);

    public HardwareMap(Context context, OpModeManagerNotifier opModeManagerNotifier) {
        this.appContext = context;
        ArrayList arrayList = new ArrayList(30);
        this.allDeviceMappings = arrayList;
        arrayList.add(this.dcMotorController);
        arrayList.add(this.dcMotor);
        arrayList.add(this.servoController);
        arrayList.add(this.servo);
        arrayList.add(this.crservo);
        arrayList.add(this.touchSensorMultiplexer);
        arrayList.add(this.analogInput);
        arrayList.add(this.digitalChannel);
        arrayList.add(this.opticalDistanceSensor);
        arrayList.add(this.touchSensor);
        arrayList.add(this.pwmOutput);
        arrayList.add(this.i2cDevice);
        arrayList.add(this.i2cDeviceSynch);
        arrayList.add(this.colorSensor);
        arrayList.add(this.led);
        arrayList.add(this.accelerationSensor);
        arrayList.add(this.compassSensor);
        arrayList.add(this.gyroSensor);
        arrayList.add(this.irSeekerSensor);
        arrayList.add(this.lightSensor);
        arrayList.add(this.ultrasonicSensor);
        arrayList.add(this.voltageSensor);
        AnonymousClass1 r3 = new OpModeManagerNotifier.Notifications() {
            public void onOpModePostStop(OpMode opMode) {
            }

            public void onOpModePreStart(OpMode opMode) {
            }

            public void onOpModePreInit(OpMode opMode) {
                synchronized (HardwareMap.this.lock) {
                    RobotLog.dd(HardwareMap.TAG, "Clearing which device instances have been retrieved");
                    for (List<DeviceInstancesFromSingleConfigEntry> it : HardwareMap.this.devicesWithMultipleDriversMap.values()) {
                        for (DeviceInstancesFromSingleConfigEntry deviceInstancesFromSingleConfigEntry : it) {
                            for (DeviceInstanceHolder deviceInstanceHolder : deviceInstancesFromSingleConfigEntry.deviceInstanceHolders) {
                                deviceInstanceHolder.hasBeenRetrieved = false;
                            }
                        }
                    }
                }
            }
        };
        this.opModeNotifications = r3;
        if (opModeManagerNotifier != null) {
            opModeManagerNotifier.registerListener(r3);
        }
    }

    public <T> T get(Class<? extends T> cls, String str) {
        T tryGet;
        synchronized (this.lock) {
            String trim = str.trim();
            tryGet = tryGet(cls, trim);
            if (tryGet == null) {
                throw new IllegalArgumentException(String.format("Unable to find a hardware device with name \"%s\" and type %s", new Object[]{trim, cls.getSimpleName()}));
            }
        }
        return tryGet;
    }

    /* JADX WARNING: Removed duplicated region for block: B:37:0x00a6 A[LOOP:2: B:37:0x00a6->B:40:0x00b9, LOOP_START] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <T> T tryGet(java.lang.Class<? extends T> r8, java.lang.String r9) {
        /*
            r7 = this;
            java.lang.Object r0 = r7.lock
            monitor-enter(r0)
            java.lang.String r9 = r9.trim()     // Catch:{ all -> 0x00bd }
            java.util.Map<java.lang.String, java.util.List<com.qualcomm.robotcore.hardware.HardwareDevice>> r1 = r7.allDevicesMap     // Catch:{ all -> 0x00bd }
            java.lang.Object r1 = r1.get(r9)     // Catch:{ all -> 0x00bd }
            java.util.List r1 = (java.util.List) r1     // Catch:{ all -> 0x00bd }
            if (r1 == 0) goto L_0x002f
            java.util.Iterator r1 = r1.iterator()     // Catch:{ all -> 0x00bd }
        L_0x0015:
            boolean r2 = r1.hasNext()     // Catch:{ all -> 0x00bd }
            if (r2 == 0) goto L_0x002f
            java.lang.Object r2 = r1.next()     // Catch:{ all -> 0x00bd }
            com.qualcomm.robotcore.hardware.HardwareDevice r2 = (com.qualcomm.robotcore.hardware.HardwareDevice) r2     // Catch:{ all -> 0x00bd }
            boolean r3 = r8.isInstance(r2)     // Catch:{ all -> 0x00bd }
            if (r3 == 0) goto L_0x0015
            r7.initializeDeviceIfNecessary(r2)     // Catch:{ all -> 0x00bd }
            java.lang.Object r1 = r8.cast(r2)     // Catch:{ all -> 0x00bd }
            goto L_0x0030
        L_0x002f:
            r1 = 0
        L_0x0030:
            boolean r2 = com.qualcomm.robotcore.util.Device.isRevControlHub()     // Catch:{ all -> 0x00bd }
            if (r2 == 0) goto L_0x0090
            if (r1 != 0) goto L_0x0090
            java.lang.String r2 = r8.getSimpleName()     // Catch:{ all -> 0x00bd }
            java.lang.String r3 = "BNO055"
            boolean r2 = r2.contains(r3)     // Catch:{ all -> 0x00bd }
            if (r2 != 0) goto L_0x0050
            java.lang.String r8 = r8.getSimpleName()     // Catch:{ all -> 0x00bd }
            java.lang.String r2 = "LynxEmbeddedIMU"
            boolean r8 = r8.contains(r2)     // Catch:{ all -> 0x00bd }
            if (r8 == 0) goto L_0x0090
        L_0x0050:
            java.util.Iterator r8 = r7.iterator()     // Catch:{ all -> 0x00bd }
            r2 = 0
            r3 = r2
        L_0x0056:
            boolean r4 = r8.hasNext()     // Catch:{ all -> 0x00bd }
            if (r4 == 0) goto L_0x0087
            java.lang.Object r4 = r8.next()     // Catch:{ all -> 0x00bd }
            com.qualcomm.robotcore.hardware.HardwareDevice r4 = (com.qualcomm.robotcore.hardware.HardwareDevice) r4     // Catch:{ all -> 0x00bd }
            java.lang.Class r4 = r4.getClass()     // Catch:{ all -> 0x00bd }
            java.lang.String r4 = r4.getSimpleName()     // Catch:{ all -> 0x00bd }
            java.lang.String r5 = "BHI260"
            boolean r5 = r4.contains(r5)     // Catch:{ all -> 0x00bd }
            r6 = 1
            if (r5 == 0) goto L_0x0075
            r2 = r6
            goto L_0x0056
        L_0x0075:
            java.lang.String r5 = "BNO055"
            boolean r5 = r4.contains(r5)     // Catch:{ all -> 0x00bd }
            if (r5 != 0) goto L_0x0085
            java.lang.String r5 = "LynxEmbeddedIMU"
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x00bd }
            if (r4 == 0) goto L_0x0056
        L_0x0085:
            r3 = r6
            goto L_0x0056
        L_0x0087:
            if (r2 == 0) goto L_0x0090
            if (r3 != 0) goto L_0x0090
            java.lang.String r8 = "You attempted to use the BNO055 interface when only a BHI260AP IMU is configured. This Control Hub contains a BHI260AP IMU, and you need to update your code to use the IMU interface rather than the BNO055 interface."
            com.qualcomm.robotcore.util.RobotLog.addGlobalWarningMessage(r8)     // Catch:{ all -> 0x00bd }
        L_0x0090:
            if (r1 == 0) goto L_0x00bb
            java.util.Map<java.lang.String, java.util.List<com.qualcomm.robotcore.hardware.HardwareMap$DeviceInstancesFromSingleConfigEntry>> r8 = r7.devicesWithMultipleDriversMap     // Catch:{ all -> 0x00bd }
            boolean r8 = r8.containsKey(r9)     // Catch:{ all -> 0x00bd }
            if (r8 == 0) goto L_0x00bb
            java.util.Map<java.lang.String, java.util.List<com.qualcomm.robotcore.hardware.HardwareMap$DeviceInstancesFromSingleConfigEntry>> r8 = r7.devicesWithMultipleDriversMap     // Catch:{ all -> 0x00bd }
            java.lang.Object r8 = r8.get(r9)     // Catch:{ all -> 0x00bd }
            java.util.List r8 = (java.util.List) r8     // Catch:{ all -> 0x00bd }
            java.util.Iterator r8 = r8.iterator()     // Catch:{ all -> 0x00bd }
        L_0x00a6:
            boolean r2 = r8.hasNext()     // Catch:{ all -> 0x00bd }
            if (r2 == 0) goto L_0x00bb
            java.lang.Object r2 = r8.next()     // Catch:{ all -> 0x00bd }
            com.qualcomm.robotcore.hardware.HardwareMap$DeviceInstancesFromSingleConfigEntry r2 = (com.qualcomm.robotcore.hardware.HardwareMap.DeviceInstancesFromSingleConfigEntry) r2     // Catch:{ all -> 0x00bd }
            r3 = r1
            com.qualcomm.robotcore.hardware.HardwareDevice r3 = (com.qualcomm.robotcore.hardware.HardwareDevice) r3     // Catch:{ all -> 0x00bd }
            boolean r2 = r2.warnIfOtherDriverHasBeenRetrieved(r3, r9)     // Catch:{ all -> 0x00bd }
            if (r2 == 0) goto L_0x00a6
        L_0x00bb:
            monitor-exit(r0)     // Catch:{ all -> 0x00bd }
            return r1
        L_0x00bd:
            r8 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00bd }
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.HardwareMap.tryGet(java.lang.Class, java.lang.String):java.lang.Object");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001d, code lost:
        return null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public <T> T get(java.lang.Class<? extends T> r3, com.qualcomm.robotcore.util.SerialNumber r4) {
        /*
            r2 = this;
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            java.util.Map<com.qualcomm.robotcore.util.SerialNumber, com.qualcomm.robotcore.hardware.HardwareDevice> r1 = r2.serialNumberMap     // Catch:{ all -> 0x001f }
            java.lang.Object r4 = r1.get(r4)     // Catch:{ all -> 0x001f }
            com.qualcomm.robotcore.hardware.HardwareDevice r4 = (com.qualcomm.robotcore.hardware.HardwareDevice) r4     // Catch:{ all -> 0x001f }
            if (r4 == 0) goto L_0x001c
            boolean r1 = r3.isInstance(r4)     // Catch:{ all -> 0x001f }
            if (r1 == 0) goto L_0x001c
            r2.initializeDeviceIfNecessary(r4)     // Catch:{ all -> 0x001f }
            java.lang.Object r3 = r3.cast(r4)     // Catch:{ all -> 0x001f }
            monitor-exit(r0)     // Catch:{ all -> 0x001f }
            return r3
        L_0x001c:
            monitor-exit(r0)     // Catch:{ all -> 0x001f }
            r3 = 0
            return r3
        L_0x001f:
            r3 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x001f }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.HardwareMap.get(java.lang.Class, com.qualcomm.robotcore.util.SerialNumber):java.lang.Object");
    }

    public HardwareDevice get(String str) {
        HardwareDevice hardwareDevice;
        synchronized (this.lock) {
            String trim = str.trim();
            List list = this.allDevicesMap.get(trim);
            if (list != null) {
                Iterator it = list.iterator();
                if (it.hasNext()) {
                    hardwareDevice = (HardwareDevice) it.next();
                    initializeDeviceIfNecessary(hardwareDevice);
                }
            }
            throw new IllegalArgumentException(String.format("Unable to find a hardware device with name \"%s\"", new Object[]{trim}));
        }
        return hardwareDevice;
    }

    public <T> List<T> getAll(Class<? extends T> cls) {
        LinkedList linkedList;
        synchronized (this.lock) {
            linkedList = new LinkedList();
            for (HardwareDevice next : unsafeIterable()) {
                if (cls.isInstance(next)) {
                    initializeDeviceIfNecessary(next);
                    linkedList.add(cls.cast(next));
                }
            }
        }
        return linkedList;
    }

    public SortedSet<String> getAllNames(Class<? extends HardwareDevice> cls) {
        TreeSet treeSet;
        Set set;
        synchronized (this.lock) {
            rebuildDeviceNamesIfNecessary();
            treeSet = new TreeSet();
            for (HardwareDevice next : unsafeIterable()) {
                if (cls.isInstance(next) && (set = this.deviceNames.get(next)) != null) {
                    treeSet.addAll(set);
                }
            }
        }
        return treeSet;
    }

    public void put(String str, HardwareDevice hardwareDevice) {
        internalPut((SerialNumber) null, str, hardwareDevice);
    }

    public void put(String str, List<HardwareDevice> list) {
        synchronized (this.lock) {
            for (HardwareDevice internalPut : list) {
                internalPut((SerialNumber) null, str, internalPut);
            }
            List list2 = this.devicesWithMultipleDriversMap.get(str);
            if (list2 == null) {
                list2 = new ArrayList(1);
                this.devicesWithMultipleDriversMap.put(str, list2);
            }
            list2.add(new DeviceInstancesFromSingleConfigEntry(list));
        }
    }

    public void put(SerialNumber serialNumber, String str, HardwareDevice hardwareDevice) {
        Assert.assertNotNull(serialNumber);
        internalPut(serialNumber, str, hardwareDevice);
    }

    /* access modifiers changed from: protected */
    public void internalPut(SerialNumber serialNumber, String str, HardwareDevice hardwareDevice) {
        synchronized (this.lock) {
            String trim = str.trim();
            List list = this.allDevicesMap.get(trim);
            if (list == null) {
                list = new ArrayList(1);
                this.allDevicesMap.put(trim, list);
            }
            if (!list.contains(hardwareDevice)) {
                this.allDevicesList = null;
                list.add(hardwareDevice);
            }
            if (serialNumber != null) {
                this.serialNumberMap.put(serialNumber, hardwareDevice);
            }
            rebuildDeviceNamesIfNecessary();
            recordDeviceName(trim, hardwareDevice);
        }
    }

    public boolean remove(String str, HardwareDevice hardwareDevice) {
        return remove((SerialNumber) null, str, hardwareDevice);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x002c, code lost:
        return true;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean remove(com.qualcomm.robotcore.util.SerialNumber r3, java.lang.String r4, com.qualcomm.robotcore.hardware.HardwareDevice r5) {
        /*
            r2 = this;
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            java.lang.String r4 = r4.trim()     // Catch:{ all -> 0x0031 }
            java.util.Map<java.lang.String, java.util.List<com.qualcomm.robotcore.hardware.HardwareDevice>> r1 = r2.allDevicesMap     // Catch:{ all -> 0x0031 }
            java.lang.Object r1 = r1.get(r4)     // Catch:{ all -> 0x0031 }
            java.util.List r1 = (java.util.List) r1     // Catch:{ all -> 0x0031 }
            if (r1 == 0) goto L_0x002e
            r1.remove(r5)     // Catch:{ all -> 0x0031 }
            boolean r5 = r1.isEmpty()     // Catch:{ all -> 0x0031 }
            if (r5 == 0) goto L_0x001f
            java.util.Map<java.lang.String, java.util.List<com.qualcomm.robotcore.hardware.HardwareDevice>> r5 = r2.allDevicesMap     // Catch:{ all -> 0x0031 }
            r5.remove(r4)     // Catch:{ all -> 0x0031 }
        L_0x001f:
            r4 = 0
            r2.allDevicesList = r4     // Catch:{ all -> 0x0031 }
            r2.deviceNames = r4     // Catch:{ all -> 0x0031 }
            if (r3 == 0) goto L_0x002b
            java.util.Map<com.qualcomm.robotcore.util.SerialNumber, com.qualcomm.robotcore.hardware.HardwareDevice> r4 = r2.serialNumberMap     // Catch:{ all -> 0x0031 }
            r4.remove(r3)     // Catch:{ all -> 0x0031 }
        L_0x002b:
            monitor-exit(r0)     // Catch:{ all -> 0x0031 }
            r3 = 1
            return r3
        L_0x002e:
            monitor-exit(r0)     // Catch:{ all -> 0x0031 }
            r3 = 0
            return r3
        L_0x0031:
            r3 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0031 }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.HardwareMap.remove(com.qualcomm.robotcore.util.SerialNumber, java.lang.String, com.qualcomm.robotcore.hardware.HardwareDevice):boolean");
    }

    public Set<String> getNamesOf(HardwareDevice hardwareDevice) {
        Set<String> set;
        synchronized (this.lock) {
            rebuildDeviceNamesIfNecessary();
            set = this.deviceNames.get(hardwareDevice);
            if (set == null) {
                set = new HashSet<>();
            }
        }
        return set;
    }

    /* access modifiers changed from: protected */
    public void recordDeviceName(String str, HardwareDevice hardwareDevice) {
        String trim = str.trim();
        Set set = this.deviceNames.get(hardwareDevice);
        if (set == null) {
            set = new HashSet();
            this.deviceNames.put(hardwareDevice, set);
        }
        set.add(trim);
    }

    /* access modifiers changed from: protected */
    public void rebuildDeviceNamesIfNecessary() {
        if (this.deviceNames == null) {
            this.deviceNames = new ConcurrentHashMap();
            for (Map.Entry next : this.allDevicesMap.entrySet()) {
                for (HardwareDevice recordDeviceName : (List) next.getValue()) {
                    recordDeviceName((String) next.getKey(), recordDeviceName);
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public void buildAllDevicesList() {
        if (this.allDevicesList == null) {
            HashSet hashSet = new HashSet();
            for (String str : this.allDevicesMap.keySet()) {
                hashSet.addAll(this.allDevicesMap.get(str));
            }
            this.allDevicesList = new ArrayList(hashSet);
        }
    }

    public int size() {
        int size;
        synchronized (this.lock) {
            buildAllDevicesList();
            size = this.allDevicesList.size();
        }
        return size;
    }

    public Iterator<HardwareDevice> iterator() {
        Iterator<HardwareDevice> it;
        RobotLog.ww(TAG, (Throwable) new RuntimeException(), "HardwareMap iterator was used, which blindly initializes all uninitialized devices");
        synchronized (this.lock) {
            buildAllDevicesList();
            initializeMultipleDevicesIfNecessary(this.allDevicesList);
            it = new ArrayList(this.allDevicesList).iterator();
        }
        return it;
    }

    public Iterable<HardwareDevice> unsafeIterable() {
        return new Iterable<HardwareDevice>() {
            public Iterator<HardwareDevice> iterator() {
                Iterator<HardwareDevice> it;
                synchronized (HardwareMap.this.lock) {
                    HardwareMap.this.buildAllDevicesList();
                    it = new ArrayList(HardwareMap.this.allDevicesList).iterator();
                }
                return it;
            }
        };
    }

    /* access modifiers changed from: private */
    public void initializeDeviceIfNecessary(HardwareDevice hardwareDevice) {
        Class<I2cDeviceSynchDevice> cls = i2cDriverBaseClass;
        if (cls.isAssignableFrom(hardwareDevice.getClass())) {
            cls.cast(hardwareDevice).initializeIfNecessary();
        }
    }

    /* access modifiers changed from: private */
    public void initializeMultipleDevicesIfNecessary(Iterable<? extends HardwareDevice> iterable) {
        for (HardwareDevice initializeDeviceIfNecessary : iterable) {
            initializeDeviceIfNecessary(initializeDeviceIfNecessary);
        }
    }

    public class DeviceMapping<DEVICE_TYPE extends HardwareDevice> implements Iterable<DEVICE_TYPE> {
        private final Class<DEVICE_TYPE> deviceTypeClass;
        private final Map<String, DEVICE_TYPE> map = new HashMap();

        public DeviceMapping(Class<DEVICE_TYPE> cls) {
            this.deviceTypeClass = cls;
        }

        public Class<DEVICE_TYPE> getDeviceTypeClass() {
            return this.deviceTypeClass;
        }

        public DEVICE_TYPE cast(Object obj) {
            return (HardwareDevice) this.deviceTypeClass.cast(obj);
        }

        public DEVICE_TYPE get(String str) {
            DEVICE_TYPE device_type;
            synchronized (HardwareMap.this.lock) {
                String trim = str.trim();
                device_type = (HardwareDevice) this.map.get(trim);
                if (device_type != null) {
                    HardwareMap.this.initializeDeviceIfNecessary(device_type);
                } else {
                    throw new IllegalArgumentException(String.format("Unable to find a hardware device with the name \"%s\"", new Object[]{trim}));
                }
            }
            return device_type;
        }

        public void put(String str, DEVICE_TYPE device_type) {
            internalPut((SerialNumber) null, str, device_type);
        }

        public void put(SerialNumber serialNumber, String str, DEVICE_TYPE device_type) {
            internalPut(serialNumber, str, device_type);
        }

        /* access modifiers changed from: protected */
        public void internalPut(SerialNumber serialNumber, String str, DEVICE_TYPE device_type) {
            synchronized (HardwareMap.this.lock) {
                String trim = str.trim();
                remove(serialNumber, trim);
                HardwareMap.this.internalPut(serialNumber, trim, device_type);
                putLocal(trim, device_type);
            }
        }

        public void putLocal(String str, DEVICE_TYPE device_type) {
            synchronized (HardwareMap.this.lock) {
                this.map.put(str.trim(), device_type);
            }
        }

        public boolean contains(String str) {
            boolean containsKey;
            synchronized (HardwareMap.this.lock) {
                containsKey = this.map.containsKey(str.trim());
            }
            return containsKey;
        }

        public boolean remove(String str) {
            return remove((SerialNumber) null, str);
        }

        public boolean remove(SerialNumber serialNumber, String str) {
            synchronized (HardwareMap.this.lock) {
                String trim = str.trim();
                HardwareDevice hardwareDevice = (HardwareDevice) this.map.remove(trim);
                if (hardwareDevice == null) {
                    return false;
                }
                HardwareMap.this.remove(serialNumber, trim, hardwareDevice);
                return true;
            }
        }

        public Iterator<DEVICE_TYPE> iterator() {
            Iterator<DEVICE_TYPE> it;
            synchronized (HardwareMap.this.lock) {
                HardwareMap.this.initializeMultipleDevicesIfNecessary(this.map.values());
                it = new ArrayList(this.map.values()).iterator();
            }
            return it;
        }

        public Set<Map.Entry<String, DEVICE_TYPE>> entrySet() {
            HashSet hashSet;
            synchronized (HardwareMap.this.lock) {
                HardwareMap.this.initializeMultipleDevicesIfNecessary(this.map.values());
                hashSet = new HashSet(this.map.entrySet());
            }
            return hashSet;
        }

        public int size() {
            int size;
            synchronized (HardwareMap.this.lock) {
                size = this.map.size();
            }
            return size;
        }
    }

    public void logDevices() {
        RobotLog.i("========= Device Information ===================================================");
        RobotLog.i(String.format(LOG_FORMAT, new Object[]{"Type", "Name", "Connection"}));
        for (Map.Entry next : this.allDevicesMap.entrySet()) {
            for (HardwareDevice hardwareDevice : (List) next.getValue()) {
                String connectionInfo = hardwareDevice.getConnectionInfo();
                RobotLog.i(String.format(LOG_FORMAT, new Object[]{hardwareDevice.getDeviceName(), (String) next.getKey(), connectionInfo}));
            }
        }
    }

    protected static class DeviceInstanceHolder {
        boolean hasBeenRetrieved = false;
        final HardwareDevice instance;

        protected DeviceInstanceHolder(HardwareDevice hardwareDevice) {
            this.instance = hardwareDevice;
        }
    }

    protected static class DeviceInstancesFromSingleConfigEntry {
        final List<DeviceInstanceHolder> deviceInstanceHolders;

        protected DeviceInstancesFromSingleConfigEntry(List<HardwareDevice> list) {
            this.deviceInstanceHolders = new ArrayList(list.size());
            for (HardwareDevice deviceInstanceHolder : list) {
                this.deviceInstanceHolders.add(new DeviceInstanceHolder(deviceInstanceHolder));
            }
        }

        public boolean warnIfOtherDriverHasBeenRetrieved(HardwareDevice hardwareDevice, String str) {
            boolean z = false;
            boolean z2 = false;
            for (DeviceInstanceHolder next : this.deviceInstanceHolders) {
                if (next.instance == hardwareDevice) {
                    next.hasBeenRetrieved = true;
                    z = true;
                } else if (next.hasBeenRetrieved) {
                    z2 = true;
                }
            }
            if (!z || !z2) {
                return false;
            }
            RobotLog.addGlobalWarningMessage(AppUtil.getDefContext().getString(R.string.warningRetrievedMultipleDeviceInstances, new Object[]{str}));
            return true;
        }
    }
}

package com.qualcomm.robotcore.hardware;

public interface ColorRangeSensor extends ColorSensor, NormalizedColorSensor, DistanceSensor, OpticalDistanceSensor, LightSensor {
}

package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.util.SerialNumber;

public interface DigitalChannelController extends HardwareDevice {
    DigitalChannel.Mode getDigitalChannelMode(int i);

    boolean getDigitalChannelState(int i);

    SerialNumber getSerialNumber();

    void setDigitalChannelMode(int i, DigitalChannel.Mode mode);

    @Deprecated
    void setDigitalChannelMode(int i, Mode mode);

    void setDigitalChannelState(int i, boolean z);

    /* renamed from: com.qualcomm.robotcore.hardware.DigitalChannelController$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$DigitalChannelController$Mode;

        static {
            int[] iArr = new int[Mode.values().length];
            $SwitchMap$com$qualcomm$robotcore$hardware$DigitalChannelController$Mode = iArr;
            try {
                iArr[Mode.INPUT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
        }
    }

    @Deprecated
    public enum Mode {
        INPUT,
        OUTPUT;

        public DigitalChannel.Mode migrate() {
            if (AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$DigitalChannelController$Mode[ordinal()] != 1) {
                return DigitalChannel.Mode.OUTPUT;
            }
            return DigitalChannel.Mode.INPUT;
        }
    }
}

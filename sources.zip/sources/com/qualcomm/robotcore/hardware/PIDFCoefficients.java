package com.qualcomm.robotcore.hardware;

import com.qualcomm.hardware.lynx.LynxServoController;
import org.firstinspires.ftc.robotcore.internal.system.Misc;

public class PIDFCoefficients {
    public MotorControlAlgorithm algorithm;
    public double d;
    public double f;
    public double i;
    public double p;

    public String toString() {
        return Misc.formatForUser("%s(p=%f i=%f d=%f f=%f alg=%s)", getClass().getSimpleName(), Double.valueOf(this.p), Double.valueOf(this.i), Double.valueOf(this.d), Double.valueOf(this.f), this.algorithm);
    }

    public PIDFCoefficients() {
        this.f = LynxServoController.apiPositionFirst;
        this.d = LynxServoController.apiPositionFirst;
        this.i = LynxServoController.apiPositionFirst;
        this.p = LynxServoController.apiPositionFirst;
        this.algorithm = MotorControlAlgorithm.PIDF;
    }

    public PIDFCoefficients(double d2, double d3, double d4, double d5, MotorControlAlgorithm motorControlAlgorithm) {
        this.p = d2;
        this.i = d3;
        this.d = d4;
        this.f = d5;
        this.algorithm = motorControlAlgorithm;
    }

    public PIDFCoefficients(double d2, double d3, double d4, double d5) {
        this(d2, d3, d4, d5, MotorControlAlgorithm.PIDF);
    }

    public PIDFCoefficients(PIDFCoefficients pIDFCoefficients) {
        this.p = pIDFCoefficients.p;
        this.i = pIDFCoefficients.i;
        this.d = pIDFCoefficients.d;
        this.f = pIDFCoefficients.f;
        this.algorithm = pIDFCoefficients.algorithm;
    }

    public PIDFCoefficients(PIDCoefficients pIDCoefficients) {
        this.p = pIDCoefficients.p;
        this.i = pIDCoefficients.i;
        this.d = pIDCoefficients.d;
        this.f = LynxServoController.apiPositionFirst;
        this.algorithm = MotorControlAlgorithm.LegacyPID;
    }
}

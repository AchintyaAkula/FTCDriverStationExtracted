package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import org.firstinspires.ftc.robotcore.internal.system.Misc;

public class LynxModuleMeta {
    protected LynxModuleImuType imuType;
    protected final boolean isParent;
    protected final int moduleAddress;
    protected Integer revProductNumber;

    public LynxModuleMeta(int i, boolean z) {
        this.moduleAddress = i;
        this.isParent = z;
        this.imuType = LynxModuleImuType.UNKNOWN;
    }

    public LynxModuleMeta(LynxModuleMeta lynxModuleMeta) {
        this.moduleAddress = lynxModuleMeta.getModuleAddress();
        this.isParent = lynxModuleMeta.isParent();
        this.imuType = lynxModuleMeta.imuType;
        this.revProductNumber = lynxModuleMeta.revProductNumber;
    }

    public int getModuleAddress() {
        return this.moduleAddress;
    }

    public boolean isParent() {
        return this.isParent;
    }

    public synchronized LynxModuleImuType imuType() {
        if (this.imuType == null) {
            this.imuType = LynxModuleImuType.UNKNOWN;
        }
        return this.imuType;
    }

    public synchronized void setImuType(LynxModuleImuType lynxModuleImuType) {
        this.imuType = lynxModuleImuType;
    }

    public synchronized int revProductNumber() {
        if (this.revProductNumber == null) {
            this.revProductNumber = Integer.valueOf(LynxConstants.EXPANSION_HUB_PRODUCT_NUMBER);
        }
        return this.revProductNumber.intValue();
    }

    public synchronized void setRevProductNumber(int i) {
        this.revProductNumber = Integer.valueOf(i);
    }

    public synchronized String toString() {
        return Misc.formatForUser("LynxModuleMeta(#%d,%b,ImuType.%s)", Integer.valueOf(this.moduleAddress), Boolean.valueOf(this.isParent), imuType());
    }
}

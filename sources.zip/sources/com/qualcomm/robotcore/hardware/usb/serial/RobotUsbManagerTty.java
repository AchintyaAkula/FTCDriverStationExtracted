package com.qualcomm.robotcore.hardware.usb.serial;

import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.hardware.usb.RobotUsbManager;
import com.qualcomm.robotcore.util.SerialNumber;
import java.util.ArrayList;
import java.util.List;

public class RobotUsbManagerTty implements RobotUsbManager {
    public static final String TAG = "RobotUsbManagerTty";
    protected SerialNumber serialNumberEmbedded = LynxConstants.SERIAL_NUMBER_EMBEDDED;

    /* access modifiers changed from: package-private */
    public Object getLock() {
        return RobotUsbManagerTty.class;
    }

    public List<SerialNumber> scanForDevices() throws RobotCoreException {
        ArrayList arrayList = new ArrayList();
        arrayList.add(this.serialNumberEmbedded);
        return arrayList;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(9:7|8|9|10|11|12|13|14|15) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x0050 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.qualcomm.robotcore.hardware.usb.RobotUsbDevice openBySerialNumber(com.qualcomm.robotcore.util.SerialNumber r6) throws com.qualcomm.robotcore.exception.RobotCoreException {
        /*
            r5 = this;
            java.lang.Object r0 = r5.getLock()
            monitor-enter(r0)
            com.qualcomm.robotcore.util.SerialNumber r1 = r5.serialNumberEmbedded     // Catch:{ all -> 0x007c }
            boolean r1 = r1.equals((java.lang.Object) r6)     // Catch:{ all -> 0x007c }
            if (r1 == 0) goto L_0x0070
            boolean r1 = com.qualcomm.robotcore.hardware.usb.RobotUsbDeviceImplBase.isOpen(r6)     // Catch:{ all -> 0x007c }
            if (r1 != 0) goto L_0x0064
            org.firstinspires.ftc.robotcore.internal.hardware.android.AndroidBoard r6 = org.firstinspires.ftc.robotcore.internal.hardware.android.AndroidBoard.getInstance()     // Catch:{ all -> 0x007c }
            java.io.File r6 = r6.getUartLocation()     // Catch:{ all -> 0x007c }
            com.qualcomm.robotcore.hardware.usb.serial.SerialPort r1 = new com.qualcomm.robotcore.hardware.usb.serial.SerialPort     // Catch:{ IOException -> 0x0052 }
            r2 = 460800(0x70800, float:6.45718E-40)
            r1.<init>(r6, r2)     // Catch:{ IOException -> 0x0052 }
            com.qualcomm.robotcore.hardware.usb.serial.RobotUsbDeviceTty r3 = new com.qualcomm.robotcore.hardware.usb.serial.RobotUsbDeviceTty     // Catch:{ all -> 0x007c }
            com.qualcomm.robotcore.util.SerialNumber r4 = r5.serialNumberEmbedded     // Catch:{ all -> 0x007c }
            r3.<init>(r1, r4, r6)     // Catch:{ all -> 0x007c }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice$FirmwareVersion r6 = new com.qualcomm.robotcore.hardware.usb.RobotUsbDevice$FirmwareVersion     // Catch:{ all -> 0x007c }
            r1 = 1
            r4 = 0
            r6.<init>(r1, r4)     // Catch:{ all -> 0x007c }
            r3.setFirmwareVersion(r6)     // Catch:{ all -> 0x007c }
            com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r6 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.LYNX_USB_DEVICE     // Catch:{ all -> 0x007c }
            r3.setDeviceType(r6)     // Catch:{ all -> 0x007c }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice$USBIdentifiers r6 = com.qualcomm.robotcore.hardware.usb.RobotUsbDevice.USBIdentifiers.createLynxIdentifiers()     // Catch:{ all -> 0x007c }
            r3.setUsbIdentifiers(r6)     // Catch:{ all -> 0x007c }
            android.app.Application r6 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getDefContext()     // Catch:{ all -> 0x007c }
            int r1 = com.qualcomm.robotcore.R.string.descriptionLynxEmbeddedModule     // Catch:{ all -> 0x007c }
            java.lang.String r6 = r6.getString(r1)     // Catch:{ all -> 0x007c }
            r3.setProductName(r6)     // Catch:{ all -> 0x007c }
            r3.setBaudRate(r2)     // Catch:{ RobotUsbException -> 0x0050 }
        L_0x0050:
            monitor-exit(r0)     // Catch:{ all -> 0x007c }
            return r3
        L_0x0052:
            r1 = move-exception
            java.lang.String r2 = "exception in %s.open(%s)"
            java.lang.String r3 = "RobotUsbManagerTty"
            java.lang.String r6 = r6.getPath()     // Catch:{ all -> 0x007c }
            java.lang.Object[] r6 = new java.lang.Object[]{r3, r6}     // Catch:{ all -> 0x007c }
            com.qualcomm.robotcore.exception.RobotCoreException r6 = com.qualcomm.robotcore.exception.RobotCoreException.createChained(r1, r2, r6)     // Catch:{ all -> 0x007c }
            throw r6     // Catch:{ all -> 0x007c }
        L_0x0064:
            com.qualcomm.robotcore.exception.RobotCoreException r1 = new com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x007c }
            java.lang.String r2 = "%s is already open: unable to open second time"
            java.lang.Object[] r6 = new java.lang.Object[]{r6}     // Catch:{ all -> 0x007c }
            r1.<init>((java.lang.String) r2, (java.lang.Object[]) r6)     // Catch:{ all -> 0x007c }
            throw r1     // Catch:{ all -> 0x007c }
        L_0x0070:
            com.qualcomm.robotcore.exception.RobotCoreException r1 = new com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x007c }
            java.lang.String r2 = "TTY for %s not found"
            java.lang.Object[] r6 = new java.lang.Object[]{r6}     // Catch:{ all -> 0x007c }
            r1.<init>((java.lang.String) r2, (java.lang.Object[]) r6)     // Catch:{ all -> 0x007c }
            throw r1     // Catch:{ all -> 0x007c }
        L_0x007c:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x007c }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.robotcore.hardware.usb.serial.RobotUsbManagerTty.openBySerialNumber(com.qualcomm.robotcore.util.SerialNumber):com.qualcomm.robotcore.hardware.usb.RobotUsbDevice");
    }
}

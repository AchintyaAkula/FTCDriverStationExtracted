package com.qualcomm.robotcore.hardware;

public interface RobotCoreLynxController extends HardwareDevice {
}

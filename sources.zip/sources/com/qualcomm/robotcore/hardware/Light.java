package com.qualcomm.robotcore.hardware;

public interface Light {
    boolean isLightOn();
}

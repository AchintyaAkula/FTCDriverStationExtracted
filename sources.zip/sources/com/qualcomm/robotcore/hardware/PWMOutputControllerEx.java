package com.qualcomm.robotcore.hardware;

public interface PWMOutputControllerEx {
    boolean isPwmEnabled(int i);

    void setPwmDisable(int i);

    void setPwmEnable(int i);
}

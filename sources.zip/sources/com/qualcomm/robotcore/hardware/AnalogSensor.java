package com.qualcomm.robotcore.hardware;

public interface AnalogSensor {
    double readRawVoltage();
}

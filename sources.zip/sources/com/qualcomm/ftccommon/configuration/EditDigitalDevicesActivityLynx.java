package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.R;

public class EditDigitalDevicesActivityLynx extends EditDigitalDevicesActivity {
    public String getTag() {
        return getClass().getSimpleName();
    }

    public EditDigitalDevicesActivityLynx() {
        this.layoutItem = R.layout.digital_device_lynx;
    }
}

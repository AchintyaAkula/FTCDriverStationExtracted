package com.qualcomm.ftccommon.configuration;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import com.qualcomm.ftccommon.R;
import com.qualcomm.ftccommon.configuration.EditActivity;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;
import com.qualcomm.robotcore.hardware.configuration.EthernetOverUsbConfiguration;
import com.qualcomm.robotcore.util.RobotLog;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.regex.Pattern;

public class EditEthernetOverUsbActivity extends EditActivity {
    public static final RequestCode requestCode = RequestCode.EDIT_ETHERNET_OVER_USB;
    EditText ipAddressInput;
    EditText textDeviceName;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.ethernet_device);
        this.textDeviceName = (EditText) findViewById(R.id.ethernetDeviceName);
        deserialize(EditParameters.fromIntent(this, getIntent()));
        this.textDeviceName.addTextChangedListener(new EditActivity.SetNameTextWatcher(this.controllerConfiguration));
        this.textDeviceName.setText(this.controllerConfiguration.getName());
        EditText editText = (EditText) findViewById(R.id.ethernetDeviceIpAddress);
        this.ipAddressInput = editText;
        editText.setText(((EthernetOverUsbConfiguration) this.controllerConfiguration).getIpAddress().getHostAddress());
        this.ipAddressInput.setFilters(new InputFilter[]{new IpAddressInputFilter()});
        this.ipAddressInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                isValidIPAddress(editable.toString());
            }

            private boolean isValidIPAddress(String str) {
                return Pattern.compile("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\\.|$)){4}$").matcher(str).matches();
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        logActivityResult(i, i2, intent);
        if (i2 == -1) {
            EditParameters fromIntent = EditParameters.fromIntent(this, intent);
            RequestCode fromValue = RequestCode.fromValue(i);
            if (fromValue != EditSwapUsbDevices.requestCode && fromValue == requestCode) {
                EthernetOverUsbConfiguration ethernetOverUsbConfiguration = (EthernetOverUsbConfiguration) fromIntent.getConfiguration();
            }
            this.currentCfgFile.markDirty();
            this.robotConfigFileManager.setActiveConfig(this.currentCfgFile);
        }
    }

    public void onDoneButtonPressed(View view) {
        finishOk();
    }

    /* access modifiers changed from: protected */
    public void finishOk() {
        String obj = this.ipAddressInput.getText().toString();
        this.controllerConfiguration.setName(this.textDeviceName.getText().toString());
        try {
            ((EthernetOverUsbConfiguration) this.controllerConfiguration).setIpAddress(InetAddress.getByName(obj));
        } catch (UnknownHostException unused) {
            RobotLog.ee(EditActivity.TAG, "Ignoring ip address change, invalid ip address: %s", obj);
        }
        finishOk(new EditParameters((EditActivity) this, (DeviceConfiguration) this.controllerConfiguration, getRobotConfigMap()));
    }

    public void onCancelButtonPressed(View view) {
        finishCancel();
    }
}

package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.CommandList;
import com.qualcomm.hardware.HardwareDeviceManager;
import com.qualcomm.robotcore.eventloop.SyncdDevice;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.LynxModuleMetaList;
import com.qualcomm.robotcore.hardware.ScannedDevices;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.util.NextLock;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import com.qualcomm.robotcore.util.ThreadPool;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import org.firstinspires.ftc.robotcore.external.function.Supplier;
import org.firstinspires.ftc.robotcore.internal.network.CallbackResult;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.RecvLoopRunnable;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;

public class USBScanManager {
    public static final String TAG = "FtcConfigTag";
    private static final USBScanManager instance = new USBScanManager();
    public static final int msWaitDefault = 4000;
    protected DeviceManager deviceManager;
    protected final ExecutorService executorService;
    protected final boolean isRemoteConfig;
    protected final Map<String, LynxModuleDiscoveryState> lynxModuleDiscoveryStateMap;
    protected final NetworkConnectionHandler networkConnectionHandler;
    protected ScannedDevices remoteScannedDevices;
    protected final Object remoteScannedDevicesLock = new Object();
    protected final NextLock scanResultsSequence = new NextLock();
    protected final ThreadPool.Singleton<ScannedDevices> scanningSingleton;

    public static USBScanManager getInstance() {
        return instance;
    }

    protected class LynxModuleDiscoveryState {
        protected NextLock lynxDiscoverySequence = new NextLock();
        protected ThreadPool.Singleton<LynxModuleMetaList> lynxDiscoverySingleton = new ThreadPool.Singleton<>();
        protected final Object remoteLynxDiscoveryLock = new Object();
        protected LynxModuleMetaList remoteLynxModules;
        protected SerialNumber serialNumber;

        protected LynxModuleDiscoveryState(SerialNumber serialNumber2) {
            this.serialNumber = serialNumber2;
            this.remoteLynxModules = new LynxModuleMetaList(serialNumber2);
            this.lynxDiscoverySingleton.setService(USBScanManager.this.executorService);
        }
    }

    private USBScanManager() {
        ExecutorService executorService2 = ThreadPool.getDefault();
        this.executorService = executorService2;
        ThreadPool.Singleton<ScannedDevices> singleton = new ThreadPool.Singleton<>();
        this.scanningSingleton = singleton;
        NetworkConnectionHandler instance2 = NetworkConnectionHandler.getInstance();
        this.networkConnectionHandler = instance2;
        this.lynxModuleDiscoveryStateMap = new ConcurrentHashMap();
        boolean isDriverStation = AppUtil.getInstance().isDriverStation();
        this.isRemoteConfig = isDriverStation;
        if (isDriverStation) {
            instance2.pushReceiveLoopCallback(new ResultsReceiver());
        } else {
            this.deviceManager = new HardwareDeviceManager(AppUtil.getDefContext(), (SyncdDevice.Manager) null);
        }
        singleton.setService(executorService2);
    }

    public ExecutorService getExecutorService() {
        return this.executorService;
    }

    public DeviceManager getDeviceManager() {
        return this.deviceManager;
    }

    /* access modifiers changed from: package-private */
    public LynxModuleDiscoveryState getDiscoveryState(SerialNumber serialNumber) {
        LynxModuleDiscoveryState lynxModuleDiscoveryState;
        synchronized (this.lynxModuleDiscoveryStateMap) {
            lynxModuleDiscoveryState = this.lynxModuleDiscoveryStateMap.get(serialNumber.getString());
            if (lynxModuleDiscoveryState == null) {
                lynxModuleDiscoveryState = new LynxModuleDiscoveryState(serialNumber);
                this.lynxModuleDiscoveryStateMap.put(serialNumber.getString(), lynxModuleDiscoveryState);
            }
        }
        return lynxModuleDiscoveryState;
    }

    public Supplier<LynxModuleMetaList> getLynxModuleMetaListSupplier(final SerialNumber serialNumber) {
        return new Supplier<LynxModuleMetaList>() {
            public LynxModuleMetaList get() {
                try {
                    return USBScanManager.this.startLynxModuleEnumerationIfNecessary(serialNumber).await();
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                    return null;
                }
            }
        };
    }

    public ThreadPool.SingletonResult<LynxModuleMetaList> startLynxModuleEnumerationIfNecessary(final SerialNumber serialNumber) {
        final LynxModuleDiscoveryState discoveryState = getDiscoveryState(serialNumber);
        return discoveryState.lynxDiscoverySingleton.submit((int) msWaitDefault, new Callable<LynxModuleMetaList>() {
            /* JADX WARNING: Removed duplicated region for block: B:30:0x0084 A[SYNTHETIC, Splitter:B:30:0x0084] */
            /* JADX WARNING: Removed duplicated region for block: B:44:0x00b8  */
            /* JADX WARNING: Removed duplicated region for block: B:45:0x00bb  */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public com.qualcomm.robotcore.hardware.LynxModuleMetaList call() throws java.lang.InterruptedException {
                /*
                    r6 = this;
                    java.lang.String r0 = "discovering lynx modules threw exception: "
                    com.qualcomm.ftccommon.configuration.USBScanManager r1 = com.qualcomm.ftccommon.configuration.USBScanManager.this
                    boolean r1 = r1.isRemoteConfig
                    if (r1 == 0) goto L_0x0043
                    com.qualcomm.ftccommon.configuration.USBScanManager$LynxModuleDiscoveryState r0 = r0
                    com.qualcomm.robotcore.util.NextLock r0 = r0.lynxDiscoverySequence
                    com.qualcomm.robotcore.util.NextLock$Waiter r0 = r0.getNextWaiter()
                    java.lang.String r1 = "FtcConfigTag"
                    java.lang.String r2 = "sending remote lynx module discovery request..."
                    com.qualcomm.robotcore.util.RobotLog.vv(r1, r2)
                    com.qualcomm.ftccommon.configuration.USBScanManager r1 = com.qualcomm.ftccommon.configuration.USBScanManager.this
                    org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler r1 = r1.networkConnectionHandler
                    com.qualcomm.robotcore.robocol.Command r2 = new com.qualcomm.robotcore.robocol.Command
                    java.lang.String r3 = "CMD_DISCOVER_LYNX_MODULES"
                    com.qualcomm.robotcore.util.SerialNumber r4 = r4
                    java.lang.String r4 = r4.getString()
                    r2.<init>(r3, r4)
                    r1.sendCommand(r2)
                    r0.awaitNext()
                    java.lang.String r0 = "FtcConfigTag"
                    java.lang.String r1 = "...remote scan lynx module discovery completed."
                    com.qualcomm.robotcore.util.RobotLog.vv(r0, r1)
                    com.qualcomm.ftccommon.configuration.USBScanManager$LynxModuleDiscoveryState r0 = r0
                    java.lang.Object r1 = r0.remoteLynxDiscoveryLock
                    monitor-enter(r1)
                    com.qualcomm.ftccommon.configuration.USBScanManager$LynxModuleDiscoveryState r0 = r0     // Catch:{ all -> 0x0040 }
                    com.qualcomm.robotcore.hardware.LynxModuleMetaList r0 = r0.remoteLynxModules     // Catch:{ all -> 0x0040 }
                    monitor-exit(r1)     // Catch:{ all -> 0x0040 }
                    return r0
                L_0x0040:
                    r0 = move-exception
                    monitor-exit(r1)     // Catch:{ all -> 0x0040 }
                    throw r0
                L_0x0043:
                    java.lang.String r1 = "FtcConfigTag"
                    java.lang.String r2 = "discovering lynx modules on lynx device=%s..."
                    com.qualcomm.robotcore.util.SerialNumber r3 = r4
                    java.lang.Object[] r3 = new java.lang.Object[]{r3}
                    com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r1, (java.lang.String) r2, (java.lang.Object[]) r3)
                    r1 = 0
                    com.qualcomm.ftccommon.configuration.USBScanManager r2 = com.qualcomm.ftccommon.configuration.USBScanManager.this     // Catch:{ all -> 0x0080 }
                    com.qualcomm.robotcore.hardware.DeviceManager r2 = r2.deviceManager     // Catch:{ all -> 0x0080 }
                    com.qualcomm.robotcore.util.SerialNumber r3 = r4     // Catch:{ all -> 0x0080 }
                    com.qualcomm.robotcore.hardware.RobotCoreLynxUsbDevice r2 = r2.createLynxUsbDevice(r3, r1)     // Catch:{ all -> 0x0080 }
                    r3 = 1
                    com.qualcomm.robotcore.hardware.LynxModuleMetaList r3 = r2.discoverModules(r3)     // Catch:{ all -> 0x007e }
                    if (r2 == 0) goto L_0x0068
                    r2.close()     // Catch:{ RobotCoreException -> 0x0066 }
                    goto L_0x0068
                L_0x0066:
                    r2 = move-exception
                    goto L_0x008c
                L_0x0068:
                    java.lang.String r0 = "FtcConfigTag"
                    java.lang.String r1 = "...discovering lynx modules complete: %s"
                    if (r3 != 0) goto L_0x0071
                    java.lang.String r2 = "null"
                    goto L_0x0075
                L_0x0071:
                    java.lang.String r2 = r3.toString()
                L_0x0075:
                    java.lang.Object[] r2 = new java.lang.Object[]{r2}
                    com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r0, (java.lang.String) r1, (java.lang.Object[]) r2)
                    r1 = r3
                    goto L_0x00af
                L_0x007e:
                    r3 = move-exception
                    goto L_0x0082
                L_0x0080:
                    r3 = move-exception
                    r2 = r1
                L_0x0082:
                    if (r2 == 0) goto L_0x0087
                    r2.close()     // Catch:{ RobotCoreException -> 0x008a, all -> 0x0088 }
                L_0x0087:
                    throw r3     // Catch:{ RobotCoreException -> 0x008a, all -> 0x0088 }
                L_0x0088:
                    r0 = move-exception
                    goto L_0x00b2
                L_0x008a:
                    r2 = move-exception
                    r3 = r1
                L_0x008c:
                    java.lang.String r4 = "FtcConfigTag"
                    java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x00b0 }
                    r5.<init>(r0)     // Catch:{ all -> 0x00b0 }
                    java.lang.String r0 = r2.toString()     // Catch:{ all -> 0x00b0 }
                    java.lang.StringBuilder r0 = r5.append(r0)     // Catch:{ all -> 0x00b0 }
                    java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x00b0 }
                    com.qualcomm.robotcore.util.RobotLog.ee(r4, r0)     // Catch:{ all -> 0x00b0 }
                    java.lang.String r0 = "FtcConfigTag"
                    java.lang.String r2 = "...discovering lynx modules complete: %s"
                    java.lang.String r3 = "null"
                    java.lang.Object[] r3 = new java.lang.Object[]{r3}
                    com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r0, (java.lang.String) r2, (java.lang.Object[]) r3)
                L_0x00af:
                    return r1
                L_0x00b0:
                    r0 = move-exception
                    r1 = r3
                L_0x00b2:
                    java.lang.String r2 = "FtcConfigTag"
                    java.lang.String r3 = "...discovering lynx modules complete: %s"
                    if (r1 != 0) goto L_0x00bb
                    java.lang.String r1 = "null"
                    goto L_0x00bf
                L_0x00bb:
                    java.lang.String r1 = r1.toString()
                L_0x00bf:
                    java.lang.Object[] r1 = new java.lang.Object[]{r1}
                    com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r3, (java.lang.Object[]) r1)
                    throw r0
                */
                throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.configuration.USBScanManager.AnonymousClass2.call():com.qualcomm.robotcore.hardware.LynxModuleMetaList");
            }
        });
    }

    public ThreadPool.SingletonResult<ScannedDevices> startDeviceScanIfNecessary() {
        return this.scanningSingleton.submit((int) msWaitDefault, new Callable<ScannedDevices>() {
            public ScannedDevices call() throws InterruptedException {
                ScannedDevices scannedDevices;
                if (USBScanManager.this.isRemoteConfig) {
                    NextLock.Waiter nextWaiter = USBScanManager.this.scanResultsSequence.getNextWaiter();
                    RobotLog.vv("FtcConfigTag", "sending remote scan request...");
                    USBScanManager.this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_SCAN));
                    nextWaiter.awaitNext();
                    RobotLog.vv("FtcConfigTag", "...remote scan request completed.");
                    synchronized (USBScanManager.this.remoteScannedDevicesLock) {
                        scannedDevices = USBScanManager.this.remoteScannedDevices;
                    }
                    return scannedDevices;
                }
                RobotLog.vv("FtcConfigTag", "scanning USB bus...");
                try {
                    ScannedDevices scanForUsbDevices = USBScanManager.this.deviceManager.scanForUsbDevices();
                    RobotLog.vv("FtcConfigTag", ".. scanning complete: %s", scanForUsbDevices == null ? "null" : scanForUsbDevices.keySet().toString());
                    return scanForUsbDevices;
                } catch (RobotCoreException e) {
                    RobotLog.ee("FtcConfigTag", (Throwable) e, "USB bus scan threw exception");
                    RobotLog.vv("FtcConfigTag", ".. scanning complete: %s", "null");
                    return null;
                } catch (Throwable th) {
                    RobotLog.vv("FtcConfigTag", ".. scanning complete: %s", "null");
                    throw th;
                }
            }
        });
    }

    public ScannedDevices awaitScannedDevices() throws InterruptedException {
        ScannedDevices await = this.scanningSingleton.await();
        if (await != null) {
            return await;
        }
        RobotLog.vv("FtcConfigTag", "USBScanManager.await() returning made-up scan result");
        return new ScannedDevices();
    }

    public LynxModuleMetaList awaitLynxModules(SerialNumber serialNumber) throws InterruptedException {
        LynxModuleMetaList await = getDiscoveryState(serialNumber).lynxDiscoverySingleton.await();
        if (await != null) {
            return await;
        }
        RobotLog.vv("FtcConfigTag", "USBScanManager.awaitLynxModules() returning made-up result");
        return new LynxModuleMetaList(serialNumber);
    }

    public String packageCommandResponse(ScannedDevices scannedDevices) {
        return scannedDevices.toSerializationString();
    }

    public String packageCommandResponse(LynxModuleMetaList lynxModuleMetaList) {
        return lynxModuleMetaList.toSerializationString();
    }

    private class ResultsReceiver extends RecvLoopRunnable.DegenerateCallback {
        private ResultsReceiver() {
        }

        public CallbackResult commandEvent(Command command) throws RobotCoreException {
            String name = command.getName();
            name.hashCode();
            if (name.equals(CommandList.CMD_DISCOVER_LYNX_MODULES_RESP)) {
                RobotLog.vv("FtcConfigTag", "Received lynx module discovery response");
                LynxModuleMetaList fromSerializationString = LynxModuleMetaList.fromSerializationString(command.getExtra());
                LynxModuleDiscoveryState discoveryState = USBScanManager.this.getDiscoveryState(fromSerializationString.serialNumber);
                synchronized (discoveryState.remoteLynxDiscoveryLock) {
                    discoveryState.remoteLynxModules = fromSerializationString;
                    discoveryState.lynxDiscoverySequence.advanceNext();
                }
                return CallbackResult.HANDLED_CONTINUE;
            } else if (!name.equals(CommandList.CMD_SCAN_RESP)) {
                return CallbackResult.NOT_HANDLED;
            } else {
                RobotLog.vv("FtcConfigTag", "Received USB scan response");
                ScannedDevices fromSerializationString2 = ScannedDevices.fromSerializationString(command.getExtra());
                synchronized (USBScanManager.this.remoteScannedDevicesLock) {
                    USBScanManager.this.remoteScannedDevices = fromSerializationString2;
                    USBScanManager.this.scanResultsSequence.advanceNext();
                }
                return CallbackResult.HANDLED_CONTINUE;
            }
        }
    }
}

package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.R;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;

public class EditAnalogInputDevicesActivity extends EditPortListSpinnerActivity {
    public static final RequestCode requestCode = RequestCode.EDIT_ANALOG_INPUT;

    public String getTag() {
        return getClass().getSimpleName();
    }

    /* access modifiers changed from: protected */
    public ConfigurationType.DeviceFlavor getDeviceFlavorBeingConfigured() {
        return ConfigurationType.DeviceFlavor.ANALOG_SENSOR;
    }

    public EditAnalogInputDevicesActivity() {
        this.layoutMain = R.layout.analog_inputs;
        this.idListParentLayout = R.id.item_list_parent;
        this.layoutItem = R.layout.analog_input_device;
        this.idItemRowPort = R.id.row_port;
        this.idItemSpinner = R.id.choiceSpinner;
        this.idItemEditTextResult = R.id.editTextResult;
        this.idItemPortNumber = R.id.port_number;
    }
}

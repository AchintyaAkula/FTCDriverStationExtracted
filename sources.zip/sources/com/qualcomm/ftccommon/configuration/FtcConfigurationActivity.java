package com.qualcomm.ftccommon.configuration;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.qualcomm.ftccommon.R;
import com.qualcomm.ftccommon.configuration.RobotConfigFileManager;
import com.qualcomm.robotcore.exception.DuplicateNameException;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.ScannedDevices;
import com.qualcomm.robotcore.hardware.configuration.BuiltInConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.ControllerConfiguration;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;
import com.qualcomm.robotcore.hardware.configuration.LynxUsbDeviceConfiguration;
import com.qualcomm.robotcore.hardware.configuration.ReadXMLFileHandler;
import com.qualcomm.robotcore.hardware.configuration.RhspModuleConfiguration;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import com.qualcomm.robotcore.util.ThreadPool;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;
import org.firstinspires.ftc.robotcore.internal.network.CallbackResult;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.RecvLoopRunnable;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.system.Misc;
import org.firstinspires.ftc.robotcore.internal.ui.UILocation;
import org.firstinspires.inspection.InspectionState;
import org.xmlpull.v1.XmlPullParser;

public class FtcConfigurationActivity extends EditActivity {
    protected static final boolean DEBUG = false;
    public static final String TAG = "FtcConfigTag";
    public static final RequestCode requestCode = RequestCode.EDIT_FILE;
    protected final RecvLoopRunnable.RecvLoopCallback commandCallback = new CommandCallback();
    DialogInterface.OnClickListener doNothingAndCloseListener = new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialogInterface, int i) {
        }
    };
    protected Semaphore feedbackPosted = new Semaphore(0);
    protected int idFeedbackAnchor = R.id.feedbackAnchor;
    protected long msSaveSplashDelay = 1000;
    protected NetworkConnectionHandler networkConnectionHandler = NetworkConnectionHandler.getInstance();
    protected final Object robotConfigMapLock = new Object();
    protected ThreadPool.Singleton scanButtonSingleton = new ThreadPool.Singleton();
    protected final USBScanManager usbScanManager = USBScanManager.getInstance();

    public String getTag() {
        return "FtcConfigTag";
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        RobotLog.vv("FtcConfigTag", "onCreate()");
        setContentView(R.layout.activity_ftc_configuration);
        try {
            deserialize(EditParameters.fromIntent(this, getIntent()));
            ((Button) findViewById(R.id.scanButton)).setVisibility(0);
            ((Button) findViewById(R.id.doneButton)).setText(R.string.buttonNameSave);
            startExecutorService();
        } catch (RobotCoreException unused) {
            RobotLog.ee("FtcConfigTag", "exception thrown during FtcConfigurationActivity.onCreate()");
            finishCancel();
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        if (this.remoteConfigure) {
            this.networkConnectionHandler.pushReceiveLoopCallback(this.commandCallback);
        }
        if (!this.remoteConfigure) {
            this.robotConfigFileManager.createConfigFolder();
        }
        if (!this.currentCfgFile.isDirty()) {
            ensureConfigFileIsFresh();
        }
    }

    /* access modifiers changed from: protected */
    public void ensureConfigFileIsFresh() {
        if (this.haveRobotConfigMapParameter) {
            populateListAndWarnDevices();
        } else if (this.remoteConfigure) {
            this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_REQUEST_PARTICULAR_CONFIGURATION, this.currentCfgFile.toString()));
        } else {
            readFile();
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        if (this.remoteConfigure) {
            this.networkConnectionHandler.removeReceiveLoopCallback(this.commandCallback);
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        RobotLog.vv("FtcConfigTag", "FtcConfigurationActivity.onDestroy()");
        super.onDestroy();
    }

    public void onDevicesInfoButtonPressed(View view) {
        RobotLog.vv("FtcConfigTag", "onDevicesInfoButtonPressed()");
        AlertDialog.Builder buildBuilder = this.utility.buildBuilder(getString(R.string.titleDevices), getString(R.string.msgInfoHowToUse));
        buildBuilder.setPositiveButton(getString(R.string.buttonNameOK), this.doNothingAndCloseListener);
        AlertDialog create = buildBuilder.create();
        create.show();
        ((TextView) create.findViewById(16908299)).setTextSize(14.0f);
    }

    public void onDoneInfoButtonPressed(View view) {
        RobotLog.vv("FtcConfigTag", "onDoneInfoButtonPressed()");
        AlertDialog.Builder buildBuilder = this.utility.buildBuilder(getString(R.string.titleSaveConfiguration), getString(R.string.msgInfoSave));
        buildBuilder.setPositiveButton(getString(R.string.buttonNameOK), this.doNothingAndCloseListener);
        AlertDialog create = buildBuilder.create();
        create.show();
        ((TextView) create.findViewById(16908299)).setTextSize(14.0f);
    }

    public void onScanButtonPressed(View view) {
        dirtyCheckThenSingletonUSBScanAndUpdateUI(true);
    }

    /* access modifiers changed from: package-private */
    public void dirtyCheckThenSingletonUSBScanAndUpdateUI(final boolean z) {
        final AnonymousClass2 r0 = new Runnable() {
            public void run() {
                ThreadPool.logThreadLifeCycle("USB bus scan handler", new Runnable() {
                    public void run() {
                        if (z) {
                            FtcConfigurationActivity.this.synchronouslySetFeedbackWhile(FtcConfigurationActivity.this.getString(R.string.ftcConfigScanning), InspectionState.NO_VERSION, new Runnable() {
                                public void run() {
                                    FtcConfigurationActivity.this.doUSBScanAndUpdateUI();
                                }
                            });
                        } else {
                            FtcConfigurationActivity.this.doUSBScanAndUpdateUI();
                        }
                    }
                });
            }
        };
        if (this.currentCfgFile.isDirty()) {
            AlertDialog.Builder buildBuilder = this.utility.buildBuilder(getString(R.string.titleUnsavedChanges), getString(R.string.msgAlertBeforeScan));
            buildBuilder.setPositiveButton(R.string.buttonNameOK, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    FtcConfigurationActivity.this.scanButtonSingleton.submit(ThreadPool.Singleton.INFINITE_TIMEOUT, r0);
                }
            });
            buildBuilder.setNegativeButton(R.string.buttonNameCancel, this.doNothingAndCloseListener);
            buildBuilder.show();
            return;
        }
        this.scanButtonSingleton.submit(ThreadPool.Singleton.INFINITE_TIMEOUT, (Runnable) r0);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't wrap try/catch for region: R(2:7|8) */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0056, code lost:
        com.qualcomm.robotcore.util.RobotLog.vv("FtcConfigTag", "...doUSBScanAndUpdateUI()");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0059, code lost:
        throw r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0049, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:?, code lost:
        java.lang.Thread.currentThread().interrupt();
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x004b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void doUSBScanAndUpdateUI() {
        /*
            r5 = this;
            java.lang.String r0 = "...doUSBScanAndUpdateUI()"
            java.lang.String r1 = "doUSBScanAndUpdateUI()..."
            java.lang.String r2 = "FtcConfigTag"
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r1)
            com.qualcomm.ftccommon.configuration.USBScanManager r1 = r5.usbScanManager     // Catch:{ InterruptedException -> 0x004b }
            com.qualcomm.robotcore.util.ThreadPool$SingletonResult r1 = r1.startDeviceScanIfNecessary()     // Catch:{ InterruptedException -> 0x004b }
            java.lang.Object r1 = r1.await()     // Catch:{ InterruptedException -> 0x004b }
            com.qualcomm.robotcore.hardware.ScannedDevices r1 = (com.qualcomm.robotcore.hardware.ScannedDevices) r1     // Catch:{ InterruptedException -> 0x004b }
            if (r1 == 0) goto L_0x0036
            java.lang.String r3 = "scan for devices on USB bus found %d devices"
            int r4 = r1.size()     // Catch:{ InterruptedException -> 0x004b }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ InterruptedException -> 0x004b }
            java.lang.Object[] r4 = new java.lang.Object[]{r4}     // Catch:{ InterruptedException -> 0x004b }
            com.qualcomm.robotcore.util.RobotLog.dd((java.lang.String) r2, (java.lang.String) r3, (java.lang.Object[]) r4)     // Catch:{ InterruptedException -> 0x004b }
            r5.buildRobotConfigMapFromScanned(r1)     // Catch:{ InterruptedException -> 0x004b }
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r1 = r5.appUtil     // Catch:{ InterruptedException -> 0x004b }
            com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$4 r3 = new com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$4     // Catch:{ InterruptedException -> 0x004b }
            r3.<init>()     // Catch:{ InterruptedException -> 0x004b }
            r1.synchronousRunOnUiThread(r3)     // Catch:{ InterruptedException -> 0x004b }
            goto L_0x0052
        L_0x0036:
            java.lang.String r1 = "scan for devices on USB bus failed"
            com.qualcomm.robotcore.util.RobotLog.ee(r2, r1)     // Catch:{ InterruptedException -> 0x004b }
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r1 = r5.appUtil     // Catch:{ InterruptedException -> 0x004b }
            org.firstinspires.ftc.robotcore.internal.ui.UILocation r3 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.ONLY_LOCAL     // Catch:{ InterruptedException -> 0x004b }
            int r4 = com.qualcomm.ftccommon.R.string.ftcConfigScanningFailed     // Catch:{ InterruptedException -> 0x004b }
            java.lang.String r4 = r5.getString(r4)     // Catch:{ InterruptedException -> 0x004b }
            r1.showToast(r3, r4)     // Catch:{ InterruptedException -> 0x004b }
            goto L_0x0052
        L_0x0049:
            r1 = move-exception
            goto L_0x0056
        L_0x004b:
            java.lang.Thread r1 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0049 }
            r1.interrupt()     // Catch:{ all -> 0x0049 }
        L_0x0052:
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r0)
            return
        L_0x0056:
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.configuration.FtcConfigurationActivity.doUSBScanAndUpdateUI():void");
    }

    private void startExecutorService() throws RobotCoreException {
        this.scanButtonSingleton.reset();
        this.scanButtonSingleton.setService(this.usbScanManager.getExecutorService());
        this.usbScanManager.startDeviceScanIfNecessary();
        this.usbScanManager.getExecutorService().submit(new FtcConfigurationActivity$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$startExecutorService$0$com-qualcomm-ftccommon-configuration-FtcConfigurationActivity  reason: not valid java name */
    public /* synthetic */ void m15lambda$startExecutorService$0$comqualcommftccommonconfigurationFtcConfigurationActivity() {
        try {
            this.usbScanManager.awaitScannedDevices();
            populateListAndWarnDevices();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    private boolean carryOver(SerialNumber serialNumber, RobotConfigMap robotConfigMap) {
        if (robotConfigMap == null || !robotConfigMap.contains(serialNumber)) {
            return false;
        }
        if (!robotConfigMap.get(serialNumber).isSystemSynthetic()) {
            return true;
        }
        RobotLog.vv("FtcConfigTag", "not carrying over synthetic controller: serial=%s", serialNumber);
        return false;
    }

    private RobotConfigMap buildRobotConfigMapFromScanned(RobotConfigMap robotConfigMap, ScannedDevices scannedDevices) {
        ControllerConfiguration controllerConfiguration;
        ControllerConfiguration controllerConfiguration2;
        RobotConfigMap robotConfigMap2 = robotConfigMap;
        RobotConfigMap robotConfigMap3 = new RobotConfigMap();
        this.configurationUtility.resetNameUniquifiers();
        HashSet<Map.Entry> hashSet = new HashSet<>();
        HashSet<Map.Entry> hashSet2 = new HashSet<>();
        for (Map.Entry next : scannedDevices.entrySet()) {
            if (carryOver((SerialNumber) next.getKey(), robotConfigMap2)) {
                hashSet.add(next);
            } else {
                hashSet2.add(next);
            }
        }
        for (Map.Entry entry : hashSet) {
            SerialNumber serialNumber = (SerialNumber) entry.getKey();
            DeviceManager.UsbDeviceType usbDeviceType = (DeviceManager.UsbDeviceType) entry.getValue();
            if (usbDeviceType == DeviceManager.UsbDeviceType.LYNX_USB_DEVICE) {
                RobotLog.vv("FtcConfigTag", "Performing Lynx discovery");
                controllerConfiguration2 = this.configurationUtility.buildNewControllerConfiguration(serialNumber, usbDeviceType, this.usbScanManager.getLynxModuleMetaListSupplier(serialNumber));
                LynxUsbDeviceConfiguration lynxUsbDeviceConfiguration = (LynxUsbDeviceConfiguration) controllerConfiguration2;
                for (RhspModuleConfiguration rhspModuleConfiguration : new ArrayList(lynxUsbDeviceConfiguration.getModules())) {
                    for (RhspModuleConfiguration next2 : ((LynxUsbDeviceConfiguration) robotConfigMap2.get(serialNumber)).getModules()) {
                        if (rhspModuleConfiguration.getModuleAddress() == next2.getModuleAddress()) {
                            RobotLog.vv("FtcConfigTag", "carrying over %s", next2.getModuleSerialNumber());
                            next2.setParentModuleAddress(rhspModuleConfiguration.getParentModuleAddress());
                            lynxUsbDeviceConfiguration.getModules().remove(rhspModuleConfiguration);
                            lynxUsbDeviceConfiguration.getModules().add(next2);
                            this.configurationUtility.noteExistingName(next2.getConfigurationType(), next2.getName());
                        }
                    }
                }
            } else {
                RobotLog.vv("FtcConfigTag", "carrying over %s", serialNumber);
                controllerConfiguration2 = robotConfigMap2.get(serialNumber);
                this.configurationUtility.noteExistingName(controllerConfiguration2.getConfigurationType(), controllerConfiguration2.getName());
            }
            controllerConfiguration2.setKnownToBeAttached(true);
            robotConfigMap3.put(serialNumber, controllerConfiguration2);
        }
        for (Map.Entry entry2 : hashSet2) {
            SerialNumber serialNumber2 = (SerialNumber) entry2.getKey();
            if (((DeviceManager.UsbDeviceType) entry2.getValue()) == DeviceManager.UsbDeviceType.ETHERNET_DEVICE) {
                controllerConfiguration = this.configurationUtility.buildNewEthernetOverUsbControllerConfiguration(serialNumber2);
            } else {
                controllerConfiguration = this.configurationUtility.buildNewControllerConfiguration(serialNumber2, (DeviceManager.UsbDeviceType) entry2.getValue(), this.usbScanManager.getLynxModuleMetaListSupplier(serialNumber2));
            }
            controllerConfiguration.setKnownToBeAttached(true);
            robotConfigMap3.put(serialNumber2, controllerConfiguration);
        }
        return robotConfigMap3;
    }

    private void readFile() {
        try {
            XmlPullParser xml = this.currentCfgFile.getXml();
            if (xml != null) {
                buildControllersFromXMLResults(new ReadXMLFileHandler().parse(xml));
                populateListAndWarnDevices();
                return;
            }
            throw new RobotCoreException("can't access configuration");
        } catch (Exception e) {
            String format = String.format(getString(R.string.errorParsingConfiguration), new Object[]{this.currentCfgFile.getName()});
            RobotLog.ee("FtcConfigTag", (Throwable) e, format);
            this.appUtil.showToast(UILocation.ONLY_LOCAL, format);
        }
    }

    /* access modifiers changed from: private */
    public void populateListAndWarnDevices() {
        this.appUtil.runOnUiThread(new Runnable() {
            public void run() {
                FtcConfigurationActivity.this.populateList();
                FtcConfigurationActivity.this.warnIncompleteDevices();
            }
        });
    }

    /* access modifiers changed from: private */
    public void warnIncompleteDevices() {
        String str;
        String str2;
        if (this.scannedDevices.getErrorMessage() != null) {
            str2 = getString(R.string.errorScanningDevicesTitle);
            str = this.scannedDevices.getErrorMessage();
        } else if (!getRobotConfigMap().allControllersAreBound()) {
            str2 = getString(R.string.notAllDevicesFoundTitle);
            str = Misc.formatForUser(R.string.notAllDevicesFoundMessage, getString(R.string.noSerialNumber));
        } else if (getRobotConfigMap().size() == 0) {
            str2 = getString(R.string.noDevicesFoundTitle);
            str = getString(R.string.noDevicesFoundMessage);
            clearDuplicateWarning();
        } else {
            str2 = null;
            str = null;
        }
        if (str2 == null && str == null) {
            this.utility.hideFeedbackText(this.idFeedbackAnchor);
        } else {
            this.utility.setFeedbackText(str2 == null ? InspectionState.NO_VERSION : str2, str == null ? InspectionState.NO_VERSION : str, this.idFeedbackAnchor, R.layout.feedback, R.id.feedbackText0, R.id.feedbackText1, R.id.feedbackOKButton);
        }
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Can't wrap try/catch for region: R(9:1|2|3|4|5|6|7|8|9) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void synchronouslySetFeedbackWhile(final java.lang.String r6, final java.lang.String r7, java.lang.Runnable r8) {
        /*
            r5 = this;
            com.qualcomm.robotcore.hardware.configuration.Utility r0 = r5.utility
            int r1 = r5.idFeedbackAnchor
            int r2 = com.qualcomm.ftccommon.R.layout.feedback
            int r3 = com.qualcomm.ftccommon.R.id.feedbackText0
            int r4 = com.qualcomm.ftccommon.R.id.feedbackText1
            java.lang.CharSequence[] r0 = r0.getFeedbackText(r1, r2, r3, r4)
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r1 = r5.appUtil     // Catch:{ all -> 0x0033 }
            com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$6 r2 = new com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$6     // Catch:{ all -> 0x0033 }
            r2.<init>(r6, r7)     // Catch:{ all -> 0x0033 }
            r1.synchronousRunOnUiThread(r2)     // Catch:{ all -> 0x0033 }
            java.util.concurrent.Semaphore r6 = r5.feedbackPosted     // Catch:{ InterruptedException -> 0x001e }
            r6.acquire()     // Catch:{ InterruptedException -> 0x001e }
            goto L_0x0025
        L_0x001e:
            java.lang.Thread r6 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0033 }
            r6.interrupt()     // Catch:{ all -> 0x0033 }
        L_0x0025:
            r8.run()     // Catch:{ all -> 0x0033 }
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r6 = r5.appUtil
            com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$7 r7 = new com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$7
            r7.<init>(r0)
            r6.runOnUiThread(r7)
            return
        L_0x0033:
            r6 = move-exception
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r7 = r5.appUtil
            com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$7 r8 = new com.qualcomm.ftccommon.configuration.FtcConfigurationActivity$7
            r8.<init>(r0)
            r7.runOnUiThread(r8)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.configuration.FtcConfigurationActivity.synchronouslySetFeedbackWhile(java.lang.String, java.lang.String, java.lang.Runnable):void");
    }

    private void warnDuplicateNames(String str) {
        this.utility.setFeedbackText("Found " + str, "Please fix and re-save.", R.id.feedbackAnchorDuplicateNames, R.layout.feedback, R.id.feedbackText0, R.id.feedbackText1);
    }

    /* access modifiers changed from: private */
    public void clearDuplicateWarning() {
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.feedbackAnchorDuplicateNames);
        linearLayout.removeAllViews();
        linearLayout.setVisibility(8);
    }

    /* access modifiers changed from: private */
    public void populateList() {
        ListView listView = (ListView) findViewById(R.id.controllersList);
        try {
            this.scannedDevices = this.usbScanManager.awaitScannedDevices();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
        tellControllersAboutAttachment();
        listView.setAdapter(new DeviceInfoAdapter(this, 17367044, new LinkedList(getRobotConfigMap().controllerConfigurations())));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                ControllerConfiguration controllerConfiguration = (ControllerConfiguration) adapterView.getItemAtPosition(i);
                ConfigurationType configurationType = controllerConfiguration.getConfigurationType();
                if (configurationType == BuiltInConfigurationType.LYNX_USB_DEVICE) {
                    FtcConfigurationActivity.this.handleLaunchEdit(EditLynxUsbDeviceActivity.requestCode, EditLynxUsbDeviceActivity.class, FtcConfigurationActivity.this.initParameters(0, RhspModuleConfiguration.class, controllerConfiguration, ((LynxUsbDeviceConfiguration) controllerConfiguration).getDevices()));
                } else if (configurationType == BuiltInConfigurationType.WEBCAM) {
                    FtcConfigurationActivity.this.handleLaunchEdit(EditWebcamActivity.requestCode, EditWebcamActivity.class, FtcConfigurationActivity.this.initParameters(controllerConfiguration));
                } else if (configurationType == BuiltInConfigurationType.ETHERNET_OVER_USB_DEVICE) {
                    FtcConfigurationActivity.this.handleLaunchEdit(EditEthernetOverUsbActivity.requestCode, EditEthernetOverUsbActivity.class, FtcConfigurationActivity.this.initParameters(controllerConfiguration));
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    public <ITEM_T extends DeviceConfiguration> EditParameters initParameters(int i, Class<ITEM_T> cls, ControllerConfiguration controllerConfiguration, List<ITEM_T> list) {
        EditParameters editParameters = new EditParameters((EditActivity) this, (DeviceConfiguration) controllerConfiguration, cls, list);
        editParameters.setInitialPortNumber(i);
        editParameters.setScannedDevices(this.scannedDevices);
        editParameters.setRobotConfigMap(getRobotConfigMap());
        return editParameters;
    }

    /* access modifiers changed from: package-private */
    public <ITEM_T extends DeviceConfiguration> EditParameters initParameters(ControllerConfiguration controllerConfiguration) {
        return initParameters(0, DeviceConfiguration.class, controllerConfiguration, new ArrayList());
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        try {
            logActivityResult(i, i2, intent);
            if (i2 != 0) {
                RequestCode fromValue = RequestCode.fromValue(i);
                EditParameters fromIntent = EditParameters.fromIntent(this, intent);
                RobotLog.vv("FtcConfigTag", "onActivityResult(%s)", fromValue.toString());
                synchronized (this.robotConfigMapLock) {
                    deserializeConfigMap(fromIntent);
                }
                this.scannedDevices = this.usbScanManager.awaitScannedDevices();
                this.appUtil.runOnUiThread(new Runnable() {
                    public void run() {
                        FtcConfigurationActivity.this.currentCfgFile.markDirty();
                        FtcConfigurationActivity.this.robotConfigFileManager.updateActiveConfigHeader(FtcConfigurationActivity.this.currentCfgFile);
                        FtcConfigurationActivity.this.populateList();
                    }
                });
            }
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    public void onBackPressed() {
        RobotLog.vv("FtcConfigTag", "onBackPressed()");
        doBackOrCancel();
    }

    public void onCancelButtonPressed(View view) {
        RobotLog.vv("FtcConfigTag", "onCancelButtonPressed()");
        doBackOrCancel();
    }

    private void doBackOrCancel() {
        if (this.currentCfgFile.isDirty()) {
            AnonymousClass10 r0 = new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    FtcConfigurationActivity.this.currentCfgFile.markClean();
                    FtcConfigurationActivity.this.robotConfigFileManager.setActiveConfig(FtcConfigurationActivity.this.remoteConfigure, FtcConfigurationActivity.this.currentCfgFile);
                    FtcConfigurationActivity.this.finishCancel();
                }
            };
            AlertDialog.Builder buildBuilder = this.utility.buildBuilder(getString(R.string.saveChangesTitle), getString(R.string.saveChangesMessage));
            buildBuilder.setPositiveButton(R.string.buttonExitWithoutSaving, r0);
            buildBuilder.setNegativeButton(R.string.buttonNameCancel, this.doNothingAndCloseListener);
            buildBuilder.show();
            return;
        }
        finishCancel();
    }

    public void onDoneButtonPressed(View view) {
        RobotLog.vv("FtcConfigTag", "onDoneButtonPressed()");
        try {
            final String xml = this.robotConfigFileManager.toXml(getRobotConfigMap());
            clearDuplicateWarning();
            if (xml != null) {
                String string = getString(R.string.configNamePromptBanter);
                final EditText editText = new EditText(this);
                editText.setText(this.currentCfgFile.isNoConfig() ? InspectionState.NO_VERSION : this.currentCfgFile.getName());
                AlertDialog.Builder buildBuilder = this.utility.buildBuilder(getString(R.string.configNamePromptTitle), string);
                buildBuilder.setView(editText);
                buildBuilder.setPositiveButton(getString(R.string.buttonNameOK), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String obj = editText.getText().toString();
                        RobotConfigFileManager.ConfigNameCheckResult isPlausibleConfigName = FtcConfigurationActivity.this.robotConfigFileManager.isPlausibleConfigName(FtcConfigurationActivity.this.currentCfgFile, obj, FtcConfigurationActivity.this.extantRobotConfigurations);
                        if (!isPlausibleConfigName.success) {
                            FtcConfigurationActivity.this.appUtil.showToast(UILocation.ONLY_LOCAL, String.format("%s %s", new Object[]{String.format(isPlausibleConfigName.errorFormat, new Object[]{obj}), FtcConfigurationActivity.this.getString(R.string.configurationNotSaved)}));
                            return;
                        }
                        try {
                            if (!FtcConfigurationActivity.this.currentCfgFile.getName().equals(obj)) {
                                FtcConfigurationActivity.this.currentCfgFile = new RobotConfigFile(FtcConfigurationActivity.this.robotConfigFileManager, obj);
                            }
                            FtcConfigurationActivity.this.robotConfigFileManager.writeToFile(FtcConfigurationActivity.this.currentCfgFile, FtcConfigurationActivity.this.remoteConfigure, xml);
                            FtcConfigurationActivity.this.robotConfigFileManager.setActiveConfigAndUpdateUI(FtcConfigurationActivity.this.remoteConfigure, FtcConfigurationActivity.this.currentCfgFile);
                            FtcConfigurationActivity.this.confirmSave();
                            FtcConfigurationActivity.this.pauseAfterSave();
                            FtcConfigurationActivity.this.finishOk();
                        } catch (RobotCoreException | IOException | RuntimeException e) {
                            FtcConfigurationActivity.this.appUtil.showToast(UILocation.ONLY_LOCAL, e.getMessage());
                            RobotLog.ee("FtcConfigTag", e.getMessage());
                        }
                    }
                });
                buildBuilder.setNegativeButton(getString(R.string.buttonNameCancel), this.doNothingAndCloseListener);
                buildBuilder.show();
            }
        } catch (DuplicateNameException e) {
            warnDuplicateNames(e.getMessage());
            RobotLog.ee("FtcConfigTag", e.getMessage());
        }
    }

    /* access modifiers changed from: private */
    public void confirmSave() {
        Toast makeText = Toast.makeText(this, R.string.toastSaved, 0);
        makeText.setGravity(80, 0, 50);
        makeText.show();
    }

    /* access modifiers changed from: private */
    public void pauseAfterSave() {
        try {
            Thread.sleep(this.msSaveSplashDelay);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    private void buildControllersFromXMLResults(List<ControllerConfiguration> list) {
        synchronized (this.robotConfigMapLock) {
            this.robotConfigMap = new RobotConfigMap((Collection<ControllerConfiguration>) list);
        }
    }

    private void buildRobotConfigMapFromScanned(ScannedDevices scannedDevices) {
        synchronized (this.robotConfigMapLock) {
            this.robotConfigMap = buildRobotConfigMapFromScanned(getRobotConfigMap(), scannedDevices);
        }
    }

    /* access modifiers changed from: protected */
    public RobotConfigMap getRobotConfigMap() {
        RobotConfigMap robotConfigMap;
        synchronized (this.robotConfigMapLock) {
            robotConfigMap = super.getRobotConfigMap();
        }
        return robotConfigMap;
    }

    /* access modifiers changed from: protected */
    public void tellControllersAboutAttachment() {
        for (ControllerConfiguration next : getRobotConfigMap().controllerConfigurations()) {
            next.setKnownToBeAttached(this.scannedDevices.containsKey(next.getSerialNumber()));
        }
    }

    /* access modifiers changed from: protected */
    public CallbackResult handleCommandRequestParticularConfigurationResp(String str) throws RobotCoreException {
        buildControllersFromXMLResults(new ReadXMLFileHandler().parse((Reader) new StringReader(str)));
        populateListAndWarnDevices();
        return CallbackResult.HANDLED;
    }

    private class CommandCallback extends RecvLoopRunnable.DegenerateCallback {
        private CommandCallback() {
        }

        public CallbackResult commandEvent(Command command) throws RobotCoreException {
            CallbackResult callbackResult = CallbackResult.NOT_HANDLED;
            try {
                String name = command.getName();
                String extra = command.getExtra();
                if (name.equals(RobotCoreCommandList.CMD_REQUEST_PARTICULAR_CONFIGURATION_RESP)) {
                    return FtcConfigurationActivity.this.handleCommandRequestParticularConfigurationResp(extra);
                }
                return callbackResult;
            } catch (RobotCoreException e) {
                RobotLog.logStacktrace(e);
                return callbackResult;
            }
        }
    }
}

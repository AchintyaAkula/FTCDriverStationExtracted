package com.qualcomm.ftccommon.configuration;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.widget.EditText;

public class IpAddressEditText extends EditText {
    private static final String DOT = ".";
    private int currentNumberIndex = 0;

    static /* synthetic */ int access$008(IpAddressEditText ipAddressEditText) {
        int i = ipAddressEditText.currentNumberIndex;
        ipAddressEditText.currentNumberIndex = i + 1;
        return i;
    }

    public IpAddressEditText(Context context) {
        super(context);
        init();
    }

    public IpAddressEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public IpAddressEditText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    private void init() {
        addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void afterTextChanged(Editable editable) {
                String obj = editable.toString();
                if (!obj.isEmpty() && obj.length() % 3 == 0 && !obj.endsWith(IpAddressEditText.DOT)) {
                    editable.insert(obj.length(), IpAddressEditText.DOT);
                    IpAddressEditText.access$008(IpAddressEditText.this);
                }
            }
        });
    }

    private void moveCursorToNextNumber() {
        int selectionStart = getSelectionStart();
        if (selectionStart != getText().length() && this.currentNumberIndex < 4 && selectionStart % 3 == 2) {
            setSelection(selectionStart + 1);
            this.currentNumberIndex++;
        }
    }

    public String getIpAddress() {
        String obj = getText().toString();
        return obj.endsWith(DOT) ? obj.substring(0, obj.length() - 1) : obj;
    }
}

package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.R;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;

public abstract class EditI2cDevicesActivityAbstract<ITEM_T extends DeviceConfiguration> extends EditPortListSpinnerActivity<ITEM_T> {
    public EditI2cDevicesActivityAbstract() {
        this.layoutMain = R.layout.i2cs;
        this.idListParentLayout = R.id.item_list_parent;
        this.layoutItem = R.layout.i2c_device;
        this.idItemRowPort = R.id.row_port_i2c;
        this.idItemSpinner = R.id.choiceSpinner;
        this.idItemEditTextResult = R.id.editTextResult;
        this.idItemPortNumber = R.id.port_number;
    }

    /* access modifiers changed from: protected */
    public ConfigurationType.DeviceFlavor getDeviceFlavorBeingConfigured() {
        return ConfigurationType.DeviceFlavor.I2C;
    }
}

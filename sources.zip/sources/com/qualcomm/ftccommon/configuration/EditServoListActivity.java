package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.R;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;

public class EditServoListActivity extends EditPortListSpinnerActivity {
    public String getTag() {
        return getClass().getSimpleName();
    }

    /* access modifiers changed from: protected */
    public ConfigurationType.DeviceFlavor getDeviceFlavorBeingConfigured() {
        return ConfigurationType.DeviceFlavor.SERVO;
    }

    public EditServoListActivity() {
        this.layoutMain = R.layout.servo_list;
        this.idListParentLayout = R.id.item_list_parent;
        this.layoutItem = R.layout.servo;
        this.idItemRowPort = R.id.row_port;
        this.idItemSpinner = R.id.choiceSpinner;
        this.idItemEditTextResult = R.id.editTextResult;
        this.idItemPortNumber = R.id.port_number;
    }
}

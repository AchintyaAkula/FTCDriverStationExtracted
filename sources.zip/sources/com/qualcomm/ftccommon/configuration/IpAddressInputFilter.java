package com.qualcomm.ftccommon.configuration;

import android.text.InputFilter;
import android.text.Spanned;
import org.firstinspires.inspection.InspectionState;

public class IpAddressInputFilter implements InputFilter {
    public CharSequence filter(CharSequence charSequence, int i, int i2, Spanned spanned, int i3, int i4) {
        while (i < i2) {
            char charAt = charSequence.charAt(i);
            if (!Character.isDigit(charAt) && charAt != '.' && charAt != 8) {
                return InspectionState.NO_VERSION;
            }
            i++;
        }
        String str = spanned.toString() + charSequence.toString();
        if (str.contains("..")) {
            return InspectionState.NO_VERSION;
        }
        String[] split = str.split("\\.");
        if (split.length > 4) {
            return InspectionState.NO_VERSION;
        }
        if (split.length == 4 && str.charAt(str.length() - 1) == '.') {
            return InspectionState.NO_VERSION;
        }
        for (String length : str.split("\\.")) {
            if (length.length() > 3) {
                return InspectionState.NO_VERSION;
            }
        }
        return null;
    }
}

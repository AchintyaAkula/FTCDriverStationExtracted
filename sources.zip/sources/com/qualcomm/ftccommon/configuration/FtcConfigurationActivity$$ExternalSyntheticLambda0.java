package com.qualcomm.ftccommon.configuration;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcConfigurationActivity$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ FtcConfigurationActivity f$0;

    public /* synthetic */ FtcConfigurationActivity$$ExternalSyntheticLambda0(FtcConfigurationActivity ftcConfigurationActivity) {
        this.f$0 = ftcConfigurationActivity;
    }

    public final void run() {
        this.f$0.m15lambda$startExecutorService$0$comqualcommftccommonconfigurationFtcConfigurationActivity();
    }
}

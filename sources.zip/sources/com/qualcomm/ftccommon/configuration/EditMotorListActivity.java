package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.R;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;

public class EditMotorListActivity extends EditPortListSpinnerActivity<DeviceConfiguration> {
    ConfigurationType unspecifiedMotorType = MotorConfigurationType.getUnspecifiedMotorType();

    public String getTag() {
        return getClass().getSimpleName();
    }

    /* access modifiers changed from: protected */
    public ConfigurationType.DeviceFlavor getDeviceFlavorBeingConfigured() {
        return ConfigurationType.DeviceFlavor.MOTOR;
    }

    public EditMotorListActivity() {
        this.layoutMain = R.layout.motor_list;
        this.idListParentLayout = R.id.item_list_parent;
        this.layoutItem = R.layout.motor;
        this.idItemRowPort = R.id.row_port;
        this.idItemSpinner = R.id.choiceMotorSpinner;
        this.idItemEditTextResult = R.id.editTextResult;
        this.idItemPortNumber = R.id.port_number;
    }

    /* access modifiers changed from: protected */
    public ConfigurationType getDefaultEnabledSelection() {
        ConfigurationType configurationType = this.unspecifiedMotorType;
        if (configurationType != null) {
            return configurationType;
        }
        return super.getDefaultEnabledSelection();
    }
}

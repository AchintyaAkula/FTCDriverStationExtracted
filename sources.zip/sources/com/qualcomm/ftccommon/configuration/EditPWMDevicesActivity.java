package com.qualcomm.ftccommon.configuration;

import com.qualcomm.ftccommon.R;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;

public class EditPWMDevicesActivity extends EditPortListCheckboxActivity<DeviceConfiguration> {
    public static final RequestCode requestCode = RequestCode.EDIT_PWM_PORT;

    public String getTag() {
        return getClass().getSimpleName();
    }

    public EditPWMDevicesActivity() {
        this.layoutMain = R.layout.pwms;
        this.idListParentLayout = R.id.item_list_parent;
        this.layoutItem = R.layout.pwm_device;
        this.idItemRowPort = R.id.row_port;
        this.idItemCheckbox = R.id.checkbox_port;
        this.idItemEditTextResult = R.id.editTextResult;
        this.idItemPortNumber = R.id.port_number;
    }
}

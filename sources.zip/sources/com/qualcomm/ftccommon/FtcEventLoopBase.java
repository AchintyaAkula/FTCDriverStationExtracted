package com.qualcomm.ftccommon;

import android.app.Activity;
import androidx.core.internal.view.SupportMenu;
import androidx.core.view.ViewCompat;
import com.qualcomm.ftccommon.CommandList;
import com.qualcomm.ftccommon.UpdateUI;
import com.qualcomm.ftccommon.configuration.RobotConfigFile;
import com.qualcomm.ftccommon.configuration.RobotConfigFileManager;
import com.qualcomm.ftccommon.configuration.USBScanManager;
import com.qualcomm.hardware.HardwareFactory;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.lynx.LynxUsbDevice;
import com.qualcomm.robotcore.eventloop.EventLoop;
import com.qualcomm.robotcore.eventloop.EventLoopManager;
import com.qualcomm.robotcore.eventloop.opmode.OpModeRegister;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.Blinker;
import com.qualcomm.robotcore.hardware.EmbeddedControlHubModule;
import com.qualcomm.robotcore.hardware.LynxModuleMetaList;
import com.qualcomm.robotcore.hardware.ScannedDevices;
import com.qualcomm.robotcore.hardware.USBAccessibleLynxModule;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.hardware.configuration.ReadXMLFileHandler;
import com.qualcomm.robotcore.hardware.configuration.WriteXMLFileHandler;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import com.qualcomm.robotcore.util.ThreadPool;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import org.firstinspires.ftc.robotcore.external.Consumer;
import org.firstinspires.ftc.robotcore.external.stream.CameraStreamServer;
import org.firstinspires.ftc.robotcore.internal.collections.SimpleGson;
import org.firstinspires.ftc.robotcore.internal.network.CallbackResult;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.PreferenceRemoterRC;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.network.WifiDirectAgent;
import org.firstinspires.ftc.robotcore.internal.network.WifiDirectGroupName;
import org.firstinspires.ftc.robotcore.internal.network.WifiDirectPersistentGroupManager;
import org.firstinspires.ftc.robotcore.internal.opmode.OnBotJavaBuildLocker;
import org.firstinspires.ftc.robotcore.internal.opmode.RegisteredOpModes;
import org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.Assert;
import org.firstinspires.ftc.robotcore.internal.ui.ProgressParameters;
import org.firstinspires.ftc.robotcore.internal.ui.UILocation;
import org.firstinspires.inspection.InspectionState;
import org.xmlpull.v1.XmlPullParserException;

public abstract class FtcEventLoopBase implements EventLoop {
    public static final String TAG = "FtcEventLoop";
    protected Activity activityContext;
    protected FtcEventLoopHandler ftcEventLoopHandler;
    protected NetworkConnectionHandler networkConnectionHandler = NetworkConnectionHandler.getInstance();
    protected final RegisteredOpModes registeredOpModes;
    protected RobotConfigFileManager robotCfgFileMgr;
    protected boolean runningOnDriverStation = false;
    protected final USBScanManager usbScanManager = USBScanManager.getInstance();
    protected final OpModeRegister userOpmodeRegister;

    public void init(EventLoopManager eventLoopManager) throws RobotCoreException, InterruptedException {
    }

    protected FtcEventLoopBase(HardwareFactory hardwareFactory, OpModeRegister opModeRegister, UpdateUI.Callback callback, Activity activity) {
        this.userOpmodeRegister = opModeRegister;
        this.registeredOpModes = RegisteredOpModes.getInstance();
        this.activityContext = activity;
        this.robotCfgFileMgr = new RobotConfigFileManager(activity);
        this.ftcEventLoopHandler = new FtcEventLoopHandler(hardwareFactory, callback, activity);
    }

    public void teardown() throws RobotCoreException, InterruptedException {
        this.ftcEventLoopHandler.close();
    }

    public CallbackResult processCommand(Command command) throws InterruptedException, RobotCoreException {
        CallbackResult callbackResult = CallbackResult.HANDLED;
        String name = command.getName();
        String extra = command.getExtra();
        if (name.equals(CommandList.CMD_RESTART_ROBOT)) {
            handleCommandRestartRobot();
            return callbackResult;
        } else if (name.equals(CommandList.CMD_REQUEST_CONFIGURATIONS)) {
            handleCommandRequestConfigurations();
            return callbackResult;
        } else if (name.equals(CommandList.CMD_REQUEST_REMEMBERED_GROUPS)) {
            handleCommandRequestRememberedGroups();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_CLEAR_REMEMBERED_GROUPS)) {
            handleCommandClearRememberedGroups();
            return callbackResult;
        } else if (name.equals(CommandList.CMD_SCAN)) {
            handleCommandScan(extra);
            return callbackResult;
        } else if (name.equals(CommandList.CMD_DISCOVER_LYNX_MODULES)) {
            handleCommandDiscoverLynxModules(extra);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_LYNX_FIRMWARE_UPDATE)) {
            handleCommandLynxFirmwareUpdate(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_GET_USB_ACCESSIBLE_LYNX_MODULES)) {
            handleCommandGetUSBAccessibleLynxModules(command);
            return callbackResult;
        } else if (name.equals(CommandList.CMD_LYNX_ADDRESS_CHANGE)) {
            handleCommandLynxChangeModuleAddresses(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_GET_CANDIDATE_LYNX_FIRMWARE_IMAGES)) {
            handleCommandGetCandidateLynxFirmwareImages(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_REQUEST_INSPECTION_REPORT)) {
            handleCommandRequestInspectionReport();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_DISABLE_BLUETOOTH)) {
            handleCommandDisableBluetooth();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_REQUEST_ABOUT_INFO)) {
            handleCommandRequestAboutInfo(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_DISCONNECT_FROM_WIFI_DIRECT)) {
            handleCommandDisconnectWifiDirect();
            return callbackResult;
        } else if (name.equals(CommandList.CMD_REQUEST_CONFIGURATION_TEMPLATES)) {
            handleCommandRequestConfigurationTemplates();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_REQUEST_PARTICULAR_CONFIGURATION)) {
            handleCommandRequestParticularConfiguration(extra);
            return callbackResult;
        } else if (name.equals(CommandList.CMD_ACTIVATE_CONFIGURATION)) {
            handleCommandActivateConfiguration(extra);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_REQUEST_USER_DEVICE_TYPES)) {
            ConfigurationTypeManager.getInstance().sendUserDeviceTypes();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_REQUEST_ACTIVE_CONFIG)) {
            sendActiveConfig();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_REQUEST_OP_MODE_LIST)) {
            sendOpModeList();
            return callbackResult;
        } else if (name.equals(CommandList.CMD_SAVE_CONFIGURATION)) {
            handleCommandSaveConfiguration(extra);
            return callbackResult;
        } else if (name.equals(CommandList.CMD_DELETE_CONFIGURATION)) {
            handleCommandDeleteConfiguration(extra);
            return callbackResult;
        } else if (name.equals(CommandList.CMD_START_DS_PROGRAM_AND_MANAGE)) {
            handleCommandStartDriverStationProgramAndManage();
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_SHOW_TOAST)) {
            handleCommandShowToast(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_SHOW_DIALOG)) {
            handleCommandShowDialog(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_DISMISS_DIALOG)) {
            handleCommandDismissDialog(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_DISMISS_ALL_DIALOGS)) {
            handleCommandDismissAllDialogs(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_SHOW_PROGRESS)) {
            handleCommandShowProgress(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_DISMISS_PROGRESS)) {
            handleCommandDismissProgress(command);
            return callbackResult;
        } else if (name.equals(RobotCoreCommandList.CMD_ROBOT_CONTROLLER_PREFERENCE)) {
            return PreferenceRemoterRC.getInstance().handleCommandRobotControllerPreference(extra);
        } else {
            if (name.equals(CommandList.CmdPlaySound.Command)) {
                return SoundPlayer.getInstance().handleCommandPlaySound(extra);
            }
            if (name.equals(CommandList.CmdRequestSound.Command)) {
                return SoundPlayer.getInstance().handleCommandRequestSound(command);
            }
            if (name.equals(CommandList.CmdStopPlayingSounds.Command)) {
                return SoundPlayer.getInstance().handleCommandStopPlayingSounds(command);
            }
            if (name.equals(RobotCoreCommandList.CMD_REQUEST_FRAME)) {
                return CameraStreamServer.getInstance().handleRequestFrame();
            }
            if (name.equals(CommandList.CmdVisuallyIdentify.Command)) {
                return handleCommandVisuallyIdentify(command);
            }
            if (name.equals(RobotCoreCommandList.CMD_VISUALLY_CONFIRM_WIFI_RESET)) {
                return handleCommandVisuallyConfirmWifiReset();
            }
            if (name.equals(RobotCoreCommandList.CMD_VISUALLY_CONFIRM_WIFI_BAND_SWITCH)) {
                return handleCommandVisuallyConfirmWifiBandSwitch(command);
            }
            return CallbackResult.NOT_HANDLED;
        }
    }

    /* access modifiers changed from: protected */
    public void handleCommandActivateConfiguration(String str) {
        this.robotCfgFileMgr.setActiveConfigAndUpdateUI(this.runningOnDriverStation, this.robotCfgFileMgr.getConfigFromString(str));
    }

    /* access modifiers changed from: protected */
    public void sendActiveConfig() {
        this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_NOTIFY_ACTIVE_CONFIGURATION, this.robotCfgFileMgr.getActiveConfig().toString()));
    }

    /* access modifiers changed from: protected */
    public void sendOpModeList() {
        this.registeredOpModes.waitOpModesRegistered();
        this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_NOTIFY_OP_MODE_LIST, SimpleGson.getInstance().toJson((Object) this.registeredOpModes.getOpModes())));
    }

    /* access modifiers changed from: protected */
    public void checkForChangedOpModes() {
        boolean z;
        boolean z2 = true;
        if (this.registeredOpModes.getOnBotJavaChanged()) {
            OnBotJavaBuildLocker.lockBuildExclusiveWhile(new Runnable() {
                public void run() {
                    FtcEventLoopBase.this.registeredOpModes.clearOnBotJavaChanged();
                    FtcEventLoopBase.this.registeredOpModes.registerOnBotJavaOpModes();
                }
            });
            z = true;
        } else {
            z = false;
        }
        if (this.registeredOpModes.getExternalLibrariesChanged()) {
            this.registeredOpModes.clearExternalLibrariesChanged();
            this.registeredOpModes.registerExternalLibrariesOpModes();
            z = true;
        }
        if (this.registeredOpModes.getBlocksOpModesChanged()) {
            this.registeredOpModes.clearBlocksOpModesChanged();
            this.registeredOpModes.registerInstanceOpModes();
        } else {
            z2 = z;
        }
        if (z2) {
            sendOpModeList();
            ConfigurationTypeManager.getInstance().sendUserDeviceTypes();
        }
    }

    public void loop() {
        AppAliveNotifier.getInstance().notifyAppAlive();
    }

    /* access modifiers changed from: protected */
    public void handleCommandRestartRobot() {
        this.ftcEventLoopHandler.restartRobot();
    }

    /* access modifiers changed from: protected */
    public void handleCommandRequestParticularConfiguration(String str) {
        RobotConfigFile configFromString = this.robotCfgFileMgr.getConfigFromString(str);
        ReadXMLFileHandler readXMLFileHandler = new ReadXMLFileHandler();
        if (!configFromString.isNoConfig()) {
            try {
                String xml = new WriteXMLFileHandler().toXml((ArrayList) readXMLFileHandler.parse(configFromString.getXml()), true);
                RobotLog.vv("FtcConfigTag", "FtcEventLoop: handleCommandRequestParticularConfigFile, data: " + xml);
                this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_REQUEST_PARTICULAR_CONFIGURATION_RESP, xml));
            } catch (RobotCoreException | FileNotFoundException | XmlPullParserException e) {
                RobotLog.ee(TAG, e, "Failed to get and/or parse the requested configuration file");
            }
        }
    }

    /* access modifiers changed from: protected */
    public void handleCommandDeleteConfiguration(String str) {
        RobotConfigFile configFromString = this.robotCfgFileMgr.getConfigFromString(str);
        if (!RobotConfigFileManager.getFullPath(configFromString.getName()).delete()) {
            RobotLog.ee(TAG, "Tried to delete a file that does not exist: " + configFromString.getName());
        }
    }

    /* access modifiers changed from: protected */
    public void handleCommandSaveConfiguration(String str) {
        String[] split = str.split(RobotConfigFileManager.FILE_LIST_COMMAND_DELIMITER);
        try {
            RobotConfigFile configFromString = this.robotCfgFileMgr.getConfigFromString(split[0]);
            this.robotCfgFileMgr.writeToFile(configFromString, false, split[1]);
            this.robotCfgFileMgr.setActiveConfigAndUpdateUI(false, configFromString);
        } catch (RobotCoreException | IOException | RuntimeException e) {
            RobotLog.ee(TAG, e, "Failed to save configuration file");
        }
    }

    /* access modifiers changed from: protected */
    public void handleCommandRequestConfigurations() {
        this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_REQUEST_CONFIGURATIONS_RESP, RobotConfigFileManager.serializeXMLConfigList(this.robotCfgFileMgr.getXMLFiles())));
    }

    /* access modifiers changed from: protected */
    public void handleCommandRequestRememberedGroups() {
        this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_REQUEST_REMEMBERED_GROUPS_RESP, WifiDirectGroupName.serializeNames(new WifiDirectPersistentGroupManager(WifiDirectAgent.getInstance()).getPersistentGroups())));
    }

    /* access modifiers changed from: protected */
    public void handleCommandClearRememberedGroups() {
        new WifiDirectPersistentGroupManager(WifiDirectAgent.getInstance()).deleteAllPersistentGroups();
        AppUtil.getInstance().showToast(UILocation.BOTH, AppUtil.getDefContext().getString(R.string.toastWifiP2pRememberedGroupsCleared));
    }

    /* access modifiers changed from: protected */
    public void handleCommandScan(String str) throws RobotCoreException, InterruptedException {
        RobotLog.vv("FtcConfigTag", "handling command SCAN");
        final ThreadPool.SingletonResult<ScannedDevices> startDeviceScanIfNecessary = this.usbScanManager.startDeviceScanIfNecessary();
        ThreadPool.getDefault().execute(new Runnable() {
            public void run() {
                try {
                    ScannedDevices scannedDevices = (ScannedDevices) startDeviceScanIfNecessary.await();
                    if (scannedDevices == null) {
                        scannedDevices = new ScannedDevices();
                    }
                    String packageCommandResponse = FtcEventLoopBase.this.usbScanManager.packageCommandResponse(scannedDevices);
                    RobotLog.vv("FtcConfigTag", "handleCommandScan data='%s'", packageCommandResponse);
                    FtcEventLoopBase.this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_SCAN_RESP, packageCommandResponse));
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void handleCommandDiscoverLynxModules(String str) throws RobotCoreException {
        RobotLog.vv("FtcConfigTag", "handling command DiscoverLynxModules");
        final SerialNumber fromString = SerialNumber.fromString(str);
        final ThreadPool.SingletonResult<LynxModuleMetaList> startLynxModuleEnumerationIfNecessary = this.usbScanManager.startLynxModuleEnumerationIfNecessary(fromString);
        ThreadPool.getDefault().execute(new Runnable() {
            public void run() {
                try {
                    LynxModuleMetaList lynxModuleMetaList = (LynxModuleMetaList) startLynxModuleEnumerationIfNecessary.await();
                    if (lynxModuleMetaList == null) {
                        lynxModuleMetaList = new LynxModuleMetaList(fromString);
                    }
                    String packageCommandResponse = FtcEventLoopBase.this.usbScanManager.packageCommandResponse(lynxModuleMetaList);
                    RobotLog.vv("FtcConfigTag", "DiscoverLynxModules data='%s'", packageCommandResponse);
                    FtcEventLoopBase.this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_DISCOVER_LYNX_MODULES_RESP, packageCommandResponse));
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void handleCommandLynxFirmwareUpdate(final Command command) {
        RobotLog.vv(TAG, "handleCommandLynxFirmwareUpdate received");
        final RobotCoreCommandList.LynxFirmwareUpdate deserialize = RobotCoreCommandList.LynxFirmwareUpdate.deserialize(command.getExtra());
        ThreadPool.getDefault().submit(new Runnable() {
            public void run() {
                FtcEventLoopBase.this.networkConnectionHandler.sendReply(command, new Command(RobotCoreCommandList.CMD_LYNX_FIRMWARE_UPDATE_RESP, FtcEventLoopBase.this.updateLynxFirmware(deserialize.serialNumber, deserialize.firmwareImageFile, deserialize.originatorId).serialize()));
            }
        });
    }

    /* access modifiers changed from: protected */
    public RobotCoreCommandList.LynxFirmwareUpdateResp updateLynxFirmware(final SerialNumber serialNumber, final RobotCoreCommandList.FWImage fWImage, String str) {
        LynxUsbDevice lynxUsbDeviceForFirmwareUpdate;
        RobotCoreCommandList.LynxFirmwareUpdateResp lynxFirmwareUpdateResp = new RobotCoreCommandList.LynxFirmwareUpdateResp();
        lynxFirmwareUpdateResp.success = false;
        lynxFirmwareUpdateResp.originatorId = str;
        final boolean isEmbedded = serialNumber.isEmbedded();
        AnonymousClass5 r3 = new Consumer<ProgressParameters>() {
            Double prevPercentComplete = null;

            public void accept(ProgressParameters progressParameters) {
                String str;
                double round = (double) Math.round(progressParameters.fractionComplete() * 100.0d);
                Double d = this.prevPercentComplete;
                if (d == null || d.doubleValue() != round) {
                    this.prevPercentComplete = Double.valueOf(round);
                    if (isEmbedded) {
                        str = String.format(FtcEventLoopBase.this.activityContext.getString(R.string.controlHubFirmwareUpdateMessage), new Object[]{fWImage.getName()});
                    } else {
                        str = String.format(FtcEventLoopBase.this.activityContext.getString(R.string.expansionHubFirmwareUpdateMessage), new Object[]{serialNumber, fWImage.getName()});
                    }
                    AppUtil.getInstance().showProgress(UILocation.BOTH, str, progressParameters.fractionComplete(), 100);
                }
            }
        };
        try {
            r3.accept(new ProgressParameters(0, 1));
            lynxUsbDeviceForFirmwareUpdate = getLynxUsbDeviceForFirmwareUpdate(serialNumber);
            if (lynxUsbDeviceForFirmwareUpdate != null) {
                lynxFirmwareUpdateResp = lynxUsbDeviceForFirmwareUpdate.updateFirmware(fWImage, str, r3);
                lynxUsbDeviceForFirmwareUpdate.close();
            } else {
                RobotLog.ee(TAG, "unable to obtain lynx usb device for fw update: %s", serialNumber);
            }
            AppUtil.getInstance().dismissProgress(UILocation.BOTH);
            RobotLog.vv(TAG, "updateLynxFirmware(%s, %s): result=%s", serialNumber, fWImage.getName(), lynxFirmwareUpdateResp.serialize());
            return lynxFirmwareUpdateResp;
        } catch (Throwable th) {
            AppUtil.getInstance().dismissProgress(UILocation.BOTH);
            throw th;
        }
    }

    /* access modifiers changed from: protected */
    public void handleCommandGetUSBAccessibleLynxModules(final Command command) {
        ThreadPool.getDefault().execute(new Runnable() {
            public void run() {
                RobotCoreCommandList.USBAccessibleLynxModulesRequest deserialize = RobotCoreCommandList.USBAccessibleLynxModulesRequest.deserialize(command.getExtra());
                ArrayList<USBAccessibleLynxModule> arrayList = new ArrayList<>();
                try {
                    arrayList.addAll(FtcEventLoopBase.this.getUSBAccessibleLynxDevices(deserialize.forFirmwareUpdate));
                } catch (RobotCoreException unused) {
                }
                Collections.sort(arrayList, new Comparator<USBAccessibleLynxModule>() {
                    public int compare(USBAccessibleLynxModule uSBAccessibleLynxModule, USBAccessibleLynxModule uSBAccessibleLynxModule2) {
                        return uSBAccessibleLynxModule.getSerialNumber().getString().compareTo(uSBAccessibleLynxModule2.getSerialNumber().getString());
                    }
                });
                RobotCoreCommandList.USBAccessibleLynxModulesResp uSBAccessibleLynxModulesResp = new RobotCoreCommandList.USBAccessibleLynxModulesResp();
                uSBAccessibleLynxModulesResp.modules = arrayList;
                FtcEventLoopBase.this.networkConnectionHandler.sendReply(command, new Command(RobotCoreCommandList.CMD_GET_USB_ACCESSIBLE_LYNX_MODULES_RESP, uSBAccessibleLynxModulesResp.serialize()));
            }
        });
    }

    /* access modifiers changed from: protected */
    public LynxUsbDevice getLynxUsbDeviceForFirmwareUpdate(SerialNumber serialNumber) {
        try {
            return (LynxUsbDevice) this.usbScanManager.getDeviceManager().createLynxUsbDevice(serialNumber, (String) null);
        } catch (RobotCoreException e) {
            RobotLog.ee(TAG, e, "getLynxUsbDeviceForFirmwareUpdate(): exception opening lynx usb device: %s", serialNumber);
            return null;
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            RobotLog.ee(TAG, "Thread interrupted in getLynxUsbDeviceForFirmwareUpdate");
            return null;
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x014c, code lost:
        r13 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:57:?, code lost:
        java.lang.Thread.currentThread().interrupt();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x015d, code lost:
        return new java.util.ArrayList();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x015e, code lost:
        com.qualcomm.robotcore.util.RobotLog.vv(TAG, "...getUSBAccessibleLynxDevices()");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x0161, code lost:
        throw r13;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:56:0x014e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.List<com.qualcomm.robotcore.hardware.USBAccessibleLynxModule> getUSBAccessibleLynxDevices(boolean r13) throws com.qualcomm.robotcore.exception.RobotCoreException {
        /*
            r12 = this;
            java.lang.String r0 = "...getUSBAccessibleLynxDevices()"
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r13)
            java.lang.Object[] r1 = new java.lang.Object[]{r1}
            java.lang.String r2 = "FtcEventLoop"
            java.lang.String r3 = "getUSBAccessibleLynxDevices(includeModuleAddresses=%s)..."
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r3, (java.lang.Object[]) r1)
            com.qualcomm.ftccommon.configuration.USBScanManager r1 = com.qualcomm.ftccommon.configuration.USBScanManager.getInstance()
            com.qualcomm.robotcore.util.ThreadPool$SingletonResult r3 = r1.startDeviceScanIfNecessary()
            java.lang.Object r3 = r3.await()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.ScannedDevices r3 = (com.qualcomm.robotcore.hardware.ScannedDevices) r3     // Catch:{ InterruptedException -> 0x014e }
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch:{ InterruptedException -> 0x014e }
            r4.<init>()     // Catch:{ InterruptedException -> 0x014e }
            java.util.Set r3 = r3.entrySet()     // Catch:{ InterruptedException -> 0x014e }
            java.util.Iterator r3 = r3.iterator()     // Catch:{ InterruptedException -> 0x014e }
        L_0x002c:
            boolean r5 = r3.hasNext()     // Catch:{ InterruptedException -> 0x014e }
            if (r5 == 0) goto L_0x004f
            java.lang.Object r5 = r3.next()     // Catch:{ InterruptedException -> 0x014e }
            java.util.Map$Entry r5 = (java.util.Map.Entry) r5     // Catch:{ InterruptedException -> 0x014e }
            java.lang.Object r6 = r5.getValue()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r7 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.LYNX_USB_DEVICE     // Catch:{ InterruptedException -> 0x014e }
            if (r6 != r7) goto L_0x002c
            java.lang.Object r5 = r5.getKey()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.SerialNumber r5 = (com.qualcomm.robotcore.util.SerialNumber) r5     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.USBAccessibleLynxModule r6 = new com.qualcomm.robotcore.hardware.USBAccessibleLynxModule     // Catch:{ InterruptedException -> 0x014e }
            r6.<init>(r5)     // Catch:{ InterruptedException -> 0x014e }
            r4.add(r6)     // Catch:{ InterruptedException -> 0x014e }
            goto L_0x002c
        L_0x004f:
            boolean r3 = com.qualcomm.robotcore.hardware.configuration.LynxConstants.isRevControlHub()     // Catch:{ InterruptedException -> 0x014e }
            if (r3 == 0) goto L_0x007c
            java.util.Iterator r3 = r4.iterator()     // Catch:{ InterruptedException -> 0x014e }
        L_0x0059:
            boolean r5 = r3.hasNext()     // Catch:{ InterruptedException -> 0x014e }
            if (r5 == 0) goto L_0x0072
            java.lang.Object r5 = r3.next()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.USBAccessibleLynxModule r5 = (com.qualcomm.robotcore.hardware.USBAccessibleLynxModule) r5     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.SerialNumber r5 = r5.getSerialNumber()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.SerialNumber r6 = com.qualcomm.robotcore.hardware.configuration.LynxConstants.SERIAL_NUMBER_EMBEDDED     // Catch:{ InterruptedException -> 0x014e }
            boolean r5 = r5.equals((java.lang.Object) r6)     // Catch:{ InterruptedException -> 0x014e }
            if (r5 == 0) goto L_0x0059
            goto L_0x007c
        L_0x0072:
            com.qualcomm.robotcore.hardware.USBAccessibleLynxModule r3 = new com.qualcomm.robotcore.hardware.USBAccessibleLynxModule     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.SerialNumber r5 = com.qualcomm.robotcore.hardware.configuration.LynxConstants.SERIAL_NUMBER_EMBEDDED     // Catch:{ InterruptedException -> 0x014e }
            r3.<init>(r5)     // Catch:{ InterruptedException -> 0x014e }
            r4.add(r3)     // Catch:{ InterruptedException -> 0x014e }
        L_0x007c:
            java.util.Iterator r3 = r4.iterator()     // Catch:{ InterruptedException -> 0x014e }
        L_0x0080:
            boolean r5 = r3.hasNext()     // Catch:{ InterruptedException -> 0x014e }
            if (r5 == 0) goto L_0x009a
            java.lang.Object r5 = r3.next()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.USBAccessibleLynxModule r5 = (com.qualcomm.robotcore.hardware.USBAccessibleLynxModule) r5     // Catch:{ InterruptedException -> 0x014e }
            java.lang.String r6 = "getUSBAccessibleLynxDevices: found serial=%s"
            com.qualcomm.robotcore.util.SerialNumber r5 = r5.getSerialNumber()     // Catch:{ InterruptedException -> 0x014e }
            java.lang.Object[] r5 = new java.lang.Object[]{r5}     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r6, (java.lang.Object[]) r5)     // Catch:{ InterruptedException -> 0x014e }
            goto L_0x0080
        L_0x009a:
            if (r13 == 0) goto L_0x0137
            java.lang.String r13 = "finding module addresses and current firmware versions"
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r13)     // Catch:{ InterruptedException -> 0x014e }
            r13 = 0
            r3 = r13
        L_0x00a3:
            int r5 = r4.size()     // Catch:{ InterruptedException -> 0x014e }
            if (r3 >= r5) goto L_0x0137
            java.lang.Object r5 = r4.get(r3)     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.USBAccessibleLynxModule r5 = (com.qualcomm.robotcore.hardware.USBAccessibleLynxModule) r5     // Catch:{ InterruptedException -> 0x014e }
            java.lang.String r6 = "getUSBAccessibleLynxDevices: finding module address for usbModule %s"
            com.qualcomm.robotcore.util.SerialNumber r7 = r5.getSerialNumber()     // Catch:{ InterruptedException -> 0x014e }
            java.lang.Object[] r7 = new java.lang.Object[]{r7}     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r6, (java.lang.Object[]) r7)     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.DeviceManager r6 = r1.getDeviceManager()     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.SerialNumber r7 = r5.getSerialNumber()     // Catch:{ InterruptedException -> 0x014e }
            r8 = 0
            com.qualcomm.robotcore.hardware.RobotCoreLynxUsbDevice r6 = r6.createLynxUsbDevice(r7, r8)     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.hardware.lynx.LynxUsbDevice r6 = (com.qualcomm.hardware.lynx.LynxUsbDevice) r6     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.hardware.LynxModuleMetaList r7 = r6.discoverModules(r13)     // Catch:{ all -> 0x0130 }
            r5.setModuleAddress(r13)     // Catch:{ all -> 0x0130 }
            java.util.Iterator r7 = r7.iterator()     // Catch:{ all -> 0x0130 }
            r8 = r13
        L_0x00d7:
            boolean r9 = r7.hasNext()     // Catch:{ all -> 0x0130 }
            if (r9 == 0) goto L_0x0107
            java.lang.Object r9 = r7.next()     // Catch:{ all -> 0x0130 }
            com.qualcomm.robotcore.hardware.LynxModuleMeta r9 = (com.qualcomm.robotcore.hardware.LynxModuleMeta) r9     // Catch:{ all -> 0x0130 }
            java.lang.String r10 = "assessing %s"
            java.lang.Object[] r11 = new java.lang.Object[]{r9}     // Catch:{ all -> 0x0130 }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r10, (java.lang.Object[]) r11)     // Catch:{ all -> 0x0130 }
            int r10 = r9.getModuleAddress()     // Catch:{ all -> 0x0130 }
            if (r10 != 0) goto L_0x00f8
            java.lang.String r9 = "ignoring module with address zero"
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r9)     // Catch:{ all -> 0x0130 }
            goto L_0x00d7
        L_0x00f8:
            boolean r10 = r9.isParent()     // Catch:{ all -> 0x0130 }
            if (r10 == 0) goto L_0x00d7
            int r8 = r9.getModuleAddress()     // Catch:{ all -> 0x0130 }
            r5.setModuleAddress(r8)     // Catch:{ all -> 0x0130 }
            r8 = 1
            goto L_0x00d7
        L_0x0107:
            java.lang.String r7 = ""
            r5.setFirmwareVersionString(r7)     // Catch:{ all -> 0x0130 }
            if (r8 == 0) goto L_0x0127
            int r7 = r5.getModuleAddress()     // Catch:{ RobotCoreException -> 0x0121, TimeoutException -> 0x011f }
            com.qualcomm.ftccommon.FtcEventLoopBase$$ExternalSyntheticLambda0 r8 = new com.qualcomm.ftccommon.FtcEventLoopBase$$ExternalSyntheticLambda0     // Catch:{ RobotCoreException -> 0x0121, TimeoutException -> 0x011f }
            r8.<init>(r5)     // Catch:{ RobotCoreException -> 0x0121, TimeoutException -> 0x011f }
            java.util.concurrent.TimeUnit r5 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ RobotCoreException -> 0x0121, TimeoutException -> 0x011f }
            r9 = 250(0xfa, float:3.5E-43)
            r6.performSystemOperationOnParentModule(r7, r8, r9, r5)     // Catch:{ RobotCoreException -> 0x0121, TimeoutException -> 0x011f }
            goto L_0x0127
        L_0x011f:
            r5 = move-exception
            goto L_0x0122
        L_0x0121:
            r5 = move-exception
        L_0x0122:
            java.lang.String r7 = "exception retrieving fw version; ignoring"
            com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r2, (java.lang.Throwable) r5, (java.lang.String) r7)     // Catch:{ all -> 0x0130 }
        L_0x0127:
            int r3 = r3 + 1
            if (r6 == 0) goto L_0x00a3
            r6.close()     // Catch:{ InterruptedException -> 0x014e }
            goto L_0x00a3
        L_0x0130:
            r13 = move-exception
            if (r6 == 0) goto L_0x0136
            r6.close()     // Catch:{ InterruptedException -> 0x014e }
        L_0x0136:
            throw r13     // Catch:{ InterruptedException -> 0x014e }
        L_0x0137:
            java.lang.String r13 = "getUSBAccessibleLynxDevices(): %d modules found"
            int r1 = r4.size()     // Catch:{ InterruptedException -> 0x014e }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ InterruptedException -> 0x014e }
            java.lang.Object[] r1 = new java.lang.Object[]{r1}     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r13, (java.lang.Object[]) r1)     // Catch:{ InterruptedException -> 0x014e }
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r0)
            return r4
        L_0x014c:
            r13 = move-exception
            goto L_0x015e
        L_0x014e:
            java.lang.Thread r13 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x014c }
            r13.interrupt()     // Catch:{ all -> 0x014c }
            java.util.ArrayList r13 = new java.util.ArrayList     // Catch:{ all -> 0x014c }
            r13.<init>()     // Catch:{ all -> 0x014c }
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r0)
            return r13
        L_0x015e:
            com.qualcomm.robotcore.util.RobotLog.vv(r2, r0)
            throw r13
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.FtcEventLoopBase.getUSBAccessibleLynxDevices(boolean):java.util.List");
    }

    static /* synthetic */ void lambda$getUSBAccessibleLynxDevices$0(USBAccessibleLynxModule uSBAccessibleLynxModule, LynxModule lynxModule) {
        String nullableFirmwareVersionString = lynxModule.getNullableFirmwareVersionString();
        if (nullableFirmwareVersionString != null) {
            uSBAccessibleLynxModule.setFirmwareVersionString(nullableFirmwareVersionString);
        } else {
            RobotLog.ee(TAG, "getUSBAccessibleLynxDevices(): fw returned null");
        }
    }

    /* access modifiers changed from: protected */
    public void handleCommandLynxChangeModuleAddresses(final Command command) {
        ThreadPool.getDefault().execute(new Runnable() {
            /* JADX WARNING: Removed duplicated region for block: B:27:0x009f A[SYNTHETIC, Splitter:B:27:0x009f] */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r14 = this;
                    java.lang.String r0 = "FtcEventLoop"
                    java.lang.String r1 = "CMD_LYNX_ADDRESS_CHANGE_FINISHED"
                    r2 = 1
                    com.qualcomm.robotcore.robocol.Command r3 = r3     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.lang.String r3 = r3.getExtra()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.ftccommon.CommandList$LynxAddressChangeRequest r3 = com.qualcomm.ftccommon.CommandList.LynxAddressChangeRequest.deserialize(r3)     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.ftccommon.FtcEventLoopBase r4 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.ftccommon.configuration.USBScanManager r4 = r4.usbScanManager     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.robotcore.hardware.DeviceManager r4 = r4.getDeviceManager()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.util.ArrayList<com.qualcomm.ftccommon.CommandList$LynxAddressChangeRequest$AddressChange> r3 = r3.modulesToChange     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.util.Iterator r3 = r3.iterator()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                L_0x001d:
                    boolean r5 = r3.hasNext()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    if (r5 == 0) goto L_0x00a3
                    java.lang.Object r5 = r3.next()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.ftccommon.CommandList$LynxAddressChangeRequest$AddressChange r5 = (com.qualcomm.ftccommon.CommandList.LynxAddressChangeRequest.AddressChange) r5     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.lang.String r6 = "lynx module connected to portal %s (parent address %d): change address %d -> %d"
                    com.qualcomm.robotcore.util.SerialNumber r7 = r5.serialNumber     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    int r8 = r5.parentAddress     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    int r9 = r5.oldAddress     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    int r10 = r5.newAddress     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.lang.Integer r10 = java.lang.Integer.valueOf(r10)     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    java.lang.Object[] r7 = new java.lang.Object[]{r7, r8, r9, r10}     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r0, (java.lang.String) r6, (java.lang.Object[]) r7)     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.robotcore.util.SerialNumber r6 = r5.serialNumber     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    r7 = 0
                    com.qualcomm.robotcore.hardware.RobotCoreLynxUsbDevice r6 = r4.createLynxUsbDevice(r6, r7)     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    com.qualcomm.hardware.lynx.LynxUsbDevice r6 = (com.qualcomm.hardware.lynx.LynxUsbDevice) r6     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    int r8 = r5.oldAddress     // Catch:{ RobotCoreException -> 0x006a, TimeoutException -> 0x0068 }
                    int r9 = r5.parentAddress     // Catch:{ RobotCoreException -> 0x006a, TimeoutException -> 0x0068 }
                    com.qualcomm.ftccommon.FtcEventLoopBase$7$$ExternalSyntheticLambda0 r10 = new com.qualcomm.ftccommon.FtcEventLoopBase$7$$ExternalSyntheticLambda0     // Catch:{ RobotCoreException -> 0x006a, TimeoutException -> 0x0068 }
                    r10.<init>(r5)     // Catch:{ RobotCoreException -> 0x006a, TimeoutException -> 0x0068 }
                    java.util.concurrent.TimeUnit r12 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ RobotCoreException -> 0x006a, TimeoutException -> 0x0068 }
                    r11 = 250(0xfa, float:3.5E-43)
                    r7 = r6
                    r7.performSystemOperationOnConnectedModule(r8, r9, r10, r11, r12)     // Catch:{ RobotCoreException -> 0x006a, TimeoutException -> 0x0068 }
                    if (r6 == 0) goto L_0x001d
                    r6.close()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                    goto L_0x001d
                L_0x0066:
                    r0 = move-exception
                    goto L_0x009d
                L_0x0068:
                    r3 = move-exception
                    goto L_0x006b
                L_0x006a:
                    r3 = move-exception
                L_0x006b:
                    java.lang.String r4 = "failure during module address change"
                    com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r0, (java.lang.Throwable) r3, (java.lang.String) r4)     // Catch:{ all -> 0x0066 }
                    org.firstinspires.ftc.robotcore.internal.system.AppUtil r0 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance()     // Catch:{ all -> 0x0066 }
                    org.firstinspires.ftc.robotcore.internal.ui.UILocation r4 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH     // Catch:{ all -> 0x0066 }
                    com.qualcomm.ftccommon.FtcEventLoopBase r7 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ all -> 0x0066 }
                    android.app.Activity r7 = r7.activityContext     // Catch:{ all -> 0x0066 }
                    int r8 = com.qualcomm.ftccommon.R.string.toastLynxAddressChangeFailed     // Catch:{ all -> 0x0066 }
                    com.qualcomm.robotcore.util.SerialNumber r5 = r5.serialNumber     // Catch:{ all -> 0x0066 }
                    java.lang.Object[] r5 = new java.lang.Object[]{r5}     // Catch:{ all -> 0x0066 }
                    java.lang.String r5 = r7.getString(r8, r5)     // Catch:{ all -> 0x0066 }
                    r0.showToast(r4, r5)     // Catch:{ all -> 0x0066 }
                    r0 = 0
                    boolean r2 = r3 instanceof com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x0099 }
                    if (r2 == 0) goto L_0x0091
                    com.qualcomm.robotcore.exception.RobotCoreException r3 = (com.qualcomm.robotcore.exception.RobotCoreException) r3     // Catch:{ all -> 0x0099 }
                    throw r3     // Catch:{ all -> 0x0099 }
                L_0x0091:
                    com.qualcomm.robotcore.exception.RobotCoreException r2 = new com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x0099 }
                    java.lang.String r4 = "Failed to change module address"
                    r2.<init>((java.lang.String) r4, (java.lang.Throwable) r3)     // Catch:{ all -> 0x0099 }
                    throw r2     // Catch:{ all -> 0x0099 }
                L_0x0099:
                    r2 = move-exception
                    r13 = r2
                    r2 = r0
                    r0 = r13
                L_0x009d:
                    if (r6 == 0) goto L_0x00a2
                    r6.close()     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                L_0x00a2:
                    throw r0     // Catch:{ RobotCoreException -> 0x00ea, all -> 0x00c5 }
                L_0x00a3:
                    com.qualcomm.ftccommon.FtcEventLoopBase r0 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler r0 = r0.networkConnectionHandler     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.robotcore.robocol.Command r2 = r3     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.robotcore.robocol.Command r3 = new com.qualcomm.robotcore.robocol.Command     // Catch:{ InterruptedException -> 0x0107 }
                    r3.<init>((java.lang.String) r1)     // Catch:{ InterruptedException -> 0x0107 }
                    r0.sendReply(r2, r3)     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.system.AppUtil r0 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance()     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.ui.UILocation r1 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.ftccommon.FtcEventLoopBase r2 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ InterruptedException -> 0x0107 }
                    android.app.Activity r2 = r2.activityContext     // Catch:{ InterruptedException -> 0x0107 }
                    int r3 = com.qualcomm.ftccommon.R.string.toastLynxAddressChangeComplete     // Catch:{ InterruptedException -> 0x0107 }
                L_0x00bd:
                    java.lang.String r2 = r2.getString(r3)     // Catch:{ InterruptedException -> 0x0107 }
                    r0.showToast(r1, r2)     // Catch:{ InterruptedException -> 0x0107 }
                    goto L_0x010e
                L_0x00c5:
                    r0 = move-exception
                    com.qualcomm.ftccommon.FtcEventLoopBase r3 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler r3 = r3.networkConnectionHandler     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.robotcore.robocol.Command r4 = r3     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.robotcore.robocol.Command r5 = new com.qualcomm.robotcore.robocol.Command     // Catch:{ InterruptedException -> 0x0107 }
                    r5.<init>((java.lang.String) r1)     // Catch:{ InterruptedException -> 0x0107 }
                    r3.sendReply(r4, r5)     // Catch:{ InterruptedException -> 0x0107 }
                    if (r2 == 0) goto L_0x00e9
                    org.firstinspires.ftc.robotcore.internal.system.AppUtil r1 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance()     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.ui.UILocation r2 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.ftccommon.FtcEventLoopBase r3 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ InterruptedException -> 0x0107 }
                    android.app.Activity r3 = r3.activityContext     // Catch:{ InterruptedException -> 0x0107 }
                    int r4 = com.qualcomm.ftccommon.R.string.toastLynxAddressChangeComplete     // Catch:{ InterruptedException -> 0x0107 }
                    java.lang.String r3 = r3.getString(r4)     // Catch:{ InterruptedException -> 0x0107 }
                    r1.showToast(r2, r3)     // Catch:{ InterruptedException -> 0x0107 }
                L_0x00e9:
                    throw r0     // Catch:{ InterruptedException -> 0x0107 }
                L_0x00ea:
                    com.qualcomm.ftccommon.FtcEventLoopBase r0 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler r0 = r0.networkConnectionHandler     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.robotcore.robocol.Command r3 = r3     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.robotcore.robocol.Command r4 = new com.qualcomm.robotcore.robocol.Command     // Catch:{ InterruptedException -> 0x0107 }
                    r4.<init>((java.lang.String) r1)     // Catch:{ InterruptedException -> 0x0107 }
                    r0.sendReply(r3, r4)     // Catch:{ InterruptedException -> 0x0107 }
                    if (r2 == 0) goto L_0x010e
                    org.firstinspires.ftc.robotcore.internal.system.AppUtil r0 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance()     // Catch:{ InterruptedException -> 0x0107 }
                    org.firstinspires.ftc.robotcore.internal.ui.UILocation r1 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH     // Catch:{ InterruptedException -> 0x0107 }
                    com.qualcomm.ftccommon.FtcEventLoopBase r2 = com.qualcomm.ftccommon.FtcEventLoopBase.this     // Catch:{ InterruptedException -> 0x0107 }
                    android.app.Activity r2 = r2.activityContext     // Catch:{ InterruptedException -> 0x0107 }
                    int r3 = com.qualcomm.ftccommon.R.string.toastLynxAddressChangeComplete     // Catch:{ InterruptedException -> 0x0107 }
                    goto L_0x00bd
                L_0x0107:
                    java.lang.Thread r0 = java.lang.Thread.currentThread()
                    r0.interrupt()
                L_0x010e:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.FtcEventLoopBase.AnonymousClass7.run():void");
            }
        });
    }

    /* access modifiers changed from: protected */
    public void handleCommandGetCandidateLynxFirmwareImages(Command command) {
        final Pattern compile = Pattern.compile("(?i).*\\.bin");
        File file = AppUtil.LYNX_FIRMWARE_UPDATE_DIR;
        File[] listFiles = file.listFiles(new FileFilter() {
            public boolean accept(File file) {
                Assert.assertTrue(file.isAbsolute());
                return compile.matcher(file.getName()).matches();
            }
        });
        RobotCoreCommandList.LynxFirmwareImagesResp lynxFirmwareImagesResp = new RobotCoreCommandList.LynxFirmwareImagesResp();
        lynxFirmwareImagesResp.firstFolder = AppUtil.FIRST_FOLDER;
        for (File fWImage : listFiles) {
            lynxFirmwareImagesResp.firmwareImages.add(new RobotCoreCommandList.FWImage(fWImage, false));
        }
        try {
            File file2 = new File(file.getParentFile().getName(), file.getName());
            for (String str : this.activityContext.getAssets().list(file2.getPath())) {
                if (compile.matcher(str).matches()) {
                    File file3 = new File(file2, str);
                    Assert.assertTrue(!file3.isAbsolute());
                    lynxFirmwareImagesResp.firmwareImages.add(new RobotCoreCommandList.FWImage(file3, true));
                }
            }
        } catch (IOException unused) {
        }
        this.networkConnectionHandler.sendReply(command, new Command(RobotCoreCommandList.CMD_GET_CANDIDATE_LYNX_FIRMWARE_IMAGES_RESP, lynxFirmwareImagesResp.serialize()));
    }

    /* access modifiers changed from: protected */
    public void handleCommandRequestConfigurationTemplates() {
        this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_REQUEST_CONFIGURATION_TEMPLATES_RESP, RobotConfigFileManager.serializeXMLConfigList(this.robotCfgFileMgr.getXMLTemplates())));
    }

    /* access modifiers changed from: protected */
    public void handleCommandStartDriverStationProgramAndManage() {
        EventLoopManager eventLoopManager = this.ftcEventLoopHandler.getEventLoopManager();
        if (eventLoopManager != null) {
            String json = eventLoopManager.getWebServer().getConnectionInformation().toJson();
            RobotLog.vv(TAG, "sending p&m resp: %s", json);
            this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_START_DS_PROGRAM_AND_MANAGE_RESP, json));
            return;
        }
        RobotLog.vv(TAG, "handleCommandStartDriverStationProgramAndManage() with null EventLoopManager; ignored");
    }

    /* access modifiers changed from: protected */
    public void handleCommandShowDialog(Command command) {
        RobotCoreCommandList.ShowDialog deserialize = RobotCoreCommandList.ShowDialog.deserialize(command.getExtra());
        AppUtil.DialogParams dialogParams = new AppUtil.DialogParams(UILocation.ONLY_LOCAL, deserialize.title, deserialize.message);
        dialogParams.uuidString = deserialize.uuidString;
        AppUtil.getInstance().showDialog(dialogParams);
    }

    /* access modifiers changed from: protected */
    public void handleCommandDismissDialog(Command command) {
        AppUtil.getInstance().dismissDialog(UILocation.ONLY_LOCAL, RobotCoreCommandList.DismissDialog.deserialize(command.getExtra()));
    }

    /* access modifiers changed from: protected */
    public void handleCommandDismissAllDialogs(Command command) {
        AppUtil.getInstance().dismissAllDialogs(UILocation.ONLY_LOCAL);
    }

    /* access modifiers changed from: protected */
    public void handleCommandShowProgress(Command command) {
        RobotCoreCommandList.ShowProgress deserialize = RobotCoreCommandList.ShowProgress.deserialize(command.getExtra());
        AppUtil.getInstance().showProgress(UILocation.ONLY_LOCAL, deserialize.message, (ProgressParameters) deserialize);
    }

    /* access modifiers changed from: protected */
    public void handleCommandDismissProgress(Command command) {
        AppUtil.getInstance().dismissProgress(UILocation.ONLY_LOCAL);
    }

    /* access modifiers changed from: protected */
    public void handleCommandShowToast(Command command) {
        RobotCoreCommandList.ShowToast deserialize = RobotCoreCommandList.ShowToast.deserialize(command.getExtra());
        AppUtil.getInstance().showToast(UILocation.ONLY_LOCAL, deserialize.message, deserialize.duration);
    }

    /* access modifiers changed from: protected */
    public void handleCommandRequestInspectionReport() {
        InspectionState inspectionState = new InspectionState();
        inspectionState.initializeLocal();
        this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_REQUEST_INSPECTION_REPORT_RESP, inspectionState.serialize()));
    }

    /* access modifiers changed from: protected */
    public void handleCommandDisableBluetooth() {
        AppUtil.getInstance().setBluetoothEnabled(false);
    }

    /* access modifiers changed from: protected */
    public void handleCommandRequestAboutInfo(Command command) {
        this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_REQUEST_ABOUT_INFO_RESP, FtcAboutActivity.getLocalAboutInfo().serialize()));
    }

    /* access modifiers changed from: protected */
    public void handleCommandDisconnectWifiDirect() {
        if (WifiDirectAgent.getInstance().disconnectFromWifiDirect()) {
            AppUtil.getInstance().showToast(UILocation.BOTH, AppUtil.getDefContext().getString(R.string.toastDisconnectedFromWifiDirect));
        } else {
            AppUtil.getInstance().showToast(UILocation.BOTH, AppUtil.getDefContext().getString(R.string.toastErrorDisconnectingFromWifiDirect));
        }
    }

    /* access modifiers changed from: protected */
    public CallbackResult handleCommandVisuallyIdentify(Command command) {
        ThreadPool.getDefaultSerial().execute(new FtcEventLoopBase$$ExternalSyntheticLambda1(CommandList.CmdVisuallyIdentify.deserialize(command.getExtra())));
        return CallbackResult.HANDLED;
    }

    /* access modifiers changed from: protected */
    public CallbackResult handleCommandVisuallyConfirmWifiReset() {
        if (!LynxConstants.isRevControlHub()) {
            return CallbackResult.HANDLED;
        }
        ThreadPool.getDefaultSerial().execute(new Runnable() {
            public void run() {
                LynxModule lynxModule = (LynxModule) EmbeddedControlHubModule.get();
                if (lynxModule != null) {
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(new Blinker.Step(-65281, 100, TimeUnit.MILLISECONDS));
                    arrayList.add(new Blinker.Step(-256, 100, TimeUnit.MILLISECONDS));
                    arrayList.add(new Blinker.Step(-16711681, 100, TimeUnit.MILLISECONDS));
                    arrayList.add(new Blinker.Step(SupportMenu.CATEGORY_MASK, 100, TimeUnit.MILLISECONDS));
                    lynxModule.pushPattern(arrayList);
                    try {
                        Thread.sleep(4000);
                    } catch (InterruptedException e) {
                        RobotLog.ee(FtcEventLoopBase.TAG, (Throwable) e, "Thread interrupted while visually confirming Wi-Fi reset");
                        Thread.currentThread().interrupt();
                    }
                    lynxModule.popPattern();
                }
            }
        });
        return CallbackResult.HANDLED;
    }

    /* access modifiers changed from: protected */
    public CallbackResult handleCommandVisuallyConfirmWifiBandSwitch(Command command) {
        if (!LynxConstants.isRevControlHub()) {
            return CallbackResult.HANDLED;
        }
        final int parseInt = Integer.parseInt(command.getExtra());
        ThreadPool.getDefaultSerial().execute(new Runnable() {
            public void run() {
                LynxModule lynxModule = (LynxModule) EmbeddedControlHubModule.get();
                if (lynxModule != null) {
                    int i = parseInt == 1 ? -65281 : -256;
                    ArrayList arrayList = new ArrayList();
                    arrayList.add(new Blinker.Step(i, 200, TimeUnit.MILLISECONDS));
                    arrayList.add(new Blinker.Step(ViewCompat.MEASURED_STATE_MASK, 100, TimeUnit.MILLISECONDS));
                    lynxModule.pushPattern(arrayList);
                    try {
                        Thread.sleep(6000);
                    } catch (InterruptedException e) {
                        RobotLog.ee(FtcEventLoopBase.TAG, (Throwable) e, "Thread interrupted while visually confirming Wi-Fi band switch");
                        Thread.currentThread().interrupt();
                    }
                    lynxModule.popPattern();
                }
            }
        });
        return CallbackResult.HANDLED;
    }
}

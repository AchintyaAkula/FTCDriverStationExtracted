package com.qualcomm.ftccommon;

import com.qualcomm.hardware.lynx.LynxModule;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class VisualIdentificationManager$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ boolean f$0;

    public /* synthetic */ VisualIdentificationManager$$ExternalSyntheticLambda0(boolean z) {
        this.f$0 = z;
    }

    public final void accept(Object obj) {
        ((LynxModule) obj).visuallyIdentify(this.f$0);
    }
}

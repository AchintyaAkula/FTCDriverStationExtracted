package com.qualcomm.ftccommon;

import com.qualcomm.hardware.lynx.LynxModule;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class VisualIdentificationManager$1$$ExternalSyntheticLambda0 implements Consumer {
    public final void accept(Object obj) {
        ((LynxModule) obj).visuallyIdentify(false);
    }
}

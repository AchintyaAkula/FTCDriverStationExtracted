package com.qualcomm.ftccommon;

import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.hardware.USBAccessibleLynxModule;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcEventLoopBase$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ USBAccessibleLynxModule f$0;

    public /* synthetic */ FtcEventLoopBase$$ExternalSyntheticLambda0(USBAccessibleLynxModule uSBAccessibleLynxModule) {
        this.f$0 = uSBAccessibleLynxModule;
    }

    public final void accept(Object obj) {
        FtcEventLoopBase.lambda$getUSBAccessibleLynxDevices$0(this.f$0, (LynxModule) obj);
    }
}

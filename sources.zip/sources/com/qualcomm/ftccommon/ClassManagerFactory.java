package com.qualcomm.ftccommon;

import com.qualcomm.ftccommon.configuration.RobotConfigFileManager;
import com.qualcomm.ftccommon.configuration.RobotConfigResFilter;
import com.qualcomm.robotcore.hardware.configuration.ConfigurationTypeManager;
import java.util.Collection;
import org.firstinspires.ftc.ftccommon.internal.AnnotatedHooksClassFilter;
import org.firstinspires.ftc.robotcore.external.Supplier;
import org.firstinspires.ftc.robotcore.internal.opmode.AnnotatedOpModeClassFilter;
import org.firstinspires.ftc.robotcore.internal.opmode.BlocksClassFilter;
import org.firstinspires.ftc.robotcore.internal.opmode.ClassManager;

public class ClassManagerFactory {
    /* access modifiers changed from: private */
    public static RobotConfigResFilter idResFilter;
    /* access modifiers changed from: private */
    public static RobotConfigResFilter idTemplateResFilter;

    public static void registerFilters() {
        registerResourceFilters();
        ClassManager instance = ClassManager.getInstance();
        instance.registerFilter(AnnotatedHooksClassFilter.getInstance());
        instance.registerFilter(AnnotatedOpModeClassFilter.getInstance());
        instance.registerFilter(BlocksClassFilter.getInstance());
        instance.registerFilter(ConfigurationTypeManager.getInstance());
    }

    public static void registerResourceFilters() {
        ClassManager instance = ClassManager.getInstance();
        if (idResFilter == null) {
            idResFilter = new RobotConfigResFilter(RobotConfigFileManager.getRobotConfigTypeAttribute());
            RobotConfigFileManager.setXmlResourceIdSupplier(new Supplier<Collection<Integer>>() {
                public Collection<Integer> get() {
                    return ClassManagerFactory.idResFilter.getXmlIds();
                }
            });
        }
        if (idTemplateResFilter == null) {
            idTemplateResFilter = new RobotConfigResFilter(RobotConfigFileManager.getRobotConfigTemplateAttribute());
            RobotConfigFileManager.setXmlResourceTemplateIdSupplier(new Supplier<Collection<Integer>>() {
                public Collection<Integer> get() {
                    return ClassManagerFactory.idTemplateResFilter.getXmlIds();
                }
            });
        }
        instance.registerFilter(idResFilter);
        instance.registerFilter(idTemplateResFilter);
    }

    public static void processAllClasses() {
        ClassManager.getInstance().processAllClasses();
    }
}

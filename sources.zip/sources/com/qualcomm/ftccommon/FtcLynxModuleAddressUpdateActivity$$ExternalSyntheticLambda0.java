package com.qualcomm.ftccommon;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ FtcLynxModuleAddressUpdateActivity f$0;

    public /* synthetic */ FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda0(FtcLynxModuleAddressUpdateActivity ftcLynxModuleAddressUpdateActivity) {
        this.f$0 = ftcLynxModuleAddressUpdateActivity;
    }

    public final void run() {
        this.f$0.m12lambda$loadExpansionHubs$0$comqualcommftccommonFtcLynxModuleAddressUpdateActivity();
    }
}

package com.qualcomm.ftccommon;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import com.qualcomm.ftccommon.CommandList;
import com.qualcomm.ftccommon.configuration.EditActivity;
import com.qualcomm.ftccommon.configuration.USBScanManager;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.LynxModuleMeta;
import com.qualcomm.robotcore.hardware.LynxModuleMetaList;
import com.qualcomm.robotcore.hardware.ScannedDevices;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import com.qualcomm.robotcore.util.ThreadPool;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import org.firstinspires.ftc.robotcore.internal.network.CallbackResult;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.RecvLoopRunnable;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.Assert;
import org.firstinspires.ftc.robotcore.internal.ui.UILocation;

public class FtcLynxModuleAddressUpdateActivity extends EditActivity {
    public static final String TAG = "FtcLynxModuleAddressUpdateActivity";
    protected final DisplayedPortalList displayedPortalList = new DisplayedPortalList();
    DialogInterface.OnClickListener doNothingAndCloseListener = new DialogInterface.OnClickListener() {
        public void onClick(DialogInterface dialogInterface, int i) {
        }
    };
    protected final int msResponseWait = 10000;
    protected final NetworkConnectionHandler networkConnectionHandler = NetworkConnectionHandler.getInstance();
    protected List<PortalInfo> portals = new ArrayList();

    public String getTag() {
        return TAG;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_ftc_lynx_address_update);
        ((Button) findViewById(R.id.applyButton)).setVisibility(0);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        loadExpansionHubs();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void loadExpansionHubs() {
        AppUtil.getInstance().showWaitCursor(getString(R.string.dialogMessagePleaseWait), new FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda1(this), new FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda0(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$loadExpansionHubs$0$com-qualcomm-ftccommon-FtcLynxModuleAddressUpdateActivity  reason: not valid java name */
    public /* synthetic */ void m12lambda$loadExpansionHubs$0$comqualcommftccommonFtcLynxModuleAddressUpdateActivity() {
        this.displayedPortalList.initialize(this.portals);
        TextView textView = (TextView) findViewById(R.id.noDevicesNotice);
        if (this.portals.isEmpty()) {
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$loadExpansionHubs$1$com-qualcomm-ftccommon-FtcLynxModuleAddressUpdateActivity  reason: not valid java name */
    public /* synthetic */ void m13lambda$loadExpansionHubs$1$comqualcommftccommonFtcLynxModuleAddressUpdateActivity() {
        this.portals = getPortalsInfo();
    }

    protected static class PortalInfo {
        public final List<Integer> childAddresses;
        public final int parentAddress;
        public final SerialNumber serialNumber;

        public PortalInfo(SerialNumber serialNumber2, int i, List<Integer> list) {
            this.serialNumber = serialNumber2;
            this.parentAddress = i;
            this.childAddresses = list;
        }
    }

    protected class DisplayedPortalList {
        protected final List<DisplayedPortal> displayedPortals = new ArrayList();
        protected ViewGroup portalList;

        protected DisplayedPortalList() {
        }

        public void initialize(List<PortalInfo> list) {
            ViewGroup viewGroup = (ViewGroup) FtcLynxModuleAddressUpdateActivity.this.findViewById(R.id.portalList);
            this.portalList = viewGroup;
            viewGroup.removeAllViews();
            this.displayedPortals.clear();
            for (PortalInfo add : list) {
                add(add);
            }
        }

        public boolean isDirty() {
            for (DisplayedPortal isDirty : this.displayedPortals) {
                if (isDirty.isDirty()) {
                    return true;
                }
            }
            return false;
        }

        /* access modifiers changed from: protected */
        public void add(PortalInfo portalInfo) {
            ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(FtcLynxModuleAddressUpdateActivity.this.context).inflate(R.layout.lynx_portal_configure_addresses, (ViewGroup) null);
            this.portalList.addView(viewGroup);
            DisplayedPortal displayedPortal = new DisplayedPortal(viewGroup);
            displayedPortal.initialize(portalInfo);
            this.displayedPortals.add(displayedPortal);
        }
    }

    protected class DisplayedPortal {
        protected static final int lastModuleAddressChoice = 10;
        protected final List<DisplayedModule> displayedModules = new ArrayList();
        protected int originalParentAddress;
        protected final Map<Integer, Integer> originalToNewAddressMap = new HashMap();
        protected final ViewGroup portalView;
        protected SerialNumber serialNumber;

        protected DisplayedPortal(ViewGroup viewGroup) {
            this.portalView = viewGroup;
        }

        public void initialize(PortalInfo portalInfo) {
            this.serialNumber = portalInfo.serialNumber;
            this.originalParentAddress = portalInfo.parentAddress;
            TextView textView = (TextView) this.portalView.findViewById(R.id.portalSerialText);
            if (this.serialNumber.isEmbedded()) {
                textView.setText(FtcLynxModuleAddressUpdateActivity.this.getString(R.string.lynx_address_control_hub_portal));
            } else {
                textView.setText(FtcLynxModuleAddressUpdateActivity.this.getString(R.string.lynx_address_format_expansion_hub_portal_serial, new Object[]{this.serialNumber}));
                add(this.originalParentAddress);
            }
            for (Integer intValue : portalInfo.childAddresses) {
                add(intValue.intValue());
            }
            updateAvailableAddresses();
        }

        public void changeAddress(int i, int i2) {
            RobotLog.vv(FtcLynxModuleAddressUpdateActivity.TAG, "Selected address change on portal %s from %d to %d", this.serialNumber, Integer.valueOf(i), Integer.valueOf(i2));
            this.originalToNewAddressMap.put(Integer.valueOf(i), Integer.valueOf(i2));
            updateAvailableAddresses();
        }

        public boolean isDirty() {
            for (Map.Entry next : this.originalToNewAddressMap.entrySet()) {
                if (((Integer) next.getKey()).intValue() != ((Integer) next.getValue()).intValue()) {
                    return true;
                }
            }
            return false;
        }

        /* access modifiers changed from: protected */
        public void updateAvailableAddresses() {
            ArrayList arrayList = new ArrayList(10);
            for (int i = 0; i <= 10; i++) {
                if (i == 0 || !this.originalToNewAddressMap.containsValue(Integer.valueOf(i))) {
                    arrayList.add(new AddressAndDisplayName(i));
                }
            }
            for (DisplayedModule availableAddresses : this.displayedModules) {
                availableAddresses.setAvailableAddresses(arrayList);
            }
        }

        /* access modifiers changed from: protected */
        public void add(int i) {
            this.originalToNewAddressMap.put(Integer.valueOf(i), Integer.valueOf(i));
            View inflate = LayoutInflater.from(FtcLynxModuleAddressUpdateActivity.this.context).inflate(R.layout.lynx_module_configure_address, (ViewGroup) null);
            this.portalView.addView(inflate);
            DisplayedModule displayedModule = new DisplayedModule(inflate, this, i);
            displayedModule.initialize();
            this.displayedModules.add(displayedModule);
        }
    }

    protected class DisplayedModule {
        protected final ArrayAdapter<AddressAndDisplayName> availableAddressesAdapter;
        protected final int originalAddress;
        protected final DisplayedPortal portal;
        protected final Spinner spinner;
        protected final View view;

        public DisplayedModule(View view2, DisplayedPortal displayedPortal, int i) {
            Assert.assertTrue(i != 0);
            this.originalAddress = i;
            this.portal = displayedPortal;
            this.view = view2;
            ArrayAdapter<AddressAndDisplayName> arrayAdapter = new ArrayAdapter<>(FtcLynxModuleAddressUpdateActivity.this, 17367048);
            this.availableAddressesAdapter = arrayAdapter;
            arrayAdapter.setDropDownViewResource(17367049);
            Spinner spinner2 = (Spinner) view2.findViewById(R.id.spinnerChooseAddress);
            this.spinner = spinner2;
            spinner2.setAdapter(arrayAdapter);
        }

        public void initialize() {
            ((TextView) this.view.findViewById(R.id.moduleAddressText)).setText(FtcLynxModuleAddressUpdateActivity.this.getString(R.string.lynx_address_format_module_address, new Object[]{Integer.valueOf(this.originalAddress)}));
            this.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                public void onNothingSelected(AdapterView<?> adapterView) {
                }

                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                    int i2 = ((AddressAndDisplayName) adapterView.getItemAtPosition(i)).address;
                    if (i2 == DisplayedModule.this.originalAddress) {
                        DisplayedModule.this.selectNoChange();
                    } else if (i2 == 0) {
                        i2 = DisplayedModule.this.originalAddress;
                    }
                    DisplayedModule.this.portal.changeAddress(DisplayedModule.this.originalAddress, i2);
                }
            });
        }

        public void setAvailableAddresses(List<AddressAndDisplayName> list) {
            int intValue = this.portal.originalToNewAddressMap.get(Integer.valueOf(this.originalAddress)).intValue();
            AddressAndDisplayName addressAndDisplayName = new AddressAndDisplayName(intValue);
            this.availableAddressesAdapter.clear();
            this.availableAddressesAdapter.addAll(list);
            this.availableAddressesAdapter.add(addressAndDisplayName);
            this.availableAddressesAdapter.sort(Comparator.comparingInt(new FtcLynxModuleAddressUpdateActivity$DisplayedModule$$ExternalSyntheticLambda0()));
            if (intValue == this.originalAddress) {
                this.spinner.setSelection(0);
            } else {
                this.spinner.setSelection(this.availableAddressesAdapter.getPosition(addressAndDisplayName));
            }
        }

        /* access modifiers changed from: protected */
        public void selectNoChange() {
            this.spinner.setSelection(0);
        }
    }

    protected class AddressAndDisplayName {
        public final int address;
        public final String displayName;

        public AddressAndDisplayName(int i) {
            String str;
            this.address = i;
            if (i == 0) {
                str = FtcLynxModuleAddressUpdateActivity.this.getString(R.string.lynx_address_format_no_change);
            } else {
                str = FtcLynxModuleAddressUpdateActivity.this.getString(R.string.lynx_address_format_new_module_address, new Object[]{Integer.valueOf(i)});
            }
            this.displayName = str;
        }

        public String toString() {
            return this.displayName;
        }
    }

    public void onApplyButtonPressed(View view) {
        RobotLog.vv(TAG, "onApplyButtonPressed()");
        FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda2 ftcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda2 = new FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda2(this);
        if (beginApplyingChanges()) {
            AppUtil.getInstance().showWaitCursor(getString(R.string.dialogMessagePleaseWait), ftcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda2, new FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda3(this));
        } else {
            loadExpansionHubs();
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$onApplyButtonPressed$2$com-qualcomm-ftccommon-FtcLynxModuleAddressUpdateActivity  reason: not valid java name */
    public /* synthetic */ void m14lambda$onApplyButtonPressed$2$comqualcommftccommonFtcLynxModuleAddressUpdateActivity() {
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        this.networkConnectionHandler.pushReceiveLoopCallback(new RecvLoopRunnable.DegenerateCallback() {
            public CallbackResult commandEvent(Command command) throws RobotCoreException {
                if (!command.getName().equals(CommandList.CMD_LYNX_ADDRESS_CHANGE_FINISHED)) {
                    return super.commandEvent(command);
                }
                countDownLatch.countDown();
                return CallbackResult.HANDLED;
            }
        });
        try {
            countDownLatch.await();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    public void onDoneButtonPressed(View view) {
        RobotLog.vv(TAG, "onDoneButtonPressed()");
        beginApplyingChanges();
        finishOk();
    }

    public void onCancelButtonPressed(View view) {
        RobotLog.vv(TAG, "onCancelButtonPressed()");
        doBackOrCancel();
    }

    public void onBackPressed() {
        RobotLog.vv(TAG, "onBackPressed()");
        doBackOrCancel();
    }

    /* access modifiers changed from: protected */
    public boolean beginApplyingChanges() {
        ArrayList<CommandList.LynxAddressChangeRequest.AddressChange> arrayList = new ArrayList<>();
        for (DisplayedPortal next : this.displayedPortalList.displayedPortals) {
            int i = next.originalParentAddress;
            for (Map.Entry next2 : next.originalToNewAddressMap.entrySet()) {
                int intValue = ((Integer) next2.getKey()).intValue();
                int intValue2 = ((Integer) next2.getValue()).intValue();
                if (intValue != intValue2) {
                    Assert.assertTrue(intValue != 0);
                    Assert.assertTrue(intValue2 != 0);
                    CommandList.LynxAddressChangeRequest.AddressChange addressChange = new CommandList.LynxAddressChangeRequest.AddressChange();
                    addressChange.serialNumber = next.serialNumber;
                    addressChange.parentAddress = i;
                    addressChange.oldAddress = intValue;
                    addressChange.newAddress = intValue2;
                    arrayList.add(addressChange);
                    if (intValue == i) {
                        i = intValue2;
                    }
                }
            }
        }
        if (this.displayedPortalList.displayedPortals.size() > 0) {
            if (arrayList.size() > 0) {
                CommandList.LynxAddressChangeRequest lynxAddressChangeRequest = new CommandList.LynxAddressChangeRequest();
                lynxAddressChangeRequest.modulesToChange = arrayList;
                sendOrInject(new Command(CommandList.CMD_LYNX_ADDRESS_CHANGE, lynxAddressChangeRequest.serialize()));
                return true;
            }
            AppUtil.getInstance().showToast(UILocation.BOTH, getString(R.string.toastLynxAddressChangeNothingToDo));
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void doBackOrCancel() {
        if (this.displayedPortalList.isDirty()) {
            AnonymousClass3 r0 = new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    FtcLynxModuleAddressUpdateActivity.this.finishCancel();
                }
            };
            AlertDialog.Builder buildBuilder = this.utility.buildBuilder(getString(R.string.saveChangesTitle), getString(R.string.saveChangesMessageScreen));
            buildBuilder.setPositiveButton(R.string.buttonExitWithoutSaving, r0);
            buildBuilder.setNegativeButton(R.string.buttonNameCancel, this.doNothingAndCloseListener);
            buildBuilder.show();
            return;
        }
        finishCancel();
    }

    /* access modifiers changed from: protected */
    public List<PortalInfo> getPortalsInfo() {
        USBScanManager instance = USBScanManager.getInstance();
        ArrayList arrayList = new ArrayList();
        try {
            ScannedDevices await = instance.startDeviceScanIfNecessary().await(10000);
            if (await != null) {
                HashMap hashMap = new HashMap();
                for (Map.Entry next : await.entrySet()) {
                    SerialNumber serialNumber = (SerialNumber) next.getKey();
                    if (((DeviceManager.UsbDeviceType) next.getValue()) == DeviceManager.UsbDeviceType.LYNX_USB_DEVICE) {
                        hashMap.put(serialNumber, instance.startLynxModuleEnumerationIfNecessary(serialNumber));
                    }
                }
                for (Map.Entry entry : hashMap.entrySet()) {
                    SerialNumber serialNumber2 = (SerialNumber) entry.getKey();
                    LynxModuleMetaList lynxModuleMetaList = (LynxModuleMetaList) ((ThreadPool.SingletonResult) entry.getValue()).await(10000);
                    if (lynxModuleMetaList != null) {
                        ArrayList arrayList2 = new ArrayList();
                        Iterator<LynxModuleMeta> it = lynxModuleMetaList.iterator();
                        int i = 0;
                        while (it.hasNext()) {
                            LynxModuleMeta next2 = it.next();
                            int moduleAddress = next2.getModuleAddress();
                            if (next2.isParent()) {
                                i = moduleAddress;
                            } else {
                                arrayList2.add(Integer.valueOf(moduleAddress));
                            }
                        }
                        if (arrayList2.size() > 0 || (i != 0 && !serialNumber2.isEmbedded())) {
                            arrayList.add(new PortalInfo(serialNumber2, i, arrayList2));
                        }
                    }
                }
            }
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
        RobotLog.vv(TAG, "found %d REV Hub Portals", Integer.valueOf(arrayList.size()));
        return arrayList;
    }
}

package com.qualcomm.ftccommon;

import com.qualcomm.ftccommon.CommandList;
import com.qualcomm.ftccommon.configuration.USBScanManager;
import com.qualcomm.hardware.lynx.LynxUsbDevice;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.PeerStatusCallback;

public class VisualIdentificationManager {
    private static final String TAG = "VisualIDManager";
    private static final VisualIdentificationManager instance = new VisualIdentificationManager();
    /* access modifiers changed from: private */
    public final Map<SerialNumber, LynxUsbDevice.SystemOperationHandle> identificationsInProgressMap = new HashMap();

    public static VisualIdentificationManager getInstance() {
        return instance;
    }

    private VisualIdentificationManager() {
        NetworkConnectionHandler.getInstance().registerPeerStatusCallback(new PeerStatusCallback() {
            public void onPeerConnected() {
            }

            /* JADX WARNING: Code restructure failed: missing block: B:26:0x0043, code lost:
                continue;
             */
            /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x0031 */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void onPeerDisconnected() {
                /*
                    r6 = this;
                    com.qualcomm.ftccommon.VisualIdentificationManager r0 = com.qualcomm.ftccommon.VisualIdentificationManager.this
                    monitor-enter(r0)
                    java.lang.String r1 = "VisualIDManager"
                    java.lang.String r2 = "Driver Station disconnected. Stopping all visual identifications."
                    com.qualcomm.robotcore.util.RobotLog.vv(r1, r2)     // Catch:{ all -> 0x0052 }
                    com.qualcomm.ftccommon.VisualIdentificationManager r1 = com.qualcomm.ftccommon.VisualIdentificationManager.this     // Catch:{ all -> 0x0052 }
                    java.util.Map r1 = r1.identificationsInProgressMap     // Catch:{ all -> 0x0052 }
                    java.util.Collection r1 = r1.values()     // Catch:{ all -> 0x0052 }
                    java.util.Iterator r1 = r1.iterator()     // Catch:{ all -> 0x0052 }
                L_0x0018:
                    boolean r2 = r1.hasNext()     // Catch:{ all -> 0x0052 }
                    if (r2 == 0) goto L_0x0047
                    java.lang.Object r2 = r1.next()     // Catch:{ all -> 0x0052 }
                    com.qualcomm.hardware.lynx.LynxUsbDevice$SystemOperationHandle r2 = (com.qualcomm.hardware.lynx.LynxUsbDevice.SystemOperationHandle) r2     // Catch:{ all -> 0x0052 }
                    com.qualcomm.ftccommon.VisualIdentificationManager$1$$ExternalSyntheticLambda0 r3 = new com.qualcomm.ftccommon.VisualIdentificationManager$1$$ExternalSyntheticLambda0     // Catch:{ RobotCoreException -> 0x003b, TimeoutException -> 0x0039, InterruptedException -> 0x0031 }
                    r3.<init>()     // Catch:{ RobotCoreException -> 0x003b, TimeoutException -> 0x0039, InterruptedException -> 0x0031 }
                    java.util.concurrent.TimeUnit r4 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ RobotCoreException -> 0x003b, TimeoutException -> 0x0039, InterruptedException -> 0x0031 }
                    r5 = 200(0xc8, float:2.8E-43)
                    r2.performSystemOperation(r3, r5, r4)     // Catch:{ RobotCoreException -> 0x003b, TimeoutException -> 0x0039, InterruptedException -> 0x0031 }
                    goto L_0x0043
                L_0x0031:
                    java.lang.Thread r3 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0052 }
                    r3.interrupt()     // Catch:{ all -> 0x0052 }
                    goto L_0x0043
                L_0x0039:
                    r3 = move-exception
                    goto L_0x003c
                L_0x003b:
                    r3 = move-exception
                L_0x003c:
                    java.lang.String r4 = "VisualIDManager"
                    java.lang.String r5 = "Failed to stop visual identification when DS disconnected"
                    com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r4, (java.lang.Throwable) r3, (java.lang.String) r5)     // Catch:{ all -> 0x0052 }
                L_0x0043:
                    r2.close()     // Catch:{ all -> 0x0052 }
                    goto L_0x0018
                L_0x0047:
                    com.qualcomm.ftccommon.VisualIdentificationManager r1 = com.qualcomm.ftccommon.VisualIdentificationManager.this     // Catch:{ all -> 0x0052 }
                    java.util.Map r1 = r1.identificationsInProgressMap     // Catch:{ all -> 0x0052 }
                    r1.clear()     // Catch:{ all -> 0x0052 }
                    monitor-exit(r0)     // Catch:{ all -> 0x0052 }
                    return
                L_0x0052:
                    r1 = move-exception
                    monitor-exit(r0)     // Catch:{ all -> 0x0052 }
                    throw r1
                */
                throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.VisualIdentificationManager.AnonymousClass1.onPeerDisconnected():void");
            }
        });
    }

    public synchronized void handleCommandVisuallyIdentify(CommandList.CmdVisuallyIdentify cmdVisuallyIdentify) {
        SerialNumber serialNumber = cmdVisuallyIdentify.usbSerialNumber;
        int i = cmdVisuallyIdentify.parentModuleAddress;
        int i2 = cmdVisuallyIdentify.moduleAddress;
        boolean z = cmdVisuallyIdentify.shouldIdentify;
        RobotLog.vv(TAG, "Setting visual identification status for (serial=%s parentAddress=%d address=%d) to %b", serialNumber, Integer.valueOf(i), Integer.valueOf(i2), Boolean.valueOf(z));
        LynxUsbDevice.SystemOperationHandle systemOperationHandle = this.identificationsInProgressMap.get(serialNumber);
        if (systemOperationHandle == null) {
            try {
                systemOperationHandle = ((LynxUsbDevice) USBScanManager.getInstance().getDeviceManager().createLynxUsbDevice(serialNumber.getScannableDeviceSerialNumber(), (String) null)).keepConnectedModuleAliveForSystemOperations(cmdVisuallyIdentify.moduleAddress, cmdVisuallyIdentify.parentModuleAddress);
            } catch (RobotCoreException | InterruptedException | TimeoutException e) {
                RobotLog.ee(TAG, e, "Failed to visually identify REV Hub");
            }
        }
        systemOperationHandle.performSystemOperation(new VisualIdentificationManager$$ExternalSyntheticLambda0(z), 200, TimeUnit.MILLISECONDS);
        if (!z) {
            this.identificationsInProgressMap.remove(serialNumber);
            if (systemOperationHandle != null) {
                systemOperationHandle.close();
            }
        } else if (systemOperationHandle != null) {
            this.identificationsInProgressMap.put(serialNumber, systemOperationHandle);
        }
    }
}

package com.qualcomm.ftccommon;

import com.qualcomm.hardware.lynx.LynxModule;
import java.util.concurrent.atomic.AtomicReference;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcEventLoop$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ AtomicReference f$0;

    public /* synthetic */ FtcEventLoop$$ExternalSyntheticLambda0(AtomicReference atomicReference) {
        this.f$0 = atomicReference;
    }

    public final void accept(Object obj) {
        FtcEventLoop.lambda$init$0(this.f$0, (LynxModule) obj);
    }
}

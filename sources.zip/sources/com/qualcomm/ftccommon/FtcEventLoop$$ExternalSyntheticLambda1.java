package com.qualcomm.ftccommon;

import com.qualcomm.hardware.lynx.LynxModule;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcEventLoop$$ExternalSyntheticLambda1 implements Consumer {
    public final void accept(Object obj) {
        FtcEventLoop.lambda$init$1((LynxModule) obj);
    }
}

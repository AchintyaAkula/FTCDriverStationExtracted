package com.qualcomm.ftccommon;

import com.qualcomm.ftccommon.FtcLynxModuleAddressUpdateActivity;
import java.util.function.ToIntFunction;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcLynxModuleAddressUpdateActivity$DisplayedModule$$ExternalSyntheticLambda0 implements ToIntFunction {
    public final int applyAsInt(Object obj) {
        return ((FtcLynxModuleAddressUpdateActivity.AddressAndDisplayName) obj).address;
    }
}

package com.qualcomm.ftccommon;

import android.content.Context;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.widget.FrameLayout;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.wifi.NetworkType;
import org.firstinspires.ftc.robotcore.internal.network.DeviceNameManagerFactory;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.PreferencesHelper;
import org.firstinspires.ftc.robotcore.internal.ui.ThemedActivity;
import org.firstinspires.inspection.R;

public class FtcAdvancedRCSettingsActivity extends ThemedActivity {
    protected static final String CLIENT_CONNECTED = "CLIENT_CONNECTED";
    public static final String TAG = "FtcAdvancedRCSettingsActivity";

    public String getTag() {
        return TAG;
    }

    /* access modifiers changed from: protected */
    public FrameLayout getBackBar() {
        return (FrameLayout) findViewById(R.id.backbar);
    }

    public static class SettingsFragment extends PreferenceFragment {
        protected boolean clientConnected = false;
        protected boolean controlHubConnectionMode;
        protected PreferencesHelper preferencesHelper;
        protected boolean remoteConfigure = AppUtil.getInstance().isDriverStation();

        public SettingsFragment() {
            boolean z = false;
            this.controlHubConnectionMode = NetworkConnectionHandler.getNetworkType(AppUtil.getDefContext()) == NetworkType.WIRELESSAP ? true : z;
            this.preferencesHelper = new PreferencesHelper(FtcAdvancedRCSettingsActivity.TAG);
        }

        public void onCreate(Bundle bundle) {
            super.onCreate(bundle);
            this.clientConnected = getArguments().getBoolean(FtcAdvancedRCSettingsActivity.CLIENT_CONNECTED);
            addPreferencesFromResource(R.xml.advanced_rc_settings);
            Preference findPreference = findPreference(getString(R.string.pref_launch_wifi_remembered_groups_edit));
            Preference findPreference2 = findPreference(getString(R.string.pref_launch_wifi_channel_edit));
            Preference findPreference3 = findPreference(getString(R.string.pref_launch_lynx_firmware_update));
            if (LynxConstants.isRevControlHub() || this.controlHubConnectionMode) {
                findPreference3.setSummary(R.string.summaryLynxFirmwareUpdateCH);
            }
            boolean z = false;
            if (!this.clientConnected) {
                for (int i = 0; i < getPreferenceScreen().getPreferenceCount(); i++) {
                    getPreferenceScreen().getPreference(i).setEnabled(false);
                }
            }
            if ((this.remoteConfigure && LynxConstants.isRevControlHub()) || (this.clientConnected && !this.preferencesHelper.readBoolean(getString(R.string.pref_wifip2p_remote_channel_change_works), false))) {
                z = true;
            }
            findPreference2.setEnabled(!z);
            findPreference.setEnabled(!z);
            RobotLog.vv(FtcAdvancedRCSettingsActivity.TAG, "clientConnected=%s", Boolean.valueOf(this.clientConnected));
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_generic_settings);
        DeviceNameManagerFactory.getInstance().initializeDeviceNameIfNecessary();
        SettingsFragment settingsFragment = new SettingsFragment();
        Bundle bundle2 = new Bundle();
        bundle2.putBoolean(CLIENT_CONNECTED, new PreferencesHelper(TAG, (Context) this).readBoolean(getString(R.string.pref_rc_connected), false));
        settingsFragment.setArguments(bundle2);
        getFragmentManager().beginTransaction().replace(R.id.container, settingsFragment).commit();
    }
}

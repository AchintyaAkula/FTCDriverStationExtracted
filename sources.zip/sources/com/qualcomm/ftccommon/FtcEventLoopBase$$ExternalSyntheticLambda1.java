package com.qualcomm.ftccommon;

import com.qualcomm.ftccommon.CommandList;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcEventLoopBase$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ CommandList.CmdVisuallyIdentify f$0;

    public /* synthetic */ FtcEventLoopBase$$ExternalSyntheticLambda1(CommandList.CmdVisuallyIdentify cmdVisuallyIdentify) {
        this.f$0 = cmdVisuallyIdentify;
    }

    public final void run() {
        VisualIdentificationManager.getInstance().handleCommandVisuallyIdentify(this.f$0);
    }
}

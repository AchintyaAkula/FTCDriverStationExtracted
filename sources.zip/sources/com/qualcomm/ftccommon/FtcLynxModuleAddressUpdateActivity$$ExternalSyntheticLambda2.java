package com.qualcomm.ftccommon;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ FtcLynxModuleAddressUpdateActivity f$0;

    public /* synthetic */ FtcLynxModuleAddressUpdateActivity$$ExternalSyntheticLambda2(FtcLynxModuleAddressUpdateActivity ftcLynxModuleAddressUpdateActivity) {
        this.f$0 = ftcLynxModuleAddressUpdateActivity;
    }

    public final void run() {
        this.f$0.m14lambda$onApplyButtonPressed$2$comqualcommftccommonFtcLynxModuleAddressUpdateActivity();
    }
}

package com.qualcomm.ftccommon;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.robocol.Command;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.ThreadPool;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import org.firstinspires.ftc.robotcore.internal.network.CallbackResult;
import org.firstinspires.ftc.robotcore.internal.network.NetworkConnectionHandler;
import org.firstinspires.ftc.robotcore.internal.network.RecvLoopRunnable;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.network.WifiDirectAgent;
import org.firstinspires.ftc.robotcore.internal.network.WifiDirectGroupName;
import org.firstinspires.ftc.robotcore.internal.network.WifiDirectPersistentGroupManager;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.ui.ThemedActivity;
import org.firstinspires.ftc.robotcore.internal.ui.UILocation;
import org.firstinspires.inspection.R;

public class FtcWifiDirectRememberedGroupsActivity extends ThemedActivity {
    public static final String TAG = "FtcWifiDirectRememberedGroupsActivity";
    private final NetworkConnectionHandler networkConnectionHandler = NetworkConnectionHandler.getInstance();
    private WifiDirectPersistentGroupManager persistentGroupManager;
    private final RecvLoopCallback recvLoopCallback = new RecvLoopCallback();
    private final boolean remoteConfigure = AppUtil.getInstance().isDriverStation();
    /* access modifiers changed from: private */
    public Future requestGroupsFuture = null;
    /* access modifiers changed from: private */
    public final Object requestGroupsFutureLock = new Object();

    public String getTag() {
        return TAG;
    }

    /* access modifiers changed from: protected */
    public FrameLayout getBackBar() {
        return (FrameLayout) findViewById(R.id.backbar);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_ftc_wifi_remembered_groups);
        if (!this.remoteConfigure) {
            this.persistentGroupManager = new WifiDirectPersistentGroupManager(WifiDirectAgent.getInstance());
        } else {
            this.networkConnectionHandler.pushReceiveLoopCallback(this.recvLoopCallback);
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        if (!this.remoteConfigure) {
            loadLocalGroups();
        } else {
            requestRememberedGroups();
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        if (this.remoteConfigure) {
            this.networkConnectionHandler.removeReceiveLoopCallback(this.recvLoopCallback);
        }
    }

    /* access modifiers changed from: protected */
    public void loadLocalGroups() {
        loadGroupList(getLocalGroupList());
    }

    /* access modifiers changed from: protected */
    public void requestRememberedGroups() {
        RobotLog.vv(TAG, "requestRememberedGroups()");
        this.networkConnectionHandler.sendCommand(new Command(CommandList.CMD_REQUEST_REMEMBERED_GROUPS));
    }

    /* access modifiers changed from: protected */
    public CallbackResult handleCommandRequestRememberedGroupsResp(String str) throws RobotCoreException {
        RobotLog.vv(TAG, "handleCommandRequestRememberedGroupsResp()");
        loadGroupList(WifiDirectGroupName.deserializeNames(str));
        return CallbackResult.HANDLED;
    }

    /* access modifiers changed from: protected */
    public CallbackResult handleRememberedGroupsChanged() {
        synchronized (this.requestGroupsFutureLock) {
            Future future = this.requestGroupsFuture;
            if (future != null) {
                future.cancel(false);
                this.requestGroupsFuture = null;
            }
            this.requestGroupsFuture = ThreadPool.getDefaultScheduler().schedule(new Callable() {
                public Object call() throws Exception {
                    synchronized (FtcWifiDirectRememberedGroupsActivity.this.requestGroupsFutureLock) {
                        FtcWifiDirectRememberedGroupsActivity.this.requestRememberedGroups();
                        Future unused = FtcWifiDirectRememberedGroupsActivity.this.requestGroupsFuture = null;
                    }
                    return null;
                }
            }, 250, TimeUnit.MILLISECONDS);
        }
        return CallbackResult.HANDLED_CONTINUE;
    }

    /* access modifiers changed from: protected */
    public List<WifiDirectGroupName> getLocalGroupList() {
        return WifiDirectGroupName.namesFromGroups(this.persistentGroupManager.getPersistentGroups());
    }

    /* access modifiers changed from: protected */
    public void loadGroupList(final List<WifiDirectGroupName> list) {
        AppUtil.getInstance().runOnUiThread(new Runnable() {
            public void run() {
                ListView listView = (ListView) FtcWifiDirectRememberedGroupsActivity.this.findViewById(R.id.groupList);
                Collections.sort(list);
                if (list.isEmpty()) {
                    list.add(new WifiDirectGroupName(FtcWifiDirectRememberedGroupsActivity.this.getString(R.string.noRememberedGroupsFound)));
                }
                listView.setAdapter(new WifiP2pGroupItemAdapter(AppUtil.getInstance().getActivity(), 17367049, list));
            }
        });
    }

    protected class WifiP2pGroupItemAdapter extends ArrayAdapter<WifiDirectGroupName> {
        public WifiP2pGroupItemAdapter(Context context, int i, List<WifiDirectGroupName> list) {
            super(context, i, list);
        }
    }

    public void onClearRememberedGroupsClicked(View view) {
        RobotLog.vv(TAG, "onClearRememberedGroupsClicked()");
        if (!this.remoteConfigure) {
            this.persistentGroupManager.deleteAllPersistentGroups();
            AppUtil.getInstance().showToast(UILocation.BOTH, getString(R.string.toastWifiP2pRememberedGroupsCleared));
            loadLocalGroups();
            return;
        }
        this.networkConnectionHandler.sendCommand(new Command(RobotCoreCommandList.CMD_CLEAR_REMEMBERED_GROUPS));
    }

    protected class RecvLoopCallback extends RecvLoopRunnable.DegenerateCallback {
        protected RecvLoopCallback() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:15:0x002d A[Catch:{ RobotCoreException -> 0x0042 }] */
        /* JADX WARNING: Removed duplicated region for block: B:18:0x0036 A[Catch:{ RobotCoreException -> 0x0042 }] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public org.firstinspires.ftc.robotcore.internal.network.CallbackResult commandEvent(com.qualcomm.robotcore.robocol.Command r6) {
            /*
                r5 = this;
                org.firstinspires.ftc.robotcore.internal.network.CallbackResult r0 = org.firstinspires.ftc.robotcore.internal.network.CallbackResult.NOT_HANDLED
                java.lang.String r1 = r6.getName()     // Catch:{ RobotCoreException -> 0x0042 }
                int r2 = r1.hashCode()     // Catch:{ RobotCoreException -> 0x0042 }
                r3 = -1830844033(0xffffffff92df897f, float:-1.4107174E-27)
                r4 = 1
                if (r2 == r3) goto L_0x0020
                r3 = 45075229(0x2afcb1d, float:2.583052E-37)
                if (r2 == r3) goto L_0x0016
                goto L_0x002a
            L_0x0016:
                java.lang.String r2 = "CMD_REQUEST_REMEMBERED_GROUPS_RESP"
                boolean r1 = r1.equals(r2)     // Catch:{ RobotCoreException -> 0x0042 }
                if (r1 == 0) goto L_0x002a
                r1 = 0
                goto L_0x002b
            L_0x0020:
                java.lang.String r2 = "CMD_NOTIFY_WIFI_DIRECT_REMEMBERED_GROUPS_CHANGED"
                boolean r1 = r1.equals(r2)     // Catch:{ RobotCoreException -> 0x0042 }
                if (r1 == 0) goto L_0x002a
                r1 = r4
                goto L_0x002b
            L_0x002a:
                r1 = -1
            L_0x002b:
                if (r1 == 0) goto L_0x0036
                if (r1 == r4) goto L_0x0030
                goto L_0x0046
            L_0x0030:
                com.qualcomm.ftccommon.FtcWifiDirectRememberedGroupsActivity r6 = com.qualcomm.ftccommon.FtcWifiDirectRememberedGroupsActivity.this     // Catch:{ RobotCoreException -> 0x0042 }
                r6.handleRememberedGroupsChanged()     // Catch:{ RobotCoreException -> 0x0042 }
                goto L_0x0046
            L_0x0036:
                com.qualcomm.ftccommon.FtcWifiDirectRememberedGroupsActivity r1 = com.qualcomm.ftccommon.FtcWifiDirectRememberedGroupsActivity.this     // Catch:{ RobotCoreException -> 0x0042 }
                java.lang.String r6 = r6.getExtra()     // Catch:{ RobotCoreException -> 0x0042 }
                org.firstinspires.ftc.robotcore.internal.network.CallbackResult r6 = r1.handleCommandRequestRememberedGroupsResp(r6)     // Catch:{ RobotCoreException -> 0x0042 }
                r0 = r6
                goto L_0x0046
            L_0x0042:
                r6 = move-exception
                com.qualcomm.robotcore.util.RobotLog.logStacktrace(r6)
            L_0x0046:
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftccommon.FtcWifiDirectRememberedGroupsActivity.RecvLoopCallback.commandEvent(com.qualcomm.robotcore.robocol.Command):org.firstinspires.ftc.robotcore.internal.network.CallbackResult");
        }
    }
}

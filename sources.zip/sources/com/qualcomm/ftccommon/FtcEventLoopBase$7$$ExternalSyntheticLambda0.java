package com.qualcomm.ftccommon;

import com.qualcomm.ftccommon.CommandList;
import com.qualcomm.hardware.lynx.LynxModule;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcEventLoopBase$7$$ExternalSyntheticLambda0 implements Consumer {
    public final /* synthetic */ CommandList.LynxAddressChangeRequest.AddressChange f$0;

    public /* synthetic */ FtcEventLoopBase$7$$ExternalSyntheticLambda0(CommandList.LynxAddressChangeRequest.AddressChange addressChange) {
        this.f$0 = addressChange;
    }

    public final void accept(Object obj) {
        ((LynxModule) obj).setNewModuleAddress(this.f$0.newAddress);
    }
}

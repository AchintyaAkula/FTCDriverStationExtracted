package com.qualcomm.ftcdriverstation;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcDriverStationActivity$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ FtcDriverStationActivity f$0;

    public /* synthetic */ FtcDriverStationActivity$$ExternalSyntheticLambda1(FtcDriverStationActivity ftcDriverStationActivity) {
        this.f$0 = ftcDriverStationActivity;
    }

    public final void run() {
        this.f$0.m17lambda$handleCommandSetTelemetryDisplayFormat$2$comqualcommftcdriverstationFtcDriverStationActivity();
    }
}

package com.qualcomm.ftcdriverstation;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FtcDriverStationActivity$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ FtcDriverStationActivity f$0;

    public /* synthetic */ FtcDriverStationActivity$$ExternalSyntheticLambda0(FtcDriverStationActivity ftcDriverStationActivity) {
        this.f$0 = ftcDriverStationActivity;
    }

    public final void run() {
        this.f$0.m16lambda$handleCommandSetTelemetryDisplayFormat$1$comqualcommftcdriverstationFtcDriverStationActivity();
    }
}

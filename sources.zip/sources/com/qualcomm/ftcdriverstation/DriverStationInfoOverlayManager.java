package com.qualcomm.ftcdriverstation;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

public class DriverStationInfoOverlayManager {
    Handler handler = new Handler(Looper.getMainLooper());
    final Runnable hideOverlayRunnable;
    protected final View infoOverlayLayout;
    protected final TextView messageTxtView;
    protected final TextView titleTxtView;

    public DriverStationInfoOverlayManager(FtcDriverStationActivity ftcDriverStationActivity) {
        this.infoOverlayLayout = ftcDriverStationActivity.findViewById(R.id.mainWindowInfoOverlayLayout);
        this.titleTxtView = (TextView) ftcDriverStationActivity.findViewById(R.id.mainWindowInfoOverlayTitle);
        this.messageTxtView = (TextView) ftcDriverStationActivity.findViewById(R.id.mainWindowInfoOverlayText);
        this.hideOverlayRunnable = new Runnable() {
            public void run() {
                DriverStationInfoOverlayManager.this.infoOverlayLayout.setVisibility(4);
            }
        };
    }

    public synchronized void showMessage(final String str, final String str2, int i) {
        this.handler.removeCallbacks(this.hideOverlayRunnable);
        this.handler.post(new Runnable() {
            public void run() {
                DriverStationInfoOverlayManager.this.titleTxtView.setText(str);
                DriverStationInfoOverlayManager.this.messageTxtView.setText(str2);
                DriverStationInfoOverlayManager.this.infoOverlayLayout.setVisibility(0);
            }
        });
        this.handler.postDelayed(this.hideOverlayRunnable, (long) i);
    }
}

package com.qualcomm.ftcdriverstation;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.Toast;
import com.qualcomm.ftccommon.SoundPlayer;
import com.qualcomm.ftcdriverstation.GamepadIndicator;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.util.Device;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.firstinspires.directgamepadaccess.android.AndroidGamepadManager;
import org.firstinspires.directgamepadaccess.core.CompositeGamepadManager;
import org.firstinspires.directgamepadaccess.core.GamepadManager;
import org.firstinspires.directgamepadaccess.core.NPlayerGamepadHelper;
import org.firstinspires.directgamepadaccess.core.UsbGamepad;
import org.firstinspires.directgamepadaccess.core.UsbGamepadControlSurfaces;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.ui.GamepadUser;
import org.firstinspires.ftc.robotcore.internal.ui.RobotCoreGamepadManager;
import org.opencv.imgproc.Imgproc;

public class DriverStationGamepadManager implements NPlayerGamepadHelper.Callback, RobotCoreGamepadManager, SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int GAMEPAD_BIND_HINT_DURATION = 2000;
    public static final int GAMEPAD_POSITION_USER_1 = 0;
    public static final int GAMEPAD_POSITION_USER_2 = 1;
    public static final int NUM_GAMEPAD_POSITIONS = 2;
    public static boolean RUMBLE_ON_BIND_DEFAULT = true;
    private static final int SOUND_ID_GAMEPAD_CONNECT = R.raw.controller_connection;
    private static final int SOUND_ID_GAMEPAD_DISCONNECT = R.raw.controller_dropped;
    private static final int UI_INDICATION_THROTTLE_MS = 100;
    private boolean advancedFeatures;
    private Context context;
    private DefaultGamepadManager defaultGamepadManager;
    private boolean enabled;
    private UsbGamepadControlSurfaces[] gamepadControlSurfaces = new UsbGamepadControlSurfaces[2];
    private GamepadManager gamepadDeviceManager;
    /* access modifiers changed from: private */
    public Map<GamepadUser, GamepadIndicator> gamepadIndicators;
    private NPlayerGamepadHelper gamepadPositionManager;
    private UsbGamepad[] gamepads = new UsbGamepad[2];
    private DriverStationInfoOverlayManager infoOverlayManager;
    private long[] lastUiIndicationTime = new long[2];
    final HashMap<Integer, UnboundGamepadButtonStateTracking> mapUnboundGamepadIdToBtnStateTracking = new HashMap<>();
    private String prefKeyRumbleOnBind;
    private Toast prevToast;
    private Gamepad[] robotCoreGamepads = new Gamepad[2];
    private volatile boolean rumbleOnBind = RUMBLE_ON_BIND_DEFAULT;
    private SharedPreferences sharedPreferences;
    private ArrayList<GamepadUser> syntheticUsersToTransmit = new ArrayList<>();
    private final boolean toastsAreBuggy;
    /* access modifiers changed from: private */
    public volatile boolean[] uiIndicationRunning = new boolean[2];

    public DriverStationGamepadManager(Context context2, DriverStationInfoOverlayManager driverStationInfoOverlayManager) {
        this.context = context2;
        this.infoOverlayManager = driverStationInfoOverlayManager;
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context2);
        String string = context2.getResources().getString(R.string.pref_key_rumble_on_bind);
        this.prefKeyRumbleOnBind = string;
        this.rumbleOnBind = this.sharedPreferences.getBoolean(string, RUMBLE_ON_BIND_DEFAULT);
        this.sharedPreferences.registerOnSharedPreferenceChangeListener(this);
        this.toastsAreBuggy = Build.MODEL.equalsIgnoreCase(Device.MODEL_E5_PLAY) || Build.MODEL.equalsIgnoreCase(Device.MODEL_E5_XT1920DL);
        this.robotCoreGamepads[0] = new Gamepad();
        this.robotCoreGamepads[1] = new Gamepad();
        this.robotCoreGamepads[0].setUser(GamepadUser.ONE);
        this.robotCoreGamepads[1].setUser(GamepadUser.TWO);
        this.gamepadControlSurfaces[0] = new UsbGamepadControlSurfaces();
        this.gamepadControlSurfaces[1] = new UsbGamepadControlSurfaces();
        SoundPlayer.getInstance().preload(context2, SOUND_ID_GAMEPAD_CONNECT);
        SoundPlayer.getInstance().preload(context2, SOUND_ID_GAMEPAD_DISCONNECT);
    }

    public synchronized void setGamepadIndicators(Map<GamepadUser, GamepadIndicator> map) {
        this.gamepadIndicators = map;
        if (this.gamepads[0] != null) {
            map.get(GamepadUser.ONE).setState(GamepadIndicator.State.VISIBLE);
        }
        if (this.gamepads[1] != null) {
            map.get(GamepadUser.TWO).setState(GamepadIndicator.State.VISIBLE);
        }
    }

    public int getNumberGamepadsAtttached() {
        int i = 0;
        for (UsbGamepad usbGamepad : this.gamepads) {
            if (usbGamepad != null) {
                i++;
            }
        }
        return i;
    }

    public void initialize(boolean z) {
        this.defaultGamepadManager = DefaultGamepadManager.getInstance(this.context);
        this.advancedFeatures = z;
        if (z) {
            CompositeGamepadManager compositeGamepadManager = new CompositeGamepadManager();
            compositeGamepadManager.setGamepadMappingSuggestor(FtcGamepadMappingSuggestor.getInstance(this.context));
            this.gamepadDeviceManager = compositeGamepadManager;
        } else {
            AndroidGamepadManager androidGamepadManager = new AndroidGamepadManager(true);
            androidGamepadManager.setGamepadMappingSuggestor(FtcGamepadMappingSuggestor.getInstance(this.context));
            this.gamepadDeviceManager = androidGamepadManager;
        }
        NPlayerGamepadHelper nPlayerGamepadHelper = new NPlayerGamepadHelper(this, 2, new NPlayerGamepadHelper.AssignmentSupplier() {
            public int getPosition(UsbGamepadControlSurfaces usbGamepadControlSurfaces) {
                if (!usbGamepadControlSurfaces.start || !usbGamepadControlSurfaces.a) {
                    return (!usbGamepadControlSurfaces.start || !usbGamepadControlSurfaces.b) ? -1 : 1;
                }
                return 0;
            }
        });
        this.gamepadPositionManager = nPlayerGamepadHelper;
        this.gamepadDeviceManager.initialize(this.context, nPlayerGamepadHelper);
        this.gamepadPositionManager.initialize(this.gamepadDeviceManager.getCurrentlyKnownGamepads());
    }

    public boolean isAdvancedFeatures() {
        return this.advancedFeatures;
    }

    public List<UsbGamepad> getKnownGamepads() {
        return this.gamepadDeviceManager.getCurrentlyKnownGamepads();
    }

    public void close() {
        this.gamepadDeviceManager.close();
    }

    public synchronized void onGamepadBound(UsbGamepad usbGamepad, int i, NPlayerGamepadHelper.BindReason bindReason) {
        if (bindReason == NPlayerGamepadHelper.BindReason.BY_DEFAULT) {
            showToast(String.format("Assigned gamepad %d by default", new Object[]{Integer.valueOf(i + 1)}));
        } else if (bindReason == NPlayerGamepadHelper.BindReason.AUTO_RECOVERY) {
            showToast(String.format("Gamepad %d auto-recovered", new Object[]{Integer.valueOf(i + 1)}));
        }
        this.robotCoreGamepads[i].setGamepadId(usbGamepad.getId());
        this.gamepads[i] = usbGamepad;
        if (i == 0) {
            this.gamepadIndicators.get(GamepadUser.ONE).setState(GamepadIndicator.State.VISIBLE);
            usbGamepad.setLEDMode(UsbGamepad.LedMode.USER_1_CONNECTED);
            if (this.rumbleOnBind) {
                usbGamepad.setRumblePower(255, 0, 215);
            }
        } else if (i == 1) {
            this.gamepadIndicators.get(GamepadUser.TWO).setState(GamepadIndicator.State.VISIBLE);
            usbGamepad.setLEDMode(UsbGamepad.LedMode.USER_2_CONNECTED);
            if (this.rumbleOnBind) {
                usbGamepad.runRumbleEffect(new UsbGamepad.RumbleEffect.Builder().addStep(255, 0, 175).addStep(0, 0, 350).addStep(255, 0, Imgproc.COLOR_BGR2YUV_YVYU).build());
            }
        }
        SoundPlayer.getInstance().play(this.context, SOUND_ID_GAMEPAD_CONNECT, 1.0f, 0, 1.0f);
    }

    public synchronized void onGamepadUnbound(int i, NPlayerGamepadHelper.UnbindReason unbindReason) {
        if (unbindReason == NPlayerGamepadHelper.UnbindReason.USB_DEV_DCed) {
            showToast(String.format("Gamepad %d connection lost", new Object[]{Integer.valueOf(i + 1)}));
            SoundPlayer.getInstance().play(this.context, SOUND_ID_GAMEPAD_DISCONNECT, 1.0f, 0, 1.0f);
        }
        this.gamepads[i] = null;
        if (i == 0) {
            this.gamepadIndicators.get(GamepadUser.ONE).setState(GamepadIndicator.State.INVISIBLE);
            this.syntheticUsersToTransmit.add(GamepadUser.ONE);
        } else if (i == 1) {
            this.gamepadIndicators.get(GamepadUser.TWO).setState(GamepadIndicator.State.INVISIBLE);
            this.syntheticUsersToTransmit.add(GamepadUser.TWO);
        }
    }

    public synchronized void onGamepadUpdate(final int i, UsbGamepadControlSurfaces usbGamepadControlSurfaces) {
        this.robotCoreGamepads[i].refreshTimestamp();
        long currentTimeMillis = System.currentTimeMillis();
        long[] jArr = this.lastUiIndicationTime;
        long j = jArr[i];
        if (currentTimeMillis - j > 100 || j == 0) {
            jArr[i] = currentTimeMillis;
            if (!this.uiIndicationRunning[i]) {
                this.uiIndicationRunning[i] = true;
                AppUtil.getInstance().runOnUiThread(new Runnable() {
                    public void run() {
                        int i = i;
                        if (i == 0) {
                            ((GamepadIndicator) DriverStationGamepadManager.this.gamepadIndicators.get(GamepadUser.ONE)).setState(GamepadIndicator.State.INDICATE);
                        } else if (i == 1) {
                            ((GamepadIndicator) DriverStationGamepadManager.this.gamepadIndicators.get(GamepadUser.TWO)).setState(GamepadIndicator.State.INDICATE);
                        }
                        DriverStationGamepadManager.this.uiIndicationRunning[i] = false;
                    }
                });
            }
        }
    }

    class UnboundGamepadButtonStateTracking {
        static final long NIL_TIME = -1;
        long startDownTime = -1;

        UnboundGamepadButtonStateTracking() {
        }
    }

    public void onGamepadUpdateForUnboundGamepad(UsbGamepad usbGamepad, UsbGamepadControlSurfaces usbGamepadControlSurfaces) {
        int id = usbGamepad.getId();
        synchronized (this.mapUnboundGamepadIdToBtnStateTracking) {
            if (!this.mapUnboundGamepadIdToBtnStateTracking.containsKey(Integer.valueOf(id))) {
                this.mapUnboundGamepadIdToBtnStateTracking.put(Integer.valueOf(id), new UnboundGamepadButtonStateTracking());
            }
            UnboundGamepadButtonStateTracking unboundGamepadButtonStateTracking = this.mapUnboundGamepadIdToBtnStateTracking.get(Integer.valueOf(id));
            boolean z = false;
            if (usbGamepadControlSurfaces.start && unboundGamepadButtonStateTracking.startDownTime == -1) {
                unboundGamepadButtonStateTracking.startDownTime = System.currentTimeMillis();
            } else if (!usbGamepadControlSurfaces.start && unboundGamepadButtonStateTracking.startDownTime != -1) {
                if (System.currentTimeMillis() - unboundGamepadButtonStateTracking.startDownTime < 2000) {
                    z = true;
                }
                unboundGamepadButtonStateTracking.startDownTime = -1;
            }
            if ((!usbGamepadControlSurfaces.start && (usbGamepadControlSurfaces.areAnyButtonsPressed() || usbGamepadControlSurfaces.areAnyAnalogInputsDisplaced())) || z) {
                if (usbGamepadControlSurfaces.type == UsbGamepadControlSurfaces.Type.SONY_PS4_COMPATIBLE) {
                    this.infoOverlayManager.showMessage(this.context.getString(R.string.gamepad_bind_hint_title), this.context.getString(R.string.gamepad_ps4_ps5_bind_hint), 2000);
                } else if (usbGamepadControlSurfaces.type == UsbGamepadControlSurfaces.Type.XBOX_360_COMPATIBLE) {
                    this.infoOverlayManager.showMessage(this.context.getString(R.string.gamepad_bind_hint_title), this.context.getString(R.string.gamepad_xbox_bind_hint), 2000);
                }
            }
        }
    }

    public synchronized void onGamepadOpenFailed(UsbGamepad usbGamepad, UsbGamepad.OpenResultCode openResultCode) {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0038, code lost:
        return -1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized int getDefaultPositionForGamepad(int r3, int r4, java.lang.String r5) {
        /*
            r2 = this;
            monitor-enter(r2)
            com.qualcomm.ftcdriverstation.DefaultGamepadManager r0 = r2.defaultGamepadManager     // Catch:{ all -> 0x003a }
            java.lang.String r0 = r0.getPosition1Default()     // Catch:{ all -> 0x003a }
            if (r0 == 0) goto L_0x001c
            com.qualcomm.ftcdriverstation.DefaultGamepadManager r0 = r2.defaultGamepadManager     // Catch:{ all -> 0x003a }
            java.lang.String r0 = r0.getPosition1Default()     // Catch:{ all -> 0x003a }
            java.lang.String r1 = com.qualcomm.ftcdriverstation.DefaultGamepadManager.getIdString(r3, r4, r5)     // Catch:{ all -> 0x003a }
            boolean r0 = r0.equals(r1)     // Catch:{ all -> 0x003a }
            if (r0 == 0) goto L_0x001c
            monitor-exit(r2)
            r3 = 0
            return r3
        L_0x001c:
            com.qualcomm.ftcdriverstation.DefaultGamepadManager r0 = r2.defaultGamepadManager     // Catch:{ all -> 0x003a }
            java.lang.String r0 = r0.getPosition2Default()     // Catch:{ all -> 0x003a }
            if (r0 == 0) goto L_0x0037
            com.qualcomm.ftcdriverstation.DefaultGamepadManager r0 = r2.defaultGamepadManager     // Catch:{ all -> 0x003a }
            java.lang.String r0 = r0.getPosition2Default()     // Catch:{ all -> 0x003a }
            java.lang.String r3 = com.qualcomm.ftcdriverstation.DefaultGamepadManager.getIdString(r3, r4, r5)     // Catch:{ all -> 0x003a }
            boolean r3 = r0.equals(r3)     // Catch:{ all -> 0x003a }
            if (r3 == 0) goto L_0x0037
            monitor-exit(r2)
            r3 = 1
            return r3
        L_0x0037:
            monitor-exit(r2)
            r3 = -1
            return r3
        L_0x003a:
            r3 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x003a }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.ftcdriverstation.DriverStationGamepadManager.getDefaultPositionForGamepad(int, int, java.lang.String):int");
    }

    private void showToast(String str) {
        if (this.toastsAreBuggy) {
            Toast toast = this.prevToast;
            if (toast != null) {
                toast.cancel();
            }
            Toast makeText = Toast.makeText(this.context, str, 0);
            makeText.show();
            this.prevToast = makeText;
            return;
        }
        Toast.makeText(this.context, str, 0).show();
    }

    public void setEnabled(boolean z) {
        this.enabled = z;
    }

    public synchronized List<Gamepad> getGamepadsForTransmission() {
        if (!this.enabled) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList(2);
        for (int i = 0; i < 2; i++) {
            if (this.gamepadPositionManager.captureGamepadStateIfAvailable(i, this.gamepadControlSurfaces[i])) {
                copyControlSurfaceToGamepad(this.gamepadControlSurfaces[i], this.robotCoreGamepads[i]);
                arrayList.add(this.robotCoreGamepads[i]);
            }
        }
        Iterator<GamepadUser> it = this.syntheticUsersToTransmit.iterator();
        while (it.hasNext()) {
            GamepadUser next = it.next();
            Iterator it2 = arrayList.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                }
                Gamepad gamepad = (Gamepad) it2.next();
                if (gamepad.getUser() == next) {
                    arrayList.remove(gamepad);
                    break;
                }
            }
            Gamepad gamepad2 = new Gamepad();
            gamepad2.setGamepadId(-2);
            gamepad2.refreshTimestamp();
            gamepad2.setUser(next);
            arrayList.add(gamepad2);
        }
        this.syntheticUsersToTransmit.clear();
        return arrayList;
    }

    public synchronized void resetLedsForBindStatus() {
        UsbGamepad usbGamepad = this.gamepads[0];
        if (usbGamepad != null) {
            usbGamepad.setLEDMode(UsbGamepad.LedMode.USER_1_CONNECTED);
        }
        UsbGamepad usbGamepad2 = this.gamepads[1];
        if (usbGamepad2 != null) {
            usbGamepad2.setLEDMode(UsbGamepad.LedMode.USER_2_CONNECTED);
        }
    }

    public synchronized void setLedColor(int i, int i2, int i3, int i4) {
        int i5 = i - 1;
        if (i5 <= 2 && i5 >= 0) {
            UsbGamepad usbGamepad = this.gamepads[i5];
            if (usbGamepad != null) {
                usbGamepad.setLedColor((byte) i2, (byte) i3, (byte) i4);
            }
        }
    }

    public synchronized void runLedEffect(Gamepad.LedEffect ledEffect) {
        UsbGamepad usbGamepad;
        int i = ledEffect.user - 1;
        if (i <= 2 && i >= 0 && (usbGamepad = this.gamepads[i]) != null) {
            usbGamepad.runLedEffect(ftcLedEffectToDriverLayerEffect(ledEffect));
        }
    }

    private UsbGamepad.LedEffect ftcLedEffectToDriverLayerEffect(Gamepad.LedEffect ledEffect) {
        UsbGamepad.LedEffect.Builder builder = new UsbGamepad.LedEffect.Builder();
        Iterator<Gamepad.LedEffect.Step> it = ledEffect.steps.iterator();
        while (it.hasNext()) {
            Gamepad.LedEffect.Step next = it.next();
            builder.addStep((byte) next.r, (byte) next.g, (byte) next.b, next.duration);
        }
        builder.setRepeating(ledEffect.repeating);
        return builder.build();
    }

    public synchronized void runRumbleEffect(Gamepad.RumbleEffect rumbleEffect) {
        UsbGamepad usbGamepad;
        int i = rumbleEffect.user - 1;
        if (i <= 2 && i >= 0 && (usbGamepad = this.gamepads[i]) != null) {
            usbGamepad.runRumbleEffect(ftcRumbleEffectToDriverLayerEffect(rumbleEffect));
        }
    }

    public synchronized void setRumblePowers(int i, int i2, int i3) {
        int i4 = i - 1;
        if (i4 <= 2 && i4 >= 0) {
            UsbGamepad usbGamepad = this.gamepads[i4];
            if (usbGamepad != null) {
                usbGamepad.setRumblePower((short) i2, (short) i3);
            }
        }
    }

    private UsbGamepad.RumbleEffect ftcRumbleEffectToDriverLayerEffect(Gamepad.RumbleEffect rumbleEffect) {
        UsbGamepad.RumbleEffect.Builder builder = new UsbGamepad.RumbleEffect.Builder();
        Iterator<Gamepad.RumbleEffect.Step> it = rumbleEffect.steps.iterator();
        while (it.hasNext()) {
            Gamepad.RumbleEffect.Step next = it.next();
            builder.addStep(next.large, next.small, next.duration);
        }
        return builder.build();
    }

    public synchronized void stopGamepadRumble() {
        for (int i = 0; i < 2; i++) {
            UsbGamepad usbGamepad = this.gamepads[i];
            if (usbGamepad != null) {
                usbGamepad.setRumblePower(0, 0);
            }
        }
    }

    private static void copyControlSurfaceToGamepad(UsbGamepadControlSurfaces usbGamepadControlSurfaces, Gamepad gamepad) {
        gamepad.left_trigger = usbGamepadControlSurfaces.left_trigger;
        gamepad.right_trigger = usbGamepadControlSurfaces.right_trigger;
        gamepad.right_stick_button = usbGamepadControlSurfaces.right_stick_button;
        gamepad.left_stick_button = usbGamepadControlSurfaces.left_stick_button;
        gamepad.back = usbGamepadControlSurfaces.back;
        gamepad.start = usbGamepadControlSurfaces.start;
        gamepad.dpad_right = usbGamepadControlSurfaces.dpad_right;
        gamepad.dpad_left = usbGamepadControlSurfaces.dpad_left;
        gamepad.dpad_down = usbGamepadControlSurfaces.dpad_down;
        gamepad.dpad_up = usbGamepadControlSurfaces.dpad_up;
        gamepad.y = usbGamepadControlSurfaces.y;
        gamepad.x = usbGamepadControlSurfaces.x;
        gamepad.b = usbGamepadControlSurfaces.b;
        gamepad.a = usbGamepadControlSurfaces.a;
        gamepad.guide = usbGamepadControlSurfaces.guide;
        gamepad.touchpad = usbGamepadControlSurfaces.touchpad;
        gamepad.touchpad_finger_1 = usbGamepadControlSurfaces.touchpad_finger_1;
        gamepad.touchpad_finger_2 = usbGamepadControlSurfaces.touchpad_finger_2;
        if (usbGamepadControlSurfaces.type == UsbGamepadControlSurfaces.Type.SONY_PS4_COMPATIBLE) {
            gamepad.touchpad_finger_1_x = (usbGamepadControlSurfaces.touchpad_finger_1_x * 2.0f) - 1.0f;
            gamepad.touchpad_finger_1_y = -((usbGamepadControlSurfaces.touchpad_finger_1_y * 2.0f) - 1.0f);
            gamepad.touchpad_finger_2_x = (usbGamepadControlSurfaces.touchpad_finger_2_x * 2.0f) - 1.0f;
            gamepad.touchpad_finger_2_y = -((usbGamepadControlSurfaces.touchpad_finger_2_y * 2.0f) - 1.0f);
        } else {
            gamepad.touchpad_finger_1_x = 0.0f;
            gamepad.touchpad_finger_1_y = 0.0f;
            gamepad.touchpad_finger_2_x = 0.0f;
            gamepad.touchpad_finger_2_y = 0.0f;
        }
        gamepad.right_bumper = usbGamepadControlSurfaces.right_bumper;
        gamepad.left_bumper = usbGamepadControlSurfaces.left_bumper;
        gamepad.left_stick_x = usbGamepadControlSurfaces.left_stick_x;
        gamepad.left_stick_y = usbGamepadControlSurfaces.left_stick_y;
        gamepad.right_stick_x = usbGamepadControlSurfaces.right_stick_x;
        gamepad.right_stick_y = usbGamepadControlSurfaces.right_stick_y;
        gamepad.type = usbGamepadControlSurfaces.type == UsbGamepadControlSurfaces.Type.SONY_PS4_COMPATIBLE ? Gamepad.Type.SONY_PS4 : Gamepad.Type.XBOX_360;
    }

    public synchronized void handleGamepadEvent(MotionEvent motionEvent) {
        this.gamepadDeviceManager.onMotionEvent(motionEvent);
    }

    public synchronized void handleGamepadEvent(KeyEvent keyEvent) {
        this.gamepadDeviceManager.onKeyEvent(keyEvent);
    }

    public synchronized void handleNewIntent(Intent intent) {
        this.gamepadDeviceManager.onNewIntent(intent);
    }

    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences2, String str) {
        if (str.equals(this.prefKeyRumbleOnBind)) {
            this.rumbleOnBind = sharedPreferences2.getBoolean(this.prefKeyRumbleOnBind, RUMBLE_ON_BIND_DEFAULT);
        }
    }
}

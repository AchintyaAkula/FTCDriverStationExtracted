package com.qualcomm.hardware.limelightvision;

import com.qualcomm.hardware.lynx.LynxServoController;
import java.util.ArrayList;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.inspection.InspectionState;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LLResultTypes {
    /* access modifiers changed from: private */
    public static List<List<Double>> parsePoints(JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        if (jSONArray != null) {
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONArray optJSONArray = jSONArray.optJSONArray(i);
                if (optJSONArray != null && optJSONArray.length() == 2) {
                    ArrayList arrayList2 = new ArrayList();
                    arrayList2.add(Double.valueOf(optJSONArray.optDouble(0, LynxServoController.apiPositionFirst)));
                    arrayList2.add(Double.valueOf(optJSONArray.optDouble(1, LynxServoController.apiPositionFirst)));
                    arrayList.add(arrayList2);
                }
            }
        }
        return arrayList;
    }

    /* access modifiers changed from: private */
    public static double[] parsePoseArray(JSONArray jSONArray) {
        double[] dArr = new double[6];
        if (jSONArray != null && jSONArray.length() >= 6) {
            for (int i = 0; i < 6; i++) {
                dArr[i] = jSONArray.optDouble(i, LynxServoController.apiPositionFirst);
            }
        }
        return dArr;
    }

    public static class BarcodeResult {
        private String data;
        private String family;
        private double targetArea;
        private List<List<Double>> targetCorners;
        private double targetXDegrees;
        private double targetXDegreesNoCrosshair;
        private double targetXPixels;
        private double targetYDegrees;
        private double targetYDegreesNoCrosshair;
        private double targetYPixels;

        protected BarcodeResult(JSONObject jSONObject) {
            this.family = jSONObject.optString("fam", InspectionState.NO_VERSION);
            this.data = jSONObject.optString("data", InspectionState.NO_VERSION);
            this.targetXPixels = jSONObject.optDouble("txp", LynxServoController.apiPositionFirst);
            this.targetYPixels = jSONObject.optDouble("typ", LynxServoController.apiPositionFirst);
            this.targetXDegrees = jSONObject.optDouble("tx", LynxServoController.apiPositionFirst);
            this.targetYDegrees = jSONObject.optDouble("ty", LynxServoController.apiPositionFirst);
            this.targetXDegreesNoCrosshair = jSONObject.optDouble("tx_nocross", LynxServoController.apiPositionFirst);
            this.targetYDegreesNoCrosshair = jSONObject.optDouble("ty_nocross", LynxServoController.apiPositionFirst);
            this.targetArea = jSONObject.optDouble("ta", LynxServoController.apiPositionFirst);
            this.targetCorners = LLResultTypes.parsePoints(jSONObject.optJSONArray("pts"));
        }

        public String getFamily() {
            return this.family;
        }

        public String getData() {
            return this.data;
        }

        public double getTargetXPixels() {
            return this.targetXPixels;
        }

        public double getTargetYPixels() {
            return this.targetYPixels;
        }

        public double getTargetXDegrees() {
            return this.targetXDegrees;
        }

        public double getTargetYDegrees() {
            return this.targetYDegrees;
        }

        public double getTargetXDegreesNoCrosshair() {
            return this.targetXDegreesNoCrosshair;
        }

        public double getTargetYDegreesNoCrosshair() {
            return this.targetYDegreesNoCrosshair;
        }

        public double getTargetArea() {
            return this.targetArea;
        }

        public List<List<Double>> getTargetCorners() {
            return this.targetCorners;
        }
    }

    public static class ClassifierResult {
        private int classId;
        private String className;
        private double confidence;

        protected ClassifierResult(JSONObject jSONObject) {
            this.className = jSONObject.optString("class", InspectionState.NO_VERSION);
            this.classId = jSONObject.optInt("classID", 0);
            this.confidence = jSONObject.optDouble("conf", LynxServoController.apiPositionFirst);
        }

        public String getClassName() {
            return this.className;
        }

        public int getClassId() {
            return this.classId;
        }

        public double getConfidence() {
            return this.confidence;
        }
    }

    public static class DetectorResult {
        private int classId;
        private String className;
        private double confidence;
        private double targetArea;
        private List<List<Double>> targetCorners;
        private double targetXDegrees;
        private double targetXDegreesNoCrosshair;
        private double targetXPixels;
        private double targetYDegrees;
        private double targetYDegreesNoCrosshair;
        private double targetYPixels;

        protected DetectorResult(JSONObject jSONObject) {
            this.className = jSONObject.optString("class", InspectionState.NO_VERSION);
            this.classId = jSONObject.optInt("classID", 0);
            this.confidence = jSONObject.optDouble("conf", LynxServoController.apiPositionFirst);
            this.targetArea = jSONObject.optDouble("ta", LynxServoController.apiPositionFirst);
            this.targetXPixels = jSONObject.optDouble("txp", LynxServoController.apiPositionFirst);
            this.targetYPixels = jSONObject.optDouble("typ", LynxServoController.apiPositionFirst);
            this.targetXDegrees = jSONObject.optDouble("tx", LynxServoController.apiPositionFirst);
            this.targetYDegrees = jSONObject.optDouble("ty", LynxServoController.apiPositionFirst);
            this.targetXDegreesNoCrosshair = jSONObject.optDouble("tx_nocross", LynxServoController.apiPositionFirst);
            this.targetYDegreesNoCrosshair = jSONObject.optDouble("ty_nocross", LynxServoController.apiPositionFirst);
            this.targetCorners = LLResultTypes.parsePoints(jSONObject.optJSONArray("pts"));
        }

        public String getClassName() {
            return this.className;
        }

        public int getClassId() {
            return this.classId;
        }

        public double getConfidence() {
            return this.confidence;
        }

        public List<List<Double>> getTargetCorners() {
            return this.targetCorners;
        }

        public double getTargetArea() {
            return this.targetArea;
        }

        public double getTargetXPixels() {
            return this.targetXPixels;
        }

        public double getTargetYPixels() {
            return this.targetYPixels;
        }

        public double getTargetXDegrees() {
            return this.targetXDegrees;
        }

        public double getTargetYDegrees() {
            return this.targetYDegrees;
        }

        public double getTargetXDegreesNoCrosshair() {
            return this.targetXDegreesNoCrosshair;
        }

        public double getTargetYDegreesNoCrosshair() {
            return this.targetYDegreesNoCrosshair;
        }
    }

    public static class FiducialResult {
        private Pose3D cameraPoseTargetSpace;
        private String family;
        private int fiducialId;
        private Pose3D robotPoseFieldSpace;
        private Pose3D robotPoseTargetSpace;
        private double skew;
        private double targetArea;
        private List<List<Double>> targetCorners;
        private Pose3D targetPoseCameraSpace;
        private Pose3D targetPoseRobotSpace;
        private double targetXDegrees;
        private double targetXDegreesNoCrosshair;
        private double targetXPixels;
        private double targetYDegrees;
        private double targetYDegreesNoCrosshair;
        private double targetYPixels;

        protected FiducialResult(JSONObject jSONObject) {
            this.fiducialId = jSONObject.optInt("fID", 0);
            this.family = jSONObject.optString("fam", InspectionState.NO_VERSION);
            this.skew = jSONObject.optDouble("skew", LynxServoController.apiPositionFirst);
            this.cameraPoseTargetSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6c_ts")));
            this.robotPoseFieldSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6r_fs")));
            this.robotPoseTargetSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6r_ts")));
            this.targetPoseCameraSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6t_cs")));
            this.targetPoseRobotSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6t_rs")));
            this.targetArea = jSONObject.optDouble("ta", LynxServoController.apiPositionFirst);
            this.targetXPixels = jSONObject.optDouble("txp", LynxServoController.apiPositionFirst);
            this.targetYPixels = jSONObject.optDouble("typ", LynxServoController.apiPositionFirst);
            this.targetXDegrees = jSONObject.optDouble("tx", LynxServoController.apiPositionFirst);
            this.targetYDegrees = jSONObject.optDouble("ty", LynxServoController.apiPositionFirst);
            this.targetXDegreesNoCrosshair = jSONObject.optDouble("tx_nocross", LynxServoController.apiPositionFirst);
            this.targetYDegreesNoCrosshair = jSONObject.optDouble("ty_nocross", LynxServoController.apiPositionFirst);
            this.targetCorners = LLResultTypes.parsePoints(jSONObject.optJSONArray("pts"));
        }

        public int getFiducialId() {
            return this.fiducialId;
        }

        public String getFamily() {
            return this.family;
        }

        public List<List<Double>> getTargetCorners() {
            return this.targetCorners;
        }

        public double getSkew() {
            return this.skew;
        }

        public Pose3D getCameraPoseTargetSpace() {
            return this.cameraPoseTargetSpace;
        }

        public Pose3D getRobotPoseFieldSpace() {
            return this.robotPoseFieldSpace;
        }

        public Pose3D getRobotPoseTargetSpace() {
            return this.robotPoseTargetSpace;
        }

        public Pose3D getTargetPoseCameraSpace() {
            return this.targetPoseCameraSpace;
        }

        public Pose3D getTargetPoseRobotSpace() {
            return this.targetPoseRobotSpace;
        }

        public double getTargetArea() {
            return this.targetArea;
        }

        public double getTargetXPixels() {
            return this.targetXPixels;
        }

        public double getTargetYPixels() {
            return this.targetYPixels;
        }

        public double getTargetXDegrees() {
            return this.targetXDegrees;
        }

        public double getTargetYDegrees() {
            return this.targetYDegrees;
        }

        public double getTargetXDegreesNoCrosshair() {
            return this.targetXDegreesNoCrosshair;
        }

        public double getTargetYDegreesNoCrosshair() {
            return this.targetYDegreesNoCrosshair;
        }
    }

    public static class ColorResult {
        private Pose3D cameraPoseTargetSpace;
        private Pose3D robotPoseFieldSpace;
        private Pose3D robotPoseTargetSpace;
        private double targetArea;
        private List<List<Double>> targetCorners;
        private Pose3D targetPoseCameraSpace;
        private Pose3D targetPoseRobotSpace;
        private double targetXDegrees;
        private double targetXDegreesNoCrosshair;
        private double targetXPixels;
        private double targetYDegrees;
        private double targetYDegreesNoCrosshair;
        private double targetYPixels;

        protected ColorResult(JSONObject jSONObject) {
            this.cameraPoseTargetSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6c_ts")));
            this.robotPoseFieldSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6r_fs")));
            this.robotPoseTargetSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6r_ts")));
            this.targetPoseCameraSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6t_cs")));
            this.targetPoseRobotSpace = LLResult.createPose3DRobot(LLResultTypes.parsePoseArray(jSONObject.optJSONArray("t6t_rs")));
            this.targetArea = jSONObject.optDouble("ta", LynxServoController.apiPositionFirst);
            this.targetXPixels = jSONObject.optDouble("txp", LynxServoController.apiPositionFirst);
            this.targetYPixels = jSONObject.optDouble("typ", LynxServoController.apiPositionFirst);
            this.targetXDegrees = jSONObject.optDouble("tx", LynxServoController.apiPositionFirst);
            this.targetYDegrees = jSONObject.optDouble("ty", LynxServoController.apiPositionFirst);
            this.targetXDegreesNoCrosshair = jSONObject.optDouble("tx_nocross", LynxServoController.apiPositionFirst);
            this.targetYDegreesNoCrosshair = jSONObject.optDouble("ty_nocross", LynxServoController.apiPositionFirst);
            this.targetCorners = LLResultTypes.parsePoints(jSONObject.optJSONArray("pts"));
        }

        public List<List<Double>> getTargetCorners() {
            return this.targetCorners;
        }

        public Pose3D getCameraPoseTargetSpace() {
            return this.cameraPoseTargetSpace;
        }

        public Pose3D getRobotPoseFieldSpace() {
            return this.robotPoseFieldSpace;
        }

        public Pose3D getRobotPoseTargetSpace() {
            return this.robotPoseTargetSpace;
        }

        public Pose3D getTargetPoseCameraSpace() {
            return this.targetPoseCameraSpace;
        }

        public Pose3D getTargetPoseRobotSpace() {
            return this.targetPoseRobotSpace;
        }

        public double getTargetArea() {
            return this.targetArea;
        }

        public double getTargetXPixels() {
            return this.targetXPixels;
        }

        public double getTargetYPixels() {
            return this.targetYPixels;
        }

        public double getTargetXDegrees() {
            return this.targetXDegrees;
        }

        public double getTargetYDegrees() {
            return this.targetYDegrees;
        }

        public double getTargetXDegreesNoCrosshair() {
            return this.targetXDegreesNoCrosshair;
        }

        public double getTargetYDegreesNoCrosshair() {
            return this.targetYDegreesNoCrosshair;
        }
    }

    public static class CalibrationResult {
        private static final double DEFAULT_REPORT_VAL = 0.0d;
        private double[] camMatVector;
        private String displayName;
        private double[] distortionCoefficients;
        private double reprojectionError;
        private double resX;
        private double resY;
        private boolean valid;

        public CalibrationResult() {
            this(InspectionState.NO_VERSION, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst, new double[9], new double[5]);
        }

        public CalibrationResult(String str, double d, double d2, double d3, double[] dArr, double[] dArr2) {
            this.displayName = str;
            this.resX = d;
            this.resY = d2;
            this.reprojectionError = d3;
            this.camMatVector = (double[]) dArr.clone();
            this.distortionCoefficients = (double[]) dArr2.clone();
            this.valid = true;
        }

        protected CalibrationResult(JSONObject jSONObject) {
            this();
            if (jSONObject != null) {
                try {
                    this.displayName = jSONObject.optString("DISPLAY_NAME", InspectionState.NO_VERSION);
                    this.reprojectionError = jSONObject.optDouble("REPROJECTION_ERROR", LynxServoController.apiPositionFirst);
                    this.resX = jSONObject.optDouble("RES_X", LynxServoController.apiPositionFirst);
                    this.resY = jSONObject.optDouble("RES_Y", LynxServoController.apiPositionFirst);
                    JSONArray optJSONArray = jSONObject.optJSONArray("INTRINSICS_MATRIX");
                    if (optJSONArray == null || optJSONArray.length() != 9) {
                        this.valid = false;
                    } else {
                        for (int i = 0; i < 9; i++) {
                            this.camMatVector[i] = optJSONArray.optDouble(i, LynxServoController.apiPositionFirst);
                        }
                    }
                    JSONArray optJSONArray2 = jSONObject.optJSONArray("DISTORTION_COEFFICIENTS");
                    if (optJSONArray2 == null || optJSONArray2.length() != 5) {
                        this.valid = false;
                    } else {
                        for (int i2 = 0; i2 < 5; i2++) {
                            this.distortionCoefficients[i2] = optJSONArray2.optDouble(i2, LynxServoController.apiPositionFirst);
                        }
                    }
                    if (this.resX == LynxServoController.apiPositionFirst || this.resY == LynxServoController.apiPositionFirst) {
                        this.valid = false;
                    }
                } catch (Exception unused) {
                }
            }
        }

        public boolean isValid() {
            return (!this.valid || this.resX == LynxServoController.apiPositionFirst || this.resY == LynxServoController.apiPositionFirst || this.camMatVector[0] == LynxServoController.apiPositionFirst) ? false : true;
        }

        public String getDisplayName() {
            return this.displayName;
        }

        public double getResX() {
            return this.resX;
        }

        public double getResY() {
            return this.resY;
        }

        public double getReprojectionError() {
            return this.reprojectionError;
        }

        public double[] getCamMatVector() {
            return (double[]) this.camMatVector.clone();
        }

        public double[] getDistortionCoefficients() {
            return (double[]) this.distortionCoefficients.clone();
        }

        /* access modifiers changed from: protected */
        public JSONObject toJson() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("DISPLAY_NAME", getDisplayName());
                jSONObject.put("REPROJECTION_ERROR", getReprojectionError());
                jSONObject.put("RES_X", getResX());
                jSONObject.put("RES_Y", getResY());
                jSONObject.put("INTRINSICS_MATRIX", new JSONArray(getCamMatVector()));
                jSONObject.put("DISTORTION_COEFFICIENTS", new JSONArray(getDistortionCoefficients()));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jSONObject;
        }
    }
}

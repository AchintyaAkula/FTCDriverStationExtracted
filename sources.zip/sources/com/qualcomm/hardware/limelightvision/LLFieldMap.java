package com.qualcomm.hardware.limelightvision;

import com.qualcomm.ftccommon.configuration.RobotConfigResFilter;
import com.qualcomm.hardware.lynx.LynxServoController;
import java.util.ArrayList;
import java.util.List;
import org.firstinspires.inspection.InspectionState;
import org.json.JSONArray;
import org.json.JSONObject;

public class LLFieldMap {
    private List<Fiducial> fiducials;
    private String type;

    public static class Fiducial {
        private String family;
        private int id;
        private boolean isUnique;
        private double size;
        private List<Double> transform;

        public Fiducial() {
            this(-1, 165.1d, "apriltag3_36h11_classic", new ArrayList(16), true);
        }

        public Fiducial(int i, double d, String str, List<Double> list, boolean z) {
            this.id = i;
            this.size = d;
            this.family = str;
            this.transform = new ArrayList(list);
            this.isUnique = z;
        }

        protected Fiducial(JSONObject jSONObject) {
            this();
            if (jSONObject != null) {
                try {
                    this.id = jSONObject.optInt("id", -1);
                    this.size = jSONObject.optDouble("size", 165.1d);
                    this.family = jSONObject.optString("family", "apriltag3_36h11_classic");
                    this.transform = new ArrayList();
                    JSONArray optJSONArray = jSONObject.optJSONArray("transform");
                    if (optJSONArray != null) {
                        for (int i = 0; i < optJSONArray.length(); i++) {
                            this.transform.add(Double.valueOf(optJSONArray.optDouble(i, LynxServoController.apiPositionFirst)));
                        }
                    }
                    this.isUnique = jSONObject.optBoolean("unique", true);
                } catch (Exception unused) {
                }
            }
        }

        public int getId() {
            return this.id;
        }

        public double getSize() {
            return this.size;
        }

        public String getFamily() {
            return this.family;
        }

        public List<Double> getTransform() {
            return new ArrayList(this.transform);
        }

        public boolean isUnique() {
            return this.isUnique;
        }

        /* access modifiers changed from: protected */
        public JSONObject toJson() {
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("id", this.id);
                jSONObject.put("size", this.size);
                jSONObject.put("family", this.family);
                jSONObject.put("transform", new JSONArray(this.transform));
                jSONObject.put("unique", this.isUnique);
            } catch (Exception unused) {
            }
            return jSONObject;
        }
    }

    public LLFieldMap() {
        this(new ArrayList(), InspectionState.NO_VERSION);
    }

    public LLFieldMap(List<Fiducial> list, String str) {
        this.fiducials = new ArrayList(list);
        this.type = str;
    }

    protected LLFieldMap(JSONObject jSONObject) {
        this();
        if (jSONObject != null) {
            try {
                this.type = jSONObject.optString(RobotConfigResFilter.robotConfigRootTypeAttribute, InspectionState.NO_VERSION);
                JSONArray optJSONArray = jSONObject.optJSONArray("fiducials");
                if (optJSONArray != null) {
                    for (int i = 0; i < optJSONArray.length(); i++) {
                        JSONObject optJSONObject = optJSONArray.optJSONObject(i);
                        if (optJSONObject != null) {
                            this.fiducials.add(new Fiducial(optJSONObject));
                        }
                    }
                }
            } catch (Exception unused) {
            }
        }
    }

    public List<Fiducial> getFiducials() {
        return new ArrayList(this.fiducials);
    }

    public String getType() {
        return this.type;
    }

    public int getNumberOfTags() {
        return this.fiducials.size();
    }

    public boolean isValid() {
        if (getNumberOfTags() == 0) {
            return false;
        }
        if (getType() == "ftc" || getType() == "frc") {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public JSONObject toJson() {
        JSONObject jSONObject = new JSONObject();
        try {
            JSONArray jSONArray = new JSONArray();
            for (Fiducial json : this.fiducials) {
                jSONArray.put(json.toJson());
            }
            jSONObject.put("fiducials", jSONArray);
            jSONObject.put(RobotConfigResFilter.robotConfigRootTypeAttribute, this.type);
        } catch (Exception unused) {
        }
        return jSONObject;
    }
}

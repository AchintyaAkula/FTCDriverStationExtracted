package com.qualcomm.hardware.limelightvision;

import com.qualcomm.hardware.lynx.LynxServoController;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.inspection.InspectionState;
import org.json.JSONObject;

public class LLStatus {
    private Quaternion cameraQuat;
    private int cid;
    private double cpu;
    private double finalYaw;
    private double fps;
    private int hwType;
    private int ignoreNT;
    private int interfaceNeedsRefresh;
    private String name;
    private int pipeImgCount;
    private int pipelineIndex;
    private String pipelineType;
    private double ram;
    private int snapshotMode;
    private double temp;

    public LLStatus() {
        this.cameraQuat = new Quaternion(1.0f, 0.0f, 0.0f, 0.0f, 0);
        this.cid = 0;
        this.cpu = LynxServoController.apiPositionFirst;
        this.finalYaw = LynxServoController.apiPositionFirst;
        this.fps = LynxServoController.apiPositionFirst;
        this.hwType = 0;
        this.ignoreNT = 0;
        this.interfaceNeedsRefresh = 0;
        this.name = InspectionState.NO_VERSION;
        this.pipeImgCount = 0;
        this.pipelineIndex = 0;
        this.pipelineType = InspectionState.NO_VERSION;
        this.ram = LynxServoController.apiPositionFirst;
        this.snapshotMode = 0;
        this.temp = LynxServoController.apiPositionFirst;
    }

    protected LLStatus(JSONObject jSONObject) {
        this();
        if (jSONObject != null) {
            try {
                JSONObject optJSONObject = jSONObject.optJSONObject("cameraQuat");
                if (optJSONObject != null) {
                    this.cameraQuat.w = (float) optJSONObject.optDouble("w", 1.0d);
                    this.cameraQuat.x = (float) optJSONObject.optDouble("x", LynxServoController.apiPositionFirst);
                    this.cameraQuat.y = (float) optJSONObject.optDouble("y", LynxServoController.apiPositionFirst);
                    this.cameraQuat.z = (float) optJSONObject.optDouble("z", LynxServoController.apiPositionFirst);
                }
                this.cid = jSONObject.optInt("cid", 0);
                this.cpu = jSONObject.optDouble("cpu", LynxServoController.apiPositionFirst);
                this.finalYaw = jSONObject.optDouble("finalYaw", LynxServoController.apiPositionFirst);
                this.fps = jSONObject.optDouble("fps", LynxServoController.apiPositionFirst);
                this.hwType = jSONObject.optInt("hwType", 0);
                this.ignoreNT = jSONObject.optInt("ignoreNT", 0);
                this.interfaceNeedsRefresh = jSONObject.optInt("interfaceNeedsRefresh", 0);
                this.name = jSONObject.optString("name", InspectionState.NO_VERSION);
                this.pipeImgCount = jSONObject.optInt("pipeImgCount", 0);
                this.pipelineIndex = jSONObject.optInt("pipelineIndex", 0);
                this.pipelineType = jSONObject.optString("pipelineType", InspectionState.NO_VERSION);
                this.ram = jSONObject.optDouble("ram", LynxServoController.apiPositionFirst);
                this.snapshotMode = jSONObject.optInt("snapshotMode", 0);
                this.temp = jSONObject.optDouble("temp", LynxServoController.apiPositionFirst);
            } catch (Exception unused) {
            }
        }
    }

    public Quaternion getCameraQuat() {
        return this.cameraQuat;
    }

    public int getCid() {
        return this.cid;
    }

    public double getCpu() {
        return this.cpu;
    }

    public double getFinalYaw() {
        return this.finalYaw;
    }

    public double getFps() {
        return this.fps;
    }

    public int getHwType() {
        return this.hwType;
    }

    private int getIgnoreNT() {
        return this.ignoreNT;
    }

    private int getInterfaceNeedsRefresh() {
        return this.interfaceNeedsRefresh;
    }

    public String getName() {
        return this.name;
    }

    public int getPipeImgCount() {
        return this.pipeImgCount;
    }

    public int getPipelineIndex() {
        return this.pipelineIndex;
    }

    public String getPipelineType() {
        return this.pipelineType;
    }

    public double getRam() {
        return this.ram;
    }

    public int getSnapshotMode() {
        return this.snapshotMode;
    }

    public double getTemp() {
        return this.temp;
    }

    public String toString() {
        return "LLStatus{cameraQuat=" + this.cameraQuat.toString() + ", cid=" + this.cid + ", cpu=" + this.cpu + ", finalYaw=" + this.finalYaw + ", fps=" + this.fps + ", hwType=" + this.hwType + ", ignoreNT=" + this.ignoreNT + ", interfaceNeedsRefresh=" + this.interfaceNeedsRefresh + ", name='" + this.name + "', pipeImgCount=" + this.pipeImgCount + ", pipelineIndex=" + this.pipelineIndex + ", pipelineType='" + this.pipelineType + "', ram=" + this.ram + ", snapshotMode=" + this.snapshotMode + ", temp=" + this.temp + '}';
    }
}

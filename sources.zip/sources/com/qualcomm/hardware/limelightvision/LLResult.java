package com.qualcomm.hardware.limelightvision;

import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.util.ElapsedTime;
import java.util.ArrayList;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.inspection.InspectionState;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LLResult {
    private List<LLResultTypes.BarcodeResult> barcodeResults = new ArrayList();
    private List<LLResultTypes.ClassifierResult> classifierResults = new ArrayList();
    private List<LLResultTypes.ColorResult> colorResults = new ArrayList();
    private long controlHubTimeStamp;
    private List<LLResultTypes.DetectorResult> detectorResults = new ArrayList();
    private List<LLResultTypes.FiducialResult> fiducialResults = new ArrayList();
    private JSONObject jsonData;
    private double parseLatency = LynxServoController.apiPositionFirst;

    protected LLResult(JSONObject jSONObject) throws JSONException {
        this.jsonData = jSONObject;
        setControlHubTimeStamp(System.currentTimeMillis());
        parseResults();
    }

    /* access modifiers changed from: package-private */
    public void setControlHubTimeStamp(long j) {
        this.controlHubTimeStamp = j;
    }

    public long getControlHubTimeStamp() {
        return this.controlHubTimeStamp;
    }

    public long getControlHubTimeStampNanos() {
        return this.controlHubTimeStamp * ElapsedTime.MILLIS_IN_NANO;
    }

    public long getStaleness() {
        return System.currentTimeMillis() - this.controlHubTimeStamp;
    }

    private void parseResults() throws JSONException {
        long nanoTime = System.nanoTime();
        JSONArray optJSONArray = this.jsonData.optJSONArray("Barcode");
        if (optJSONArray != null) {
            for (int i = 0; i < optJSONArray.length(); i++) {
                this.barcodeResults.add(new LLResultTypes.BarcodeResult(optJSONArray.getJSONObject(i)));
            }
        }
        JSONArray optJSONArray2 = this.jsonData.optJSONArray("Classifier");
        if (optJSONArray2 != null) {
            for (int i2 = 0; i2 < optJSONArray2.length(); i2++) {
                this.classifierResults.add(new LLResultTypes.ClassifierResult(optJSONArray2.getJSONObject(i2)));
            }
        }
        JSONArray optJSONArray3 = this.jsonData.optJSONArray("Detector");
        if (optJSONArray3 != null) {
            for (int i3 = 0; i3 < optJSONArray3.length(); i3++) {
                this.detectorResults.add(new LLResultTypes.DetectorResult(optJSONArray3.getJSONObject(i3)));
            }
        }
        JSONArray optJSONArray4 = this.jsonData.optJSONArray("Fiducial");
        if (optJSONArray4 != null) {
            for (int i4 = 0; i4 < optJSONArray4.length(); i4++) {
                this.fiducialResults.add(new LLResultTypes.FiducialResult(optJSONArray4.getJSONObject(i4)));
            }
        }
        JSONArray optJSONArray5 = this.jsonData.optJSONArray("Retro");
        if (optJSONArray5 != null) {
            for (int i5 = 0; i5 < optJSONArray5.length(); i5++) {
                this.colorResults.add(new LLResultTypes.ColorResult(optJSONArray5.getJSONObject(i5)));
            }
        }
        this.parseLatency = ((double) (System.nanoTime() - nanoTime)) / 1000000.0d;
    }

    public List<LLResultTypes.BarcodeResult> getBarcodeResults() {
        return this.barcodeResults;
    }

    public List<LLResultTypes.ClassifierResult> getClassifierResults() {
        return this.classifierResults;
    }

    public List<LLResultTypes.DetectorResult> getDetectorResults() {
        return this.detectorResults;
    }

    public List<LLResultTypes.FiducialResult> getFiducialResults() {
        return this.fiducialResults;
    }

    public List<LLResultTypes.ColorResult> getColorResults() {
        return this.colorResults;
    }

    public double getFocusMetric() {
        return this.jsonData.optDouble("focus_metric", LynxServoController.apiPositionFirst);
    }

    public Pose3D getBotpose() {
        return createPose3DRobot(getDoubleArray("botpose", 6));
    }

    private Pose3D getBotposeWpiblue() {
        return createPose3DRobot(getDoubleArray("botpose_wpiblue", 6));
    }

    private Pose3D getBotposeWpired() {
        return createPose3DRobot(getDoubleArray("botpose_wpired", 6));
    }

    public Pose3D getBotpose_MT2() {
        return createPose3DRobot(getDoubleArray("botpose_orb", 6));
    }

    private Pose3D getBotposeWpiblue_MT2() {
        return createPose3DRobot(getDoubleArray("botpose_orb_wpiblue", 6));
    }

    private Pose3D getBotposeOrbWpired_MT2() {
        return createPose3DRobot(getDoubleArray("botpose_orb_wpired", 6));
    }

    public double[] getStddevMt1() {
        return getDoubleArray("stdev_mt1", 6);
    }

    public double[] getStddevMt2() {
        return getDoubleArray("stdev_mt2", 6);
    }

    public int getBotposeTagCount() {
        return this.jsonData.optInt("botpose_tagcount", 0);
    }

    public double getBotposeSpan() {
        return this.jsonData.optDouble("botpose_span", LynxServoController.apiPositionFirst);
    }

    public double getBotposeAvgDist() {
        return this.jsonData.optDouble("botpose_avgdist", LynxServoController.apiPositionFirst);
    }

    public double getBotposeAvgArea() {
        return this.jsonData.optDouble("botpose_avgarea", LynxServoController.apiPositionFirst);
    }

    public double[] getPythonOutput() {
        double[] doubleArray = getDoubleArray("PythonOut", 0);
        double[] dArr = new double[32];
        System.arraycopy(doubleArray, 0, dArr, 0, Math.min(doubleArray.length, 32));
        return dArr;
    }

    public double getCaptureLatency() {
        return this.jsonData.optDouble("cl", LynxServoController.apiPositionFirst);
    }

    public String getPipelineType() {
        return this.jsonData.optString("pipelineType", InspectionState.NO_VERSION);
    }

    public double getTx() {
        return this.jsonData.optDouble("tx", LynxServoController.apiPositionFirst);
    }

    public double getTy() {
        return this.jsonData.optDouble("ty", LynxServoController.apiPositionFirst);
    }

    public double getTxNC() {
        return this.jsonData.optDouble("txnc", LynxServoController.apiPositionFirst);
    }

    public double getTyNC() {
        return this.jsonData.optDouble("tync", LynxServoController.apiPositionFirst);
    }

    public double getTa() {
        return this.jsonData.optDouble("ta", LynxServoController.apiPositionFirst);
    }

    public int getPipelineIndex() {
        return this.jsonData.optInt("pID", 0);
    }

    private Pose3D getCameraPose_RobotSpace() {
        return createPose3DRobot(getDoubleArray("t6c_rs", 6));
    }

    public double getTargetingLatency() {
        return this.jsonData.optDouble("tl", LynxServoController.apiPositionFirst);
    }

    public double getTimestamp() {
        return this.jsonData.optDouble("ts", LynxServoController.apiPositionFirst);
    }

    public boolean isValid() {
        return this.jsonData.optInt("v", 0) == 1;
    }

    public double getParseLatency() {
        return this.parseLatency;
    }

    private double[] getDoubleArray(String str, int i) {
        JSONArray optJSONArray = this.jsonData.optJSONArray(str);
        if (optJSONArray == null) {
            return new double[i];
        }
        double[] dArr = new double[optJSONArray.length()];
        for (int i2 = 0; i2 < optJSONArray.length(); i2++) {
            dArr[i2] = optJSONArray.optDouble(i2);
        }
        return dArr;
    }

    protected static Pose3D createPose3DRobot(double[] dArr) {
        double[] dArr2 = dArr;
        if (dArr2.length < 6) {
            return new Pose3D(new Position(), new YawPitchRollAngles(AngleUnit.DEGREES, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst, 0));
        }
        return new Pose3D(new Position(DistanceUnit.METER, dArr2[0], dArr2[1], dArr2[2], 0), new YawPitchRollAngles(AngleUnit.DEGREES, dArr2[5], dArr2[4], dArr2[3], 0));
    }

    protected static LLResult parse(JSONObject jSONObject) {
        try {
            return new LLResult(jSONObject);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String toString() {
        return this.jsonData.toString();
    }
}

package com.qualcomm.hardware.limelightvision;

import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.util.SerialNumber;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import org.firstinspires.ftc.robotcore.internal.usb.EthernetOverUsbSerialNumber;
import org.firstinspires.inspection.InspectionState;
import org.json.JSONArray;
import org.json.JSONObject;

public class Limelight3A implements HardwareDevice {
    private static final int CONNECTION_TIMEOUT = 100;
    private static final int DELETEREQUEST_TIMEOUT = 15000;
    private static final int GETREQUEST_TIMEOUT = 100;
    private static final long ISCONNECTED_THRESHOLD = 250;
    private static final int MAX_POLL_RATE_HZ = 250;
    private static final int MIN_POLL_RATE_HZ = 1;
    private static final int POSTREQUEST_TIMEOUT = 15000;
    private static final int PYTHON_INPUT_MAX_SIZE = 32;
    private static final int RUNNING = 2;
    private static final int STARTING = 1;
    private static final int STOPPED = 0;
    private static final String TAG = "Limelight3A";
    private final String baseUrl;
    private volatile ScheduledExecutorService executor;
    private final Object executorLock = new Object();
    private InetAddress inetAddress;
    private volatile boolean isExecutorInitialized = false;
    private volatile long lastUpdateTime = 0;
    private volatile LLResult latestResult;
    private String name;
    private long pollIntervalMs = 10;
    private EthernetOverUsbSerialNumber serialNumber;
    private final AtomicInteger state = new AtomicInteger(0);

    public int getVersion() {
        return 0;
    }

    public void resetDeviceConfigurationForOpMode() {
    }

    public Limelight3A(SerialNumber serialNumber2, String str, InetAddress inetAddress2) {
        this.name = str;
        this.serialNumber = (EthernetOverUsbSerialNumber) serialNumber2;
        this.inetAddress = inetAddress2;
        this.baseUrl = "http://" + inetAddress2.getHostAddress() + ":5807";
        this.executor = Executors.newSingleThreadScheduledExecutor();
    }

    private synchronized void ensureExecutorRunning() {
        synchronized (this.executorLock) {
            if (this.executor == null || this.executor.isShutdown()) {
                this.executor = Executors.newSingleThreadScheduledExecutor();
                this.isExecutorInitialized = false;
            }
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(2:11|12) */
    /* JADX WARNING: Code restructure failed: missing block: B:12:?, code lost:
        r10.state.set(0);
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x002d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void start() {
        /*
            r10 = this;
            monitor-enter(r10)
            java.util.concurrent.atomic.AtomicInteger r0 = r10.state     // Catch:{ all -> 0x0034 }
            r1 = 1
            r2 = 0
            boolean r0 = r0.compareAndSet(r2, r1)     // Catch:{ all -> 0x0034 }
            if (r0 != 0) goto L_0x000d
            monitor-exit(r10)
            return
        L_0x000d:
            r10.ensureExecutorRunning()     // Catch:{ Exception -> 0x002d }
            boolean r0 = r10.isExecutorInitialized     // Catch:{ Exception -> 0x002d }
            if (r0 != 0) goto L_0x0026
            java.util.concurrent.ScheduledExecutorService r3 = r10.executor     // Catch:{ Exception -> 0x002d }
            com.qualcomm.hardware.limelightvision.Limelight3A$$ExternalSyntheticLambda0 r4 = new com.qualcomm.hardware.limelightvision.Limelight3A$$ExternalSyntheticLambda0     // Catch:{ Exception -> 0x002d }
            r4.<init>(r10)     // Catch:{ Exception -> 0x002d }
            long r7 = r10.pollIntervalMs     // Catch:{ Exception -> 0x002d }
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ Exception -> 0x002d }
            r5 = 0
            r3.scheduleAtFixedRate(r4, r5, r7, r9)     // Catch:{ Exception -> 0x002d }
            r10.isExecutorInitialized = r1     // Catch:{ Exception -> 0x002d }
        L_0x0026:
            java.util.concurrent.atomic.AtomicInteger r0 = r10.state     // Catch:{ Exception -> 0x002d }
            r1 = 2
            r0.set(r1)     // Catch:{ Exception -> 0x002d }
            goto L_0x0032
        L_0x002d:
            java.util.concurrent.atomic.AtomicInteger r0 = r10.state     // Catch:{ all -> 0x0034 }
            r0.set(r2)     // Catch:{ all -> 0x0034 }
        L_0x0032:
            monitor-exit(r10)
            return
        L_0x0034:
            r0 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x0034 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.limelightvision.Limelight3A.start():void");
    }

    public synchronized void pause() {
        if (this.state.get() == 2) {
            this.state.set(0);
        }
    }

    public synchronized void stop() {
        this.state.set(0);
        this.isExecutorInitialized = false;
        if (!this.executor.isShutdown()) {
            this.executor.shutdownNow();
        }
    }

    public boolean isRunning() {
        return this.state.get() == 2;
    }

    public synchronized void setPollRateHz(int i) {
        if (this.state.get() != 2) {
            this.pollIntervalMs = (long) (1000 / Math.max(1, Math.min(i, 250)));
        }
    }

    public long getTimeSinceLastUpdate() {
        return System.currentTimeMillis() - this.lastUpdateTime;
    }

    public boolean isConnected() {
        return getTimeSinceLastUpdate() <= ISCONNECTED_THRESHOLD;
    }

    /* access modifiers changed from: private */
    public void updateLatestResult() {
        if (this.state.get() == 2) {
            try {
                JSONObject sendGetRequest = sendGetRequest("/results");
                if (sendGetRequest != null) {
                    this.latestResult = LLResult.parse(sendGetRequest);
                    this.lastUpdateTime = System.currentTimeMillis();
                }
            } catch (Exception unused) {
            }
        }
    }

    public LLResult getLatestResult() {
        if (this.latestResult == null) {
            this.latestResult = LLResult.parse(new JSONObject());
        }
        return this.latestResult;
    }

    public LLStatus getStatus() {
        JSONObject sendGetRequest = sendGetRequest("/status");
        if (sendGetRequest == null) {
            return new LLStatus();
        }
        return new LLStatus(sendGetRequest);
    }

    private JSONObject getHWReport() {
        return sendGetRequest("/hwreport");
    }

    public boolean reloadPipeline() {
        return sendPostRequest("/reload-pipeline", (String) null);
    }

    private JSONObject getPipelineDefault() {
        return sendGetRequest("/pipeline-default");
    }

    private JSONObject getPipelineAtIndex(int i) {
        return sendGetRequest("/pipeline-atindex?index=" + i);
    }

    public boolean pipelineSwitch(int i) {
        return sendPostRequest("/pipeline-switch?index=" + i, (String) null);
    }

    private JSONObject getSnapscriptNames() {
        return sendGetRequest("/getsnapscriptnames");
    }

    public boolean captureSnapshot(String str) {
        return sendPostRequest("/capture-snapshot?snapname=" + str, (String) null);
    }

    private JSONObject snapshotManifest() {
        return sendGetRequest("/snapshotmanifest");
    }

    public boolean deleteSnapshots() {
        return sendDeleteRequest("/delete-snapshots");
    }

    public boolean deleteSnapshot(String str) {
        return sendDeleteRequest("/delete-snapshot?snapname=" + str);
    }

    private boolean updatePipeline(JSONObject jSONObject, boolean z) {
        return sendPostRequest("/update-pipeline".concat(z ? "?flush=1" : InspectionState.NO_VERSION), jSONObject.toString());
    }

    public boolean updatePythonInputs(double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8) {
        return updatePythonInputs(new double[]{d, d2, d3, d4, d5, d6, d7, d8});
    }

    public boolean updatePythonInputs(double[] dArr) {
        if (!(dArr == null || dArr.length == 0 || dArr.length > 32)) {
            try {
                return sendPostRequest("/update-pythoninputs", new JSONArray(dArr).toString());
            } catch (Exception unused) {
            }
        }
        return false;
    }

    public boolean updateRobotOrientation(double d) {
        try {
            return sendPostRequest("/update-robotorientation", new JSONArray(new double[]{d, 0.0d, 0.0d, 0.0d, 0.0d, 0.0d}).toString());
        } catch (Exception unused) {
            return false;
        }
    }

    private boolean uploadPipeline(JSONObject jSONObject, Integer num) {
        return sendPostRequest("/upload-pipeline" + (num != null ? "?index=" + num : InspectionState.NO_VERSION), jSONObject.toString());
    }

    public boolean uploadPipeline(String str, Integer num) {
        return sendPostRequest("/upload-pipeline" + (num != null ? "?index=" + num : InspectionState.NO_VERSION), str);
    }

    public boolean uploadFieldmap(LLFieldMap lLFieldMap, Integer num) {
        if (!lLFieldMap.isValid()) {
            return false;
        }
        return sendPostRequest("/upload-fieldmap" + (num != null ? "?index=" + num : InspectionState.NO_VERSION), lLFieldMap.toJson().toString());
    }

    public boolean uploadPython(String str, Integer num) {
        return sendPostRequest("/upload-python" + (num != null ? "?index=" + num : InspectionState.NO_VERSION), str);
    }

    public LLResultTypes.CalibrationResult getCalDefault() {
        return new LLResultTypes.CalibrationResult(sendGetRequest("/cal-default"));
    }

    public LLResultTypes.CalibrationResult getCalFile() {
        return new LLResultTypes.CalibrationResult(sendGetRequest("/cal-file"));
    }

    public LLResultTypes.CalibrationResult getCalEEPROM() {
        return new LLResultTypes.CalibrationResult(sendGetRequest("/cal-eeprom"));
    }

    public LLResultTypes.CalibrationResult getCalLatest() {
        return new LLResultTypes.CalibrationResult(sendGetRequest("/cal-latest"));
    }

    private boolean updateCalEEPROM(LLResultTypes.CalibrationResult calibrationResult) {
        return sendPostRequest("/cal-eeprom", calibrationResult.toJson().toString());
    }

    private boolean updateCalFile(LLResultTypes.CalibrationResult calibrationResult) {
        return sendPostRequest("/cal-file", calibrationResult.toJson().toString());
    }

    private boolean deleteCalLatest() {
        return sendDeleteRequest("/cal-latest");
    }

    private boolean deleteCalEEPROM() {
        return sendDeleteRequest("/cal-eeprom");
    }

    private boolean deleteCalFile() {
        return sendDeleteRequest("/cal-file");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0043, code lost:
        if (r5 != null) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0053, code lost:
        if (r5 != null) goto L_0x0055;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0055, code lost:
        r5.disconnect();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0058, code lost:
        return null;
     */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x004e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private org.json.JSONObject sendGetRequest(java.lang.String r5) {
        /*
            r4 = this;
            r0 = 0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            r1.<init>()     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.lang.String r2 = r4.baseUrl     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.lang.StringBuilder r5 = r1.append(r5)     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.net.URL r1 = new java.net.URL     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            r1.<init>(r5)     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.net.URLConnection r5 = r1.openConnection()     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.net.HttpURLConnection r5 = (java.net.HttpURLConnection) r5     // Catch:{ Exception -> 0x0052, all -> 0x0048 }
            java.lang.String r1 = "GET"
            r5.setRequestMethod(r1)     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            r1 = 100
            r5.setReadTimeout(r1)     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            r5.setConnectTimeout(r1)     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            int r1 = r5.getResponseCode()     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            r2 = 200(0xc8, float:2.8E-43)
            if (r1 != r2) goto L_0x0043
            java.lang.String r1 = r4.readResponse(r5)     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            org.json.JSONObject r2 = new org.json.JSONObject     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            r2.<init>(r1)     // Catch:{ Exception -> 0x0053, all -> 0x0046 }
            if (r5 == 0) goto L_0x0042
            r5.disconnect()
        L_0x0042:
            return r2
        L_0x0043:
            if (r5 == 0) goto L_0x0058
            goto L_0x0055
        L_0x0046:
            r0 = move-exception
            goto L_0x004c
        L_0x0048:
            r5 = move-exception
            r3 = r0
            r0 = r5
            r5 = r3
        L_0x004c:
            if (r5 == 0) goto L_0x0051
            r5.disconnect()
        L_0x0051:
            throw r0
        L_0x0052:
            r5 = r0
        L_0x0053:
            if (r5 == 0) goto L_0x0058
        L_0x0055:
            r5.disconnect()
        L_0x0058:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.limelightvision.Limelight3A.sendGetRequest(java.lang.String):org.json.JSONObject");
    }

    private String readResponse(HttpURLConnection httpURLConnection) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
        StringBuilder sb = new StringBuilder();
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine != null) {
                sb.append(readLine);
            } else {
                bufferedReader.close();
                return sb.toString();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:35:0x0078  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean sendPostRequest(java.lang.String r5, java.lang.String r6) {
        /*
            r4 = this;
            r0 = 0
            r1 = 0
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            r2.<init>()     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.lang.String r3 = r4.baseUrl     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.lang.StringBuilder r5 = r2.append(r5)     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.net.URL r2 = new java.net.URL     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            r2.<init>(r5)     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.net.URLConnection r5 = r2.openConnection()     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.net.HttpURLConnection r5 = (java.net.HttpURLConnection) r5     // Catch:{ Exception -> 0x007c, all -> 0x0075 }
            java.lang.String r1 = "POST"
            r5.setRequestMethod(r1)     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            r1 = 1
            r5.setDoOutput(r1)     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            java.lang.String r2 = "Content-Type"
            java.lang.String r3 = "application/json"
            r5.setRequestProperty(r2, r3)     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            r2 = 15000(0x3a98, float:2.102E-41)
            r5.setReadTimeout(r2)     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            r2 = 100
            r5.setConnectTimeout(r2)     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            if (r6 == 0) goto L_0x005c
            java.io.OutputStream r2 = r5.getOutputStream()     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            java.nio.charset.Charset r3 = java.nio.charset.StandardCharsets.UTF_8     // Catch:{ all -> 0x0050 }
            byte[] r6 = r6.getBytes(r3)     // Catch:{ all -> 0x0050 }
            int r3 = r6.length     // Catch:{ all -> 0x0050 }
            r2.write(r6, r0, r3)     // Catch:{ all -> 0x0050 }
            if (r2 == 0) goto L_0x005c
            r2.close()     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            goto L_0x005c
        L_0x0050:
            r6 = move-exception
            if (r2 == 0) goto L_0x005b
            r2.close()     // Catch:{ all -> 0x0057 }
            goto L_0x005b
        L_0x0057:
            r1 = move-exception
            r6.addSuppressed(r1)     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
        L_0x005b:
            throw r6     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
        L_0x005c:
            int r6 = r5.getResponseCode()     // Catch:{ Exception -> 0x0073, all -> 0x0070 }
            r2 = 200(0xc8, float:2.8E-43)
            if (r6 != r2) goto L_0x006a
            if (r5 == 0) goto L_0x0069
            r5.disconnect()
        L_0x0069:
            return r1
        L_0x006a:
            if (r5 == 0) goto L_0x0081
            r5.disconnect()
            goto L_0x0081
        L_0x0070:
            r6 = move-exception
            r1 = r5
            goto L_0x0076
        L_0x0073:
            r1 = r5
            goto L_0x007c
        L_0x0075:
            r6 = move-exception
        L_0x0076:
            if (r1 == 0) goto L_0x007b
            r1.disconnect()
        L_0x007b:
            throw r6
        L_0x007c:
            if (r1 == 0) goto L_0x0081
            r1.disconnect()
        L_0x0081:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.limelightvision.Limelight3A.sendPostRequest(java.lang.String, java.lang.String):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x004d  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:28:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean sendDeleteRequest(java.lang.String r5) {
        /*
            r4 = this;
            r0 = 0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            r1.<init>()     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.lang.String r2 = r4.baseUrl     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.lang.StringBuilder r5 = r1.append(r5)     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.net.URL r1 = new java.net.URL     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            r1.<init>(r5)     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.net.URLConnection r5 = r1.openConnection()     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.net.HttpURLConnection r5 = (java.net.HttpURLConnection) r5     // Catch:{ Exception -> 0x0051, all -> 0x0047 }
            java.lang.String r0 = "DELETE"
            r5.setRequestMethod(r0)     // Catch:{ Exception -> 0x0045, all -> 0x0043 }
            r0 = 15000(0x3a98, float:2.102E-41)
            r5.setReadTimeout(r0)     // Catch:{ Exception -> 0x0045, all -> 0x0043 }
            r0 = 100
            r5.setConnectTimeout(r0)     // Catch:{ Exception -> 0x0045, all -> 0x0043 }
            int r0 = r5.getResponseCode()     // Catch:{ Exception -> 0x0045, all -> 0x0043 }
            r1 = 200(0xc8, float:2.8E-43)
            if (r0 != r1) goto L_0x003d
            if (r5 == 0) goto L_0x003b
            r5.disconnect()
        L_0x003b:
            r5 = 1
            return r5
        L_0x003d:
            if (r5 == 0) goto L_0x0056
            r5.disconnect()
            goto L_0x0056
        L_0x0043:
            r0 = move-exception
            goto L_0x004b
        L_0x0045:
            r0 = r5
            goto L_0x0051
        L_0x0047:
            r5 = move-exception
            r3 = r0
            r0 = r5
            r5 = r3
        L_0x004b:
            if (r5 == 0) goto L_0x0050
            r5.disconnect()
        L_0x0050:
            throw r0
        L_0x0051:
            if (r0 == 0) goto L_0x0056
            r0.disconnect()
        L_0x0056:
            r5 = 0
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.limelightvision.Limelight3A.sendDeleteRequest(java.lang.String):boolean");
    }

    public void shutdown() {
        stop();
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.LimelightVision;
    }

    public String getDeviceName() {
        return this.name;
    }

    public String getConnectionInfo() {
        return this.serialNumber.toString();
    }

    public void close() {
        stop();
    }
}

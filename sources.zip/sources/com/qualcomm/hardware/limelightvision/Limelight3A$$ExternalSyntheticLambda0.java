package com.qualcomm.hardware.limelightvision;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Limelight3A$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Limelight3A f$0;

    public /* synthetic */ Limelight3A$$ExternalSyntheticLambda0(Limelight3A limelight3A) {
        this.f$0 = limelight3A;
    }

    public final void run() {
        this.f$0.updateLatestResult();
    }
}

package com.qualcomm.hardware.maxbotix;

import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynch;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDevice;
import com.qualcomm.robotcore.hardware.I2cWaitControl;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.util.TypeConversion;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@DeviceProperties(name = "MaxSonar I2CXL", xmlTag = "MaxSonarI2CXL")
@I2cDeviceType
public class MaxSonarI2CXL extends I2cDeviceSynchDevice<I2cDeviceSynch> {
    protected static final byte CHANGE_I2C_ADDR_UNLOCK_1 = -86;
    protected static final byte CHANGE_I2C_ADDR_UNLOCK_2 = -91;
    protected static final byte CMD_PING = 81;
    protected static final byte DEFAULT_I2C_ADDR = -32;
    protected static int DEFAULT_SONAR_PROPAGATION_DELAY_MS = 50;
    protected static final byte NUM_RANGE_BYTES = 2;
    protected double lastDistance = -1.0d;
    protected long lastPingTime;

    public MaxSonarI2CXL(I2cDeviceSynch i2cDeviceSynch) {
        super(i2cDeviceSynch, true);
        ((I2cDeviceSynch) this.deviceClient).setI2cAddress(I2cAddr.create8bit(-32));
        ((I2cDeviceSynch) this.deviceClient).engage();
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.MaxBotix;
    }

    /* access modifiers changed from: protected */
    public synchronized boolean doInitialize() {
        return true;
    }

    public String getDeviceName() {
        return "MaxSonar I2CXL";
    }

    /* access modifiers changed from: protected */
    public void ping() {
        ((I2cDeviceSynch) this.deviceClient).write8(81, I2cWaitControl.ATOMIC);
    }

    /* access modifiers changed from: protected */
    public double getRangingResult(DistanceUnit distanceUnit) {
        return distanceUnit.fromCm((double) TypeConversion.byteArrayToShort(((I2cDeviceSynch) this.deviceClient).read(2)));
    }

    public double getDistanceSync(DistanceUnit distanceUnit) {
        return getDistanceSync(DEFAULT_SONAR_PROPAGATION_DELAY_MS, distanceUnit);
    }

    public double getDistanceSync(int i, DistanceUnit distanceUnit) {
        ping();
        try {
            Thread.sleep((long) i);
            return getRangingResult(distanceUnit);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            return LynxServoController.apiPositionFirst;
        }
    }

    public double getDistanceAsync(DistanceUnit distanceUnit) {
        return getDistanceAsync(DEFAULT_SONAR_PROPAGATION_DELAY_MS, distanceUnit);
    }

    public double getDistanceAsync(int i, DistanceUnit distanceUnit) {
        if (System.currentTimeMillis() - this.lastPingTime > ((long) i)) {
            this.lastDistance = getRangingResult(distanceUnit);
            ping();
            this.lastPingTime = System.currentTimeMillis();
        }
        return this.lastDistance;
    }

    public void setI2cAddress(I2cAddr i2cAddr) {
        ((I2cDeviceSynch) this.deviceClient).setI2cAddress(i2cAddr);
    }

    public I2cAddr getI2cAddress() {
        return ((I2cDeviceSynch) this.deviceClient).getI2cAddress();
    }

    public void writeI2cAddrToSensorEEPROM(byte b) {
        ((I2cDeviceSynch) this.deviceClient).write(new byte[]{CHANGE_I2C_ADDR_UNLOCK_1, CHANGE_I2C_ADDR_UNLOCK_2, b});
    }
}

package com.qualcomm.hardware.digitalchickenlabs;

import com.qualcomm.hardware.digitalchickenlabs.OctoQuad;
import com.qualcomm.hardware.lynx.LynxI2cDeviceSynch;
import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.robotcore.util.RobotLog;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

@I2cDeviceType
@DeviceProperties(name = "OctoQuadFTC", xmlTag = "OctoQuadFTC")
public class OctoQuadImpl extends I2cDeviceSynchDevice<I2cDeviceSynchSimple> implements OctoQuad {
    private static final byte CMD_READ_PARAM = 2;
    private static final byte CMD_RESET_ENCODERS = 21;
    private static final byte CMD_RESET_EVERYTHING = 20;
    private static final byte CMD_RESET_LOCALIZER = 40;
    private static final byte CMD_SET_PARAM = 1;
    private static final byte CMD_WRITE_PARAMS_TO_FLASH = 3;
    private static final int I2C_ADDRESS = 48;
    private static final ByteOrder OCTOQUAD_ENDIAN = ByteOrder.LITTLE_ENDIAN;
    private static final byte PARAM_CHANNEL_BANK_CONFIG = 2;
    private static final byte PARAM_CHANNEL_PULSE_WIDTH_MIN_MAX = 4;
    private static final byte PARAM_CHANNEL_PULSE_WIDTH_TRACKS_WRAP = 5;
    private static final byte PARAM_CHANNEL_VEL_INTVL = 3;
    private static final byte PARAM_ENCODER_DIRECTIONS = 0;
    private static final byte PARAM_I2C_RECOVERY_MODE = 1;
    private static final byte PARAM_LOCALIZER_IMU_HEADING_SCALAR = 54;
    private static final byte PARAM_LOCALIZER_PORT_X = 55;
    private static final byte PARAM_LOCALIZER_PORT_Y = 56;
    private static final byte PARAM_LOCALIZER_TCP_OFFSET_X_MM = 52;
    private static final byte PARAM_LOCALIZER_TCP_OFFSET_Y_MM = 53;
    private static final byte PARAM_LOCALIZER_VEL_INTVL = 57;
    private static final byte PARAM_LOCALIZER_X_TICKS_PER_MM = 50;
    private static final byte PARAM_LOCALIZER_Y_TICKS_PER_MM = 51;
    private static final float SCALAR_LOCALIZER_HEADING = 2.0E-4f;
    private static final float SCALAR_LOCALIZER_HEADING_VELOCITY = 0.0016666667f;
    private static final int SUPPORTED_FW_VERSION_MAJ = 3;
    private static final int SUPPORTED_FW_VERSION_MIN = 0;
    private static final short crc16_profibus_init = -1;
    private static final short[] crc16_profibus_table = {0, 7631, 15262, 9809, 30524, 27379, 19618, 20845, -4488, -3145, -10778, -14295, -26300, -31605, -23846, -16619, -16065, -8976, -1375, -6290, -18941, -21556, -29283, -28590, 12103, 12936, 5337, 2326, 22651, 17844, 25573, 32298, -24655, -32130, -23505, -17952, -6003, -2750, -11501, -12580, 29129, 27654, 19031, 22424, 1781, 6970, 15723, 8356, 24206, 17217, 25872, 30943, 10674, 13437, 4652, 4067, -20234, -21191, -29848, -26969, -14390, -9723, -940, -7781, 8877, 16226, 6451, 1276, 21905, 18526, 28175, 29632, -13099, -12006, -2229, -5500, -17431, -23002, -32649, -25160, -7278, -419, -10228, -14909, -27474, -30367, -20688, -19713, 3562, 4133, 13940, 11195, 31446, 26393, 16712, 23687, -17124, -24365, -31102, -25779, -13792, -10257, -3650, -5007, 21348, 20139, 26874, 30005, 9304, 14743, 8134, 521, 31779, 25068, 18365, 23154, 2847, 5840, 12417, 11598, -28069, -28780, -22075, -19446, -6809, -1880, -8455, -15562, 17754, 22677, 32452, 25355, 12902, 12201, 2552, 5175, -21726, -18707, -28484, -29325, -9186, -15919, -6272, -1457, -31643, -26198, -16389, -24012, -3239, -4458, -14137, -11000, 27165, 30674, 20867, 19532, 7457, 238, 9919, 15216, -9493, -14556, -7819, -838, -21033, -20456, -27063, -29818, 13459, 10588, 3853, 4802, 17327, 24160, 30769, 26110, 7124, 1563, 8266, 15749, 27880, 28967, 22390, 19129, -2644, -6045, -12750, -11267, -32112, -24737, -18162, -23359, 26615, 31288, 23657, 16806, 4299, 3332, 11093, 13978, -30321, -27584, -19951, -20514, -333, -7300, -15059, -10014, -22840, -17657, -25258, -32615, -11788, -13253, -5526, -2139, 18608, 21887, 29486, 28385, 16268, 8771, 1042, 6621, -1978, -6775, -15400, -8681, -28806, -27979, -19228, -22229, 5694, 3057, 11680, 12399, 24834, 31949, 23196, 18259, 14713, 9398, 743, 7976, 20037, 21386, 30171, 26644, -10495, -13618, -4961, -3760, -24515, -16910, -25693, -31124};
    private static final short crc16_profibus_xor_out = -1;
    protected OctoQuad.EncoderDataBlock cachedData = new OctoQuad.EncoderDataBlock();
    protected OctoQuad.CachingMode cachingMode = OctoQuad.CachingMode.AUTO;
    private boolean isInitialized = false;
    protected boolean[] posHasBeenRead = new boolean[8];
    protected boolean[] velHasBeenRead = new boolean[8];

    public OctoQuadImpl(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z);
        this.deviceClient.setI2cAddress(I2cAddr.create7bit(48));
        super.registerArmingStateCallback(false);
    }

    /* access modifiers changed from: protected */
    public boolean doInitialize() {
        ((LynxI2cDeviceSynch) this.deviceClient).setBusSpeed(LynxI2cDeviceSynch.BusSpeed.FAST_400K);
        this.isInitialized = false;
        verifyInitialization();
        return true;
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.DigitalChickenLabs;
    }

    public String getDeviceName() {
        return "OctoQuadFTC";
    }

    enum RegisterType {
        uint8_t(1),
        int32_t(4),
        int16_t(2),
        uint16_t(2),
        float32(4);
        
        public final int length;

        private RegisterType(int i) {
            this.length = i;
        }
    }

    enum Register {
        CHIP_ID(0, RegisterType.uint8_t),
        FIRMWARE_VERSION_MAJOR(1, RegisterType.uint8_t),
        FIRMWARE_VERSION_MINOR(2, RegisterType.uint8_t),
        FIRMWARE_VERSION_ENGINEERING(3, RegisterType.uint8_t),
        COMMAND(4, RegisterType.uint8_t),
        COMMAND_DAT_0(5, RegisterType.uint8_t),
        COMMAND_DAT_1(6, RegisterType.uint8_t),
        COMMAND_DAT_2(7, RegisterType.uint8_t),
        COMMAND_DAT_3(8, RegisterType.uint8_t),
        COMMAND_DAT_4(9, RegisterType.uint8_t),
        COMMAND_DAT_5(10, RegisterType.uint8_t),
        COMMAND_DAT_6(11, RegisterType.uint8_t),
        LOCALIZER_YAW_AXIS(12, RegisterType.uint8_t),
        LOCALIZER_STATUS(13, RegisterType.uint8_t),
        LOCALIZER_VX(14, RegisterType.int16_t),
        LOCALIZER_VY(16, RegisterType.int16_t),
        LOCALIZER_VH(18, RegisterType.int16_t),
        LOCALIZER_X(20, RegisterType.int16_t),
        LOCALIZER_Y(22, RegisterType.int16_t),
        LOCALIZER_H(24, RegisterType.int16_t),
        LOCALIZER_CRC16(26, RegisterType.uint16_t),
        ENCODER_0_POSITION(28, RegisterType.int32_t),
        ENCODER_1_POSITION(32, RegisterType.int32_t),
        ENCODER_2_POSITION(36, RegisterType.int32_t),
        ENCODER_3_POSITION(40, RegisterType.int32_t),
        ENCODER_4_POSITION(44, RegisterType.int32_t),
        ENCODER_5_POSITION(48, RegisterType.int32_t),
        ENCODER_6_POSITION(52, RegisterType.int32_t),
        ENCODER_7_POSITION(56, RegisterType.int32_t),
        ENCODER_0_VELOCITY(60, RegisterType.int16_t),
        ENCODER_1_VELOCITY(62, RegisterType.int16_t),
        ENCODER_2_VELOCITY(64, RegisterType.int16_t),
        ENCODER_3_VELOCITY(66, RegisterType.int16_t),
        ENCODER_4_VELOCITY(68, RegisterType.int16_t),
        ENCODER_5_VELOCITY(70, RegisterType.int16_t),
        ENCODER_6_VELOCITY(72, RegisterType.int16_t),
        ENCODER_7_VELOCITY(74, RegisterType.int16_t),
        ENCODER_DATA_CRC16(76, RegisterType.uint16_t);
        
        public final byte addr;
        public final int length;

        private Register(int i, RegisterType registerType) {
            this.addr = (byte) i;
            this.length = registerType.length;
        }
    }

    public byte getChipId() {
        return readRegister(Register.CHIP_ID)[0];
    }

    public OctoQuad.FirmwareVersion getFirmwareVersion() {
        byte[] readContiguousRegisters = readContiguousRegisters(Register.FIRMWARE_VERSION_MAJOR, Register.FIRMWARE_VERSION_ENGINEERING);
        return new OctoQuad.FirmwareVersion(readContiguousRegisters[0] & 255, readContiguousRegisters[1] & 255, readContiguousRegisters[2] & 255);
    }

    public String getFirmwareVersionString() {
        return getFirmwareVersion().toString();
    }

    public int readSinglePosition(int i) {
        return readSinglePosition_Caching(i);
    }

    public void resetSinglePosition(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{CMD_RESET_ENCODERS, (byte) (1 << i)});
        if (this.cachingMode == OctoQuad.CachingMode.AUTO) {
            refreshCache();
        }
    }

    public void resetAllPositions() {
        verifyInitialization();
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{CMD_RESET_ENCODERS, -1});
        if (this.cachingMode == OctoQuad.CachingMode.AUTO) {
            refreshCache();
        }
    }

    public void resetMultiplePositions(boolean[] zArr) {
        verifyInitialization();
        if (zArr.length == 8) {
            byte b = 0;
            for (int i = 0; i <= 7; i++) {
                b = (byte) (b | (zArr[i] ? (byte) (1 << i) : 0));
            }
            writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{CMD_RESET_ENCODERS, b});
            if (this.cachingMode == OctoQuad.CachingMode.AUTO) {
                refreshCache();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("resets.length != 8");
    }

    public void resetMultiplePositions(int... iArr) {
        verifyInitialization();
        for (int throwIfRangeIsInvalid : iArr) {
            Range.throwIfRangeIsInvalid(throwIfRangeIsInvalid, 0, 7);
        }
        byte b = 0;
        for (int i : iArr) {
            b = (byte) (b | ((byte) (1 << i)));
        }
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{CMD_RESET_ENCODERS, b});
        if (this.cachingMode == OctoQuad.CachingMode.AUTO) {
            refreshCache();
        }
    }

    public void setSingleEncoderDirection(int i, OctoQuad.EncoderDirection encoderDirection) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{2, 0});
        byte b = readRegister(Register.COMMAND_DAT_0)[0];
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, 0, (byte) (encoderDirection == OctoQuad.EncoderDirection.REVERSE ? ((byte) (1 << i)) | b : ((byte) (~(1 << i))) & b)});
    }

    public OctoQuad.EncoderDirection getSingleEncoderDirection(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{2, 0});
        return ((1 << i) & readRegister(Register.COMMAND_DAT_0)[0]) != 0 ? OctoQuad.EncoderDirection.REVERSE : OctoQuad.EncoderDirection.FORWARD;
    }

    public void setAllEncoderDirections(boolean[] zArr) {
        verifyInitialization();
        if (zArr.length == 8) {
            byte b = 0;
            for (int i = 0; i <= 7; i++) {
                if (zArr[i]) {
                    b = (byte) (b | ((byte) (1 << i)));
                }
            }
            writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, 0, b});
            return;
        }
        throw new IllegalArgumentException("reverse.length != 8");
    }

    public short readSingleVelocity(int i) {
        return readSingleVelocity_Caching(i);
    }

    private void unpackAllEncoderData(ByteBuffer byteBuffer, OctoQuad.EncoderDataBlock encoderDataBlock) {
        byteBuffer.mark();
        byte[] bArr = new byte[((RegisterType.int32_t.length + RegisterType.int16_t.length) * 8)];
        byteBuffer.get(bArr);
        byteBuffer.reset();
        boolean z = false;
        for (int i = 0; i < 8; i++) {
            encoderDataBlock.positions[i] = byteBuffer.getInt();
        }
        for (int i2 = 0; i2 < 8; i2++) {
            encoderDataBlock.velocities[i2] = byteBuffer.getShort();
        }
        short s = byteBuffer.getShort();
        short calc_crc16_profibus = calc_crc16_profibus(bArr);
        if (calc_crc16_profibus == s) {
            z = true;
        }
        encoderDataBlock.crcOk = z;
        if (!encoderDataBlock.crcOk) {
            RobotLog.ee("OctoQuadImpl", String.format("Encoder data CRC error! Expect = 0x%x Actual = 0x%x", new Object[]{Short.valueOf(calc_crc16_profibus), Short.valueOf(s)}));
        }
    }

    public void readAllEncoderData(OctoQuad.EncoderDataBlock encoderDataBlock) {
        verifyInitialization();
        if (encoderDataBlock.positions.length != 8) {
            throw new IllegalArgumentException("out.counts.length != 8");
        } else if (encoderDataBlock.velocities.length == 8) {
            ByteBuffer wrap = ByteBuffer.wrap(readContiguousRegisters(Register.ENCODER_0_POSITION, Register.ENCODER_DATA_CRC16));
            wrap.order(OCTOQUAD_ENDIAN);
            unpackAllEncoderData(wrap, encoderDataBlock);
            if (encoderDataBlock.crcOk) {
                encoderDataBlock.copyTo(this.cachedData);
                Arrays.fill(this.posHasBeenRead, false);
                Arrays.fill(this.velHasBeenRead, false);
            }
        } else {
            throw new IllegalArgumentException("out.velocities.length != 8");
        }
    }

    public OctoQuad.EncoderDataBlock readAllEncoderData() {
        OctoQuad.EncoderDataBlock encoderDataBlock = new OctoQuad.EncoderDataBlock();
        readAllEncoderData(encoderDataBlock);
        return encoderDataBlock;
    }

    public void setSingleVelocitySampleInterval(int i, int i2) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        Range.throwIfRangeIsInvalid(i2, 1, 255);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_2, new byte[]{1, 3, (byte) i, (byte) i2});
    }

    public int getSingleVelocitySampleInterval(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{2, 3, (byte) i});
        return readRegister(Register.COMMAND_DAT_0)[0] & 255;
    }

    public void setAllVelocitySampleIntervals(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 1, 255);
        for (int i2 = 0; i2 <= 7; i2++) {
            writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_2, new byte[]{1, 3, (byte) i2, (byte) i});
        }
    }

    public void setSingleChannelPulseWidthParams(int i, int i2, int i3) {
        setSingleChannelPulseWidthParams(i, new OctoQuad.ChannelPulseWidthParams(i2, i3));
    }

    public void setSingleChannelPulseWidthParams(int i, OctoQuad.ChannelPulseWidthParams channelPulseWidthParams) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        Range.throwIfRangeIsInvalid(channelPulseWidthParams.min_length_us, 0, 65535);
        Range.throwIfRangeIsInvalid(channelPulseWidthParams.max_length_us, 0, 65535);
        if (channelPulseWidthParams.max_length_us > channelPulseWidthParams.min_length_us) {
            ByteBuffer allocate = ByteBuffer.allocate(7);
            allocate.order(OCTOQUAD_ENDIAN);
            allocate.put((byte) 1);
            allocate.put((byte) 4);
            allocate.put((byte) i);
            allocate.putShort((short) channelPulseWidthParams.min_length_us);
            allocate.putShort((short) channelPulseWidthParams.max_length_us);
            writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_5, allocate.array());
            return;
        }
        throw new RuntimeException("params.max_length_us <= params.min_length_us");
    }

    public OctoQuad.ChannelPulseWidthParams getSingleChannelPulseWidthParams(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{2, 4, (byte) i});
        ByteBuffer wrap = ByteBuffer.wrap(readContiguousRegisters(Register.COMMAND_DAT_0, Register.COMMAND_DAT_3));
        wrap.order(OCTOQUAD_ENDIAN);
        OctoQuad.ChannelPulseWidthParams channelPulseWidthParams = new OctoQuad.ChannelPulseWidthParams();
        channelPulseWidthParams.min_length_us = wrap.getShort() & 65535;
        channelPulseWidthParams.max_length_us = wrap.getShort() & 65535;
        return channelPulseWidthParams;
    }

    public void setSingleChannelPulseWidthTracksWrap(int i, boolean z) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{2, PARAM_CHANNEL_PULSE_WIDTH_TRACKS_WRAP});
        byte b = readRegister(Register.COMMAND_DAT_0)[0];
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, PARAM_CHANNEL_PULSE_WIDTH_TRACKS_WRAP, (byte) (z ? ((byte) (1 << i)) | b : ((byte) (~(1 << i))) & b)});
    }

    public boolean getSingleChannelPulseWidthTracksWrap(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{2, PARAM_CHANNEL_PULSE_WIDTH_TRACKS_WRAP});
        if (((1 << i) & readRegister(Register.COMMAND_DAT_0)[0]) != 0) {
            return true;
        }
        return false;
    }

    public void setAllChannelsPulseWidthTracksWrap(boolean[] zArr) {
        verifyInitialization();
        if (zArr.length == 8) {
            byte b = 0;
            for (int i = 0; i <= 7; i++) {
                if (zArr[i]) {
                    b = (byte) (b | ((byte) (1 << i)));
                }
            }
            writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, PARAM_CHANNEL_PULSE_WIDTH_TRACKS_WRAP, b});
            return;
        }
        throw new IllegalArgumentException("trackWrap.length != 8");
    }

    public void setLocalizerCountsPerMM_X(float f) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid((double) f, (double) LynxServoController.apiPositionFirst, 3.4028234663852886E38d);
        ByteBuffer allocate = ByteBuffer.allocate(6);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.put((byte) 1);
        allocate.put(PARAM_LOCALIZER_X_TICKS_PER_MM);
        allocate.putFloat(f);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_4, allocate.array());
    }

    public void setLocalizerCountsPerMM_Y(float f) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid((double) f, (double) LynxServoController.apiPositionFirst, 3.4028234663852886E38d);
        ByteBuffer allocate = ByteBuffer.allocate(6);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.put((byte) 1);
        allocate.put((byte) 51);
        allocate.putFloat(f);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_4, allocate.array());
    }

    public void setLocalizerTcpOffsetMM_X(float f) {
        verifyInitialization();
        ByteBuffer allocate = ByteBuffer.allocate(6);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.put((byte) 1);
        allocate.put(PARAM_LOCALIZER_TCP_OFFSET_X_MM);
        allocate.putFloat(f);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_4, allocate.array());
    }

    public void setLocalizerTcpOffsetMM_Y(float f) {
        verifyInitialization();
        ByteBuffer allocate = ByteBuffer.allocate(6);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.put((byte) 1);
        allocate.put(PARAM_LOCALIZER_TCP_OFFSET_Y_MM);
        allocate.putFloat(f);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_4, allocate.array());
    }

    public void setLocalizerImuHeadingScalar(float f) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid((double) f, (double) LynxServoController.apiPositionFirst, 3.4028234663852886E38d);
        ByteBuffer allocate = ByteBuffer.allocate(6);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.put((byte) 1);
        allocate.put(PARAM_LOCALIZER_IMU_HEADING_SCALAR);
        allocate.putFloat(f);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_4, allocate.array());
    }

    public void setLocalizerPortX(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, PARAM_LOCALIZER_PORT_X, (byte) i});
    }

    public void setLocalizerPortY(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 0, 7);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, PARAM_LOCALIZER_PORT_Y, (byte) i});
    }

    public void setLocalizerVelocityIntervalMS(int i) {
        verifyInitialization();
        Range.throwIfRangeIsInvalid(i, 1, 255);
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, PARAM_LOCALIZER_VEL_INTVL, (byte) i});
    }

    public OctoQuad.LocalizerStatus getLocalizerStatus() {
        verifyInitialization();
        byte b = readRegister(Register.LOCALIZER_STATUS)[0] & 255;
        if (b < OctoQuad.LocalizerStatus.values().length) {
            return OctoQuad.LocalizerStatus.values()[b];
        }
        return OctoQuad.LocalizerStatus.INVALID;
    }

    public OctoQuad.LocalizerYawAxis getLocalizerHeadingAxisChoice() {
        verifyInitialization();
        byte b = readRegister(Register.LOCALIZER_YAW_AXIS)[0] & 255;
        if (b < OctoQuad.LocalizerYawAxis.values().length) {
            return OctoQuad.LocalizerYawAxis.values()[b];
        }
        return OctoQuad.LocalizerYawAxis.UNDECIDED;
    }

    public void resetLocalizerAndCalibrateIMU() {
        verifyInitialization();
        writeRegister(Register.COMMAND, new byte[]{CMD_RESET_LOCALIZER});
    }

    private void unpackLocalizerData(ByteBuffer byteBuffer, OctoQuad.LocalizerDataBlock localizerDataBlock) {
        byteBuffer.mark();
        int i = (RegisterType.uint16_t.length * 6) + RegisterType.uint8_t.length;
        byte[] bArr = new byte[i];
        byteBuffer.get(bArr);
        byteBuffer.reset();
        byte b = byteBuffer.get() & 255;
        if (b < OctoQuad.LocalizerStatus.values().length) {
            localizerDataBlock.localizerStatus = OctoQuad.LocalizerStatus.values()[b];
        } else {
            localizerDataBlock.localizerStatus = OctoQuad.LocalizerStatus.INVALID;
        }
        localizerDataBlock.velX_mmS = byteBuffer.getShort();
        localizerDataBlock.velY_mmS = byteBuffer.getShort();
        localizerDataBlock.velHeading_radS = ((float) byteBuffer.getShort()) * SCALAR_LOCALIZER_HEADING_VELOCITY;
        localizerDataBlock.posX_mm = byteBuffer.getShort();
        localizerDataBlock.posY_mm = byteBuffer.getShort();
        localizerDataBlock.heading_rad = ((float) byteBuffer.getShort()) * SCALAR_LOCALIZER_HEADING;
        short s = byteBuffer.getShort();
        short calc_crc16_profibus = calc_crc16_profibus(bArr);
        localizerDataBlock.crcOk = calc_crc16_profibus == s;
        if (!localizerDataBlock.crcOk) {
            RobotLog.ee("OctoQuadImpl", String.format("Localizer data CRC error! Expect = 0x%x Actual = 0x%x", new Object[]{Short.valueOf(calc_crc16_profibus), Short.valueOf(s)}));
            StringBuilder sb = new StringBuilder();
            for (int i2 = 0; i2 < i; i2++) {
                sb.append(String.format(" 0x%x", new Object[]{Byte.valueOf(bArr[i2])}));
            }
            sb.append("\r\n");
            System.err.print(sb);
        }
    }

    public void readLocalizerData(OctoQuad.LocalizerDataBlock localizerDataBlock) {
        verifyInitialization();
        ByteBuffer wrap = ByteBuffer.wrap(readContiguousRegisters(Register.LOCALIZER_STATUS, Register.LOCALIZER_CRC16));
        wrap.order(OCTOQUAD_ENDIAN);
        unpackLocalizerData(wrap, localizerDataBlock);
    }

    public OctoQuad.LocalizerDataBlock readLocalizerData() {
        OctoQuad.LocalizerDataBlock localizerDataBlock = new OctoQuad.LocalizerDataBlock();
        readLocalizerData(localizerDataBlock);
        return localizerDataBlock;
    }

    public void readLocalizerDataAndAllEncoderData(OctoQuad.LocalizerDataBlock localizerDataBlock, OctoQuad.EncoderDataBlock encoderDataBlock) {
        verifyInitialization();
        ByteBuffer wrap = ByteBuffer.wrap(readContiguousRegisters(Register.LOCALIZER_STATUS, Register.ENCODER_DATA_CRC16));
        wrap.order(OCTOQUAD_ENDIAN);
        unpackLocalizerData(wrap, localizerDataBlock);
        unpackAllEncoderData(wrap, encoderDataBlock);
    }

    public void setAllLocalizerParameters(int i, int i2, float f, float f2, float f3, float f4, float f5, int i3) {
        setLocalizerPortX(i);
        setLocalizerPortY(i2);
        setLocalizerCountsPerMM_X(f);
        setLocalizerCountsPerMM_Y(f2);
        setLocalizerTcpOffsetMM_X(f3);
        setLocalizerTcpOffsetMM_Y(f4);
        setLocalizerImuHeadingScalar(f5);
        setLocalizerVelocityIntervalMS(i3);
    }

    public void setLocalizerPose(int i, int i2, float f) {
        verifyInitialization();
        ByteBuffer allocate = ByteBuffer.allocate(6);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.putShort((short) i);
        allocate.putShort((short) i2);
        allocate.putShort((short) ((int) (f / SCALAR_LOCALIZER_HEADING)));
        writeContiguousRegisters(Register.LOCALIZER_X, Register.LOCALIZER_H, allocate.array());
    }

    public void setLocalizerHeading(float f) {
        verifyInitialization();
        ByteBuffer allocate = ByteBuffer.allocate(2);
        allocate.order(OCTOQUAD_ENDIAN);
        allocate.putShort((short) ((int) (f / SCALAR_LOCALIZER_HEADING)));
        writeRegister(Register.LOCALIZER_H, allocate.array());
    }

    public void resetEverything() {
        verifyInitialization();
        writeRegister(Register.COMMAND, new byte[]{CMD_RESET_EVERYTHING});
    }

    public void setChannelBankConfig(OctoQuad.ChannelBankConfig channelBankConfig) {
        verifyInitialization();
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, 2, channelBankConfig.bVal});
    }

    public OctoQuad.ChannelBankConfig getChannelBankConfig() {
        verifyInitialization();
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{2, 2});
        byte b = readRegister(Register.COMMAND_DAT_0)[0];
        for (OctoQuad.ChannelBankConfig channelBankConfig : OctoQuad.ChannelBankConfig.values()) {
            if (channelBankConfig.bVal == b) {
                return channelBankConfig;
            }
        }
        return OctoQuad.ChannelBankConfig.ALL_QUADRATURE;
    }

    public void setI2cRecoveryMode(OctoQuad.I2cRecoveryMode i2cRecoveryMode) {
        verifyInitialization();
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_1, new byte[]{1, 1, i2cRecoveryMode.bVal});
    }

    public OctoQuad.I2cRecoveryMode getI2cRecoveryMode() {
        verifyInitialization();
        writeContiguousRegisters(Register.COMMAND, Register.COMMAND_DAT_0, new byte[]{2, 1});
        byte b = readRegister(Register.COMMAND_DAT_0)[0];
        for (OctoQuad.I2cRecoveryMode i2cRecoveryMode : OctoQuad.I2cRecoveryMode.values()) {
            if (i2cRecoveryMode.bVal == b) {
                return i2cRecoveryMode;
            }
        }
        return OctoQuad.I2cRecoveryMode.NONE;
    }

    public void saveParametersToFlash() {
        verifyInitialization();
        writeRegister(Register.COMMAND, new byte[]{3});
        try {
            Thread.sleep(100);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    public void setCachingMode(OctoQuad.CachingMode cachingMode2) {
        this.cachingMode = cachingMode2;
    }

    public void refreshCache() {
        readAllEncoderData(this.cachedData);
        Arrays.fill(this.posHasBeenRead, false);
        Arrays.fill(this.velHasBeenRead, false);
    }

    public int readSinglePosition_Caching(int i) {
        if (this.cachingMode == OctoQuad.CachingMode.AUTO && this.posHasBeenRead[i]) {
            refreshCache();
        }
        this.posHasBeenRead[i] = true;
        return this.cachedData.positions[i];
    }

    public short readSingleVelocity_Caching(int i) {
        if (this.cachingMode == OctoQuad.CachingMode.AUTO && this.velHasBeenRead[i]) {
            refreshCache();
        }
        this.velHasBeenRead[i] = true;
        return this.cachedData.velocities[i];
    }

    private void verifyInitialization() {
        if (!this.isInitialized) {
            byte chipId = getChipId();
            if (chipId != 81) {
                RobotLog.addGlobalWarningMessage("OctoQuad does not report correct CHIP_ID value; (got 0x%X; expected 0x%X) this likely indicates I2C comms are not working", Byte.valueOf(chipId), Byte.valueOf(OctoQuad.OCTOQUAD_CHIP_ID));
            }
            OctoQuad.FirmwareVersion firmwareVersion = getFirmwareVersion();
            if (firmwareVersion.maj != 3) {
                RobotLog.addGlobalWarningMessage("OctoQuad is running a different major firmware version than this driver was built for (current=%d; expected=%d) IT IS HIGHLY LIKELY THAT NOTHING WILL WORK! You should flash the firmware to a compatible version (Refer to the \"Field-Upgradable Firmware\" section in the OctoQuad datasheet).", Integer.valueOf(firmwareVersion.maj), 3);
            } else if (firmwareVersion.min < 0) {
                RobotLog.addGlobalWarningMessage("OctoQuad is running an older minor firmware revision than this driver was built for; certain features may not work (current=%d; expected=%d). You should update the firmware on your OctoQuad (Refer to Section 6 in the OctoQuad datasheet).", Integer.valueOf(firmwareVersion.min), 0);
            } else if (firmwareVersion.min > 0) {
                RobotLog.addGlobalWarningMessage("OctoQuad is running a newer minor firmware revision than this driver was built for; (current=%d; expected=%d). You will not be able to access new features in the updated firmware without an updated I2C driver.", Integer.valueOf(firmwareVersion.min), 0);
            }
            this.isInitialized = true;
        }
    }

    private byte[] readRegister(Register register) {
        return this.deviceClient.read(register.addr, register.length);
    }

    private byte[] readContiguousRegisters(Register register, Register register2) {
        byte b = register.addr;
        return this.deviceClient.read(b, (register2.addr + register2.length) - b);
    }

    private void writeRegister(Register register, byte[] bArr) {
        if (register.length == bArr.length) {
            this.deviceClient.write((int) register.addr, bArr);
            return;
        }
        throw new IllegalArgumentException("reg.length != bytes.length");
    }

    private void writeContiguousRegisters(Register register, Register register2, byte[] bArr) {
        byte b = register.addr;
        if ((register2.addr + register2.length) - b == bArr.length) {
            this.deviceClient.write((int) b, bArr);
            return;
        }
        throw new IllegalArgumentException("bytesToWrite != dat.length");
    }

    private static short calc_crc16_profibus(byte[] bArr, int i) {
        short s = -1;
        for (int i2 = 0; i2 < i; i2++) {
            s = (short) (crc16_profibus_table[((s >> 8) ^ bArr[i2 & 255]) & 255] ^ (s << 8));
        }
        return (short) (~s);
    }

    private static short calc_crc16_profibus(byte[] bArr) {
        return calc_crc16_profibus(bArr, bArr.length);
    }
}

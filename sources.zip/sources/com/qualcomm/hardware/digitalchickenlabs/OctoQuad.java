package com.qualcomm.hardware.digitalchickenlabs;

import com.qualcomm.robotcore.hardware.HardwareDevice;
import java.util.Locale;

public interface OctoQuad extends HardwareDevice {
    public static final int ENCODER_FIRST = 0;
    public static final int ENCODER_LAST = 7;
    public static final int MAX_PULSE_WIDTH_US = 65535;
    public static final int MAX_VELOCITY_MEASUREMENT_INTERVAL_MS = 255;
    public static final int MIN_PULSE_WIDTH_US = 0;
    public static final int MIN_VELOCITY_MEASUREMENT_INTERVAL_MS = 1;
    public static final int NUM_ENCODERS = 8;
    public static final byte OCTOQUAD_CHIP_ID = 81;
    public static final int SUPPORTED_FW_VERSION_MAJ = 3;

    public enum CachingMode {
        MANUAL,
        AUTO
    }

    public enum EncoderDirection {
        FORWARD,
        REVERSE
    }

    ChannelBankConfig getChannelBankConfig();

    byte getChipId();

    FirmwareVersion getFirmwareVersion();

    String getFirmwareVersionString();

    I2cRecoveryMode getI2cRecoveryMode();

    LocalizerYawAxis getLocalizerHeadingAxisChoice();

    LocalizerStatus getLocalizerStatus();

    ChannelPulseWidthParams getSingleChannelPulseWidthParams(int i);

    boolean getSingleChannelPulseWidthTracksWrap(int i);

    EncoderDirection getSingleEncoderDirection(int i);

    int getSingleVelocitySampleInterval(int i);

    EncoderDataBlock readAllEncoderData();

    void readAllEncoderData(EncoderDataBlock encoderDataBlock);

    LocalizerDataBlock readLocalizerData();

    void readLocalizerData(LocalizerDataBlock localizerDataBlock);

    void readLocalizerDataAndAllEncoderData(LocalizerDataBlock localizerDataBlock, EncoderDataBlock encoderDataBlock);

    @Deprecated
    int readSinglePosition(int i);

    int readSinglePosition_Caching(int i);

    @Deprecated
    short readSingleVelocity(int i);

    short readSingleVelocity_Caching(int i);

    void refreshCache();

    void resetAllPositions();

    void resetEverything();

    void resetLocalizerAndCalibrateIMU();

    void resetMultiplePositions(int... iArr);

    void resetMultiplePositions(boolean[] zArr);

    void resetSinglePosition(int i);

    void saveParametersToFlash();

    void setAllChannelsPulseWidthTracksWrap(boolean[] zArr);

    void setAllEncoderDirections(boolean[] zArr);

    void setAllLocalizerParameters(int i, int i2, float f, float f2, float f3, float f4, float f5, int i3);

    void setAllVelocitySampleIntervals(int i);

    void setCachingMode(CachingMode cachingMode);

    void setChannelBankConfig(ChannelBankConfig channelBankConfig);

    void setI2cRecoveryMode(I2cRecoveryMode i2cRecoveryMode);

    void setLocalizerCountsPerMM_X(float f);

    void setLocalizerCountsPerMM_Y(float f);

    void setLocalizerHeading(float f);

    void setLocalizerImuHeadingScalar(float f);

    void setLocalizerPortX(int i);

    void setLocalizerPortY(int i);

    void setLocalizerPose(int i, int i2, float f);

    void setLocalizerTcpOffsetMM_X(float f);

    void setLocalizerTcpOffsetMM_Y(float f);

    void setLocalizerVelocityIntervalMS(int i);

    void setSingleChannelPulseWidthParams(int i, int i2, int i3);

    void setSingleChannelPulseWidthParams(int i, ChannelPulseWidthParams channelPulseWidthParams);

    void setSingleChannelPulseWidthTracksWrap(int i, boolean z);

    void setSingleEncoderDirection(int i, EncoderDirection encoderDirection);

    void setSingleVelocitySampleInterval(int i, int i2);

    public static class FirmwareVersion {
        public final int eng;
        public final int maj;
        public final int min;

        public FirmwareVersion(int i, int i2, int i3) {
            this.maj = i;
            this.min = i2;
            this.eng = i3;
        }

        public String toString() {
            return String.format(Locale.US, "%d.%d.%d", new Object[]{Integer.valueOf(this.maj), Integer.valueOf(this.min), Integer.valueOf(this.eng)});
        }
    }

    public enum ChannelBankConfig {
        ALL_QUADRATURE(0),
        ALL_PULSE_WIDTH(1),
        BANK1_QUADRATURE_BANK2_PULSE_WIDTH(2);
        
        final byte bVal;

        private ChannelBankConfig(int i) {
            this.bVal = (byte) i;
        }
    }

    public static class EncoderDataBlock {
        public boolean crcOk;
        public int[] positions = new int[8];
        public short[] velocities = new short[8];

        public boolean isDataValid() {
            return this.crcOk;
        }

        public void copyTo(EncoderDataBlock encoderDataBlock) {
            System.arraycopy(this.positions, 0, encoderDataBlock.positions, 0, 8);
            System.arraycopy(this.velocities, 0, encoderDataBlock.velocities, 0, 8);
            encoderDataBlock.crcOk = this.crcOk;
        }
    }

    public static class ChannelPulseWidthParams {
        public int max_length_us;
        public int min_length_us;

        public ChannelPulseWidthParams() {
        }

        public ChannelPulseWidthParams(int i, int i2) {
            this.min_length_us = i;
            this.max_length_us = i2;
        }
    }

    public static class LocalizerDataBlock {
        public boolean crcOk;
        public float heading_rad;
        public LocalizerStatus localizerStatus;
        public short posX_mm;
        public short posY_mm;
        public float velHeading_radS;
        public short velX_mmS;
        public short velY_mmS;

        public boolean isDataValid() {
            return this.crcOk && this.localizerStatus == LocalizerStatus.RUNNING;
        }
    }

    public enum LocalizerStatus {
        INVALID(0),
        NOT_INITIALIZED(1),
        WARMING_UP_IMU(2),
        CALIBRATING_IMU(3),
        RUNNING(4),
        FAULT_NO_IMU(5);
        
        final int code;

        private LocalizerStatus(int i) {
            this.code = i;
        }
    }

    public enum LocalizerYawAxis {
        UNDECIDED(0),
        X(1),
        X_INV(2),
        Y(3),
        Y_INV(4),
        Z(5),
        Z_INV(6);
        
        final int code;

        private LocalizerYawAxis(int i) {
            this.code = i;
        }
    }

    public enum I2cRecoveryMode {
        NONE(0),
        MODE_1_PERIPH_RST_ON_FRAME_ERR(1),
        MODE_2_M1_PLUS_SCL_IDLE_ONESHOT_TGL(2);
        
        final byte bVal;

        private I2cRecoveryMode(int i) {
            this.bVal = (byte) i;
        }
    }
}

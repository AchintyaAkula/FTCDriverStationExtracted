package com.qualcomm.hardware.lynx;

import com.qualcomm.robotcore.hardware.usb.RobotUsbDevice;
import com.qualcomm.robotcore.hardware.usb.RobotUsbManager;
import com.qualcomm.robotcore.util.SerialNumber;
import org.firstinspires.ftc.robotcore.internal.hardware.usb.ArmableUsbDevice;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxUsbDeviceImpl$$ExternalSyntheticLambda5 implements ArmableUsbDevice.OpenRobotUsbDevice {
    public final /* synthetic */ RobotUsbManager f$0;
    public final /* synthetic */ SerialNumber f$1;

    public /* synthetic */ LynxUsbDeviceImpl$$ExternalSyntheticLambda5(RobotUsbManager robotUsbManager, SerialNumber serialNumber) {
        this.f$0 = robotUsbManager;
        this.f$1 = serialNumber;
    }

    public final RobotUsbDevice open() {
        return LynxUsbDeviceImpl.lambda$createUsbOpener$0(this.f$0, this.f$1);
    }
}

package com.qualcomm.hardware.lynx;

import com.qualcomm.robotcore.hardware.LynxModuleMeta;
import java.util.function.Predicate;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxUsbDeviceImpl$$ExternalSyntheticLambda0 implements Predicate {
    public final boolean test(Object obj) {
        return ((LynxModuleMeta) obj).isParent();
    }
}

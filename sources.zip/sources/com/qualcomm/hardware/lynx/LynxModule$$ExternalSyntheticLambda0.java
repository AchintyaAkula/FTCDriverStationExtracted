package com.qualcomm.hardware.lynx;

import com.qualcomm.hardware.HardwareManualControlOpMode;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxModule$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ LynxModule f$0;
    public final /* synthetic */ HardwareManualControlOpMode f$1;
    public final /* synthetic */ int f$2;
    public final /* synthetic */ int f$3;

    public /* synthetic */ LynxModule$$ExternalSyntheticLambda0(LynxModule lynxModule, HardwareManualControlOpMode hardwareManualControlOpMode, int i, int i2) {
        this.f$0 = lynxModule;
        this.f$1 = hardwareManualControlOpMode;
        this.f$2 = i;
        this.f$3 = i2;
    }

    public final void run() {
        this.f$0.m24lambda$sendGetModuleStatusAndProcessResponse$0$comqualcommhardwarelynxLynxModule(this.f$1, this.f$2, this.f$3);
    }
}

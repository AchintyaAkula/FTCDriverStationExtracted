package com.qualcomm.hardware.lynx;

import android.graphics.Color;
import androidx.core.view.ViewCompat;
import com.qualcomm.hardware.HardwareManualControlOpMode;
import com.qualcomm.hardware.R;
import com.qualcomm.hardware.bosch.BHI260IMU;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055Util;
import com.qualcomm.hardware.lynx.commands.LynxCommand;
import com.qualcomm.hardware.lynx.commands.LynxDatagram;
import com.qualcomm.hardware.lynx.commands.LynxInterface;
import com.qualcomm.hardware.lynx.commands.LynxMessage;
import com.qualcomm.hardware.lynx.commands.LynxRespondable;
import com.qualcomm.hardware.lynx.commands.LynxResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxDekaInterfaceCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxFirmwareVersionManager;
import com.qualcomm.hardware.lynx.commands.core.LynxFtdiResetControlCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetADCCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetADCResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetBulkInputDataCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetBulkInputDataResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxPhoneChargeControlCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxPhoneChargeQueryCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxPhoneChargeQueryResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxReadVersionStringCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxReadVersionStringResponse;
import com.qualcomm.hardware.lynx.commands.standard.LynxAck;
import com.qualcomm.hardware.lynx.commands.standard.LynxDiscoveryCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxFailSafeCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxGetModuleLEDColorCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxGetModuleStatusCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxKeepAliveCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxNack;
import com.qualcomm.hardware.lynx.commands.standard.LynxQueryInterfaceCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxSetDebugLogLevelCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxSetModuleLEDColorCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxSetModuleLEDPatternCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxSetNewModuleAddressCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxStandardCommand;
import com.qualcomm.robotcore.eventloop.opmode.OpModeManagerImpl;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.Blinker;
import com.qualcomm.robotcore.hardware.EmbeddedControlHubModule;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.HardwareDeviceHealth;
import com.qualcomm.robotcore.hardware.LynxModuleImuType;
import com.qualcomm.robotcore.hardware.RobotConfigNameable;
import com.qualcomm.robotcore.hardware.VisuallyIdentifiableHardwareDevice;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.hardware.usb.RobotArmingStateNotifier;
import com.qualcomm.robotcore.util.ClassUtil;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import com.qualcomm.robotcore.util.ThreadPool;
import com.qualcomm.robotcore.util.TypeConversion;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.firstinspires.ftc.robotcore.external.function.Consumer;
import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.robotcore.external.navigation.TempUnit;
import org.firstinspires.ftc.robotcore.external.navigation.VoltageUnit;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.Assert;
import org.firstinspires.ftc.robotcore.internal.system.Misc;
import org.firstinspires.ftc.robotcore.internal.usb.LynxModuleSerialNumber;
import org.firstinspires.inspection.InspectionState;
import org.opencv.imgproc.Imgproc;

public class LynxModule extends LynxCommExceptionHandler implements LynxModuleIntf, RobotArmingStateNotifier, RobotArmingStateNotifier.Callback, Blinker, VisuallyIdentifiableHardwareDevice {
    public static final String TAG = "LynxModule";
    public static BlinkerPolicy blinkerPolicy = new CountModuleAddressBlinkerPolicy();
    protected static final byte moduleStatusPersistentBits = 28;
    protected static final int msInitialContact = 500;
    protected static final int msKeepAliveTimeout = 2500;
    protected static Map<Class<? extends LynxCommand>, MessageClassAndCtor> responseClasses = new HashMap();
    protected static Map<Integer, MessageClassAndCtor> standardMessages = new HashMap();
    protected final Object addrAndSerialLock;
    protected boolean attentionRequiredPreviously;
    protected Map<String, List<LynxDekaInterfaceCommand<?>>> bulkCachingHistory;
    protected final Object bulkCachingLock;
    protected BulkCachingMode bulkCachingMode;
    protected final ConcurrentHashMap<Integer, MessageClassAndCtor> commandClasses;
    protected List<LynxController> controllers;
    protected ArrayList<Blinker.Step> currentSteps;
    protected final Object engagementLock = this;
    protected ScheduledExecutorService executor;
    protected boolean ftdiResetWatchdogActive;
    protected boolean ftdiResetWatchdogActiveWhenEngaged;
    protected final Object i2cLock;
    protected final ConcurrentHashMap<String, LynxInterface> interfacesQueried;
    protected boolean isEngaged;
    protected volatile boolean isNotResponding = false;
    protected volatile boolean isOpen;
    protected boolean isParent;
    protected volatile boolean isSystemSynthetic;
    protected volatile boolean isUserModule;
    protected boolean isVisuallyIdentifying;
    protected BulkData lastBulkData;
    protected LynxUsbDevice lynxUsbDevice;
    protected int moduleAddress;
    protected SerialNumber moduleSerialNumber;
    protected Future<?> moduleStatusFuture;
    protected final Object moduleStatusLock;
    protected AtomicInteger nextMessageNumber;
    protected Future<?> pingFuture;
    protected final Object pingFutureLock;
    protected int previousModuleStatus;
    protected Deque<ArrayList<Blinker.Step>> previousSteps;
    protected final Object startStopLock;
    protected final Set<Class<? extends LynxCommand>> supportedCommands;
    protected int systemOperationCounter = 0;
    protected final ConcurrentHashMap<Integer, LynxRespondable> unfinishedCommands;

    public interface BlinkerPolicy {
        List<Blinker.Step> getIdlePattern(LynxModule lynxModule);

        List<Blinker.Step> getVisuallyIdentifyPattern(LynxModule lynxModule);
    }

    public enum BulkCachingMode {
        OFF,
        MANUAL,
        AUTO
    }

    public int getBlinkerPatternMaxLength() {
        return 16;
    }

    /* access modifiers changed from: protected */
    public int getMsModulePingInterval() {
        return 1950;
    }

    public int getVersion() {
        return 1;
    }

    /* access modifiers changed from: protected */
    public String getTag() {
        return TAG;
    }

    static {
        addStandardMessage(LynxAck.class);
        addStandardMessage(LynxNack.class);
        addStandardMessage(LynxKeepAliveCommand.class);
        addStandardMessage(LynxGetModuleStatusCommand.class);
        addStandardMessage(LynxFailSafeCommand.class);
        addStandardMessage(LynxSetNewModuleAddressCommand.class);
        addStandardMessage(LynxQueryInterfaceCommand.class);
        addStandardMessage(LynxSetNewModuleAddressCommand.class);
        addStandardMessage(LynxSetModuleLEDColorCommand.class);
        addStandardMessage(LynxGetModuleLEDColorCommand.class);
        correlateStandardResponse(LynxGetModuleStatusCommand.class);
        correlateStandardResponse(LynxQueryInterfaceCommand.class);
        correlateStandardResponse(LynxGetModuleLEDColorCommand.class);
    }

    protected static class MessageClassAndCtor {
        public Class<? extends LynxMessage> clazz;
        public Constructor<? extends LynxMessage> ctor;

        protected MessageClassAndCtor() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:8:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0011 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void assignCtor() throws java.lang.NoSuchMethodException {
            /*
                r5 = this;
                r0 = 0
                r1 = 1
                java.lang.Class<? extends com.qualcomm.hardware.lynx.commands.LynxMessage> r2 = r5.clazz     // Catch:{ NoSuchMethodException -> 0x0011 }
                java.lang.Class[] r3 = new java.lang.Class[r1]     // Catch:{ NoSuchMethodException -> 0x0011 }
                java.lang.Class<com.qualcomm.hardware.lynx.LynxModule> r4 = com.qualcomm.hardware.lynx.LynxModule.class
                r3[r0] = r4     // Catch:{ NoSuchMethodException -> 0x0011 }
                java.lang.reflect.Constructor r2 = r2.getConstructor(r3)     // Catch:{ NoSuchMethodException -> 0x0011 }
                r5.ctor = r2     // Catch:{ NoSuchMethodException -> 0x0011 }
                goto L_0x0023
            L_0x0011:
                java.lang.Class<? extends com.qualcomm.hardware.lynx.commands.LynxMessage> r2 = r5.clazz     // Catch:{ NoSuchMethodException -> 0x0020 }
                java.lang.Class[] r1 = new java.lang.Class[r1]     // Catch:{ NoSuchMethodException -> 0x0020 }
                java.lang.Class<com.qualcomm.hardware.lynx.LynxModuleIntf> r3 = com.qualcomm.hardware.lynx.LynxModuleIntf.class
                r1[r0] = r3     // Catch:{ NoSuchMethodException -> 0x0020 }
                java.lang.reflect.Constructor r0 = r2.getConstructor(r1)     // Catch:{ NoSuchMethodException -> 0x0020 }
                r5.ctor = r0     // Catch:{ NoSuchMethodException -> 0x0020 }
                goto L_0x0023
            L_0x0020:
                r0 = 0
                r5.ctor = r0
            L_0x0023:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxModule.MessageClassAndCtor.assignCtor():void");
        }
    }

    protected static void addStandardMessage(Class<? extends LynxMessage> cls) {
        try {
            Integer num = (Integer) LynxMessage.invokeStaticNullaryMethod(cls, "getStandardCommandNumber");
            Assert.assertTrue((num.intValue() & 32768) == 0);
            MessageClassAndCtor messageClassAndCtor = new MessageClassAndCtor();
            messageClassAndCtor.clazz = cls;
            messageClassAndCtor.assignCtor();
            standardMessages.put(num, messageClassAndCtor);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            RobotLog.ee(TAG, "error registering %s", cls.getSimpleName());
        }
    }

    protected static void correlateStandardResponse(Class<? extends LynxCommand> cls) {
        try {
            correlateResponse(cls, LynxCommand.getResponseClass(cls));
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            RobotLog.ee(TAG, "error registering response to %s", cls.getSimpleName());
        }
    }

    public static void correlateResponse(Class<? extends LynxCommand> cls, Class<? extends LynxResponse> cls2) throws NoSuchMethodException {
        MessageClassAndCtor messageClassAndCtor = new MessageClassAndCtor();
        messageClassAndCtor.clazz = cls2;
        messageClassAndCtor.assignCtor();
        responseClasses.put(cls, messageClassAndCtor);
    }

    public LynxModule(LynxUsbDevice lynxUsbDevice2, int i, boolean z, boolean z2) {
        this.lynxUsbDevice = lynxUsbDevice2;
        this.controllers = new CopyOnWriteArrayList();
        this.addrAndSerialLock = new Object();
        this.moduleAddress = i;
        this.moduleSerialNumber = new LynxModuleSerialNumber(lynxUsbDevice2.getSerialNumber(), i);
        this.isParent = z;
        this.isSystemSynthetic = false;
        this.isEngaged = true;
        this.isUserModule = z2;
        this.isOpen = true;
        this.startStopLock = new Object();
        this.nextMessageNumber = new AtomicInteger(0);
        ConcurrentHashMap<Integer, MessageClassAndCtor> concurrentHashMap = new ConcurrentHashMap<>(standardMessages);
        this.commandClasses = concurrentHashMap;
        this.supportedCommands = new HashSet();
        for (MessageClassAndCtor next : concurrentHashMap.values()) {
            if (ClassUtil.inheritsFrom(next.clazz, LynxCommand.class)) {
                this.supportedCommands.add(next.clazz);
            }
        }
        this.interfacesQueried = new ConcurrentHashMap<>();
        this.unfinishedCommands = new ConcurrentHashMap<>();
        this.i2cLock = new Object();
        this.currentSteps = new ArrayList<>();
        this.previousSteps = new ArrayDeque();
        this.isVisuallyIdentifying = false;
        this.executor = null;
        this.pingFuture = null;
        this.moduleStatusFuture = null;
        this.attentionRequiredPreviously = false;
        this.previousModuleStatus = Integer.MIN_VALUE;
        this.moduleStatusLock = new Object();
        this.pingFutureLock = new Object();
        this.ftdiResetWatchdogActive = false;
        this.ftdiResetWatchdogActiveWhenEngaged = false;
        this.bulkCachingMode = BulkCachingMode.OFF;
        this.bulkCachingHistory = new HashMap();
        this.bulkCachingLock = new Object();
        startExecutor();
        this.lynxUsbDevice.registerCallback(this, false);
    }

    public String toString() {
        return Misc.formatForUser("LynxModule(mod#=%d, serial=%s)", Integer.valueOf(getModuleAddress()), getSerialNumber());
    }

    public void close() {
        synchronized (this.startStopLock) {
            if (this.isOpen) {
                stopFtdiResetWatchdog();
                RobotLog.vv(TAG, "close(#%d)", Integer.valueOf(getModuleAddress()));
                for (LynxController close : this.controllers) {
                    close.close();
                }
                unregisterCallback(this);
                this.lynxUsbDevice.removeConfiguredModule(this);
                this.isOpen = false;
                stopAttentionRequired();
                stopPingTimer(true);
                stopExecutor();
            }
        }
    }

    public boolean isOpen() {
        return this.isOpen;
    }

    public boolean isUserModule() {
        return this.isUserModule;
    }

    public void setUserModule(boolean z) {
        warnIfClosed();
        this.isUserModule = z;
    }

    public boolean isSystemSynthetic() {
        return this.isSystemSynthetic;
    }

    public void setSystemSynthetic(boolean z) {
        warnIfClosed();
        this.isSystemSynthetic = z;
    }

    public void noteController(LynxController lynxController) {
        warnIfClosed();
        this.controllers.add(lynxController);
    }

    public int getRevProductNumber() {
        try {
            return queryInterface(new LynxInterface(LynxConstants.SERVO_HUB_INTERFACE_NAME, new Class[0])) ? LynxConstants.SERVO_HUB_PRODUCT_NUMBER : LynxConstants.EXPANSION_HUB_PRODUCT_NUMBER;
        } catch (InterruptedException e) {
            RobotLog.ee(TAG, (Throwable) e, "Failed to determine the REV product number");
            return LynxConstants.EXPANSION_HUB_PRODUCT_NUMBER;
        }
    }

    public int getModuleAddress() {
        int i;
        synchronized (this.addrAndSerialLock) {
            i = this.moduleAddress;
        }
        return i;
    }

    public void setNewModuleAddress(final int i) {
        warnIfClosed();
        if (i != getModuleAddress()) {
            this.lynxUsbDevice.changeModuleAddress(this, i, new Runnable() {
                public void run() {
                    try {
                        LynxSetNewModuleAddressCommand lynxSetNewModuleAddressCommand = new LynxSetNewModuleAddressCommand(LynxModule.this, (byte) i);
                        lynxSetNewModuleAddressCommand.acquireNetworkLock();
                        try {
                            int moduleAddress = LynxModule.this.getModuleAddress();
                            lynxSetNewModuleAddressCommand.send();
                            synchronized (LynxModule.this.addrAndSerialLock) {
                                LynxModule.this.moduleAddress = i;
                                LynxModule.this.moduleSerialNumber = new LynxModuleSerialNumber(LynxModule.this.getSerialNumber(), i);
                            }
                            HardwareManualControlOpMode instance = HardwareManualControlOpMode.getInstance();
                            if (instance != null) {
                                instance.onLynxModuleAddressChanged(LynxModule.this, moduleAddress, i);
                            }
                            lynxSetNewModuleAddressCommand.releaseNetworkLock();
                        } catch (Throwable th) {
                            lynxSetNewModuleAddressCommand.releaseNetworkLock();
                            throw th;
                        }
                    } catch (LynxNackException | InterruptedException e) {
                        LynxModule.this.handleException(e);
                    }
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    public byte getNewMessageNumber() {
        while (true) {
            byte andIncrement = (byte) this.nextMessageNumber.getAndIncrement();
            int unsignedByteToInt = TypeConversion.unsignedByteToInt(andIncrement);
            if (andIncrement != 0 && !this.unfinishedCommands.containsKey(Integer.valueOf(unsignedByteToInt))) {
                return andIncrement;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x001b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setAttentionRequired(boolean r4) {
        /*
            r3 = this;
            r3.warnIfClosed()
            java.lang.Object r0 = r3.moduleStatusLock
            monitor-enter(r0)
            if (r4 != 0) goto L_0x000e
            boolean r1 = r3.attentionRequiredPreviously     // Catch:{ all -> 0x0033 }
            if (r1 == 0) goto L_0x000e
            r1 = 1
            goto L_0x000f
        L_0x000e:
            r1 = r4
        L_0x000f:
            r3.attentionRequiredPreviously = r4     // Catch:{ all -> 0x0033 }
            boolean r2 = r3.isOpen     // Catch:{ all -> 0x0033 }
            if (r2 == 0) goto L_0x002c
            if (r1 == 0) goto L_0x002c
            java.util.concurrent.Future<?> r1 = r3.moduleStatusFuture     // Catch:{ all -> 0x0033 }
            if (r1 == 0) goto L_0x001f
            r2 = 0
            r1.cancel(r2)     // Catch:{ all -> 0x0033 }
        L_0x001f:
            java.util.concurrent.ScheduledExecutorService r1 = r3.executor     // Catch:{ all -> 0x0033 }
            com.qualcomm.hardware.lynx.LynxModule$2 r2 = new com.qualcomm.hardware.lynx.LynxModule$2     // Catch:{ all -> 0x0033 }
            r2.<init>()     // Catch:{ all -> 0x0033 }
            java.util.concurrent.Future r1 = r1.submit(r2)     // Catch:{ all -> 0x0033 }
            r3.moduleStatusFuture = r1     // Catch:{ all -> 0x0033 }
        L_0x002c:
            monitor-exit(r0)     // Catch:{ all -> 0x0033 }
            if (r4 == 0) goto L_0x0032
            r3.forgetLastKnown()
        L_0x0032:
            return
        L_0x0033:
            r4 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0033 }
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxModule.setAttentionRequired(boolean):void");
    }

    /* access modifiers changed from: protected */
    public void noteDatagramReceived() {
        warnIfClosed();
        if (this.isNotResponding) {
            this.isNotResponding = false;
            RobotLog.vv(TAG, "REV Hub #%d has reconnected", Integer.valueOf(getModuleAddress()));
        }
    }

    public void noteNotResponding() {
        warnIfClosed();
        this.isNotResponding = true;
    }

    public boolean isNotResponding() {
        warnIfClosed();
        return this.isNotResponding;
    }

    /* access modifiers changed from: protected */
    public void warnIfClosed() {
        if (!isOpen()) {
            RobotLog.ww(TAG, (Throwable) new RuntimeException(), "Attempted use of a closed LynxModule instance");
        }
    }

    /* access modifiers changed from: protected */
    public void stopAttentionRequired() {
        synchronized (this.moduleStatusLock) {
            Future<?> future = this.moduleStatusFuture;
            if (future != null) {
                future.cancel(true);
                ThreadPool.awaitFuture(this.moduleStatusFuture, 250, TimeUnit.MILLISECONDS);
                this.moduleStatusFuture = null;
            }
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0029, code lost:
        if (r6.testAnyBits(-23) == false) goto L_0x003a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x002b, code lost:
        com.qualcomm.robotcore.util.RobotLog.vv(TAG, "received status: %s", r6.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x003a, code lost:
        r0 = com.qualcomm.hardware.HardwareManualControlOpMode.getInstance();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x003e, code lost:
        if (r0 == null) goto L_0x0054;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0040, code lost:
        com.qualcomm.robotcore.util.ThreadPool.getDefault().submit(new com.qualcomm.hardware.lynx.LynxModule$$ExternalSyntheticLambda0(r5, r0, r6.getStatus(), r6.getMotorAlerts()));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0058, code lost:
        if (r6.isKeepAliveTimeout() == false) goto L_0x005d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x005a, code lost:
        resendCurrentPattern();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0061, code lost:
        if (r6.isDeviceReset() == false) goto L_0x0073;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0067, code lost:
        if (isUserModule() == false) goto L_0x0073;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0069, code lost:
        com.qualcomm.hardware.lynx.LynxModuleWarningManager.getInstance().reportModuleReset(r5);
        resendCurrentPattern();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0077, code lost:
        if (r6.isBatteryLow() == false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x007d, code lost:
        if (isUserModule() == false) goto L_?;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x007f, code lost:
        com.qualcomm.hardware.lynx.LynxModuleWarningManager.getInstance().reportModuleLowBattery(r5);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void sendGetModuleStatusAndProcessResponse(boolean r6) {
        /*
            r5 = this;
            com.qualcomm.hardware.lynx.commands.standard.LynxGetModuleStatusCommand r0 = new com.qualcomm.hardware.lynx.commands.standard.LynxGetModuleStatusCommand
            r0.<init>(r5, r6)
            com.qualcomm.hardware.lynx.commands.LynxMessage r6 = r0.sendReceive()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            com.qualcomm.hardware.lynx.commands.standard.LynxGetModuleStatusResponse r6 = (com.qualcomm.hardware.lynx.commands.standard.LynxGetModuleStatusResponse) r6     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            java.lang.Object r0 = r5.moduleStatusLock     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            monitor-enter(r0)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            int r1 = r6.getStatus()     // Catch:{ all -> 0x0087 }
            int r2 = r6.getMotorAlerts()     // Catch:{ all -> 0x0087 }
            int r3 = r5.previousModuleStatus     // Catch:{ all -> 0x0087 }
            if (r1 != r3) goto L_0x001e
            if (r2 != 0) goto L_0x001e
            monitor-exit(r0)     // Catch:{ all -> 0x0087 }
            return
        L_0x001e:
            r1 = r1 & 28
            r5.previousModuleStatus = r1     // Catch:{ all -> 0x0087 }
            monitor-exit(r0)     // Catch:{ all -> 0x0087 }
            r0 = -23
            boolean r0 = r6.testAnyBits(r0)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r0 == 0) goto L_0x003a
            java.lang.String r0 = "LynxModule"
            java.lang.String r1 = "received status: %s"
            java.lang.String r2 = r6.toString()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            java.lang.Object[] r2 = new java.lang.Object[]{r2}     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r0, (java.lang.String) r1, (java.lang.Object[]) r2)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
        L_0x003a:
            com.qualcomm.hardware.HardwareManualControlOpMode r0 = com.qualcomm.hardware.HardwareManualControlOpMode.getInstance()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r0 == 0) goto L_0x0054
            int r1 = r6.getStatus()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            int r2 = r6.getMotorAlerts()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            java.util.concurrent.ExecutorService r3 = com.qualcomm.robotcore.util.ThreadPool.getDefault()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            com.qualcomm.hardware.lynx.LynxModule$$ExternalSyntheticLambda0 r4 = new com.qualcomm.hardware.lynx.LynxModule$$ExternalSyntheticLambda0     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            r4.<init>(r5, r0, r1, r2)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            r3.submit(r4)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
        L_0x0054:
            boolean r0 = r6.isKeepAliveTimeout()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r0 == 0) goto L_0x005d
            r5.resendCurrentPattern()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
        L_0x005d:
            boolean r0 = r6.isDeviceReset()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r0 == 0) goto L_0x0073
            boolean r0 = r5.isUserModule()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r0 == 0) goto L_0x0073
            com.qualcomm.hardware.lynx.LynxModuleWarningManager r0 = com.qualcomm.hardware.lynx.LynxModuleWarningManager.getInstance()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            r0.reportModuleReset(r5)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            r5.resendCurrentPattern()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
        L_0x0073:
            boolean r6 = r6.isBatteryLow()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r6 == 0) goto L_0x0092
            boolean r6 = r5.isUserModule()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            if (r6 == 0) goto L_0x0092
            com.qualcomm.hardware.lynx.LynxModuleWarningManager r6 = com.qualcomm.hardware.lynx.LynxModuleWarningManager.getInstance()     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            r6.reportModuleLowBattery(r5)     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
            goto L_0x0092
        L_0x0087:
            r6 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0087 }
            throw r6     // Catch:{ LynxNackException -> 0x008e, RuntimeException -> 0x008c, InterruptedException -> 0x008a }
        L_0x008a:
            r6 = move-exception
            goto L_0x008f
        L_0x008c:
            r6 = move-exception
            goto L_0x008f
        L_0x008e:
            r6 = move-exception
        L_0x008f:
            r5.handleException(r6)
        L_0x0092:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxModule.sendGetModuleStatusAndProcessResponse(boolean):void");
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$sendGetModuleStatusAndProcessResponse$0$com-qualcomm-hardware-lynx-LynxModule  reason: not valid java name */
    public /* synthetic */ void m24lambda$sendGetModuleStatusAndProcessResponse$0$comqualcommhardwarelynxLynxModule(HardwareManualControlOpMode hardwareManualControlOpMode, int i, int i2) {
        hardwareManualControlOpMode.onLynxModuleStatusChanged(this, i, i2);
    }

    /* access modifiers changed from: protected */
    public void forgetLastKnown() {
        for (LynxController forgetLastKnown : this.controllers) {
            forgetLastKnown.forgetLastKnown();
        }
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.Lynx;
    }

    public String getDeviceName() {
        return String.format("%s (%s)", new Object[]{AppUtil.getDefContext().getString(R.string.expansionHubDisplayName), getFirmwareVersionString()});
    }

    public String getFirmwareVersionString() {
        String nullableFirmwareVersionString = getNullableFirmwareVersionString();
        return nullableFirmwareVersionString == null ? AppUtil.getDefContext().getString(com.qualcomm.robotcore.R.string.lynxUnavailableFWVersionString) : nullableFirmwareVersionString;
    }

    public String getNullableFirmwareVersionString() {
        warnIfClosed();
        try {
            return ((LynxReadVersionStringResponse) new LynxReadVersionStringCommand(this).sendReceive()).getNullableVersionString();
        } catch (LynxNackException | InterruptedException e) {
            handleException(e);
            return null;
        }
    }

    public String getConnectionInfo() {
        return String.format("%s; module %d", new Object[]{this.lynxUsbDevice.getConnectionInfo(), Integer.valueOf(getModuleAddress())});
    }

    public void resetDeviceConfigurationForOpMode() {
        warnIfClosed();
        setBulkCachingMode(BulkCachingMode.OFF);
    }

    public List<String> getGlobalWarnings() {
        warnIfClosed();
        ArrayList arrayList = new ArrayList();
        for (LynxController healthStatusWarningMessage : this.controllers) {
            String healthStatusWarningMessage2 = getHealthStatusWarningMessage(healthStatusWarningMessage);
            if (!healthStatusWarningMessage2.isEmpty()) {
                arrayList.add(healthStatusWarningMessage2);
            }
        }
        return arrayList;
    }

    public static String getHealthStatusWarningMessage(HardwareDeviceHealth hardwareDeviceHealth) {
        String str;
        if (AnonymousClass4.$SwitchMap$com$qualcomm$robotcore$hardware$HardwareDeviceHealth$HealthStatus[hardwareDeviceHealth.getHealthStatus().ordinal()] != 1) {
            return InspectionState.NO_VERSION;
        }
        if (hardwareDeviceHealth instanceof RobotConfigNameable) {
            str = ((RobotConfigNameable) hardwareDeviceHealth).getUserConfiguredName();
            if (str != null) {
                str = AppUtil.getDefContext().getString(R.string.quotes, new Object[]{str});
            }
        } else {
            str = null;
        }
        if (str == null && (hardwareDeviceHealth instanceof HardwareDevice)) {
            HardwareDevice hardwareDevice = (HardwareDevice) hardwareDeviceHealth;
            str = AppUtil.getDefContext().getString(R.string.hwDeviceDescriptionAndConnection, new Object[]{hardwareDevice.getDeviceName(), hardwareDevice.getConnectionInfo()});
        }
        if (str == null) {
            str = AppUtil.getDefContext().getString(R.string.hwPoorlyNamedDevice);
        }
        return AppUtil.getDefContext().getString(R.string.unhealthyDevice, new Object[]{str});
    }

    public SerialNumber getModuleSerialNumber() {
        SerialNumber serialNumber;
        synchronized (this.addrAndSerialLock) {
            serialNumber = this.moduleSerialNumber;
        }
        return serialNumber;
    }

    public SerialNumber getSerialNumber() {
        return this.lynxUsbDevice.getSerialNumber();
    }

    public RobotArmingStateNotifier.ARMINGSTATE getArmingState() {
        return this.lynxUsbDevice.getArmingState();
    }

    public void registerCallback(RobotArmingStateNotifier.Callback callback, boolean z) {
        this.lynxUsbDevice.registerCallback(callback, z);
    }

    public void unregisterCallback(RobotArmingStateNotifier.Callback callback) {
        this.lynxUsbDevice.unregisterCallback(callback);
    }

    /* renamed from: com.qualcomm.hardware.lynx.LynxModule$4  reason: invalid class name */
    static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$HardwareDeviceHealth$HealthStatus;
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$usb$RobotArmingStateNotifier$ARMINGSTATE;

        static {
            int[] iArr = new int[RobotArmingStateNotifier.ARMINGSTATE.values().length];
            $SwitchMap$com$qualcomm$robotcore$hardware$usb$RobotArmingStateNotifier$ARMINGSTATE = iArr;
            try {
                iArr[RobotArmingStateNotifier.ARMINGSTATE.DISARMED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            int[] iArr2 = new int[HardwareDeviceHealth.HealthStatus.values().length];
            $SwitchMap$com$qualcomm$robotcore$hardware$HardwareDeviceHealth$HealthStatus = iArr2;
            try {
                iArr2[HardwareDeviceHealth.HealthStatus.UNHEALTHY.ordinal()] = 1;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public void onModuleStateChange(RobotArmingStateNotifier robotArmingStateNotifier, RobotArmingStateNotifier.ARMINGSTATE armingstate) {
        int i = AnonymousClass4.$SwitchMap$com$qualcomm$robotcore$hardware$usb$RobotArmingStateNotifier$ARMINGSTATE[armingstate.ordinal()];
    }

    public void engage() {
        warnIfClosed();
        synchronized (this.engagementLock) {
            if (!this.isEngaged) {
                RobotLog.vv(TAG, "engaging lynx module #%d", Integer.valueOf(getModuleAddress()));
                for (LynxController engage : this.controllers) {
                    engage.engage();
                }
                this.isEngaged = true;
                if (this.ftdiResetWatchdogActiveWhenEngaged) {
                    startFtdiResetWatchdog();
                }
            }
        }
    }

    public void disengage() {
        warnIfClosed();
        synchronized (this.engagementLock) {
            if (this.isEngaged) {
                RobotLog.vv(TAG, "disengaging lynx module #%d", Integer.valueOf(getModuleAddress()));
                stopFtdiResetWatchdog(true);
                this.isEngaged = false;
                nackUnfinishedCommands();
                for (LynxController disengage : this.controllers) {
                    disengage.disengage();
                }
                nackUnfinishedCommands();
            }
        }
    }

    public boolean isEngaged() {
        boolean z;
        warnIfClosed();
        synchronized (this.engagementLock) {
            z = this.isEngaged;
        }
        return z;
    }

    public void visuallyIdentify(boolean z) {
        warnIfClosed();
        synchronized (this) {
            boolean z2 = this.isVisuallyIdentifying;
            if (z2 != z) {
                if (!z2) {
                    internalPushPattern(blinkerPolicy.getVisuallyIdentifyPattern(this));
                } else {
                    popPattern();
                }
                this.isVisuallyIdentifying = z;
            }
        }
    }

    public void setConstant(int i) {
        warnIfClosed();
        Blinker.Step step = new Blinker.Step(i, 1, TimeUnit.SECONDS);
        ArrayList arrayList = new ArrayList();
        arrayList.add(step);
        setPattern(arrayList);
    }

    public void stopBlinking() {
        warnIfClosed();
        setConstant(ViewCompat.MEASURED_STATE_MASK);
    }

    public synchronized void setPattern(Collection<Blinker.Step> collection) {
        ArrayList<Blinker.Step> arrayList = collection == null ? new ArrayList<>() : new ArrayList<>(collection);
        this.currentSteps = arrayList;
        sendLEDPatternSteps(arrayList);
    }

    public synchronized Collection<Blinker.Step> getPattern() {
        warnIfClosed();
        return new ArrayList(this.currentSteps);
    }

    /* access modifiers changed from: protected */
    public void resendCurrentPattern() {
        RobotLog.vv(TAG, "resendCurrentPattern()");
        sendLEDPatternSteps(this.currentSteps);
    }

    public synchronized void pushPattern(Collection<Blinker.Step> collection) {
        visuallyIdentify(false);
        internalPushPattern(collection);
    }

    /* access modifiers changed from: protected */
    public void internalPushPattern(Collection<Blinker.Step> collection) {
        warnIfClosed();
        this.previousSteps.push(this.currentSteps);
        setPattern(collection);
    }

    public synchronized boolean patternStackNotEmpty() {
        warnIfClosed();
        return this.previousSteps.size() > 0;
    }

    public synchronized boolean popPattern() {
        warnIfClosed();
        try {
            setPattern(this.previousSteps.pop());
        } catch (NoSuchElementException unused) {
            setPattern((Collection<Blinker.Step>) null);
            return false;
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public void sendLEDPatternSteps(Collection<Blinker.Step> collection) {
        warnIfClosed();
        RobotLog.vv(TAG, "sendLEDPatternSteps(): steps=%s", collection);
        ping();
        LynxSetModuleLEDPatternCommand.Steps steps = new LynxSetModuleLEDPatternCommand.Steps();
        for (Blinker.Step add : collection) {
            steps.add(add);
        }
        try {
            new LynxSetModuleLEDPatternCommand(this, steps).sendReceive();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
        }
    }

    public static class BreathingBlinkerPolicy implements BlinkerPolicy {
        public List<Blinker.Step> getIdlePattern(LynxModule lynxModule) {
            float[] fArr = {0.0f, 0.0f, 0.0f};
            Color.colorToHSV(-16711681, fArr);
            final float f = fArr[0];
            final ArrayList arrayList = new ArrayList();
            AnonymousClass1 r2 = new Consumer<Integer>() {
                public void accept(Integer num) {
                    arrayList.add(new Blinker.Step(Color.HSVToColor(new float[]{f, 1.0f, 1.0f - ((float) Math.sqrt((double) (1.0f - (((((float) num.intValue()) / 8.0f) * 0.95f) + 0.05f))))}), 125, TimeUnit.MILLISECONDS));
                }
            };
            for (int i = 0; i <= 8; i++) {
                r2.accept(Integer.valueOf(i));
            }
            for (int i2 = 7; i2 > 0; i2--) {
                r2.accept(Integer.valueOf(i2));
            }
            return arrayList;
        }

        public List<Blinker.Step> getVisuallyIdentifyPattern(LynxModule lynxModule) {
            ArrayList arrayList = new ArrayList();
            long j = (long) Imgproc.COLOR_BGR2YUV_YVYU;
            arrayList.add(new Blinker.Step(-16711681, j, TimeUnit.MILLISECONDS));
            long j2 = (long) 75;
            arrayList.add(new Blinker.Step(ViewCompat.MEASURED_STATE_MASK, j2, TimeUnit.MILLISECONDS));
            arrayList.add(new Blinker.Step(-65281, j, TimeUnit.MILLISECONDS));
            arrayList.add(new Blinker.Step(ViewCompat.MEASURED_STATE_MASK, j2, TimeUnit.MILLISECONDS));
            return arrayList;
        }
    }

    public static class CountModuleAddressBlinkerPolicy extends BreathingBlinkerPolicy {
        public List<Blinker.Step> getIdlePattern(LynxModule lynxModule) {
            ArrayList arrayList = new ArrayList();
            if (lynxModule.getModuleAddress() == 173) {
                arrayList.add(new Blinker.Step(-16711936, 1, TimeUnit.SECONDS));
                return arrayList;
            }
            arrayList.add(new Blinker.Step(-16711936, (long) 4500, TimeUnit.MILLISECONDS));
            long j = (long) 500;
            arrayList.add(new Blinker.Step(ViewCompat.MEASURED_STATE_MASK, j, TimeUnit.MILLISECONDS));
            int min = Math.min(lynxModule.getModuleAddress(), (16 - arrayList.size()) / 2);
            for (int i = 0; i < min; i++) {
                arrayList.add(new Blinker.Step(-16776961, j, TimeUnit.MILLISECONDS));
                arrayList.add(new Blinker.Step(ViewCompat.MEASURED_STATE_MASK, j, TimeUnit.MILLISECONDS));
            }
            return arrayList;
        }
    }

    public boolean isParent() {
        warnIfClosed();
        return this.isParent;
    }

    public void pingAndQueryKnownInterfacesAndEtc() throws RobotCoreException, InterruptedException {
        warnIfClosed();
        RobotLog.vv(TAG, "pingAndQueryKnownInterfaces mod=%d", Integer.valueOf(getModuleAddress()));
        pingInitialContact();
        queryInterface(LynxDekaInterfaceCommand.createDekaInterface());
        startFtdiResetWatchdog();
        initializeDebugLogging();
        initializeLEDS();
        if (isParent() && LynxConstants.isEmbeddedSerialNumber(getSerialNumber())) {
            RobotLog.vv(TAG, "setAsControlHubEmbeddedModule(mod=%d)", Integer.valueOf(getModuleAddress()));
            EmbeddedControlHubModule.set(this);
        }
    }

    /* access modifiers changed from: protected */
    public void initializeLEDS() {
        setPattern(blinkerPolicy.getIdlePattern(this));
    }

    /* access modifiers changed from: protected */
    public void initializeDebugLogging() throws RobotCoreException, InterruptedException {
        setDebug(DebugGroup.MODULELED, DebugVerbosity.HIGH);
    }

    /* access modifiers changed from: protected */
    public void pingInitialContact() throws RobotCoreException, InterruptedException {
        ElapsedTime elapsedTime = new ElapsedTime();
        while (elapsedTime.milliseconds() < 500.0d) {
            try {
                ping(true);
                return;
            } catch (LynxNackException | RobotCoreException | RuntimeException unused) {
                RobotLog.vv(TAG, "retrying ping mod=%d", Integer.valueOf(getModuleAddress()));
            }
        }
        throw new RobotCoreException("initial ping contact failed: mod=%d", Integer.valueOf(getModuleAddress()));
    }

    public void validateCommand(LynxMessage lynxMessage) throws LynxUnsupportedCommandException {
        warnIfClosed();
        synchronized (this.interfacesQueried) {
            if (this.lynxUsbDevice.getArmingState() == RobotArmingStateNotifier.ARMINGSTATE.ARMED) {
                int commandNumber = lynxMessage.getCommandNumber();
                if (!LynxStandardCommand.isStandardCommandNumber(commandNumber)) {
                    if (!this.commandClasses.containsKey(Integer.valueOf(commandNumber))) {
                        throw new LynxUnsupportedCommandException(this, lynxMessage);
                    }
                }
            }
        }
    }

    public boolean isCommandSupported(Class<? extends LynxCommand> cls) {
        boolean z;
        warnIfClosed();
        synchronized (this.interfacesQueried) {
            if (getModuleAddress() == 0) {
                z = cls == LynxDiscoveryCommand.class;
            } else {
                z = this.supportedCommands.contains(cls);
            }
        }
        return z;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x00eb, code lost:
        r8 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:?, code lost:
        com.qualcomm.robotcore.util.RobotLog.ee(TAG, r8, "exception registering %s", r7.getSimpleName());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0120, code lost:
        com.qualcomm.robotcore.util.RobotLog.vv(TAG, "mod#=%d queryInterface(): interface %s is not supported", java.lang.Integer.valueOf(getModuleAddress()), r12.getInterfaceName());
        r12.setWasNacked(true);
        r11.interfacesQueried.put(r12.getInterfaceName(), r12);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x015e, code lost:
        org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance().showAlertDialog(org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH, "Unsupported Servo Hub Firmware Version", "The Robot Controller app needs to be updated to support the firmware version of the connected Servo Hub");
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:32:? A[ExcHandler: LynxNackException (unused com.qualcomm.hardware.lynx.LynxNackException), SYNTHETIC, Splitter:B:5:0x0011] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean queryInterface(com.qualcomm.hardware.lynx.commands.LynxInterface r12) throws java.lang.InterruptedException {
        /*
            r11 = this;
            r11.warnIfClosed()
            java.util.concurrent.ConcurrentHashMap<java.lang.String, com.qualcomm.hardware.lynx.commands.LynxInterface> r0 = r11.interfacesQueried
            monitor-enter(r0)
            com.qualcomm.hardware.lynx.commands.standard.LynxQueryInterfaceCommand r1 = new com.qualcomm.hardware.lynx.commands.standard.LynxQueryInterfaceCommand     // Catch:{ all -> 0x016e }
            java.lang.String r2 = r12.getInterfaceName()     // Catch:{ all -> 0x016e }
            r1.<init>(r11, r2)     // Catch:{ all -> 0x016e }
            r2 = 1
            r3 = 0
            com.qualcomm.hardware.lynx.commands.LynxMessage r1 = r1.sendReceive()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            com.qualcomm.hardware.lynx.commands.standard.LynxQueryInterfaceResponse r1 = (com.qualcomm.hardware.lynx.commands.standard.LynxQueryInterfaceResponse) r1     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            r12.setWasNacked(r3)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            int r4 = r1.getCommandNumberFirst()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            r12.setBaseCommandNumber(r4)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.String r4 = "LynxModule"
            java.lang.String r5 = "mod#=%d queryInterface(%s)=%d commands starting at %d"
            int r6 = r11.getModuleAddress()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.String r7 = r12.getInterfaceName()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            int r8 = r1.getNumberOfCommands()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            int r9 = r1.getCommandNumberFirst()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Object[] r6 = new java.lang.Object[]{r6, r7, r8, r9}     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r4, (java.lang.String) r5, (java.lang.Object[]) r6)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.util.List r4 = r12.getCommandClasses()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.util.concurrent.ConcurrentHashMap<java.lang.Integer, com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor> r5 = r11.commandClasses     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.util.Set r5 = r5.entrySet()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.util.Iterator r5 = r5.iterator()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
        L_0x005a:
            boolean r6 = r5.hasNext()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            if (r6 == 0) goto L_0x008b
            java.lang.Object r6 = r5.next()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.util.Map$Entry r6 = (java.util.Map.Entry) r6     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Object r7 = r6.getValue()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor r7 = (com.qualcomm.hardware.lynx.LynxModule.MessageClassAndCtor) r7     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Class<? extends com.qualcomm.hardware.lynx.commands.LynxMessage> r7 = r7.clazz     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            boolean r7 = r4.contains(r7)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            if (r7 == 0) goto L_0x005a
            java.util.concurrent.ConcurrentHashMap<java.lang.Integer, com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor> r7 = r11.commandClasses     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Object r8 = r6.getKey()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            r7.remove(r8)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.util.Set<java.lang.Class<? extends com.qualcomm.hardware.lynx.commands.LynxCommand>> r7 = r11.supportedCommands     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Object r6 = r6.getValue()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor r6 = (com.qualcomm.hardware.lynx.LynxModule.MessageClassAndCtor) r6     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Class<? extends com.qualcomm.hardware.lynx.commands.LynxMessage> r6 = r6.clazz     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            r7.remove(r6)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            goto L_0x005a
        L_0x008b:
            java.util.Iterator r5 = r4.iterator()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            r6 = r3
        L_0x0090:
            boolean r7 = r5.hasNext()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            if (r7 == 0) goto L_0x0100
            java.lang.Object r7 = r5.next()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Class r7 = (java.lang.Class) r7     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            int r8 = r1.getNumberOfCommands()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            if (r6 < r8) goto L_0x00ca
            java.lang.String r5 = "LynxModule"
            java.lang.String r6 = "mod#=%d intf=%s: expected %d commands; found %d"
            int r7 = r11.getModuleAddress()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.String r8 = r12.getInterfaceName()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            int r4 = r4.size()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            int r1 = r1.getNumberOfCommands()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Object[] r1 = new java.lang.Object[]{r7, r8, r4, r1}     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r5, (java.lang.String) r6, (java.lang.Object[]) r1)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            goto L_0x0100
        L_0x00ca:
            if (r7 != 0) goto L_0x00cd
            goto L_0x00fd
        L_0x00cd:
            int r8 = r1.getCommandNumberFirst()     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            int r8 = r8 + r6
            com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor r9 = new com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            r9.<init>()     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            r9.clazz = r7     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            r9.assignCtor()     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            java.util.concurrent.ConcurrentHashMap<java.lang.Integer, com.qualcomm.hardware.lynx.LynxModule$MessageClassAndCtor> r10 = r11.commandClasses     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            r10.put(r8, r9)     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            java.util.Set<java.lang.Class<? extends com.qualcomm.hardware.lynx.commands.LynxCommand>> r8 = r11.supportedCommands     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            r8.add(r7)     // Catch:{ NoSuchMethodException -> 0x00ed, RuntimeException -> 0x00eb, LynxNackException -> 0x0120 }
            goto L_0x00fd
        L_0x00eb:
            r8 = move-exception
            goto L_0x00ee
        L_0x00ed:
            r8 = move-exception
        L_0x00ee:
            java.lang.String r9 = "LynxModule"
            java.lang.String r10 = "exception registering %s"
            java.lang.String r7 = r7.getSimpleName()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.Object[] r7 = new java.lang.Object[]{r7}     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            com.qualcomm.robotcore.util.RobotLog.ee(r9, r8, r10, r7)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
        L_0x00fd:
            int r6 = r6 + 1
            goto L_0x0090
        L_0x0100:
            java.util.concurrent.ConcurrentHashMap<java.lang.String, com.qualcomm.hardware.lynx.commands.LynxInterface> r1 = r11.interfacesQueried     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            java.lang.String r4 = r12.getInterfaceName()     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            r1.put(r4, r12)     // Catch:{ LynxNackException -> 0x0120, RuntimeException -> 0x010a }
            goto L_0x016c
        L_0x010a:
            r1 = move-exception
            java.lang.String r2 = "LynxModule"
            java.lang.String r4 = "exception during queryInterface(%s)"
            java.lang.String r12 = r12.getInterfaceName()     // Catch:{ all -> 0x016e }
            java.lang.Object[] r12 = new java.lang.Object[]{r12}     // Catch:{ all -> 0x016e }
            com.qualcomm.robotcore.util.RobotLog.ee(r2, r1, r4, r12)     // Catch:{ all -> 0x016e }
            java.lang.String r12 = "REV Hub interface query failed"
            com.qualcomm.robotcore.util.RobotLog.setGlobalErrorMsg(r12)     // Catch:{ all -> 0x016e }
            goto L_0x016b
        L_0x0120:
            java.lang.String r1 = "LynxModule"
            java.lang.String r4 = "mod#=%d queryInterface(): interface %s is not supported"
            int r5 = r11.getModuleAddress()     // Catch:{ all -> 0x016e }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x016e }
            java.lang.String r6 = r12.getInterfaceName()     // Catch:{ all -> 0x016e }
            java.lang.Object[] r5 = new java.lang.Object[]{r5, r6}     // Catch:{ all -> 0x016e }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r1, (java.lang.String) r4, (java.lang.Object[]) r5)     // Catch:{ all -> 0x016e }
            r12.setWasNacked(r2)     // Catch:{ all -> 0x016e }
            java.util.concurrent.ConcurrentHashMap<java.lang.String, com.qualcomm.hardware.lynx.commands.LynxInterface> r1 = r11.interfacesQueried     // Catch:{ all -> 0x016e }
            java.lang.String r2 = r12.getInterfaceName()     // Catch:{ all -> 0x016e }
            r1.put(r2, r12)     // Catch:{ all -> 0x016e }
            java.lang.String r12 = r12.getInterfaceName()     // Catch:{ all -> 0x016e }
            java.lang.String r1 = "DEKA"
            boolean r12 = java.util.Objects.equals(r12, r1)     // Catch:{ all -> 0x016e }
            if (r12 == 0) goto L_0x016b
            com.qualcomm.hardware.lynx.commands.LynxInterface r12 = new com.qualcomm.hardware.lynx.commands.LynxInterface     // Catch:{ all -> 0x016e }
            java.lang.String r1 = "SERVO_HUB"
            java.lang.Class[] r2 = new java.lang.Class[r3]     // Catch:{ all -> 0x016e }
            r12.<init>(r1, r2)     // Catch:{ all -> 0x016e }
            boolean r12 = r11.queryInterface(r12)     // Catch:{ all -> 0x016e }
            if (r12 == 0) goto L_0x016b
            org.firstinspires.ftc.robotcore.internal.system.AppUtil r12 = org.firstinspires.ftc.robotcore.internal.system.AppUtil.getInstance()     // Catch:{ all -> 0x016e }
            org.firstinspires.ftc.robotcore.internal.ui.UILocation r1 = org.firstinspires.ftc.robotcore.internal.ui.UILocation.BOTH     // Catch:{ all -> 0x016e }
            java.lang.String r2 = "Unsupported Servo Hub Firmware Version"
            java.lang.String r4 = "The Robot Controller app needs to be updated to support the firmware version of the connected Servo Hub"
            r12.showAlertDialog(r1, r2, r4)     // Catch:{ all -> 0x016e }
        L_0x016b:
            r2 = r3
        L_0x016c:
            monitor-exit(r0)     // Catch:{ all -> 0x016e }
            return r2
        L_0x016e:
            r12 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x016e }
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxModule.queryInterface(com.qualcomm.hardware.lynx.commands.LynxInterface):boolean");
    }

    public LynxInterface getInterface(String str) {
        LynxInterface lynxInterface;
        warnIfClosed();
        synchronized (this.interfacesQueried) {
            lynxInterface = this.interfacesQueried.get(str);
            if (lynxInterface == null) {
                RobotLog.ee(TAG, "interface \"%s\" has not been successfully queried for %s", str, this);
            } else if (lynxInterface.wasNacked()) {
                RobotLog.ee(TAG, "interface \"%s\" not supported on %s", str, this);
            }
        }
        return lynxInterface;
    }

    /* access modifiers changed from: protected */
    public void ping() {
        try {
            ping(false);
        } catch (LynxNackException | RobotCoreException | InterruptedException | RuntimeException e) {
            handleException(e);
        }
    }

    /* access modifiers changed from: protected */
    public void ping(boolean z) throws RobotCoreException, InterruptedException, LynxNackException {
        warnIfClosed();
        new LynxKeepAliveCommand(this, z).send();
    }

    public void resetPingTimer(LynxMessage lynxMessage) {
        warnIfClosed();
        startPingTimer();
    }

    /* access modifiers changed from: protected */
    public void startPingTimer() {
        warnIfClosed();
        synchronized (this.pingFutureLock) {
            stopPingTimer(false);
            if (this.isOpen) {
                try {
                    this.pingFuture = this.executor.schedule(new Runnable() {
                        public void run() {
                            if (LynxModule.this.isOpen) {
                                LynxModule.this.ping();
                            }
                        }
                    }, (long) getMsModulePingInterval(), TimeUnit.MILLISECONDS);
                } catch (RejectedExecutionException unused) {
                    RobotLog.vv(TAG, "mod#=%d: scheduling of ping rejected: ignored", Integer.valueOf(getModuleAddress()));
                    this.pingFuture = null;
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void stopPingTimer(boolean z) {
        synchronized (this.pingFutureLock) {
            Future<?> future = this.pingFuture;
            if (future != null) {
                future.cancel(false);
                if (z && !ThreadPool.awaitFuture(this.pingFuture, 250, TimeUnit.MILLISECONDS)) {
                    RobotLog.vv(TAG, "mod#=%d: unable to await ping future cancellation", Integer.valueOf(getModuleAddress()));
                }
                this.pingFuture = null;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void startFtdiResetWatchdog() {
        synchronized (this.engagementLock) {
            if (!this.ftdiResetWatchdogActive) {
                this.ftdiResetWatchdogActive = true;
                setFtdiResetWatchdog(true);
            }
            if (this.isEngaged) {
                this.ftdiResetWatchdogActiveWhenEngaged = this.ftdiResetWatchdogActive;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void stopFtdiResetWatchdog() {
        stopFtdiResetWatchdog(false);
    }

    /* access modifiers changed from: protected */
    public void stopFtdiResetWatchdog(boolean z) {
        synchronized (this.engagementLock) {
            if (this.ftdiResetWatchdogActive) {
                this.ftdiResetWatchdogActive = false;
                setFtdiResetWatchdog(false);
            }
            if (this.isEngaged && !z) {
                this.ftdiResetWatchdogActiveWhenEngaged = this.ftdiResetWatchdogActive;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void setFtdiResetWatchdog(boolean z) {
        if (isCommandSupported(LynxFtdiResetControlCommand.class)) {
            boolean interrupted = Thread.interrupted();
            RobotLog.vv(TAG, "sending LynxFtdiResetControlCommand(%s) wasInterrupted=%s", Boolean.valueOf(z), Boolean.valueOf(interrupted));
            try {
                new LynxFtdiResetControlCommand(this, z).sendReceive();
            } catch (LynxNackException | InterruptedException | RuntimeException e) {
                handleException(e);
            }
            if (interrupted) {
                Thread.currentThread().interrupt();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void startExecutor() {
        if (this.executor == null) {
            this.executor = ThreadPool.newScheduledExecutor(1, "lynx module executor");
        }
    }

    /* access modifiers changed from: protected */
    public void stopExecutor() {
        ScheduledExecutorService scheduledExecutorService = this.executor;
        if (scheduledExecutorService != null) {
            scheduledExecutorService.shutdownNow();
            try {
                ThreadPool.awaitTermination(this.executor, 2, TimeUnit.SECONDS, "lynx module executor");
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static class BulkData {
        private final boolean fake;
        private final LynxGetBulkInputDataResponse resp;

        private BulkData(LynxGetBulkInputDataResponse lynxGetBulkInputDataResponse, boolean z) {
            this.resp = lynxGetBulkInputDataResponse;
            this.fake = z;
        }

        public boolean getDigitalChannelState(int i) {
            return this.resp.getDigitalInput(i);
        }

        public int getMotorCurrentPosition(int i) {
            return this.resp.getEncoder(i);
        }

        public int getMotorVelocity(int i) {
            return this.resp.getVelocity(i);
        }

        public boolean isMotorBusy(int i) {
            return !this.resp.isAtTarget(i);
        }

        public boolean isMotorOverCurrent(int i) {
            return this.resp.isOverCurrent(i);
        }

        public double getAnalogInputVoltage(int i) {
            return getAnalogInputVoltage(i, VoltageUnit.VOLTS);
        }

        public double getAnalogInputVoltage(int i, VoltageUnit voltageUnit) {
            return voltageUnit.convert((double) this.resp.getAnalogInput(i), VoltageUnit.MILLIVOLTS);
        }

        public boolean isFake() {
            return this.fake;
        }
    }

    public BulkData getBulkData() {
        warnIfClosed();
        synchronized (this.bulkCachingLock) {
            clearBulkCache();
            try {
                BulkData bulkData = new BulkData((LynxGetBulkInputDataResponse) new LynxGetBulkInputDataCommand(this).sendReceive(), false);
                this.lastBulkData = bulkData;
                return bulkData;
            } catch (InterruptedException e) {
                e = e;
                handleException(e);
                BulkData bulkData2 = (BulkData) LynxUsbUtil.makePlaceholderValue(new BulkData(new LynxGetBulkInputDataResponse(this), true));
                this.lastBulkData = bulkData2;
                return bulkData2;
            } catch (RuntimeException e2) {
                e = e2;
                handleException(e);
                BulkData bulkData22 = (BulkData) LynxUsbUtil.makePlaceholderValue(new BulkData(new LynxGetBulkInputDataResponse(this), true));
                this.lastBulkData = bulkData22;
                return bulkData22;
            } catch (LynxNackException e3) {
                e = e3;
                handleException(e);
                BulkData bulkData222 = (BulkData) LynxUsbUtil.makePlaceholderValue(new BulkData(new LynxGetBulkInputDataResponse(this), true));
                this.lastBulkData = bulkData222;
                return bulkData222;
            }
        }
    }

    public BulkCachingMode getBulkCachingMode() {
        warnIfClosed();
        return this.bulkCachingMode;
    }

    public void setBulkCachingMode(BulkCachingMode bulkCachingMode2) {
        warnIfClosed();
        synchronized (this.bulkCachingLock) {
            if (bulkCachingMode2 == BulkCachingMode.OFF) {
                clearBulkCache();
            }
            this.bulkCachingMode = bulkCachingMode2;
        }
    }

    public void clearBulkCache() {
        warnIfClosed();
        synchronized (this.bulkCachingLock) {
            for (List<LynxDekaInterfaceCommand<?>> clear : this.bulkCachingHistory.values()) {
                clear.clear();
            }
            this.lastBulkData = null;
        }
    }

    /* access modifiers changed from: package-private */
    public BulkData recordBulkCachingCommandIntent(LynxDekaInterfaceCommand<?> lynxDekaInterfaceCommand) {
        warnIfClosed();
        return recordBulkCachingCommandIntent(lynxDekaInterfaceCommand, InspectionState.NO_VERSION);
    }

    /* access modifiers changed from: package-private */
    public BulkData recordBulkCachingCommandIntent(LynxDekaInterfaceCommand<?> lynxDekaInterfaceCommand, String str) {
        BulkData bulkData;
        warnIfClosed();
        synchronized (this.bulkCachingLock) {
            List list = this.bulkCachingHistory.get(str);
            if (this.bulkCachingMode == BulkCachingMode.AUTO) {
                if (list == null) {
                    list = new ArrayList();
                    this.bulkCachingHistory.put(str, list);
                }
                Iterator it = list.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        break;
                    }
                    LynxDekaInterfaceCommand lynxDekaInterfaceCommand2 = (LynxDekaInterfaceCommand) it.next();
                    if (lynxDekaInterfaceCommand2.getDestModuleAddress() == lynxDekaInterfaceCommand.getDestModuleAddress() && lynxDekaInterfaceCommand2.getCommandNumber() == lynxDekaInterfaceCommand.getCommandNumber() && Arrays.equals(lynxDekaInterfaceCommand2.toPayloadByteArray(), lynxDekaInterfaceCommand.toPayloadByteArray())) {
                        clearBulkCache();
                        break;
                    }
                }
            }
            if (this.lastBulkData == null) {
                getBulkData();
            }
            if (this.bulkCachingMode == BulkCachingMode.AUTO) {
                list.add(lynxDekaInterfaceCommand);
            }
            bulkData = this.lastBulkData;
        }
        return bulkData;
    }

    public void failSafe() throws RobotCoreException, InterruptedException, LynxNackException {
        warnIfClosed();
        new LynxFailSafeCommand(this).send();
        forgetLastKnown();
    }

    public void attemptFailSafeAndIgnoreErrors() {
        try {
            failSafe();
        } catch (LynxNackException | RobotCoreException | InterruptedException | RuntimeException unused) {
        }
    }

    public void enablePhoneCharging(boolean z) throws RobotCoreException, InterruptedException, LynxNackException {
        warnIfClosed();
        new LynxPhoneChargeControlCommand(this, z).send();
    }

    public boolean isPhoneChargingEnabled() throws RobotCoreException, InterruptedException, LynxNackException {
        warnIfClosed();
        return ((LynxPhoneChargeQueryResponse) new LynxPhoneChargeQueryCommand(this).sendReceive()).isChargeEnabled();
    }

    public double getCurrent(CurrentUnit currentUnit) {
        warnIfClosed();
        try {
            return currentUnit.convert((double) ((LynxGetADCResponse) new LynxGetADCCommand(this, LynxGetADCCommand.Channel.BATTERY_CURRENT, LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue(), CurrentUnit.MILLIAMPS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public double getGpioBusCurrent(CurrentUnit currentUnit) {
        warnIfClosed();
        try {
            return currentUnit.convert((double) ((LynxGetADCResponse) new LynxGetADCCommand(this, LynxGetADCCommand.Channel.GPIO_CURRENT, LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue(), CurrentUnit.MILLIAMPS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public double getI2cBusCurrent(CurrentUnit currentUnit) {
        warnIfClosed();
        try {
            return currentUnit.convert((double) ((LynxGetADCResponse) new LynxGetADCCommand(this, LynxGetADCCommand.Channel.I2C_BUS_CURRENT, LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue(), CurrentUnit.MILLIAMPS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public double getInputVoltage(VoltageUnit voltageUnit) {
        warnIfClosed();
        try {
            return voltageUnit.convert((double) ((LynxGetADCResponse) new LynxGetADCCommand(this, LynxGetADCCommand.Channel.BATTERY_MONITOR, LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue(), VoltageUnit.MILLIVOLTS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public double getAuxiliaryVoltage(VoltageUnit voltageUnit) {
        warnIfClosed();
        try {
            return voltageUnit.convert((double) ((LynxGetADCResponse) new LynxGetADCCommand(this, LynxGetADCCommand.Channel.FIVE_VOLT_MONITOR, LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue(), VoltageUnit.MILLIVOLTS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public double getTemperature(TempUnit tempUnit) {
        warnIfClosed();
        try {
            return tempUnit.fromCelsius(((double) ((LynxGetADCResponse) new LynxGetADCCommand(this, LynxGetADCCommand.Channel.CONTROLLER_TEMPERATURE, LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue()) / 10.0d);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public LynxModuleImuType getImuType() {
        warnIfClosed();
        if (!LynxConstants.revHubTypeCanHaveImu(getRevProductNumber())) {
            return LynxModuleImuType.NONE;
        }
        LynxI2cDeviceSynch createLynxI2cDeviceSynch = LynxFirmwareVersionManager.createLynxI2cDeviceSynch(AppUtil.getDefContext(), this, 0);
        try {
            LynxModuleImuType lynxModuleImuType = LynxModuleImuType.NONE;
            createLynxI2cDeviceSynch.setI2cAddress(BNO055IMU.I2CADDR_DEFAULT);
            if (BNO055Util.imuIsPresent(createLynxI2cDeviceSynch, false)) {
                lynxModuleImuType = LynxModuleImuType.BNO055;
            }
            if (lynxModuleImuType == LynxModuleImuType.NONE && this.lynxUsbDevice.getSerialNumber().isEmbedded() && isParent() && BHI260IMU.imuIsPresent(createLynxI2cDeviceSynch)) {
                lynxModuleImuType = LynxModuleImuType.BHI260;
            }
            if (lynxModuleImuType == LynxModuleImuType.NONE && this.isNotResponding) {
                lynxModuleImuType = LynxModuleImuType.UNKNOWN;
            }
            return lynxModuleImuType;
        } finally {
            createLynxI2cDeviceSynch.close();
        }
    }

    public enum DebugGroup {
        NONE(0),
        MAIN(1),
        TOHOST(2),
        FROMHOST(3),
        ADC(4),
        PWMSERVO(5),
        MODULELED(6),
        DIGITALIO(7),
        I2C(8),
        MOTOR0(9),
        MOTOR1(10),
        MOTOR2(11),
        MOTOR3(12);
        
        public final byte bVal;

        private DebugGroup(int i) {
            this.bVal = (byte) i;
        }

        public static DebugGroup fromInt(int i) {
            for (DebugGroup debugGroup : values()) {
                if (debugGroup.bVal == ((byte) i)) {
                    return debugGroup;
                }
            }
            return NONE;
        }
    }

    public enum DebugVerbosity {
        OFF(0),
        LOW(1),
        MEDIUM(2),
        HIGH(3);
        
        public final byte bVal;

        private DebugVerbosity(int i) {
            this.bVal = (byte) i;
        }

        public static DebugVerbosity fromInt(int i) {
            for (DebugVerbosity debugVerbosity : values()) {
                if (debugVerbosity.bVal == ((byte) i)) {
                    return debugVerbosity;
                }
            }
            return OFF;
        }
    }

    public void setDebug(DebugGroup debugGroup, DebugVerbosity debugVerbosity) throws InterruptedException {
        warnIfClosed();
        try {
            new LynxSetDebugLogLevelCommand(this, debugGroup, debugVerbosity).send();
        } catch (LynxNackException | RuntimeException e) {
            handleException(e);
        }
    }

    public <T> T acquireI2cLockWhile(Supplier<T> supplier) throws InterruptedException, RobotCoreException, LynxNackException {
        T t;
        warnIfClosed();
        synchronized (this.i2cLock) {
            t = supplier.get();
        }
        return t;
    }

    public void acquireNetworkTransmissionLock(LynxMessage lynxMessage) throws InterruptedException {
        warnIfClosed();
        this.lynxUsbDevice.acquireNetworkTransmissionLock(lynxMessage);
    }

    public void releaseNetworkTransmissionLock(LynxMessage lynxMessage) throws InterruptedException {
        warnIfClosed();
        this.lynxUsbDevice.releaseNetworkTransmissionLock(lynxMessage);
    }

    public void sendCommand(LynxMessage lynxMessage) throws InterruptedException, LynxUnsupportedCommandException {
        warnIfClosed();
        if (!lynxMessage.isDangerous() || !OpModeManagerImpl.shouldPreventDangerousHardwareAccess()) {
            lynxMessage.setMessageNumber(getNewMessageNumber());
            int messageNumber = lynxMessage.getMessageNumber();
            lynxMessage.setSerialization(new LynxDatagram(lynxMessage));
            boolean z = lynxMessage.isAckable() || lynxMessage.isResponseExpected();
            this.unfinishedCommands.put(Integer.valueOf(messageNumber), (LynxRespondable) lynxMessage);
            this.lynxUsbDevice.transmit(lynxMessage);
            if (!z) {
                finishedWithMessage(lynxMessage);
                return;
            }
            return;
        }
        ((LynxRespondable) lynxMessage).onNackReceived(new LynxNack((LynxModuleIntf) this, (LynxNack.ReasonCode) LynxNack.StandardReasonCode.CANCELLED_FOR_SAFETY));
    }

    public void retransmit(LynxMessage lynxMessage) throws InterruptedException {
        warnIfClosed();
        RobotLog.vv(TAG, "retransmitting: mod=%d cmd=0x%02x msg#=%d ref#=%d ", Integer.valueOf(getModuleAddress()), Integer.valueOf(lynxMessage.getCommandNumber()), Integer.valueOf(lynxMessage.getMessageNumber()), Integer.valueOf(lynxMessage.getReferenceNumber()));
        this.lynxUsbDevice.transmit(lynxMessage);
    }

    public void finishedWithMessage(LynxMessage lynxMessage) {
        if (LynxUsbDeviceImpl.DEBUG_LOG_DATAGRAMS_FINISH) {
            RobotLog.vv(TAG, "finishing mod=%d msg#=%d", Integer.valueOf(lynxMessage.getModuleAddress()), Integer.valueOf(lynxMessage.getMessageNumber()));
        }
        this.unfinishedCommands.remove(Integer.valueOf(lynxMessage.getMessageNumber()));
        lynxMessage.forgetSerialization();
    }

    public void pretendFinishExtantCommands() throws InterruptedException {
        warnIfClosed();
        for (LynxRespondable pretendFinish : this.unfinishedCommands.values()) {
            pretendFinish.pretendFinish();
        }
    }

    public void onIncomingDatagramReceived(LynxDatagram lynxDatagram) {
        warnIfClosed();
        noteDatagramReceived();
        try {
            MessageClassAndCtor messageClassAndCtor = this.commandClasses.get(Integer.valueOf(lynxDatagram.getCommandNumber()));
            if (messageClassAndCtor != null) {
                if (lynxDatagram.isResponse()) {
                    messageClassAndCtor = responseClasses.get(messageClassAndCtor.clazz);
                }
                if (messageClassAndCtor != null) {
                    LynxMessage lynxMessage = (LynxMessage) messageClassAndCtor.ctor.newInstance(new Object[]{this});
                    lynxMessage.setSerialization(lynxDatagram);
                    lynxMessage.loadFromSerialization();
                    if (LynxUsbDeviceImpl.DEBUG_LOG_MESSAGES) {
                        RobotLog.vv(TAG, "rec'd: mod=%d cmd=0x%02x(%s) msg#=%d ref#=%d", Integer.valueOf(lynxDatagram.getSourceModuleAddress()), Integer.valueOf(lynxDatagram.getPacketId()), lynxMessage.getClass().getSimpleName(), Integer.valueOf(lynxMessage.getMessageNumber()), Integer.valueOf(lynxMessage.getReferenceNumber()));
                    }
                    if (!lynxMessage.isAck()) {
                        if (!lynxMessage.isNack()) {
                            LynxRespondable lynxRespondable = this.unfinishedCommands.get(Integer.valueOf(lynxDatagram.getReferenceNumber()));
                            if (lynxRespondable != null) {
                                Assert.assertTrue(lynxMessage.isResponse());
                                lynxRespondable.onResponseReceived((LynxResponse) lynxMessage);
                                finishedWithMessage(lynxRespondable);
                                return;
                            }
                            RobotLog.ee(TAG, "unable to find originating command for packetid=0x%04x msg#=%d ref#=%d", Integer.valueOf(lynxDatagram.getPacketId()), Integer.valueOf(lynxDatagram.getMessageNumber()), Integer.valueOf(lynxDatagram.getReferenceNumber()));
                            return;
                        }
                    }
                    LynxRespondable lynxRespondable2 = this.unfinishedCommands.get(Integer.valueOf(lynxDatagram.getReferenceNumber()));
                    if (lynxRespondable2 != null) {
                        if (lynxMessage.isNack()) {
                            lynxRespondable2.onNackReceived((LynxNack) lynxMessage);
                        } else {
                            lynxRespondable2.onAckReceived((LynxAck) lynxMessage);
                        }
                        finishedWithMessage(lynxRespondable2);
                        return;
                    }
                    RobotLog.ee(TAG, "unable to find originating LynxRespondable for mod=%d msg#=%d ref#=%d", Integer.valueOf(lynxDatagram.getSourceModuleAddress()), Integer.valueOf(lynxDatagram.getMessageNumber()), Integer.valueOf(lynxDatagram.getReferenceNumber()));
                    return;
                }
                return;
            }
            RobotLog.ee(TAG, "no command class known for command=0x%02x", Integer.valueOf(lynxDatagram.getCommandNumber()));
        } catch (IllegalAccessException | InstantiationException | RuntimeException | InvocationTargetException e) {
            RobotLog.ee(TAG, e, "internal error in LynxModule.noteIncomingDatagramReceived()");
        }
    }

    public void abandonUnfinishedCommands() {
        warnIfClosed();
        this.unfinishedCommands.clear();
    }

    /* access modifiers changed from: protected */
    public void nackUnfinishedCommands() {
        warnIfClosed();
        while (!this.unfinishedCommands.isEmpty()) {
            for (LynxRespondable next : this.unfinishedCommands.values()) {
                RobotLog.vv(TAG, "force-nacking unfinished command=%s mod=%d msg#=%d", next.getClass().getSimpleName(), Integer.valueOf(next.getModuleAddress()), Integer.valueOf(next.getMessageNumber()));
                next.onNackReceived(new LynxNack((LynxModuleIntf) this, (LynxNack.ReasonCode) next.isResponseExpected() ? LynxNack.StandardReasonCode.ABANDONED_WAITING_FOR_RESPONSE : LynxNack.StandardReasonCode.ABANDONED_WAITING_FOR_ACK));
                finishedWithMessage(next);
            }
        }
    }
}

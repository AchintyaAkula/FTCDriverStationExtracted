package com.qualcomm.hardware.lynx.commands.core;

import com.qualcomm.hardware.lynx.LynxModuleIntf;
import com.qualcomm.hardware.lynx.commands.LynxDatagram;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorPIDFControlLoopCoefficientsCommand;
import java.nio.ByteBuffer;

public class LynxGetMotorPIDFControlLoopCoefficientsResponse extends LynxDekaInterfaceResponse {
    private static final int cbPayload = 17;
    private int d = 0;
    private int f = 0;
    private int i = 0;
    private byte motorControlAlgorithm = 0;
    private int p = 0;

    public LynxGetMotorPIDFControlLoopCoefficientsResponse(LynxModuleIntf lynxModuleIntf) {
        super(lynxModuleIntf);
    }

    public int getP() {
        return this.p;
    }

    public int getI() {
        return this.i;
    }

    public int getD() {
        return this.d;
    }

    public int getF() {
        return this.f;
    }

    public LynxSetMotorPIDFControlLoopCoefficientsCommand.InternalMotorControlAlgorithm getInternalMotorControlAlgorithm() {
        return LynxSetMotorPIDFControlLoopCoefficientsCommand.InternalMotorControlAlgorithm.fromByte(this.motorControlAlgorithm);
    }

    public byte[] toPayloadByteArray() {
        ByteBuffer order = ByteBuffer.allocate(17).order(LynxDatagram.LYNX_ENDIAN);
        order.putInt(this.p);
        order.putInt(this.i);
        order.putInt(this.d);
        order.putInt(this.f);
        order.put(this.motorControlAlgorithm);
        return order.array();
    }

    public void fromPayloadByteArray(byte[] bArr) {
        ByteBuffer order = ByteBuffer.wrap(bArr).order(LynxDatagram.LYNX_ENDIAN);
        this.p = order.getInt();
        this.i = order.getInt();
        this.d = order.getInt();
        this.f = order.getInt();
        this.motorControlAlgorithm = order.get();
    }
}

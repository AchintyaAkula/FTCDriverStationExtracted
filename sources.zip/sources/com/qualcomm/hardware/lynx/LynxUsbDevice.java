package com.qualcomm.hardware.lynx;

import com.qualcomm.hardware.lynx.commands.LynxMessage;
import com.qualcomm.robotcore.eventloop.SyncdDevice;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.Engagable;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.LynxModuleDescription;
import com.qualcomm.robotcore.hardware.LynxModuleMetaList;
import com.qualcomm.robotcore.hardware.RobotCoreLynxUsbDevice;
import com.qualcomm.robotcore.hardware.usb.RobotUsbDevice;
import com.qualcomm.robotcore.hardware.usb.RobotUsbModule;
import com.qualcomm.robotcore.util.GlobalWarningSource;
import com.qualcomm.robotcore.util.SerialNumber;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.firstinspires.ftc.robotcore.external.Consumer;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.ui.ProgressParameters;

public interface LynxUsbDevice extends RobotUsbModule, GlobalWarningSource, RobotCoreLynxUsbDevice, HardwareDevice, SyncdDevice, Engagable {
    void acquireNetworkTransmissionLock(LynxMessage lynxMessage) throws InterruptedException;

    void changeModuleAddress(LynxModule lynxModule, int i, Runnable runnable);

    LynxModuleMetaList discoverModules(boolean z) throws RobotCoreException, InterruptedException;

    void failSafe();

    LynxUsbDeviceImpl getDelegationTarget();

    LynxModule getOrAddModule(LynxModuleDescription lynxModuleDescription) throws RobotCoreException, InterruptedException;

    RobotUsbDevice getRobotUsbDevice();

    boolean isSystemSynthetic();

    SystemOperationHandle keepConnectedModuleAliveForSystemOperations(int i, int i2) throws RobotCoreException, InterruptedException;

    void noteMissingModule(int i, String str);

    void performSystemOperationOnConnectedModule(int i, int i2, Consumer<LynxModule> consumer, int i3, TimeUnit timeUnit) throws RobotCoreException, InterruptedException, TimeoutException;

    void performSystemOperationOnParentModule(int i, Consumer<LynxModule> consumer, int i2, TimeUnit timeUnit) throws RobotCoreException, InterruptedException, TimeoutException;

    void releaseNetworkTransmissionLock(LynxMessage lynxMessage) throws InterruptedException;

    void removeConfiguredModule(LynxModule lynxModule);

    void setSystemSynthetic(boolean z);

    boolean setupControlHubEmbeddedModule() throws InterruptedException, RobotCoreException;

    void transmit(LynxMessage lynxMessage) throws InterruptedException;

    RobotCoreCommandList.LynxFirmwareUpdateResp updateFirmware(RobotCoreCommandList.FWImage fWImage, String str, Consumer<ProgressParameters> consumer);

    public static class SystemOperationHandle {
        protected volatile boolean closed = false;
        protected final LynxUsbDeviceImpl lynxUsb;
        protected final LynxModule module;
        protected final LynxModule parentModule;

        protected SystemOperationHandle(LynxUsbDeviceImpl lynxUsbDeviceImpl, LynxModule lynxModule, LynxModule lynxModule2) {
            this.lynxUsb = lynxUsbDeviceImpl;
            this.module = lynxModule;
            this.parentModule = lynxModule2;
            synchronized (lynxUsbDeviceImpl.sysOpStartStopLock) {
                lynxModule2.systemOperationCounter++;
                lynxModule.systemOperationCounter++;
            }
        }

        public void performSystemOperation(Consumer<LynxModule> consumer, int i, TimeUnit timeUnit) throws RobotCoreException, InterruptedException, TimeoutException {
            if (!this.closed) {
                this.lynxUsb.internalPerformSysOp(this.module, this.parentModule, consumer, i, timeUnit);
                return;
            }
            throw new RuntimeException("Attempted to perform system operation on closed handle");
        }

        public void close() {
            this.closed = true;
            synchronized (this.lynxUsb.sysOpStartStopLock) {
                this.parentModule.systemOperationCounter--;
                this.lynxUsb.internalCloseLynxModuleIfUnused(this.parentModule);
                this.module.systemOperationCounter--;
                this.lynxUsb.internalCloseLynxModuleIfUnused(this.module);
            }
        }

        public SerialNumber getLynxModuleSerialNumber() {
            return this.module.getModuleSerialNumber();
        }

        public boolean wrapsModule(LynxModule lynxModule) {
            return lynxModule == this.module;
        }

        public boolean wrapsSameModule(SystemOperationHandle systemOperationHandle) {
            return systemOperationHandle.module == this.module;
        }
    }
}

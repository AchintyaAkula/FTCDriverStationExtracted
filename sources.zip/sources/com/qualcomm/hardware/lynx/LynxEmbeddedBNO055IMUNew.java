package com.qualcomm.hardware.lynx;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055IMUNew;
import com.qualcomm.robotcore.R;
import com.qualcomm.robotcore.hardware.ControlSystem;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;

@DeviceProperties(builtIn = true, compatibleControlSystems = {ControlSystem.REV_HUB}, description = "@string/lynx_embedded_imu_description", name = "@string/lynx_embedded_bno055_imu_name", xmlTag = "LynxEmbeddedIMU")
@I2cDeviceType
public class LynxEmbeddedBNO055IMUNew extends BNO055IMUNew {
    public LynxEmbeddedBNO055IMUNew(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z, BNO055IMU.I2CADDR_DEFAULT);
    }

    public String getDeviceName() {
        return AppUtil.getDefContext().getString(R.string.lynx_embedded_bno055_imu_name);
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.Lynx;
    }
}

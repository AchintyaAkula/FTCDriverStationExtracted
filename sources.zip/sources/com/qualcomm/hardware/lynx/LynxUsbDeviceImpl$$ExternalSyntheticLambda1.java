package com.qualcomm.hardware.lynx;

import java.util.function.IntFunction;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxUsbDeviceImpl$$ExternalSyntheticLambda1 implements IntFunction {
    public final Object apply(int i) {
        return LynxUsbDeviceImpl.lambda$discoverModules$2(i);
    }
}

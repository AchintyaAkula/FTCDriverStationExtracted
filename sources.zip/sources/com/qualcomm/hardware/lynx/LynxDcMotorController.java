package com.qualcomm.hardware.lynx;

import android.content.Context;
import com.qualcomm.hardware.R;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.lynx.commands.LynxCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetADCCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetADCResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetBulkInputDataCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetBulkInputDataResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorChannelCurrentAlertLevelCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorChannelCurrentAlertLevelResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorChannelEnableCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorChannelEnableResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorChannelModeCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorChannelModeResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorConstantPowerCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorConstantPowerResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorEncoderPositionCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorEncoderPositionResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorPIDControlLoopCoefficientsCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorPIDControlLoopCoefficientsResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorPIDFControlLoopCoefficientsCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorPIDFControlLoopCoefficientsResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorTargetPositionCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorTargetPositionResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorTargetVelocityCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxGetMotorTargetVelocityResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxIsMotorAtTargetCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxIsMotorAtTargetResponse;
import com.qualcomm.hardware.lynx.commands.core.LynxResetMotorEncoderCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorChannelCurrentAlertLevelCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorChannelEnableCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorChannelModeCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorConstantPowerCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorPIDControlLoopCoefficientsCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorPIDFControlLoopCoefficientsCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorTargetPositionCommand;
import com.qualcomm.hardware.lynx.commands.core.LynxSetMotorTargetVelocityCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxNack;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.exception.TargetPositionNotSetException;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorController;
import com.qualcomm.robotcore.hardware.DcMotorControllerEx;
import com.qualcomm.robotcore.hardware.MotorControlAlgorithm;
import com.qualcomm.robotcore.hardware.PIDCoefficients;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.configuration.ExpansionHubMotorControllerParamsState;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;
import com.qualcomm.robotcore.util.LastKnown;
import com.qualcomm.robotcore.util.Range;
import com.qualcomm.robotcore.util.RobotLog;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;
import org.firstinspires.ftc.robotcore.internal.system.Misc;

public class LynxDcMotorController extends LynxController implements DcMotorController, DcMotorControllerEx {
    protected static boolean DEBUG = false;
    public static final String TAG = "LynxMotor";
    public static final int apiMotorFirst = 0;
    public static final int apiMotorLast = 3;
    public static final double apiPowerFirst = -1.0d;
    public static final double apiPowerLast = 1.0d;
    protected final MotorProperties[] motors = new MotorProperties[4];

    /* access modifiers changed from: protected */
    public String getTag() {
        return TAG;
    }

    protected class MotorProperties {
        Map<DcMotor.RunMode, ExpansionHubMotorControllerParamsState> desiredPIDParams = new ConcurrentHashMap();
        MotorConfigurationType internalMotorType = null;
        LastKnown<Double> lastKnownCurrentAlert = new LastKnown<>();
        LastKnown<Boolean> lastKnownEnable = new LastKnown<>();
        LastKnown<DcMotor.RunMode> lastKnownMode = new LastKnown<>();
        LastKnown<Double> lastKnownPower = new LastKnown<>();
        LastKnown<Integer> lastKnownTargetPosition = new LastKnown<>();
        LastKnown<DcMotor.ZeroPowerBehavior> lastKnownZeroPowerBehavior = new LastKnown<>();
        MotorConfigurationType motorType = MotorConfigurationType.getUnspecifiedMotorType();
        Map<DcMotor.RunMode, ExpansionHubMotorControllerParamsState> originalPIDParams = new ConcurrentHashMap();

        protected MotorProperties() {
        }
    }

    public LynxDcMotorController(Context context, LynxModule lynxModule) throws RobotCoreException, InterruptedException {
        super(context, lynxModule);
        int i = 0;
        while (true) {
            MotorProperties[] motorPropertiesArr = this.motors;
            if (i < motorPropertiesArr.length) {
                motorPropertiesArr[i] = new MotorProperties();
                i++;
            } else {
                finishConstruction();
                return;
            }
        }
    }

    public void initializeHardware() throws RobotCoreException, InterruptedException {
        runWithoutEncoders();
        floatHardware();
        forgetLastKnown();
        for (int i = 0; i <= 3; i++) {
            updateMotorParams(i);
        }
        reportPIDFControlLoopCoefficients();
    }

    /* access modifiers changed from: protected */
    public void doHook() {
        forgetLastKnown();
    }

    /* access modifiers changed from: protected */
    public void doUnhook() {
        forgetLastKnown();
    }

    public void forgetLastKnown() {
        for (MotorProperties motorProperties : this.motors) {
            motorProperties.lastKnownMode.invalidate();
            motorProperties.lastKnownPower.invalidate();
            motorProperties.lastKnownTargetPosition.invalidate();
            motorProperties.lastKnownZeroPowerBehavior.invalidate();
            motorProperties.lastKnownEnable.invalidate();
        }
    }

    public String getDeviceName() {
        return this.context.getString(R.string.lynxDcMotorControllerDisplayName);
    }

    public synchronized void setMotorEnable(int i) {
        validateMotor(i);
        internalSetMotorEnable(i, true);
    }

    public synchronized void setMotorDisable(int i) {
        validateMotor(i);
        internalSetMotorEnable(i, false);
    }

    /* access modifiers changed from: package-private */
    public void internalSetMotorEnable(int i, boolean z) {
        if (this.motors[i].lastKnownEnable.updateValue(Boolean.valueOf(z))) {
            LynxSetMotorChannelEnableCommand lynxSetMotorChannelEnableCommand = new LynxSetMotorChannelEnableCommand(getModule(), i, z);
            try {
                if (DEBUG) {
                    RobotLog.vv(TAG, "setMotorEnable mod=%d motor=%d enable=%s", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), Boolean.valueOf(z).toString());
                }
                lynxSetMotorChannelEnableCommand.send();
            } catch (LynxNackException e) {
                if (e.getNack().getNackReasonCode() != LynxNack.StandardReasonCode.MOTOR_NOT_CONFIG_BEFORE_ENABLED) {
                    handleException(e);
                    return;
                }
                throw new TargetPositionNotSetException();
            } catch (InterruptedException | RuntimeException e2) {
                handleException(e2);
            }
        }
    }

    public synchronized boolean isMotorEnabled(int i) {
        validateMotor(i);
        Boolean value = this.motors[i].lastKnownEnable.getValue();
        if (value != null) {
            return value.booleanValue();
        }
        try {
            Boolean valueOf = Boolean.valueOf(((LynxGetMotorChannelEnableResponse) new LynxGetMotorChannelEnableCommand(getModule(), i).sendReceive()).isEnabled());
            this.motors[i].lastKnownEnable.setValue(valueOf);
            return valueOf.booleanValue();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Boolean) LynxUsbUtil.makePlaceholderValue(true)).booleanValue();
        }
    }

    public synchronized void resetDeviceConfigurationForOpMode(int i) {
        validateMotor(i);
        this.motors[i].desiredPIDParams.remove(DcMotor.RunMode.RUN_TO_POSITION);
        this.motors[i].desiredPIDParams.remove(DcMotor.RunMode.RUN_USING_ENCODER);
        if (this.motors[i].originalPIDParams.containsKey(DcMotor.RunMode.RUN_TO_POSITION)) {
            this.motors[i].desiredPIDParams.put(DcMotor.RunMode.RUN_TO_POSITION, this.motors[i].originalPIDParams.get(DcMotor.RunMode.RUN_TO_POSITION));
        }
        if (this.motors[i].originalPIDParams.containsKey(DcMotor.RunMode.RUN_USING_ENCODER)) {
            this.motors[i].desiredPIDParams.put(DcMotor.RunMode.RUN_USING_ENCODER, this.motors[i].originalPIDParams.get(DcMotor.RunMode.RUN_USING_ENCODER));
        }
        if (this.motors[i].internalMotorType != null) {
            setMotorType(i, this.motors[i].internalMotorType);
        } else {
            updateMotorParams(i);
        }
    }

    public synchronized MotorConfigurationType getMotorType(int i) {
        validateMotor(i);
        return this.motors[i].motorType;
    }

    public synchronized void setMotorType(int i, MotorConfigurationType motorConfigurationType) {
        validateMotor(i);
        this.motors[i].motorType = motorConfigurationType;
        if (this.motors[i].internalMotorType == null) {
            this.motors[i].internalMotorType = motorConfigurationType;
        }
        if (motorConfigurationType.hasExpansionHubVelocityParams()) {
            rememberPIDParams(i, motorConfigurationType.getHubVelocityParams());
        }
        if (motorConfigurationType.hasExpansionHubPositionParams()) {
            rememberPIDParams(i, motorConfigurationType.getHubPositionParams());
        }
        updateMotorParams(i);
    }

    /* access modifiers changed from: protected */
    public void rememberPIDParams(int i, ExpansionHubMotorControllerParamsState expansionHubMotorControllerParamsState) {
        this.motors[i].desiredPIDParams.put(expansionHubMotorControllerParamsState.mode, expansionHubMotorControllerParamsState);
    }

    /* access modifiers changed from: protected */
    public void updateMotorParams(int i) {
        for (ExpansionHubMotorControllerParamsState next : this.motors[i].desiredPIDParams.values()) {
            if (!next.isDefault()) {
                internalSetPIDFCoefficients(i, next.mode, next.getPidfCoefficients());
            }
        }
    }

    /* access modifiers changed from: protected */
    public int getDefaultMaxMotorSpeed(int i) {
        return this.motors[i].motorType.getAchieveableMaxTicksPerSecondRounded();
    }

    public synchronized void setMotorMode(int i, DcMotor.RunMode runMode) {
        LynxCommand lynxCommand;
        validateMotor(i);
        if (!this.motors[i].lastKnownMode.isValue(runMode)) {
            Double nonTimedValue = this.motors[i].lastKnownPower.getNonTimedValue();
            if (nonTimedValue == null) {
                nonTimedValue = Double.valueOf(internalGetMotorPower(i));
            }
            DcMotor.ZeroPowerBehavior zeroPowerBehavior = DcMotor.ZeroPowerBehavior.UNKNOWN;
            if (runMode == DcMotor.RunMode.STOP_AND_RESET_ENCODER) {
                internalSetMotorPower(i, LynxServoController.apiPositionFirst);
                lynxCommand = new LynxResetMotorEncoderCommand(getModule(), i);
            } else {
                zeroPowerBehavior = internalGetZeroPowerBehavior(i);
                lynxCommand = new LynxSetMotorChannelModeCommand(getModule(), i, runMode, zeroPowerBehavior);
            }
            try {
                if (DEBUG) {
                    RobotLog.vv(TAG, "setMotorChannelMode: mod=%d motor=%d mode=%s power=%f zero=%s", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), runMode.toString(), nonTimedValue, zeroPowerBehavior.toString());
                }
                lynxCommand.send();
                this.motors[i].lastKnownMode.setValue(runMode);
                internalSetMotorPower(i, nonTimedValue.doubleValue(), true);
            } catch (LynxNackException | InterruptedException | RuntimeException e) {
                handleException(e);
            }
        }
    }

    public synchronized DcMotor.RunMode getMotorMode(int i) {
        validateMotor(i);
        return internalGetPublicMotorMode(i);
    }

    /* access modifiers changed from: protected */
    public DcMotor.RunMode internalGetPublicMotorMode(int i) {
        DcMotor.RunMode value = this.motors[i].lastKnownMode.getValue();
        if (value != null) {
            return value;
        }
        if (this.motors[i].lastKnownMode.getNonTimedValue() == DcMotor.RunMode.STOP_AND_RESET_ENCODER) {
            return DcMotor.RunMode.STOP_AND_RESET_ENCODER;
        }
        try {
            DcMotor.RunMode mode = ((LynxGetMotorChannelModeResponse) new LynxGetMotorChannelModeCommand(getModule(), i).sendReceive()).getMode();
            this.motors[i].lastKnownMode.setValue(mode);
            return mode;
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return (DcMotor.RunMode) LynxUsbUtil.makePlaceholderValue(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
    }

    /* access modifiers changed from: protected */
    public DcMotor.RunMode internalGetMotorChannelMode(int i) {
        DcMotor.RunMode value = this.motors[i].lastKnownMode.getValue();
        if (value != null && value != DcMotor.RunMode.STOP_AND_RESET_ENCODER) {
            return value;
        }
        try {
            return ((LynxGetMotorChannelModeResponse) new LynxGetMotorChannelModeCommand(getModule(), i).sendReceive()).getMode();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return (DcMotor.RunMode) LynxUsbUtil.makePlaceholderValue(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
    }

    public synchronized void setMotorPower(int i, double d) {
        validateMotor(i);
        internalSetMotorPower(i, d);
    }

    public synchronized double getMotorPower(int i) {
        validateMotor(i);
        return internalGetMotorPower(i);
    }

    /* access modifiers changed from: package-private */
    public DcMotor.ZeroPowerBehavior internalGetZeroPowerBehavior(int i) {
        DcMotor.ZeroPowerBehavior value = this.motors[i].lastKnownZeroPowerBehavior.getValue();
        if (value != null) {
            return value;
        }
        try {
            DcMotor.ZeroPowerBehavior zeroPowerBehavior = ((LynxGetMotorChannelModeResponse) new LynxGetMotorChannelModeCommand(getModule(), i).sendReceive()).getZeroPowerBehavior();
            this.motors[i].lastKnownZeroPowerBehavior.setValue(zeroPowerBehavior);
            return zeroPowerBehavior;
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return (DcMotor.ZeroPowerBehavior) LynxUsbUtil.makePlaceholderValue(DcMotor.ZeroPowerBehavior.BRAKE);
        }
    }

    /* access modifiers changed from: package-private */
    public void internalSetZeroPowerBehavior(int i, DcMotor.ZeroPowerBehavior zeroPowerBehavior) {
        if (this.motors[i].lastKnownZeroPowerBehavior.updateValue(zeroPowerBehavior)) {
            LynxSetMotorChannelModeCommand lynxSetMotorChannelModeCommand = new LynxSetMotorChannelModeCommand(getModule(), i, internalGetMotorChannelMode(i), zeroPowerBehavior);
            try {
                if (DEBUG) {
                    RobotLog.vv(TAG, "setZeroBehavior mod=%d motor=%d zero=%s", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), zeroPowerBehavior.toString());
                }
                lynxSetMotorChannelModeCommand.send();
            } catch (LynxNackException | InterruptedException | RuntimeException e) {
                handleException(e);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void internalSetMotorPower(int i, double d) {
        internalSetMotorPower(i, d, false);
    }

    /* access modifiers changed from: package-private */
    public void internalSetMotorPower(int i, double d, boolean z) {
        int i2;
        LynxCommand lynxCommand;
        int i3 = i;
        double clip = Range.clip(d, -1.0d, 1.0d);
        if (this.motors[i3].lastKnownPower.updateValue(Double.valueOf(clip)) || z) {
            int i4 = AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode[internalGetPublicMotorMode(i).ordinal()];
            if (i4 == 1 || i4 == 2) {
                i2 = (int) (Math.signum(clip) * Range.scale(Math.abs(clip), LynxServoController.apiPositionFirst, 1.0d, LynxServoController.apiPositionFirst, (double) getDefaultMaxMotorSpeed(i)));
                lynxCommand = new LynxSetMotorTargetVelocityCommand(getModule(), i3, i2);
            } else if (i4 != 3) {
                lynxCommand = null;
                i2 = 0;
            } else {
                i2 = (int) Range.scale(clip, -1.0d, 1.0d, -32767.0d, 32767.0d);
                lynxCommand = new LynxSetMotorConstantPowerCommand(getModule(), i3, i2);
            }
            if (lynxCommand != null) {
                try {
                    if (DEBUG) {
                        RobotLog.vv(TAG, "setMotorPower: mod=%d motor=%d iPower=%d", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), Integer.valueOf(i2));
                    }
                    lynxCommand.send();
                    internalSetMotorEnable(i3, true);
                } catch (LynxNackException | InterruptedException | RuntimeException e) {
                    handleException(e);
                }
            }
        }
    }

    /* renamed from: com.qualcomm.hardware.lynx.LynxDcMotorController$1  reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode;

        /* JADX WARNING: Can't wrap try/catch for region: R(8:0|1|2|3|4|5|6|(3:7|8|10)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0028 */
        static {
            /*
                com.qualcomm.robotcore.hardware.DcMotor$RunMode[] r0 = com.qualcomm.robotcore.hardware.DcMotor.RunMode.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode = r0
                com.qualcomm.robotcore.hardware.DcMotor$RunMode r1 = com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_TO_POSITION     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = $SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode     // Catch:{ NoSuchFieldError -> 0x001d }
                com.qualcomm.robotcore.hardware.DcMotor$RunMode r1 = com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_USING_ENCODER     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = $SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.qualcomm.robotcore.hardware.DcMotor$RunMode r1 = com.qualcomm.robotcore.hardware.DcMotor.RunMode.RUN_WITHOUT_ENCODER     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r0 = $SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.qualcomm.robotcore.hardware.DcMotor$RunMode r1 = com.qualcomm.robotcore.hardware.DcMotor.RunMode.STOP_AND_RESET_ENCODER     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r2 = 4
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxDcMotorController.AnonymousClass1.<clinit>():void");
        }
    }

    /* access modifiers changed from: package-private */
    public double internalGetMotorPower(int i) {
        Double d;
        int i2 = i;
        Double value = this.motors[i2].lastKnownPower.getValue();
        if (value != null) {
            if (DEBUG) {
                RobotLog.vv(TAG, "getMotorPower(cached): mod=%d motor=%d power=%f", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), value);
            }
            return value.doubleValue();
        }
        try {
            int i3 = AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode[internalGetPublicMotorMode(i).ordinal()];
            if (i3 == 1 || i3 == 2) {
                int velocity = ((LynxGetMotorTargetVelocityResponse) new LynxGetMotorTargetVelocityCommand(getModule(), i2).sendReceive()).getVelocity();
                d = Double.valueOf(((double) Math.signum((float) velocity)) * Range.scale((double) Math.abs(velocity), LynxServoController.apiPositionFirst, (double) getDefaultMaxMotorSpeed(i), LynxServoController.apiPositionFirst, 1.0d));
                if (DEBUG) {
                    RobotLog.vv(TAG, "getMotorPower: mod=%d motor=%d velocity=%d power=%f", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), Integer.valueOf(velocity), d);
                }
            } else {
                int power = ((LynxGetMotorConstantPowerResponse) new LynxGetMotorConstantPowerCommand(getModule(), i2).sendReceive()).getPower();
                d = Double.valueOf(Range.scale((double) power, -32767.0d, 32767.0d, -1.0d, 1.0d));
                if (DEBUG) {
                    RobotLog.vv(TAG, "getMotorPower: mod=%d motor=%d iPower=%d power=%f", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), Integer.valueOf(power), d);
                }
            }
            Double valueOf = Double.valueOf(Range.clip(d.doubleValue(), -1.0d, 1.0d));
            this.motors[i2].lastKnownPower.setValue(valueOf);
            return valueOf.doubleValue();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return (double) ((Integer) LynxUsbUtil.makePlaceholderValue(0)).intValue();
        }
    }

    public synchronized boolean isBusy(int i) {
        validateMotor(i);
        LynxIsMotorAtTargetCommand lynxIsMotorAtTargetCommand = new LynxIsMotorAtTargetCommand(getModule(), i);
        if (getModule() instanceof LynxModule) {
            LynxModule lynxModule = (LynxModule) getModule();
            if (lynxModule.getBulkCachingMode() != LynxModule.BulkCachingMode.OFF) {
                return lynxModule.recordBulkCachingCommandIntent(lynxIsMotorAtTargetCommand).isMotorBusy(i);
            }
        }
        if (internalGetMotorChannelMode(i) != DcMotor.RunMode.RUN_TO_POSITION) {
            return false;
        }
        try {
            return !((LynxIsMotorAtTargetResponse) lynxIsMotorAtTargetCommand.sendReceive()).isAtTarget();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Boolean) LynxUsbUtil.makePlaceholderValue(false)).booleanValue();
        }
    }

    public synchronized void setMotorZeroPowerBehavior(int i, DcMotor.ZeroPowerBehavior zeroPowerBehavior) {
        validateMotor(i);
        if (zeroPowerBehavior != DcMotor.ZeroPowerBehavior.UNKNOWN) {
            internalSetZeroPowerBehavior(i, zeroPowerBehavior);
        } else {
            throw new IllegalArgumentException("zeroPowerBehavior may not be UNKNOWN");
        }
    }

    public synchronized DcMotor.ZeroPowerBehavior getMotorZeroPowerBehavior(int i) {
        validateMotor(i);
        return internalGetZeroPowerBehavior(i);
    }

    /* access modifiers changed from: protected */
    public synchronized void setMotorPowerFloat(int i) {
        validateMotor(i);
        internalSetZeroPowerBehavior(i, DcMotor.ZeroPowerBehavior.FLOAT);
        internalSetMotorPower(i, LynxServoController.apiPositionFirst);
    }

    public synchronized boolean getMotorPowerFloat(int i) {
        validateMotor(i);
        return internalGetZeroPowerBehavior(i) == DcMotor.ZeroPowerBehavior.FLOAT && internalGetMotorPower(i) == LynxServoController.apiPositionFirst;
    }

    public synchronized void setMotorTargetPosition(int i, int i2) {
        setMotorTargetPosition(i, i2, 5);
    }

    public synchronized void setMotorTargetPosition(int i, int i2, int i3) {
        validateMotor(i);
        try {
            new LynxSetMotorTargetPositionCommand(getModule(), i, i2, i3).send();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
        }
    }

    public synchronized int getMotorTargetPosition(int i) {
        validateMotor(i);
        try {
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Integer) LynxUsbUtil.makePlaceholderValue(0)).intValue();
        }
        return ((LynxGetMotorTargetPositionResponse) new LynxGetMotorTargetPositionCommand(getModule(), i).sendReceive()).getTarget();
    }

    public synchronized int getMotorCurrentPosition(int i) {
        validateMotor(i);
        LynxGetMotorEncoderPositionCommand lynxGetMotorEncoderPositionCommand = new LynxGetMotorEncoderPositionCommand(getModule(), i);
        if (getModule() instanceof LynxModule) {
            LynxModule lynxModule = (LynxModule) getModule();
            if (lynxModule.getBulkCachingMode() != LynxModule.BulkCachingMode.OFF) {
                return lynxModule.recordBulkCachingCommandIntent(lynxGetMotorEncoderPositionCommand).getMotorCurrentPosition(i);
            }
        }
        try {
            return ((LynxGetMotorEncoderPositionResponse) lynxGetMotorEncoderPositionCommand.sendReceive()).getPosition();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Integer) LynxUsbUtil.makePlaceholderValue(0)).intValue();
        }
    }

    public synchronized void setMotorVelocity(int i, double d) {
        int i2 = AnonymousClass1.$SwitchMap$com$qualcomm$robotcore$hardware$DcMotor$RunMode[getMotorMode(i).ordinal()];
        if (!(i2 == 1 || i2 == 2)) {
            setMotorMode(i, DcMotor.RunMode.RUN_USING_ENCODER);
        }
        validateMotor(i);
        int clip = Range.clip((int) Math.round(d), -32767, 32767);
        try {
            LynxSetMotorTargetVelocityCommand lynxSetMotorTargetVelocityCommand = new LynxSetMotorTargetVelocityCommand(getModule(), i, clip);
            if (DEBUG) {
                RobotLog.vv(TAG, "setMotorVelocity: mod=%d motor=%d iPower=%d", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), Integer.valueOf(clip));
            }
            lynxSetMotorTargetVelocityCommand.send();
            internalSetMotorEnable(i, true);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
        }
    }

    public synchronized void setMotorVelocity(int i, double d, AngleUnit angleUnit) {
        validateMotor(i);
        setMotorVelocity(i, this.motors[i].motorType.getTicksPerRev() * (UnnormalizedAngleUnit.DEGREES.fromUnit(angleUnit.getUnnormalized(), d) / 360.0d));
    }

    public synchronized double getMotorVelocity(int i) {
        validateMotor(i);
        return (double) internalGetMotorTicksPerSecond(i);
    }

    public synchronized double getMotorVelocity(int i, AngleUnit angleUnit) {
        validateMotor(i);
        return angleUnit.getUnnormalized().fromDegrees((((double) internalGetMotorTicksPerSecond(i)) / this.motors[i].motorType.getTicksPerRev()) * 360.0d);
    }

    /* access modifiers changed from: package-private */
    public int internalGetMotorTicksPerSecond(int i) {
        LynxGetBulkInputDataCommand lynxGetBulkInputDataCommand = new LynxGetBulkInputDataCommand(getModule());
        if (getModule() instanceof LynxModule) {
            LynxModule lynxModule = (LynxModule) getModule();
            if (lynxModule.getBulkCachingMode() != LynxModule.BulkCachingMode.OFF) {
                return lynxModule.recordBulkCachingCommandIntent(lynxGetBulkInputDataCommand, "motorVelocity" + i).getMotorVelocity(i);
            }
        }
        try {
            return ((LynxGetBulkInputDataResponse) lynxGetBulkInputDataCommand.sendReceive()).getVelocity(i);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Integer) LynxUsbUtil.makePlaceholderValue(0)).intValue();
        }
    }

    public void setPIDCoefficients(int i, DcMotor.RunMode runMode, PIDCoefficients pIDCoefficients) {
        setPIDFCoefficients(i, runMode, new PIDFCoefficients(pIDCoefficients));
    }

    public synchronized void setPIDFCoefficients(int i, DcMotor.RunMode runMode, PIDFCoefficients pIDFCoefficients) {
        validatePIDMode(i, runMode);
        validateMotor(i);
        DcMotor.RunMode migrate = runMode.migrate();
        rememberPIDParams(i, new ExpansionHubMotorControllerParamsState(migrate, pIDFCoefficients));
        if (!internalSetPIDFCoefficients(i, migrate, pIDFCoefficients)) {
            throw new UnsupportedOperationException(Misc.formatForUser("setting of pidf coefficents not supported: motor=%d mode=%s pidf=%s", Integer.valueOf(i), migrate, pIDFCoefficients));
        }
    }

    /* access modifiers changed from: protected */
    public boolean internalSetPIDFCoefficients(int i, DcMotor.RunMode runMode, PIDFCoefficients pIDFCoefficients) {
        boolean z;
        boolean handleException;
        if (!this.motors[i].originalPIDParams.containsKey(runMode)) {
            this.motors[i].originalPIDParams.put(runMode, new ExpansionHubMotorControllerParamsState(runMode, getPIDFCoefficients(i, runMode)));
        }
        int internalCoefficientFromExternal = LynxSetMotorPIDControlLoopCoefficientsCommand.internalCoefficientFromExternal(pIDFCoefficients.p);
        int internalCoefficientFromExternal2 = LynxSetMotorPIDControlLoopCoefficientsCommand.internalCoefficientFromExternal(pIDFCoefficients.i);
        int internalCoefficientFromExternal3 = LynxSetMotorPIDControlLoopCoefficientsCommand.internalCoefficientFromExternal(pIDFCoefficients.d);
        int internalCoefficientFromExternal4 = LynxSetMotorPIDControlLoopCoefficientsCommand.internalCoefficientFromExternal(pIDFCoefficients.f);
        if (runMode != DcMotor.RunMode.RUN_TO_POSITION || pIDFCoefficients.algorithm == MotorControlAlgorithm.LegacyPID || (pIDFCoefficients.i == LynxServoController.apiPositionFirst && pIDFCoefficients.d == LynxServoController.apiPositionFirst && pIDFCoefficients.f == LynxServoController.apiPositionFirst)) {
            z = true;
        } else {
            RobotLog.ww(TAG, "using unreasonable coefficients for RUN_TO_POSITION: setPIDFCoefficients(%d, %s, %s)", Integer.valueOf(i), runMode, pIDFCoefficients);
            z = false;
        }
        if (z) {
            if (getModule().isCommandSupported(LynxSetMotorPIDFControlLoopCoefficientsCommand.class)) {
                try {
                    new LynxSetMotorPIDFControlLoopCoefficientsCommand(getModule(), i, runMode, internalCoefficientFromExternal, internalCoefficientFromExternal2, internalCoefficientFromExternal3, internalCoefficientFromExternal4, LynxSetMotorPIDFControlLoopCoefficientsCommand.InternalMotorControlAlgorithm.fromExternal(pIDFCoefficients.algorithm)).send();
                } catch (LynxNackException | InterruptedException | RuntimeException e) {
                    handleException = handleException(e);
                }
            } else if (internalCoefficientFromExternal4 == 0 && pIDFCoefficients.algorithm == MotorControlAlgorithm.LegacyPID) {
                try {
                    new LynxSetMotorPIDControlLoopCoefficientsCommand(getModule(), i, runMode, internalCoefficientFromExternal, internalCoefficientFromExternal2, internalCoefficientFromExternal3).send();
                } catch (LynxNackException | InterruptedException | RuntimeException e2) {
                    handleException = handleException(e2);
                }
            } else {
                RobotLog.ww(TAG, "not supported: setPIDFCoefficients(%d, %s, %s)", Integer.valueOf(i), runMode, pIDFCoefficients);
                return false;
            }
        }
        return z;
        return handleException;
    }

    public synchronized PIDCoefficients getPIDCoefficients(int i, DcMotor.RunMode runMode) {
        validateMotor(i);
        try {
            LynxGetMotorPIDControlLoopCoefficientsResponse lynxGetMotorPIDControlLoopCoefficientsResponse = (LynxGetMotorPIDControlLoopCoefficientsResponse) new LynxGetMotorPIDControlLoopCoefficientsCommand(getModule(), i, runMode).sendReceive();
            return new PIDCoefficients(LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDControlLoopCoefficientsResponse.getP()), LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDControlLoopCoefficientsResponse.getI()), LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDControlLoopCoefficientsResponse.getD()));
        } catch (LynxNackException e) {
            if (e.getNack().getNackReasonCode() == LynxNack.StandardReasonCode.PARAM2) {
                PIDFCoefficients pIDFCoefficients = getPIDFCoefficients(i, runMode);
                return new PIDCoefficients(pIDFCoefficients.p, pIDFCoefficients.i, pIDFCoefficients.d);
            }
            handleException(e);
            return (PIDCoefficients) LynxUsbUtil.makePlaceholderValue(new PIDCoefficients());
        } catch (InterruptedException | RuntimeException e2) {
            handleException(e2);
            return (PIDCoefficients) LynxUsbUtil.makePlaceholderValue(new PIDCoefficients());
        }
    }

    public synchronized PIDFCoefficients getPIDFCoefficients(int i, DcMotor.RunMode runMode) {
        if (getModule().isCommandSupported(LynxGetMotorPIDFControlLoopCoefficientsCommand.class)) {
            validateMotor(i);
            try {
                LynxGetMotorPIDFControlLoopCoefficientsResponse lynxGetMotorPIDFControlLoopCoefficientsResponse = (LynxGetMotorPIDFControlLoopCoefficientsResponse) new LynxGetMotorPIDFControlLoopCoefficientsCommand(getModule(), i, runMode).sendReceive();
                return new PIDFCoefficients(LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDFControlLoopCoefficientsResponse.getP()), LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDFControlLoopCoefficientsResponse.getI()), LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDFControlLoopCoefficientsResponse.getD()), LynxSetMotorPIDControlLoopCoefficientsCommand.externalCoefficientFromInternal(lynxGetMotorPIDFControlLoopCoefficientsResponse.getF()), lynxGetMotorPIDFControlLoopCoefficientsResponse.getInternalMotorControlAlgorithm().toExternal());
            } catch (LynxNackException | InterruptedException | RuntimeException e) {
                handleException(e);
                return (PIDFCoefficients) LynxUsbUtil.makePlaceholderValue(new PIDFCoefficients());
            }
        } else {
            return new PIDFCoefficients(getPIDCoefficients(i, runMode));
        }
    }

    public double getMotorCurrent(int i, CurrentUnit currentUnit) {
        try {
            return currentUnit.convert((double) ((LynxGetADCResponse) new LynxGetADCCommand(getModule(), LynxGetADCCommand.Channel.motorCurrent(i), LynxGetADCCommand.Mode.ENGINEERING).sendReceive()).getValue(), CurrentUnit.MILLIAMPS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public double getMotorCurrentAlert(int i, CurrentUnit currentUnit) {
        Double value = this.motors[i].lastKnownCurrentAlert.getValue();
        if (value != null) {
            return currentUnit.convert(value.doubleValue(), CurrentUnit.MILLIAMPS);
        }
        try {
            double currentLimit = (double) ((LynxGetMotorChannelCurrentAlertLevelResponse) new LynxGetMotorChannelCurrentAlertLevelCommand(getModule(), i).sendReceive()).getCurrentLimit();
            this.motors[i].lastKnownCurrentAlert.setValue(Double.valueOf(currentLimit));
            return currentUnit.convert(currentLimit, CurrentUnit.MILLIAMPS);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Double) LynxUsbUtil.makePlaceholderValue(Double.valueOf(LynxServoController.apiPositionFirst))).doubleValue();
        }
    }

    public void setMotorCurrentAlert(int i, double d, CurrentUnit currentUnit) {
        try {
            new LynxSetMotorChannelCurrentAlertLevelCommand(getModule(), i, (int) Math.round(currentUnit.toMilliAmps(d))).send();
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
        }
    }

    public boolean isMotorOverCurrent(int i) {
        LynxGetBulkInputDataCommand lynxGetBulkInputDataCommand = new LynxGetBulkInputDataCommand(getModule());
        if (getModule() instanceof LynxModule) {
            LynxModule lynxModule = (LynxModule) getModule();
            if (lynxModule.getBulkCachingMode() != LynxModule.BulkCachingMode.OFF) {
                return lynxModule.recordBulkCachingCommandIntent(lynxGetBulkInputDataCommand, "motorOverCurrent" + i).isMotorOverCurrent(i);
            }
        }
        try {
            return ((LynxGetBulkInputDataResponse) lynxGetBulkInputDataCommand.sendReceive()).isOverCurrent(i);
        } catch (LynxNackException | InterruptedException | RuntimeException e) {
            handleException(e);
            return ((Boolean) LynxUsbUtil.makePlaceholderValue(false)).booleanValue();
        }
    }

    public void floatHardware() {
        for (int i = 0; i <= 3; i++) {
            setMotorPowerFloat(i);
        }
    }

    private void runWithoutEncoders() {
        for (int i = 0; i <= 3; i++) {
            setMotorMode(i, DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }
    }

    private void validateMotor(int i) {
        if (i < 0 || i > 3) {
            throw new IllegalArgumentException(String.format("motor %d is invalid; valid motors are %d..%d", new Object[]{Integer.valueOf(i), 0, 3}));
        }
    }

    private void validatePIDMode(int i, DcMotor.RunMode runMode) {
        if (!runMode.isPIDMode()) {
            throw new IllegalArgumentException(String.format("motor %d: mode %s is invalid as PID Mode", new Object[]{Integer.valueOf(i), runMode}));
        }
    }

    private void reportPIDFControlLoopCoefficients() throws RobotCoreException, InterruptedException {
        reportPIDFControlLoopCoefficients(DcMotor.RunMode.RUN_TO_POSITION);
        reportPIDFControlLoopCoefficients(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    private void reportPIDFControlLoopCoefficients(DcMotor.RunMode runMode) throws RobotCoreException, InterruptedException {
        if (DEBUG) {
            for (int i = 0; i <= 3; i++) {
                PIDFCoefficients pIDFCoefficients = getPIDFCoefficients(i, runMode);
                RobotLog.vv(TAG, "mod=%d motor=%d mode=%s p=%f i=%f d=%f f=%f alg=%s", Integer.valueOf(getModuleAddress()), Integer.valueOf(i), runMode.toString(), Double.valueOf(pIDFCoefficients.p), Double.valueOf(pIDFCoefficients.i), Double.valueOf(pIDFCoefficients.d), Double.valueOf(pIDFCoefficients.f), pIDFCoefficients.algorithm);
            }
        }
    }

    /* access modifiers changed from: protected */
    public int getModuleAddress() {
        return getModule().getModuleAddress();
    }
}

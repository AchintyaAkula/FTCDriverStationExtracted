package com.qualcomm.hardware.lynx;

import android.content.Context;
import com.qualcomm.hardware.HardwareFactory;
import com.qualcomm.hardware.R;
import com.qualcomm.hardware.lynx.LynxUsbDevice;
import com.qualcomm.hardware.lynx.commands.LynxDatagram;
import com.qualcomm.hardware.lynx.commands.LynxMessage;
import com.qualcomm.hardware.lynx.commands.standard.LynxDiscoveryCommand;
import com.qualcomm.hardware.lynx.commands.standard.LynxDiscoveryResponse;
import com.qualcomm.robotcore.eventloop.SyncdDevice;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.LynxModuleDescription;
import com.qualcomm.robotcore.hardware.LynxModuleImuType;
import com.qualcomm.robotcore.hardware.LynxModuleMeta;
import com.qualcomm.robotcore.hardware.LynxModuleMetaList;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.hardware.usb.RobotArmingStateNotifier;
import com.qualcomm.robotcore.hardware.usb.RobotUsbDevice;
import com.qualcomm.robotcore.hardware.usb.RobotUsbManager;
import com.qualcomm.robotcore.hardware.usb.RobotUsbModule;
import com.qualcomm.robotcore.hardware.usb.ftdi.RobotUsbDeviceFtdi;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.IncludedFirmwareFileInfo;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import com.qualcomm.robotcore.util.ThreadPool;
import com.qualcomm.robotcore.util.TypeConversion;
import com.qualcomm.robotcore.util.Util;
import com.qualcomm.robotcore.util.WeakReferenceSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.firstinspires.ftc.robotcore.external.Consumer;
import org.firstinspires.ftc.robotcore.internal.hardware.TimeWindow;
import org.firstinspires.ftc.robotcore.internal.hardware.android.AndroidBoard;
import org.firstinspires.ftc.robotcore.internal.hardware.usb.ArmableUsbDevice;
import org.firstinspires.ftc.robotcore.internal.network.RobotCoreCommandList;
import org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.Assert;
import org.firstinspires.ftc.robotcore.internal.ui.ProgressParameters;
import org.firstinspires.ftc.robotcore.internal.usb.exception.RobotUsbDeviceClosedException;
import org.firstinspires.ftc.robotcore.internal.usb.exception.RobotUsbException;
import org.firstinspires.ftc.robotcore.internal.usb.exception.RobotUsbFTDIException;
import org.firstinspires.ftc.robotcore.internal.usb.exception.RobotUsbUnspecifiedException;

public class LynxUsbDeviceImpl extends ArmableUsbDevice implements LynxUsbDevice {
    public static boolean DEBUG_LOG_DATAGRAMS = false;
    public static boolean DEBUG_LOG_DATAGRAMS_FINISH = false;
    public static boolean DEBUG_LOG_DATAGRAMS_LOCK = false;
    public static boolean DEBUG_LOG_MESSAGES = false;
    protected static final String SEPARATOR = " / ";
    public static final String TAG = "LynxUsb";
    protected static final int cbusBothAsserted = 0;
    protected static final int cbusMask = 3;
    protected static final int cbusNProg = 2;
    protected static final int cbusNReset = 1;
    protected static final int cbusNeitherAsserted = 3;
    protected static final int cbusProgAsserted = 1;
    protected static final int cbusResetAsserted = 2;
    protected static final LynxCommExceptionHandler exceptionHandler = new LynxCommExceptionHandler(TAG);
    protected static final WeakReferenceSet<LynxUsbDeviceImpl> extantDevices = new WeakReferenceSet<>();
    protected static final int msCbusWiggle = 75;
    protected static final int msNetworkTransmissionLockAcquisitionTimeMax = 500;
    protected static final int msResetRecovery = 200;
    protected final ConcurrentHashMap<Integer, LynxModuleMeta> discoveredModules = new ConcurrentHashMap<>();
    protected final Object engageLock = new Object();
    protected boolean hasShutdownAbnormally = false;
    protected ExecutorService incomingDatagramPoller = null;
    protected boolean isEngaged = true;
    protected boolean isSystemSynthetic = false;
    protected final ConcurrentHashMap<Integer, LynxModule> knownModules = new ConcurrentHashMap<>();
    protected final ConcurrentHashMap<Integer, LynxModule> knownModulesChanging = new ConcurrentHashMap<>();
    protected final LynxFirmwareUpdater lynxFirmwareUpdater = new LynxFirmwareUpdater(this);
    protected final ConcurrentHashMap<Integer, String> missingModules = new ConcurrentHashMap<>();
    protected final MessageKeyedLock networkTransmissionLock = new MessageKeyedLock("lynx xmit lock", 500);
    protected boolean resetAttempted = false;
    protected final Set<Object> runningSysOpTrackers = new HashSet();
    protected final Object sysOpStartStopLock = new Object();
    protected boolean wasPollingWhenEngaged = true;

    public LynxUsbDeviceImpl getDelegationTarget() {
        return this;
    }

    public RobotUsbModule getOwner() {
        return this;
    }

    public int getVersion() {
        return 1;
    }

    public void resetDeviceConfigurationForOpMode() {
    }

    public void setOwner(RobotUsbModule robotUsbModule) {
    }

    /* access modifiers changed from: protected */
    public String getTag() {
        return TAG;
    }

    public static ArmableUsbDevice.OpenRobotUsbDevice createUsbOpener(RobotUsbManager robotUsbManager, SerialNumber serialNumber) {
        return new LynxUsbDeviceImpl$$ExternalSyntheticLambda5(robotUsbManager, serialNumber);
    }

    static /* synthetic */ RobotUsbDevice lambda$createUsbOpener$0(RobotUsbManager robotUsbManager, SerialNumber serialNumber) throws RobotCoreException, InterruptedException {
        RobotUsbDevice robotUsbDevice = null;
        try {
            RobotUsbDevice openUsbDevice = LynxUsbUtil.openUsbDevice(true, robotUsbManager, serialNumber);
            if (openUsbDevice.getUsbIdentifiers().isLynxDevice()) {
                openUsbDevice.setDeviceType(DeviceManager.UsbDeviceType.LYNX_USB_DEVICE);
                return openUsbDevice;
            }
            openUsbDevice.close();
            String format = String.format(Locale.US, "Supposed Lynx USB device (serial number %s) does not have expected IDs", new Object[]{serialNumber});
            RobotLog.ee(TAG, format);
            throw new RobotCoreException(format);
        } catch (RobotCoreException | RuntimeException e) {
            if (robotUsbDevice != null) {
                robotUsbDevice.close();
            }
            throw e;
        }
    }

    protected LynxUsbDeviceImpl(Context context, SerialNumber serialNumber, SyncdDevice.Manager manager, RobotUsbManager robotUsbManager) {
        super(context, serialNumber, manager, createUsbOpener(robotUsbManager, serialNumber));
        extantDevices.add(this);
        finishConstruction();
    }

    public static LynxUsbDevice findOrCreateAndArm(Context context, SerialNumber serialNumber, SyncdDevice.Manager manager, RobotUsbManager robotUsbManager) throws RobotCoreException, InterruptedException {
        WeakReferenceSet<LynxUsbDeviceImpl> weakReferenceSet = extantDevices;
        synchronized (weakReferenceSet) {
            Iterator<LynxUsbDeviceImpl> it = weakReferenceSet.iterator();
            while (it.hasNext()) {
                LynxUsbDeviceImpl next = it.next();
                if (next.getSerialNumber().equals((Object) serialNumber) && next.getArmingState() != RobotArmingStateNotifier.ARMINGSTATE.CLOSED) {
                    next.addRef();
                    RobotLog.vv(TAG, "using existing [%s]: 0x%08x", serialNumber, Integer.valueOf(next.hashCode()));
                    LynxUsbDeviceDelegate lynxUsbDeviceDelegate = new LynxUsbDeviceDelegate(next);
                    return lynxUsbDeviceDelegate;
                }
            }
            LynxUsbDeviceImpl lynxUsbDeviceImpl = new LynxUsbDeviceImpl(context, serialNumber, manager, robotUsbManager);
            RobotLog.vv(TAG, "creating new [%s]: 0x%08x", serialNumber, Integer.valueOf(lynxUsbDeviceImpl.hashCode()));
            lynxUsbDeviceImpl.armOrPretend();
            LynxUsbDeviceDelegate lynxUsbDeviceDelegate2 = new LynxUsbDeviceDelegate(lynxUsbDeviceImpl);
            return lynxUsbDeviceDelegate2;
        }
    }

    public boolean isSystemSynthetic() {
        return this.isSystemSynthetic;
    }

    public void setSystemSynthetic(boolean z) {
        this.isSystemSynthetic = z;
    }

    /* access modifiers changed from: protected */
    public void doClose() {
        WeakReferenceSet<LynxUsbDeviceImpl> weakReferenceSet = extantDevices;
        synchronized (weakReferenceSet) {
            super.doClose();
            weakReferenceSet.remove(this);
        }
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.Lynx;
    }

    public String getDeviceName() {
        return this.context.getString(R.string.moduleDisplayNameLynxUsbDevice);
    }

    public String getConnectionInfo() {
        return "USB " + getSerialNumber();
    }

    public SyncdDevice.ShutdownReason getShutdownReason() {
        RobotUsbDevice robotUsbDevice = this.robotUsbDevice;
        if (this.hasShutdownAbnormally || robotUsbDevice == null || !robotUsbDevice.isOpen()) {
            return SyncdDevice.ShutdownReason.ABNORMAL;
        }
        return SyncdDevice.ShutdownReason.NORMAL;
    }

    /* access modifiers changed from: protected */
    public boolean hasShutdownAbnormally() {
        return getShutdownReason() != SyncdDevice.ShutdownReason.NORMAL;
    }

    public synchronized void engage() {
        synchronized (this.engageLock) {
            if (!this.isEngaged) {
                if (this.wasPollingWhenEngaged && isArmed()) {
                    startPollingForIncomingDatagrams();
                }
                for (LynxModule engage : getKnownModules()) {
                    engage.engage();
                }
                this.isEngaged = true;
            }
        }
    }

    public synchronized void disengage() {
        synchronized (this.engageLock) {
            if (this.isEngaged) {
                this.isEngaged = false;
                for (LynxModule disengage : getKnownModules()) {
                    disengage.disengage();
                }
                this.wasPollingWhenEngaged = stopPollingForIncomingDatagrams();
            }
        }
    }

    public synchronized boolean isEngaged() {
        boolean z;
        synchronized (this.engageLock) {
            z = this.isEngaged;
        }
        return z;
    }

    /* access modifiers changed from: protected */
    public void doPretend() {
        RobotLog.vv(TAG, "doPretend() serial=%s", this.serialNumber);
    }

    /* access modifiers changed from: protected */
    public void armDevice(RobotUsbDevice robotUsbDevice) throws RobotCoreException, InterruptedException {
        synchronized (this.armingLock) {
            RobotLog.vv(TAG, "armDevice() serial=%s...", this.serialNumber);
            Assert.assertTrue(robotUsbDevice != null);
            this.robotUsbDevice = robotUsbDevice;
            if (!this.resetAttempted) {
                this.resetAttempted = true;
                resetDevice(this.robotUsbDevice);
            }
            this.hasShutdownAbnormally = false;
            if (this.syncdDeviceManager != null) {
                this.syncdDeviceManager.registerSyncdDevice(this);
            }
            resetNetworkTransmissionLock();
            startPollingForIncomingDatagrams();
            pingAndQueryKnownInterfaces();
            startRegularPinging();
            RobotLog.vv(TAG, "...done armDevice()");
        }
    }

    /* access modifiers changed from: protected */
    public void disarmDevice() throws InterruptedException {
        synchronized (this.armingLock) {
            RobotLog.vv(TAG, "disarmDevice() serial=%s...", this.serialNumber);
            Assert.assertFalse(isArmedOrArming());
            pretendFinishExtantCommands();
            abandonUnfinishedCommands();
            stopRegularPinging();
            stopPollingForIncomingDatagrams();
            if (this.robotUsbDevice != null) {
                this.robotUsbDevice.close();
                this.robotUsbDevice = null;
            }
            resetNetworkTransmissionLock();
            if (this.syncdDeviceManager != null) {
                this.syncdDeviceManager.unregisterSyncdDevice(this);
            }
            RobotLog.vv(TAG, "...done disarmDevice()");
        }
    }

    /* access modifiers changed from: protected */
    public void doCloseFromArmed() throws RobotCoreException, InterruptedException {
        failSafe();
        closeModules();
        super.doCloseFromArmed();
    }

    /* access modifiers changed from: protected */
    public void doCloseFromOther() throws RobotCoreException, InterruptedException {
        closeModules();
        super.doCloseFromOther();
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        java.lang.Thread.currentThread().interrupt();
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x0056 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void closeModules() {
        /*
            r4 = this;
            java.util.Collection r0 = r4.getKnownModules()
            java.util.Iterator r0 = r0.iterator()
        L_0x0008:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x002b
            java.lang.Object r1 = r0.next()
            com.qualcomm.hardware.lynx.LynxModule r1 = (com.qualcomm.hardware.lynx.LynxModule) r1
            r1.failSafe()     // Catch:{ RobotCoreException -> 0x0022, LynxNackException -> 0x0020, InterruptedException -> 0x0018 }
            goto L_0x0008
        L_0x0018:
            java.lang.Thread r1 = java.lang.Thread.currentThread()
            r1.interrupt()
            goto L_0x0008
        L_0x0020:
            r1 = move-exception
            goto L_0x0023
        L_0x0022:
            r1 = move-exception
        L_0x0023:
            java.lang.String r2 = "LynxUsb"
            java.lang.String r3 = "Failed to put module into failsafe mode before closing"
            com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r2, (java.lang.Throwable) r1, (java.lang.String) r3)
            goto L_0x0008
        L_0x002b:
            java.lang.Object r0 = r4.sysOpStartStopLock
            monitor-enter(r0)
        L_0x002e:
            java.util.Set<java.lang.Object> r1 = r4.runningSysOpTrackers     // Catch:{ InterruptedException -> 0x0056 }
            int r1 = r1.size()     // Catch:{ InterruptedException -> 0x0056 }
            if (r1 <= 0) goto L_0x003c
            java.lang.Object r1 = r4.sysOpStartStopLock     // Catch:{ InterruptedException -> 0x0056 }
            r1.wait()     // Catch:{ InterruptedException -> 0x0056 }
            goto L_0x002e
        L_0x003c:
            java.util.Collection r1 = r4.getKnownModules()     // Catch:{ InterruptedException -> 0x0056 }
            java.util.Iterator r1 = r1.iterator()     // Catch:{ InterruptedException -> 0x0056 }
        L_0x0044:
            boolean r2 = r1.hasNext()     // Catch:{ InterruptedException -> 0x0056 }
            if (r2 == 0) goto L_0x005d
            java.lang.Object r2 = r1.next()     // Catch:{ InterruptedException -> 0x0056 }
            com.qualcomm.hardware.lynx.LynxModule r2 = (com.qualcomm.hardware.lynx.LynxModule) r2     // Catch:{ InterruptedException -> 0x0056 }
            r2.close()     // Catch:{ InterruptedException -> 0x0056 }
            goto L_0x0044
        L_0x0054:
            r1 = move-exception
            goto L_0x005f
        L_0x0056:
            java.lang.Thread r1 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0054 }
            r1.interrupt()     // Catch:{ all -> 0x0054 }
        L_0x005d:
            monitor-exit(r0)     // Catch:{ all -> 0x0054 }
            return
        L_0x005f:
            monitor-exit(r0)     // Catch:{ all -> 0x0054 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxUsbDeviceImpl.closeModules():void");
    }

    public void failSafe() {
        for (LynxModule next : getKnownModules()) {
            try {
                if (next.isUserModule()) {
                    next.failSafe();
                }
            } catch (LynxNackException | RobotCoreException | InterruptedException e) {
                exceptionHandler.handleException(e);
            }
        }
    }

    /* access modifiers changed from: protected */
    public Collection<LynxModule> getKnownModules() {
        Collection<LynxModule> values;
        synchronized (this.knownModules) {
            values = this.knownModules.values();
        }
        return values;
    }

    /* access modifiers changed from: protected */
    public LynxModule findKnownModule(int i) {
        LynxModule lynxModule;
        synchronized (this.knownModules) {
            lynxModule = this.knownModules.get(Integer.valueOf(i));
            if (lynxModule == null) {
                lynxModule = this.knownModulesChanging.get(Integer.valueOf(i));
            }
        }
        return lynxModule;
    }

    public List<String> getAllModuleFirmwareVersions() {
        ArrayList arrayList = new ArrayList();
        for (LynxModule next : getKnownModules()) {
            next.getFirmwareVersionString();
            arrayList.add(next.getModuleAddress() + SEPARATOR + next.getFirmwareVersionString());
        }
        return arrayList;
    }

    public void changeModuleAddress(LynxModule lynxModule, int i, Runnable runnable) {
        int moduleAddress = lynxModule.getModuleAddress();
        if (i != moduleAddress) {
            synchronized (this.knownModules) {
                this.knownModulesChanging.put(Integer.valueOf(i), lynxModule);
            }
            runnable.run();
            synchronized (this.knownModules) {
                this.knownModules.put(Integer.valueOf(i), lynxModule);
                this.knownModules.remove(Integer.valueOf(moduleAddress));
                this.knownModulesChanging.remove(Integer.valueOf(i));
            }
        }
    }

    public void noteMissingModule(int i, String str) {
        this.missingModules.put(Integer.valueOf(i), str);
        RobotLog.ee(TAG, "module #%d did not connect at startup: skip adding its hardware items to the hardwareMap", Integer.valueOf(i));
    }

    /* access modifiers changed from: protected */
    public String composeGlobalWarning() {
        ArrayList arrayList = new ArrayList();
        String composeGlobalWarning = super.composeGlobalWarning();
        arrayList.add(composeGlobalWarning);
        if (composeGlobalWarning.isEmpty()) {
            for (String str : this.missingModules.values()) {
                arrayList.add(AppUtil.getDefContext().getString(R.string.errorExpansionHubIsMissing, new Object[]{str}));
            }
            for (LynxModule globalWarnings : getKnownModules()) {
                arrayList.addAll(globalWarnings.getGlobalWarnings());
            }
        }
        return RobotLog.combineGlobalWarnings(arrayList);
    }

    public LynxModule getOrAddModule(LynxModuleDescription lynxModuleDescription) throws InterruptedException, RobotCoreException {
        boolean z;
        LynxModule lynxModule;
        synchronized (this.sysOpStartStopLock) {
            int i = lynxModuleDescription.address;
            RobotLog.vv(TAG, "addConfiguredModule() module#=%d", Integer.valueOf(i));
            synchronized (this.knownModules) {
                z = true;
                if (!this.knownModules.containsKey(Integer.valueOf(i))) {
                    lynxModule = new LynxModule(this, i, lynxModuleDescription.isParent, lynxModuleDescription.isUserModule);
                    if (lynxModuleDescription.isSystemSynthetic) {
                        lynxModule.setSystemSynthetic(true);
                    }
                    this.knownModules.put(Integer.valueOf(i), lynxModule);
                } else {
                    lynxModule = this.knownModules.get(Integer.valueOf(i));
                    RobotLog.vv(TAG, "addConfiguredModule() module#=%d: already exists", Integer.valueOf(i));
                    if (lynxModuleDescription.isUserModule && !lynxModule.isUserModule()) {
                        RobotLog.vv(TAG, "Converting module #%d to a user module", Integer.valueOf(lynxModule.getModuleAddress()));
                        lynxModule.setUserModule(true);
                    }
                    if (lynxModuleDescription.isUserModule && lynxModuleDescription.isSystemSynthetic && !lynxModule.isSystemSynthetic()) {
                        lynxModule.setSystemSynthetic(true);
                    }
                    if (lynxModuleDescription.isParent != lynxModule.isParent()) {
                        RobotLog.ww(TAG, "addConfiguredModule(): The active configuration file may be incorrect about whether Expansion Hub %d is the parent", Integer.valueOf(lynxModule.getModuleAddress()));
                    }
                    z = false;
                }
            }
            if (z) {
                try {
                    lynxModule.pingAndQueryKnownInterfacesAndEtc();
                } catch (RobotCoreException | InterruptedException | RuntimeException e) {
                    RobotLog.logExceptionHeader(TAG, e, "addConfiguredModule() module#=%d", Integer.valueOf(lynxModule.getModuleAddress()));
                    RobotLog.ee(TAG, "Unable to communicate with REV Hub #%d at robot startup. A Robot Restart will be required to use this hub.", Integer.valueOf(lynxModule.getModuleAddress()));
                    lynxModule.close();
                    synchronized (this.knownModules) {
                        this.knownModules.remove(Integer.valueOf(lynxModule.getModuleAddress()));
                        throw e;
                    }
                }
            }
        }
        return lynxModule;
    }

    public void removeConfiguredModule(LynxModule lynxModule) {
        synchronized (this.knownModules) {
            if (lynxModule.getModuleAddress() != 0 && this.knownModules.remove(Integer.valueOf(lynxModule.getModuleAddress())) == null) {
                RobotLog.ee(TAG, "removeConfiguredModule(): mod#=%d wasn't there", Integer.valueOf(lynxModule.getModuleAddress()));
            }
        }
    }

    public void performSystemOperationOnParentModule(int i, Consumer<LynxModule> consumer, int i2, TimeUnit timeUnit) throws RobotCoreException, InterruptedException, TimeoutException {
        performSystemOperationOnConnectedModule(i, i, consumer, i2, timeUnit);
    }

    public void performSystemOperationOnConnectedModule(int i, int i2, Consumer<LynxModule> consumer, int i3, TimeUnit timeUnit) throws RobotCoreException, InterruptedException, TimeoutException {
        LynxModule lynxModule;
        LynxModuleDescription build = new LynxModuleDescription.Builder(i2, true).build();
        LynxModuleDescription build2 = new LynxModuleDescription.Builder(i, false).build();
        LynxModule orAddModule = getOrAddModule(build);
        if (i == i2) {
            lynxModule = orAddModule;
        } else {
            lynxModule = getOrAddModule(build2);
        }
        internalPerformSysOp(lynxModule, orAddModule, consumer, i3, timeUnit);
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void internalPerformSysOp(com.qualcomm.hardware.lynx.LynxModule r6, com.qualcomm.hardware.lynx.LynxModule r7, org.firstinspires.ftc.robotcore.external.Consumer<com.qualcomm.hardware.lynx.LynxModule> r8, int r9, java.util.concurrent.TimeUnit r10) throws com.qualcomm.robotcore.exception.RobotCoreException, java.lang.InterruptedException, java.util.concurrent.TimeoutException {
        /*
            r5 = this;
            java.lang.String r0 = "Received NACK when pinging LynxModule: "
            java.lang.Object r1 = new java.lang.Object
            r1.<init>()
            java.lang.Object r2 = r5.sysOpStartStopLock
            monitor-enter(r2)
            r3 = 0
            r6.ping(r3)     // Catch:{ LynxNackException -> 0x00c9 }
            int r0 = r7.systemOperationCounter     // Catch:{ all -> 0x00c7 }
            r3 = 1
            int r0 = r0 + r3
            r7.systemOperationCounter = r0     // Catch:{ all -> 0x00c7 }
            int r0 = r6.systemOperationCounter     // Catch:{ all -> 0x00c7 }
            int r0 = r0 + r3
            r6.systemOperationCounter = r0     // Catch:{ all -> 0x00c7 }
            java.util.Set<java.lang.Object> r0 = r5.runningSysOpTrackers     // Catch:{ all -> 0x00c7 }
            r0.add(r1)     // Catch:{ all -> 0x00c7 }
            monitor-exit(r2)     // Catch:{ all -> 0x00c7 }
            if (r8 == 0) goto L_0x00a5
            r0 = 0
            java.util.concurrent.ExecutorService r2 = com.qualcomm.robotcore.util.ThreadPool.getDefault()     // Catch:{ TimeoutException -> 0x007e, ExecutionException -> 0x0036 }
            com.qualcomm.hardware.lynx.LynxUsbDeviceImpl$$ExternalSyntheticLambda3 r4 = new com.qualcomm.hardware.lynx.LynxUsbDeviceImpl$$ExternalSyntheticLambda3     // Catch:{ TimeoutException -> 0x007e, ExecutionException -> 0x0036 }
            r4.<init>(r8, r6)     // Catch:{ TimeoutException -> 0x007e, ExecutionException -> 0x0036 }
            java.util.concurrent.Future r0 = r2.submit(r4)     // Catch:{ TimeoutException -> 0x007e, ExecutionException -> 0x0036 }
            long r8 = (long) r9     // Catch:{ TimeoutException -> 0x007e, ExecutionException -> 0x0036 }
            r0.get(r8, r10)     // Catch:{ TimeoutException -> 0x007e, ExecutionException -> 0x0036 }
            goto L_0x00a5
        L_0x0034:
            r8 = move-exception
            goto L_0x0083
        L_0x0036:
            r8 = move-exception
            java.lang.Throwable r8 = r8.getCause()     // Catch:{ all -> 0x0034 }
            boolean r9 = r8 instanceof java.lang.InterruptedException     // Catch:{ all -> 0x0034 }
            if (r9 != 0) goto L_0x0076
            boolean r9 = r8 instanceof com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x0034 }
            if (r9 != 0) goto L_0x0073
            boolean r9 = r8 instanceof java.lang.RuntimeException     // Catch:{ all -> 0x0034 }
            if (r9 != 0) goto L_0x0070
            boolean r9 = r8 instanceof java.util.concurrent.TimeoutException     // Catch:{ all -> 0x0034 }
            if (r9 != 0) goto L_0x006d
            java.lang.Object r9 = r5.sysOpStartStopLock
            monitor-enter(r9)
            java.util.Set<java.lang.Object> r8 = r5.runningSysOpTrackers     // Catch:{ all -> 0x006a }
            r8.remove(r1)     // Catch:{ all -> 0x006a }
            java.lang.Object r8 = r5.sysOpStartStopLock     // Catch:{ all -> 0x006a }
            r8.notifyAll()     // Catch:{ all -> 0x006a }
            int r8 = r7.systemOperationCounter     // Catch:{ all -> 0x006a }
            int r8 = r8 - r3
            r7.systemOperationCounter = r8     // Catch:{ all -> 0x006a }
            r5.internalCloseLynxModuleIfUnused(r7)     // Catch:{ all -> 0x006a }
            int r7 = r6.systemOperationCounter     // Catch:{ all -> 0x006a }
            int r7 = r7 - r3
            r6.systemOperationCounter = r7     // Catch:{ all -> 0x006a }
            r5.internalCloseLynxModuleIfUnused(r6)     // Catch:{ all -> 0x006a }
            monitor-exit(r9)     // Catch:{ all -> 0x006a }
            goto L_0x00c3
        L_0x006a:
            r6 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x006a }
            throw r6
        L_0x006d:
            java.util.concurrent.TimeoutException r8 = (java.util.concurrent.TimeoutException) r8     // Catch:{ all -> 0x0034 }
            throw r8     // Catch:{ all -> 0x0034 }
        L_0x0070:
            java.lang.RuntimeException r8 = (java.lang.RuntimeException) r8     // Catch:{ all -> 0x0034 }
            throw r8     // Catch:{ all -> 0x0034 }
        L_0x0073:
            com.qualcomm.robotcore.exception.RobotCoreException r8 = (com.qualcomm.robotcore.exception.RobotCoreException) r8     // Catch:{ all -> 0x0034 }
            throw r8     // Catch:{ all -> 0x0034 }
        L_0x0076:
            com.qualcomm.robotcore.exception.RobotCoreException r9 = new com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x0034 }
            java.lang.String r10 = "Background thread was interrupted while performing system operation"
            r9.<init>((java.lang.String) r10, (java.lang.Throwable) r8)     // Catch:{ all -> 0x0034 }
            throw r9     // Catch:{ all -> 0x0034 }
        L_0x007e:
            r8 = move-exception
            r0.cancel(r3)     // Catch:{ all -> 0x0034 }
            throw r8     // Catch:{ all -> 0x0034 }
        L_0x0083:
            java.lang.Object r9 = r5.sysOpStartStopLock
            monitor-enter(r9)
            java.util.Set<java.lang.Object> r10 = r5.runningSysOpTrackers     // Catch:{ all -> 0x00a2 }
            r10.remove(r1)     // Catch:{ all -> 0x00a2 }
            java.lang.Object r10 = r5.sysOpStartStopLock     // Catch:{ all -> 0x00a2 }
            r10.notifyAll()     // Catch:{ all -> 0x00a2 }
            int r10 = r7.systemOperationCounter     // Catch:{ all -> 0x00a2 }
            int r10 = r10 - r3
            r7.systemOperationCounter = r10     // Catch:{ all -> 0x00a2 }
            r5.internalCloseLynxModuleIfUnused(r7)     // Catch:{ all -> 0x00a2 }
            int r7 = r6.systemOperationCounter     // Catch:{ all -> 0x00a2 }
            int r7 = r7 - r3
            r6.systemOperationCounter = r7     // Catch:{ all -> 0x00a2 }
            r5.internalCloseLynxModuleIfUnused(r6)     // Catch:{ all -> 0x00a2 }
            monitor-exit(r9)     // Catch:{ all -> 0x00a2 }
            throw r8
        L_0x00a2:
            r6 = move-exception
            monitor-exit(r9)     // Catch:{ all -> 0x00a2 }
            throw r6
        L_0x00a5:
            java.lang.Object r8 = r5.sysOpStartStopLock
            monitor-enter(r8)
            java.util.Set<java.lang.Object> r9 = r5.runningSysOpTrackers     // Catch:{ all -> 0x00c4 }
            r9.remove(r1)     // Catch:{ all -> 0x00c4 }
            java.lang.Object r9 = r5.sysOpStartStopLock     // Catch:{ all -> 0x00c4 }
            r9.notifyAll()     // Catch:{ all -> 0x00c4 }
            int r9 = r7.systemOperationCounter     // Catch:{ all -> 0x00c4 }
            int r9 = r9 - r3
            r7.systemOperationCounter = r9     // Catch:{ all -> 0x00c4 }
            r5.internalCloseLynxModuleIfUnused(r7)     // Catch:{ all -> 0x00c4 }
            int r7 = r6.systemOperationCounter     // Catch:{ all -> 0x00c4 }
            int r7 = r7 - r3
            r6.systemOperationCounter = r7     // Catch:{ all -> 0x00c4 }
            r5.internalCloseLynxModuleIfUnused(r6)     // Catch:{ all -> 0x00c4 }
            monitor-exit(r8)     // Catch:{ all -> 0x00c4 }
        L_0x00c3:
            return
        L_0x00c4:
            r6 = move-exception
            monitor-exit(r8)     // Catch:{ all -> 0x00c4 }
            throw r6
        L_0x00c7:
            r6 = move-exception
            goto L_0x00e1
        L_0x00c9:
            r6 = move-exception
            com.qualcomm.robotcore.exception.RobotCoreException r7 = new com.qualcomm.robotcore.exception.RobotCoreException     // Catch:{ all -> 0x00c7 }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ all -> 0x00c7 }
            r8.<init>(r0)     // Catch:{ all -> 0x00c7 }
            com.qualcomm.hardware.lynx.commands.standard.LynxNack r6 = r6.getNack()     // Catch:{ all -> 0x00c7 }
            java.lang.StringBuilder r6 = r8.append(r6)     // Catch:{ all -> 0x00c7 }
            java.lang.String r6 = r6.toString()     // Catch:{ all -> 0x00c7 }
            r7.<init>(r6)     // Catch:{ all -> 0x00c7 }
            throw r7     // Catch:{ all -> 0x00c7 }
        L_0x00e1:
            monitor-exit(r2)     // Catch:{ all -> 0x00c7 }
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxUsbDeviceImpl.internalPerformSysOp(com.qualcomm.hardware.lynx.LynxModule, com.qualcomm.hardware.lynx.LynxModule, org.firstinspires.ftc.robotcore.external.Consumer, int, java.util.concurrent.TimeUnit):void");
    }

    /* access modifiers changed from: protected */
    public void internalCloseLynxModuleIfUnused(LynxModule lynxModule) {
        synchronized (this.sysOpStartStopLock) {
            if (findKnownModule(lynxModule.getModuleAddress()) == lynxModule) {
                if (lynxModule.systemOperationCounter < 0) {
                    RobotLog.ee(TAG, "systemOperationCounter for module %d was below 0", Integer.valueOf(lynxModule.getModuleAddress()));
                }
                if (!lynxModule.isUserModule && lynxModule.systemOperationCounter <= 0) {
                    lynxModule.close();
                }
            } else {
                throw new RuntimeException("An unaffiliated module was passed in to internalCloseLynxModuleIfAppropriate()");
            }
        }
    }

    public LynxUsbDevice.SystemOperationHandle keepConnectedModuleAliveForSystemOperations(int i, int i2) throws RobotCoreException, InterruptedException {
        LynxModule lynxModule;
        LynxModuleDescription build = new LynxModuleDescription.Builder(i2, true).build();
        LynxModuleDescription build2 = new LynxModuleDescription.Builder(i, false).build();
        LynxModule orAddModule = getOrAddModule(build);
        if (i == i2) {
            lynxModule = orAddModule;
        } else {
            lynxModule = getOrAddModule(build2);
        }
        return new LynxUsbDevice.SystemOperationHandle(this, lynxModule, orAddModule);
    }

    public LynxModuleMetaList discoverModules(boolean z) throws RobotCoreException, InterruptedException {
        RobotLog.vv(TAG, "lynx discovery beginning for device " + this.serialNumber);
        this.discoveredModules.clear();
        LynxModule lynxModule = new LynxModule(this, 0, false, false);
        try {
            new LynxDiscoveryCommand(lynxModule).send();
            long j = (((long) 254) * 3000000) + 250000000;
            long j2 = j / ElapsedTime.MILLIS_IN_NANO;
            long j3 = j - (ElapsedTime.MILLIS_IN_NANO * j2);
            RobotLog.vv(TAG, "discovery waiting %dms and %dns", Long.valueOf(j2), Long.valueOf(j3));
            Thread.sleep(j2, (int) j3);
            RobotLog.vv(TAG, "discovery waiting complete: #modules=%d", Integer.valueOf(this.discoveredModules.size()));
            RobotLog.vv(TAG, "Checking type of discovered modules");
            LynxModuleMeta[] lynxModuleMetaArr = (LynxModuleMeta[]) this.discoveredModules.values().stream().filter(new LynxUsbDeviceImpl$$ExternalSyntheticLambda0()).toArray(new LynxUsbDeviceImpl$$ExternalSyntheticLambda1());
            if (lynxModuleMetaArr.length > 0) {
                LynxModuleMeta lynxModuleMeta = lynxModuleMetaArr[0];
                for (LynxModuleMeta next : this.discoveredModules.values()) {
                    try {
                        performSystemOperationOnConnectedModule(next.getModuleAddress(), lynxModuleMeta.getModuleAddress(), new LynxUsbDeviceImpl$$ExternalSyntheticLambda2(next, z), SyncdDevice.msAbnormalReopenInterval, TimeUnit.MILLISECONDS);
                    } catch (TimeoutException e) {
                        RobotLog.ee(TAG, (Throwable) e, "Timeout expired while getting IMU type");
                    }
                }
            } else {
                RobotLog.ee(TAG, "Unable to check for onboard IMUs as the parent module was not found");
            }
            lynxModule.close();
            LynxModuleMetaList lynxModuleMetaList = new LynxModuleMetaList(this.serialNumber, this.discoveredModules.values());
            RobotLog.vv(TAG, "...lynx discovery completed");
            return lynxModuleMetaList;
        } catch (LynxNackException e2) {
            throw e2.wrap();
        } catch (Throwable th) {
            lynxModule.close();
            throw th;
        }
    }

    static /* synthetic */ LynxModuleMeta[] lambda$discoverModules$2(int i) {
        return new LynxModuleMeta[i];
    }

    static /* synthetic */ void lambda$discoverModules$3(LynxModuleMeta lynxModuleMeta, boolean z, LynxModule lynxModule) {
        lynxModuleMeta.setRevProductNumber(lynxModule.getRevProductNumber());
        if (z) {
            lynxModuleMeta.setImuType(lynxModule.getImuType());
        } else {
            lynxModuleMeta.setImuType(LynxModuleImuType.UNKNOWN);
        }
    }

    public boolean setupControlHubEmbeddedModule() throws InterruptedException, RobotCoreException {
        if (!getSerialNumber().isEmbedded()) {
            RobotLog.ww(TAG, "setupControlHubEmbeddedModule() called on non-embedded USB device");
            return false;
        }
        try {
            performSystemOperationOnParentModule(LynxConstants.CH_EMBEDDED_MODULE_ADDRESS, (Consumer<LynxModule>) null, SyncdDevice.msAbnormalReopenInterval, TimeUnit.MILLISECONDS);
            RobotLog.vv(TAG, "Verified that the embedded Control Hub module has the correct address");
            return false;
        } catch (RobotCoreException | TimeoutException unused) {
            return handleEmbeddedModuleNotFoundAtExpectedAddress();
        }
    }

    private boolean handleEmbeddedModuleNotFoundAtExpectedAddress() throws RobotCoreException, InterruptedException {
        RobotLog.ww(TAG, "Unable to find embedded Control Hub module at address %d. Attempting to resolve automatically.", Integer.valueOf(LynxConstants.CH_EMBEDDED_MODULE_ADDRESS));
        LynxModuleMeta parent = discoverModules(false).getParent();
        if (parent == null) {
            RobotLog.ee(TAG, "Unable to communicate with internal Expansion Hub. Attempting to re-flash firmware.");
            autoReflashControlHubFirmware();
            parent = discoverModules(false).getParent();
            if (parent == null) {
                RobotLog.setGlobalErrorMsg(AppUtil.getDefContext().getString(R.string.controlHubNotAbleToCommunicateWithInternalHub));
                return false;
            }
            RobotLog.ii(TAG, "Successfully un-bricked the Control Hub's embedded module");
            if (parent.getModuleAddress() == 173) {
                RobotLog.ii(TAG, "The embedded module already has the correct address");
                return false;
            }
        }
        try {
            setControlHubModuleAddress(parent);
            return true;
        } catch (TimeoutException e) {
            RobotLog.ee(TAG, (Throwable) e, "Timeout expired while setting Control Hub module address");
            return false;
        }
    }

    private void autoReflashControlHubFirmware() {
        updateFirmware(IncludedFirmwareFileInfo.FW_IMAGE, "autoFirmwareUpdate", new Consumer<ProgressParameters>() {
            public void accept(ProgressParameters progressParameters) {
                AppAliveNotifier.getInstance().notifyAppAlive();
            }
        });
        resetDevice(this.robotUsbDevice);
    }

    private void setControlHubModuleAddress(LynxModuleMeta lynxModuleMeta) throws InterruptedException, RobotCoreException, TimeoutException {
        int moduleAddress = lynxModuleMeta.getModuleAddress();
        RobotLog.vv(TAG, "Found embedded module at address %d", Integer.valueOf(moduleAddress));
        performSystemOperationOnParentModule(moduleAddress, new LynxUsbDeviceImpl$$ExternalSyntheticLambda4(), SyncdDevice.msAbnormalReopenInterval, TimeUnit.MILLISECONDS);
    }

    static /* synthetic */ void lambda$setControlHubModuleAddress$4(LynxModule lynxModule) {
        RobotLog.vv(TAG, "Setting embedded module address to %d", Integer.valueOf(LynxConstants.CH_EMBEDDED_MODULE_ADDRESS));
        lynxModule.setNewModuleAddress(LynxConstants.CH_EMBEDDED_MODULE_ADDRESS);
    }

    /* access modifiers changed from: protected */
    public void onLynxDiscoveryResponseReceived(LynxDatagram lynxDatagram) {
        LynxDiscoveryResponse lynxDiscoveryResponse = new LynxDiscoveryResponse();
        lynxDiscoveryResponse.setSerialization(lynxDatagram);
        lynxDiscoveryResponse.loadFromSerialization();
        RobotLog.vv(TAG, "onLynxDiscoveryResponseReceived()... module#=%d isParent=%s", Integer.valueOf(lynxDiscoveryResponse.getDiscoveredModuleAddress()), Boolean.toString(lynxDiscoveryResponse.isParent()));
        try {
            synchronized (this.discoveredModules) {
                if (!this.discoveredModules.containsKey(Integer.valueOf(lynxDatagram.getSourceModuleAddress()))) {
                    RobotLog.vv(TAG, "discovered lynx module#=%d isParent=%s", Integer.valueOf(lynxDiscoveryResponse.getDiscoveredModuleAddress()), Boolean.toString(lynxDiscoveryResponse.isParent()));
                    LynxModuleMeta lynxModuleMeta = new LynxModuleMeta(lynxDiscoveryResponse.getDiscoveredModuleAddress(), lynxDiscoveryResponse.isParent());
                    this.discoveredModules.put(Integer.valueOf(lynxModuleMeta.getModuleAddress()), lynxModuleMeta);
                }
            }
            RobotLog.vv(TAG, "...onLynxDiscoveryResponseReceived()");
        } catch (Throwable th) {
            RobotLog.vv(TAG, "...onLynxDiscoveryResponseReceived()");
            throw th;
        }
    }

    /* access modifiers changed from: protected */
    public void pingAndQueryKnownInterfaces() throws RobotCoreException, InterruptedException {
        for (LynxModule next : getKnownModules()) {
            if (next.isParent()) {
                next.pingAndQueryKnownInterfacesAndEtc();
            }
        }
        for (LynxModule next2 : getKnownModules()) {
            if (!next2.isParent()) {
                next2.pingAndQueryKnownInterfacesAndEtc();
            }
        }
    }

    public void lockNetworkLockAcquisitions() {
        this.networkTransmissionLock.lockAcquisitions();
    }

    public void setThrowOnNetworkLockAcquisition(boolean z) {
        this.networkTransmissionLock.throwOnLockAcquisitions(z);
    }

    /* access modifiers changed from: protected */
    public void resetNetworkTransmissionLock() throws InterruptedException {
        this.networkTransmissionLock.reset();
    }

    public void acquireNetworkTransmissionLock(LynxMessage lynxMessage) throws InterruptedException {
        this.networkTransmissionLock.acquire(lynxMessage);
    }

    public void releaseNetworkTransmissionLock(LynxMessage lynxMessage) throws InterruptedException {
        this.networkTransmissionLock.release(lynxMessage);
    }

    /* access modifiers changed from: protected */
    public void startPollingForIncomingDatagrams() {
        if (this.incomingDatagramPoller == null) {
            ExecutorService newSingleThreadExecutor = ThreadPool.newSingleThreadExecutor("lynx dg poller");
            this.incomingDatagramPoller = newSingleThreadExecutor;
            newSingleThreadExecutor.execute(new IncomingDatagramPoller());
        }
    }

    /* access modifiers changed from: protected */
    public boolean stopPollingForIncomingDatagrams() {
        boolean z = this.incomingDatagramPoller != null;
        RobotUsbDevice robotUsbDevice = this.robotUsbDevice;
        if (robotUsbDevice != null) {
            robotUsbDevice.requestReadInterrupt(true);
        }
        if (this.incomingDatagramPoller != null) {
            RobotLog.vv(TAG, "shutting down incoming datagrams");
            this.incomingDatagramPoller.shutdownNow();
            ThreadPool.awaitTerminationOrExitApplication(this.incomingDatagramPoller, 5, TimeUnit.SECONDS, "Lynx incoming datagram poller", "internal error");
            this.incomingDatagramPoller = null;
        }
        if (robotUsbDevice != null) {
            robotUsbDevice.requestReadInterrupt(false);
        }
        return z;
    }

    /* access modifiers changed from: protected */
    public void startRegularPinging() {
        for (LynxModule startPingTimer : getKnownModules()) {
            startPingTimer.startPingTimer();
        }
    }

    /* access modifiers changed from: package-private */
    public void stopRegularPinging() {
        for (LynxModule stopPingTimer : getKnownModules()) {
            stopPingTimer.stopPingTimer(true);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x007f, code lost:
        r10.noteHasBeenTransmitted();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0082, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void transmit(com.qualcomm.hardware.lynx.commands.LynxMessage r10) throws java.lang.InterruptedException {
        /*
            r9 = this;
            java.lang.Object r0 = r9.engageLock
            monitor-enter(r0)
            boolean r1 = r9.isArmedOrArming()     // Catch:{ all -> 0x0083 }
            if (r1 == 0) goto L_0x007b
            boolean r1 = r9.hasShutdownAbnormally()     // Catch:{ all -> 0x0083 }
            if (r1 != 0) goto L_0x007b
            boolean r1 = r9.isEngaged     // Catch:{ all -> 0x0083 }
            if (r1 == 0) goto L_0x007b
            com.qualcomm.hardware.lynx.commands.LynxDatagram r1 = r10.getSerialization()     // Catch:{ all -> 0x0083 }
            if (r1 == 0) goto L_0x0077
            boolean r2 = DEBUG_LOG_DATAGRAMS     // Catch:{ all -> 0x0083 }
            if (r2 != 0) goto L_0x0021
            boolean r2 = DEBUG_LOG_MESSAGES     // Catch:{ all -> 0x0083 }
            if (r2 == 0) goto L_0x0054
        L_0x0021:
            java.lang.String r2 = "LynxUsb"
            java.lang.String r3 = "xmit'ing: mod=%d cmd=0x%02x(%s) msg#=%d ref#=%d "
            int r4 = r10.getModuleAddress()     // Catch:{ all -> 0x0083 }
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ all -> 0x0083 }
            int r5 = r10.getCommandNumber()     // Catch:{ all -> 0x0083 }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x0083 }
            java.lang.Class r6 = r10.getClass()     // Catch:{ all -> 0x0083 }
            java.lang.String r6 = r6.getSimpleName()     // Catch:{ all -> 0x0083 }
            int r7 = r10.getMessageNumber()     // Catch:{ all -> 0x0083 }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ all -> 0x0083 }
            int r8 = r10.getReferenceNumber()     // Catch:{ all -> 0x0083 }
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)     // Catch:{ all -> 0x0083 }
            java.lang.Object[] r4 = new java.lang.Object[]{r4, r5, r6, r7, r8}     // Catch:{ all -> 0x0083 }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r2, (java.lang.String) r3, (java.lang.Object[]) r4)     // Catch:{ all -> 0x0083 }
        L_0x0054:
            byte[] r1 = r1.toByteArray()     // Catch:{ all -> 0x0083 }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice r2 = r9.robotUsbDevice     // Catch:{ RobotUsbException -> 0x006a, RuntimeException -> 0x0068 }
            r2.write(r1)     // Catch:{ RobotUsbException -> 0x006a, RuntimeException -> 0x0068 }
            long r1 = java.lang.System.nanoTime()     // Catch:{ all -> 0x0083 }
            r10.setNanotimeLastTransmit(r1)     // Catch:{ all -> 0x0083 }
            r10.resetModulePingTimer()     // Catch:{ all -> 0x0083 }
            goto L_0x007e
        L_0x0068:
            r10 = move-exception
            goto L_0x006b
        L_0x006a:
            r10 = move-exception
        L_0x006b:
            r9.shutdownAbnormally()     // Catch:{ all -> 0x0083 }
            java.lang.String r1 = "LynxUsb"
            java.lang.String r2 = "exception thrown in LynxUsbDevice.transmit"
            com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r1, (java.lang.Throwable) r10, (java.lang.String) r2)     // Catch:{ all -> 0x0083 }
            monitor-exit(r0)     // Catch:{ all -> 0x0083 }
            return
        L_0x0077:
            r10.onPretendTransmit()     // Catch:{ all -> 0x0083 }
            goto L_0x007e
        L_0x007b:
            r10.onPretendTransmit()     // Catch:{ all -> 0x0083 }
        L_0x007e:
            monitor-exit(r0)     // Catch:{ all -> 0x0083 }
            r10.noteHasBeenTransmitted()
            return
        L_0x0083:
            r10 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0083 }
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.lynx.LynxUsbDeviceImpl.transmit(com.qualcomm.hardware.lynx.commands.LynxMessage):void");
    }

    /* access modifiers changed from: protected */
    public void shutdownAbnormally() {
        boolean z = true;
        this.hasShutdownAbnormally = true;
        RobotUsbDevice robotUsbDevice = this.robotUsbDevice;
        if (robotUsbDevice == null || !robotUsbDevice.isAttached()) {
            z = false;
        }
        setGlobalWarning(String.format(this.context.getString(z ? R.string.warningProblemCommunicatingWithUSBDevice : R.string.warningUSBDeviceDetached), new Object[]{HardwareFactory.getDeviceDisplayName(this.context, this.serialNumber)}));
    }

    /* access modifiers changed from: protected */
    public void pretendFinishExtantCommands() throws InterruptedException {
        for (LynxModule pretendFinishExtantCommands : getKnownModules()) {
            pretendFinishExtantCommands.pretendFinishExtantCommands();
        }
    }

    /* access modifiers changed from: protected */
    public void abandonUnfinishedCommands() {
        for (LynxModule abandonUnfinishedCommands : getKnownModules()) {
            abandonUnfinishedCommands.abandonUnfinishedCommands();
        }
    }

    class IncomingDatagramPoller implements Runnable {
        boolean isSynchronized = false;
        byte[] prefix = new byte[4];
        byte[] scratch = new byte[2];
        boolean stopRequested = false;

        IncomingDatagramPoller() {
        }

        public void run() {
            ThreadPool.logThreadLifeCycle("lynx incoming datagrams", new Runnable() {
                public void run() {
                    Thread.currentThread().setPriority(6);
                    while (!IncomingDatagramPoller.this.stopRequested && !Thread.currentThread().isInterrupted() && !LynxUsbDeviceImpl.this.hasShutdownAbnormally()) {
                        LynxDatagram pollForIncomingDatagram = IncomingDatagramPoller.this.pollForIncomingDatagram();
                        if (pollForIncomingDatagram != null) {
                            if (pollForIncomingDatagram.getPacketId() == LynxDiscoveryResponse.getStandardCommandNumber()) {
                                LynxUsbDeviceImpl.this.onLynxDiscoveryResponseReceived(pollForIncomingDatagram);
                            } else {
                                LynxModule findKnownModule = LynxUsbDeviceImpl.this.findKnownModule(pollForIncomingDatagram.getSourceModuleAddress());
                                if (findKnownModule != null) {
                                    findKnownModule.onIncomingDatagramReceived(pollForIncomingDatagram);
                                }
                            }
                        }
                    }
                }
            });
        }

        /* access modifiers changed from: package-private */
        public void readIncomingBytes(byte[] bArr, int i, TimeWindow timeWindow) throws InterruptedException, RobotUsbException {
            RobotUsbDevice access$000 = LynxUsbDeviceImpl.this.robotUsbDevice;
            if (access$000 != null) {
                int read = access$000.read(bArr, 0, i, 2147483647L, timeWindow);
                if (read != i) {
                    if (read == 0) {
                        RobotLog.ee(LynxUsbDeviceImpl.TAG, "readIncomingBytes() cbToRead=%d cbRead=%d: throwing InterruptedException", Integer.valueOf(i), Integer.valueOf(read));
                        throw new InterruptedException("interrupt during robotUsbDevice.read()");
                    } else {
                        RobotLog.ee(LynxUsbDeviceImpl.TAG, "readIncomingBytes() cbToRead=%d cbRead=%d: throwing RobotCoreException", Integer.valueOf(i), Integer.valueOf(read));
                        throw new RobotUsbUnspecifiedException("readIncomingBytes() cbToRead=%d cbRead=%d", Integer.valueOf(i), Integer.valueOf(read));
                    }
                }
            } else {
                RobotLog.ee(LynxUsbDeviceImpl.TAG, "readIncomingBytes() robotUsbDevice was null");
                throw new RobotUsbUnspecifiedException("readIncomingBytes() robotUsbDevice was null");
            }
        }

        /* access modifiers changed from: package-private */
        public byte readSingleByte(byte[] bArr) throws InterruptedException, RobotUsbException {
            readIncomingBytes(bArr, 1, (TimeWindow) null);
            return bArr[0];
        }

        /* access modifiers changed from: package-private */
        public LynxDatagram pollForIncomingDatagram() {
            while (!this.stopRequested && !Thread.currentThread().isInterrupted() && !LynxUsbDeviceImpl.this.hasShutdownAbnormally()) {
                try {
                    if (this.isSynchronized) {
                        readIncomingBytes(this.prefix, 4, (TimeWindow) null);
                        if (!LynxDatagram.beginsWithFraming(this.prefix)) {
                            RobotLog.vv(LynxUsbDeviceImpl.TAG, "synchronization lost: serial=%s", LynxUsbDeviceImpl.this.serialNumber);
                            this.isSynchronized = false;
                        }
                    } else if (readSingleByte(this.scratch) == LynxDatagram.frameBytes[0]) {
                        if (readSingleByte(this.scratch) == LynxDatagram.frameBytes[1]) {
                            readIncomingBytes(this.scratch, 2, (TimeWindow) null);
                            System.arraycopy(LynxDatagram.frameBytes, 0, this.prefix, 0, 2);
                            System.arraycopy(this.scratch, 0, this.prefix, 2, 2);
                            RobotLog.vv(LynxUsbDeviceImpl.TAG, "synchronization gained: serial=%s", LynxUsbDeviceImpl.this.serialNumber);
                            this.isSynchronized = true;
                        }
                    }
                    int unsignedShortToInt = TypeConversion.unsignedShortToInt(TypeConversion.byteArrayToShort(this.prefix, 2, LynxDatagram.LYNX_ENDIAN)) - 4;
                    byte[] bArr = new byte[unsignedShortToInt];
                    TimeWindow timeWindow = new TimeWindow();
                    readIncomingBytes(bArr, unsignedShortToInt, timeWindow);
                    byte[] concatenateByteArrays = Util.concatenateByteArrays(this.prefix, bArr);
                    LynxDatagram lynxDatagram = new LynxDatagram();
                    lynxDatagram.setPayloadTimeWindow(timeWindow);
                    lynxDatagram.fromByteArray(concatenateByteArrays);
                    if (lynxDatagram.isChecksumValid()) {
                        if (LynxUsbDeviceImpl.DEBUG_LOG_DATAGRAMS) {
                            RobotLog.vv(LynxUsbDeviceImpl.TAG, "rec'd: mod=%d cmd=0x%02x msg#=%d ref#=%d ", Integer.valueOf(lynxDatagram.getSourceModuleAddress()), Integer.valueOf(lynxDatagram.getPacketId()), Integer.valueOf(lynxDatagram.getMessageNumber()), Integer.valueOf(lynxDatagram.getReferenceNumber()));
                        }
                        return lynxDatagram;
                    }
                    RobotLog.ee(LynxUsbDeviceImpl.TAG, "invalid checksum received; message ignored");
                } catch (RuntimeException | RobotUsbDeviceClosedException | RobotUsbFTDIException unused) {
                    RobotLog.vv(LynxUsbDeviceImpl.TAG, "device closed in incoming datagram loop");
                    LynxUsbDeviceImpl.this.shutdownAbnormally();
                    RobotUsbDevice access$300 = LynxUsbDeviceImpl.this.robotUsbDevice;
                    if (access$300 != null) {
                        access$300.close();
                    }
                    try {
                        LynxUsbDeviceImpl.this.pretendFinishExtantCommands();
                    } catch (InterruptedException unused2) {
                        this.stopRequested = true;
                    }
                } catch (RobotCoreException | RobotUsbException e) {
                    RobotLog.vv(LynxUsbDeviceImpl.TAG, e, "exception thrown in incoming datagram loop; ignored");
                } catch (InterruptedException unused3) {
                    this.stopRequested = true;
                }
            }
            return null;
        }
    }

    protected static RobotUsbDeviceFtdi accessCBus(RobotUsbDevice robotUsbDevice) {
        if (robotUsbDevice instanceof RobotUsbDeviceFtdi) {
            RobotUsbDeviceFtdi robotUsbDeviceFtdi = (RobotUsbDeviceFtdi) robotUsbDevice;
            if (robotUsbDeviceFtdi.supportsCbusBitbang()) {
                return robotUsbDeviceFtdi;
            }
        }
        RobotLog.ee(TAG, "accessCBus() unexpectedly failed; ignoring");
        return null;
    }

    public static void resetDevice(RobotUsbDevice robotUsbDevice) {
        if (robotUsbDevice == null) {
            RobotLog.ww(TAG, "resetDevice() called with null robotUsbDevice");
            return;
        }
        RobotLog.vv(TAG, "resetDevice() serial=%s", robotUsbDevice.getSerialNumber());
        try {
            if (LynxConstants.isEmbeddedSerialNumber(robotUsbDevice.getSerialNumber())) {
                boolean state = AndroidBoard.getInstance().getAndroidBoardIsPresentPin().getState();
                RobotLog.vv(LynxModule.TAG, "resetting embedded usb device: isPresent: was=%s", Boolean.valueOf(state));
                if (!state) {
                    AndroidBoard.getInstance().getAndroidBoardIsPresentPin().setState(true);
                    Thread.sleep((long) 75);
                }
                AndroidBoard.getInstance().getLynxModuleResetPin().setState(true);
                long j = (long) 75;
                Thread.sleep(j);
                AndroidBoard.getInstance().getLynxModuleResetPin().setState(false);
                Thread.sleep(j);
            } else {
                RobotUsbDeviceFtdi accessCBus = accessCBus(robotUsbDevice);
                if (accessCBus != null) {
                    accessCBus.cbus_setup(3, 3);
                    long j2 = (long) 75;
                    Thread.sleep(j2);
                    accessCBus.cbus_write(2);
                    Thread.sleep(j2);
                    accessCBus.cbus_write(3);
                }
            }
            Thread.sleep(200);
        } catch (InterruptedException | RobotUsbException e) {
            exceptionHandler.handleException(e);
        }
    }

    public RobotCoreCommandList.LynxFirmwareUpdateResp updateFirmware(RobotCoreCommandList.FWImage fWImage, String str, Consumer<ProgressParameters> consumer) {
        return this.lynxFirmwareUpdater.updateFirmware(fWImage, str, consumer);
    }
}

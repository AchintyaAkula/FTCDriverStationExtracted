package com.qualcomm.hardware.lynx;

import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxUsbDeviceImpl$$ExternalSyntheticLambda4 implements Consumer {
    public final void accept(Object obj) {
        LynxUsbDeviceImpl.lambda$setControlHubModuleAddress$4((LynxModule) obj);
    }
}

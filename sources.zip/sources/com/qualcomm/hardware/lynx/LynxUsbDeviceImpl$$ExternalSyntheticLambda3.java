package com.qualcomm.hardware.lynx;

import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxUsbDeviceImpl$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ Consumer f$0;
    public final /* synthetic */ LynxModule f$1;

    public /* synthetic */ LynxUsbDeviceImpl$$ExternalSyntheticLambda3(Consumer consumer, LynxModule lynxModule) {
        this.f$0 = consumer;
        this.f$1 = lynxModule;
    }

    public final void run() {
        this.f$0.accept(this.f$1);
    }
}

package com.qualcomm.hardware.lynx;

import com.qualcomm.robotcore.hardware.LynxModuleMeta;
import org.firstinspires.ftc.robotcore.external.Consumer;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class LynxUsbDeviceImpl$$ExternalSyntheticLambda2 implements Consumer {
    public final /* synthetic */ LynxModuleMeta f$0;
    public final /* synthetic */ boolean f$1;

    public /* synthetic */ LynxUsbDeviceImpl$$ExternalSyntheticLambda2(LynxModuleMeta lynxModuleMeta, boolean z) {
        this.f$0 = lynxModuleMeta;
        this.f$1 = z;
    }

    public final void accept(Object obj) {
        LynxUsbDeviceImpl.lambda$discoverModules$3(this.f$0, this.f$1, (LynxModule) obj);
    }
}

package com.qualcomm.hardware;

import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

public abstract class HardwareManualControlOpMode extends LinearOpMode {
    private static volatile HardwareManualControlOpMode instance;

    public abstract void onLynxModuleAddressChanged(LynxModule lynxModule, int i, int i2);

    public abstract void onLynxModuleStatusChanged(LynxModule lynxModule, int i, int i2);

    public static HardwareManualControlOpMode getInstance() {
        return instance;
    }

    protected static void setInstance(HardwareManualControlOpMode hardwareManualControlOpMode) {
        instance = hardwareManualControlOpMode;
    }
}

package com.qualcomm.hardware.modernrobotics.comm;

import com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsDatagram;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.usb.RobotUsbDevice;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import org.firstinspires.ftc.robotcore.internal.collections.CircularByteBuffer;
import org.firstinspires.ftc.robotcore.internal.collections.MarkedItemQueue;
import org.firstinspires.ftc.robotcore.internal.hardware.TimeWindow;
import org.firstinspires.ftc.robotcore.internal.system.Misc;
import org.firstinspires.ftc.robotcore.internal.usb.UsbConstants;

public class RobotUsbDevicePretendModernRobotics implements RobotUsbDevice {
    protected CircularByteBuffer circularByteBuffer = new CircularByteBuffer(0);
    protected boolean debugRetainBuffers = false;
    protected DeviceManager.UsbDeviceType deviceType = DeviceManager.UsbDeviceType.FTDI_USB_UNKNOWN_DEVICE;
    protected RobotUsbDevice.FirmwareVersion firmwareVersion = new RobotUsbDevice.FirmwareVersion();
    protected boolean interruptRequested = false;
    protected MarkedItemQueue markedItemQueue = new MarkedItemQueue();
    protected ModernRoboticsDatagram.AllocationContext<ModernRoboticsRequest> requestAllocationContext = new ModernRoboticsDatagram.AllocationContext<>();
    protected ModernRoboticsDatagram.AllocationContext<ModernRoboticsResponse> responseAllocationContext = new ModernRoboticsDatagram.AllocationContext<>();
    protected SerialNumber serialNumber;

    public void close() {
    }

    public boolean isAttached() {
        return true;
    }

    public boolean isOpen() {
        return true;
    }

    public void setBaudRate(int i) {
    }

    public void setBreak(boolean z) {
    }

    public void setDataCharacteristics(byte b, byte b2, byte b3) {
    }

    public void setLatencyTimer(int i) {
    }

    public RobotUsbDevicePretendModernRobotics(SerialNumber serialNumber2) {
        this.serialNumber = serialNumber2;
    }

    public SerialNumber getSerialNumber() {
        return this.serialNumber;
    }

    public String getProductName() {
        return Misc.formatForUser("pretend %s", this.deviceType);
    }

    public void setDeviceType(DeviceManager.UsbDeviceType usbDeviceType) {
        this.deviceType = usbDeviceType;
    }

    public DeviceManager.UsbDeviceType getDeviceType() {
        return this.deviceType;
    }

    public void setDebugRetainBuffers(boolean z) {
        this.debugRetainBuffers = z;
    }

    public boolean getDebugRetainBuffers() {
        return this.debugRetainBuffers;
    }

    public void logRetainedBuffers(long j, long j2, String str, String str2, Object... objArr) {
        RobotLog.ee(str, str2, objArr);
    }

    public void skipToLikelyUsbPacketStart() {
        this.circularByteBuffer.skip(this.markedItemQueue.removeUpToNextMarkedItemOrEnd());
    }

    public boolean mightBeAtUsbPacketStart() {
        return this.markedItemQueue.isAtMarkedItem() || this.markedItemQueue.isEmpty();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(10:6|(1:8)(1:9)|10|11|12|13|14|15|(1:17)|(2:19|31)(1:32)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:14:0x006c */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x009b  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00a0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void write(byte[] r5) {
        /*
            r4 = this;
            java.lang.String r0 = "undefined function: "
            r1 = 0
            com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsDatagram$AllocationContext<com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsRequest> r2 = r4.requestAllocationContext     // Catch:{ all -> 0x0097 }
            com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsRequest r5 = com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsRequest.from(r2, r5)     // Catch:{ all -> 0x0097 }
            int r2 = r5.getFunction()     // Catch:{ all -> 0x0095 }
            if (r2 != 0) goto L_0x007e
            boolean r0 = r5.isWrite()     // Catch:{ all -> 0x0095 }
            if (r0 == 0) goto L_0x002b
            com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsDatagram$AllocationContext<com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsResponse> r0 = r4.responseAllocationContext     // Catch:{ all -> 0x0095 }
            r2 = 0
            com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsResponse r1 = com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsResponse.newInstance(r0, r2)     // Catch:{ all -> 0x0095 }
            int r0 = r5.getFunction()     // Catch:{ all -> 0x0095 }
            r1.setWrite(r0)     // Catch:{ all -> 0x0095 }
            int r0 = r5.getAddress()     // Catch:{ all -> 0x0095 }
            r1.setAddress(r0)     // Catch:{ all -> 0x0095 }
            goto L_0x004d
        L_0x002b:
            com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsDatagram$AllocationContext<com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsResponse> r0 = r4.responseAllocationContext     // Catch:{ all -> 0x0095 }
            int r2 = r5.getPayloadLength()     // Catch:{ all -> 0x0095 }
            com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsResponse r1 = com.qualcomm.hardware.modernrobotics.comm.ModernRoboticsResponse.newInstance(r0, r2)     // Catch:{ all -> 0x0095 }
            int r0 = r5.getFunction()     // Catch:{ all -> 0x0095 }
            r1.setRead(r0)     // Catch:{ all -> 0x0095 }
            int r0 = r5.getAddress()     // Catch:{ all -> 0x0095 }
            r1.setAddress(r0)     // Catch:{ all -> 0x0095 }
            int r0 = r5.getPayloadLength()     // Catch:{ all -> 0x0095 }
            r1.setPayloadLength(r0)     // Catch:{ all -> 0x0095 }
            r1.clearPayload()     // Catch:{ all -> 0x0095 }
        L_0x004d:
            org.firstinspires.ftc.robotcore.internal.collections.CircularByteBuffer r0 = r4.circularByteBuffer     // Catch:{ all -> 0x0095 }
            byte[] r2 = r1.data     // Catch:{ all -> 0x0095 }
            r0.write((byte[]) r2)     // Catch:{ all -> 0x0095 }
            org.firstinspires.ftc.robotcore.internal.collections.MarkedItemQueue r0 = r4.markedItemQueue     // Catch:{ all -> 0x0095 }
            r0.addMarkedItem()     // Catch:{ all -> 0x0095 }
            org.firstinspires.ftc.robotcore.internal.collections.MarkedItemQueue r0 = r4.markedItemQueue     // Catch:{ all -> 0x0095 }
            byte[] r2 = r1.data     // Catch:{ all -> 0x0095 }
            int r2 = r2.length     // Catch:{ all -> 0x0095 }
            int r2 = r2 + -1
            r0.addUnmarkedItems(r2)     // Catch:{ all -> 0x0095 }
            r2 = 3
            r0 = 500000(0x7a120, float:7.00649E-40)
            java.lang.Thread.sleep(r2, r0)     // Catch:{ InterruptedException -> 0x006c }
            goto L_0x0073
        L_0x006c:
            java.lang.Thread r0 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x0095 }
            r0.interrupt()     // Catch:{ all -> 0x0095 }
        L_0x0073:
            if (r1 == 0) goto L_0x0078
            r1.close()
        L_0x0078:
            if (r5 == 0) goto L_0x007d
            r5.close()
        L_0x007d:
            return
        L_0x007e:
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x0095 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x0095 }
            r3.<init>(r0)     // Catch:{ all -> 0x0095 }
            int r0 = r5.getFunction()     // Catch:{ all -> 0x0095 }
            java.lang.StringBuilder r0 = r3.append(r0)     // Catch:{ all -> 0x0095 }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x0095 }
            r2.<init>(r0)     // Catch:{ all -> 0x0095 }
            throw r2     // Catch:{ all -> 0x0095 }
        L_0x0095:
            r0 = move-exception
            goto L_0x0099
        L_0x0097:
            r0 = move-exception
            r5 = r1
        L_0x0099:
            if (r1 == 0) goto L_0x009e
            r1.close()
        L_0x009e:
            if (r5 == 0) goto L_0x00a3
            r5.close()
        L_0x00a3:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.modernrobotics.comm.RobotUsbDevicePretendModernRobotics.write(byte[]):void");
    }

    public int read(byte[] bArr, int i, int i2, long j, TimeWindow timeWindow) {
        int read = this.circularByteBuffer.read(bArr, i, i2);
        this.markedItemQueue.removeItems(read);
        if (timeWindow != null) {
            timeWindow.clear();
        }
        return read;
    }

    public void resetAndFlushBuffers() {
        this.circularByteBuffer.clear();
        this.markedItemQueue.clear();
    }

    public RobotUsbDevice.FirmwareVersion getFirmwareVersion() {
        return this.firmwareVersion;
    }

    public void setFirmwareVersion(RobotUsbDevice.FirmwareVersion firmwareVersion2) {
        this.firmwareVersion = firmwareVersion2;
    }

    public void requestReadInterrupt(boolean z) {
        this.interruptRequested = z;
    }

    public RobotUsbDevice.USBIdentifiers getUsbIdentifiers() {
        RobotUsbDevice.USBIdentifiers uSBIdentifiers = new RobotUsbDevice.USBIdentifiers();
        uSBIdentifiers.vendorId = UsbConstants.VENDOR_ID_FTDI;
        uSBIdentifiers.productId = 0;
        uSBIdentifiers.bcdDevice = 0;
        return uSBIdentifiers;
    }
}

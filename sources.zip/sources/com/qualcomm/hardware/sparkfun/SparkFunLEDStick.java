package com.qualcomm.hardware.sparkfun;

import android.graphics.Color;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import org.opencv.imgproc.Imgproc;

@I2cDeviceType
@DeviceProperties(description = "@string/sparkfun_led_stick_description", name = "@string/sparkfun_led_stick_name", xmlTag = "QWIIC_LED_STICK")
public class SparkFunLEDStick extends I2cDeviceSynchDevice<I2cDeviceSynchSimple> {
    private static final I2cAddr ADDRESS_I2C_DEFAULT = I2cAddr.create7bit(35);
    private static final boolean LIMIT_TO_ONE_STICK = true;
    private static final int MAX_SEGMENT_LENGTH = 12;

    private enum Commands {
        CHANGE_LED_LENGTH(112),
        WRITE_SINGLE_LED_COLOR(113),
        WRITE_ALL_LED_COLOR(114),
        WRITE_RED_ARRAY(115),
        WRITE_GREEN_ARRAY(116),
        WRITE_BLUE_ARRAY(Imgproc.COLOR_YUV2RGB_YVYU),
        WRITE_SINGLE_LED_BRIGHTNESS(Imgproc.COLOR_YUV2BGR_YVYU),
        WRITE_ALL_LED_BRIGHTNESS(119),
        WRITE_ALL_LED_OFF(120);
        
        final int bVal;

        private Commands(int i) {
            this.bVal = i;
        }
    }

    public void setColor(int i, int i2) {
        writeI2C(Commands.WRITE_SINGLE_LED_COLOR, new byte[]{(byte) i, (byte) Color.red(i2), (byte) Color.green(i2), (byte) Color.blue(i2)});
    }

    public void setColor(int i) {
        writeI2C(Commands.WRITE_ALL_LED_COLOR, new byte[]{(byte) Color.red(i), (byte) Color.green(i), (byte) Color.blue(i)});
    }

    private void sendSegment(Commands commands, int[] iArr, int i, int i2) {
        byte[] bArr = new byte[(i2 + 2)];
        bArr[0] = (byte) i2;
        bArr[1] = (byte) i;
        for (int i3 = 0; i3 < i2; i3++) {
            bArr[i3 + 2] = (byte) iArr[i3];
        }
        writeI2C(commands, bArr);
    }

    private void setLEDColorSegment(int[] iArr, int i, int i2) {
        int[] iArr2 = new int[i2];
        int[] iArr3 = new int[i2];
        int[] iArr4 = new int[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            int i4 = i3 + i;
            iArr2[i3] = Color.red(iArr[i4]);
            iArr3[i3] = Color.green(iArr[i4]);
            iArr4[i3] = Color.blue(iArr[i4]);
        }
        sendSegment(Commands.WRITE_RED_ARRAY, iArr2, i, i2);
        sendSegment(Commands.WRITE_GREEN_ARRAY, iArr3, i, i2);
        sendSegment(Commands.WRITE_BLUE_ARRAY, iArr4, i, i2);
    }

    public void setColors(int[] iArr) {
        int length = iArr.length;
        if (length > 10) {
            length = 10;
        }
        int i = length % 12;
        int i2 = length / 12;
        for (int i3 = 0; i3 < i2; i3++) {
            setLEDColorSegment(iArr, i3 * 12, 12);
        }
        if (i > 0) {
            setLEDColorSegment(iArr, i2 * 12, i);
        }
    }

    public void setBrightness(int i, int i2) {
        writeI2C(Commands.WRITE_SINGLE_LED_BRIGHTNESS, new byte[]{(byte) i, (byte) i2});
    }

    public void setBrightness(int i) {
        writeI2C(Commands.WRITE_ALL_LED_BRIGHTNESS, new byte[]{(byte) i});
    }

    public void turnAllOff() {
        setColor(0);
    }

    private void writeI2C(Commands commands, byte[] bArr) {
        this.deviceClient.write(commands.bVal, bArr);
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.SparkFun;
    }

    /* access modifiers changed from: protected */
    public synchronized boolean doInitialize() {
        return true;
    }

    public String getDeviceName() {
        return "SparkFun Qwiic LED Strip";
    }

    public SparkFunLEDStick(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z);
        i2cDeviceSynchSimple.setI2cAddress(ADDRESS_I2C_DEFAULT);
        super.registerArmingStateCallback(false);
    }
}

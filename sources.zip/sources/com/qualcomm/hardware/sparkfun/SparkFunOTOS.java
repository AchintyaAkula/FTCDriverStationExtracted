package com.qualcomm.hardware.sparkfun;

import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynch;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDevice;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.internal.ftdi.FtConstants;

@I2cDeviceType
@DeviceProperties(description = "SparkFun Qwiic Optical Tracking Odometry Sensor", name = "SparkFun OTOS", xmlTag = "SparkFunOTOS")
public class SparkFunOTOS extends I2cDeviceSynchDevice<I2cDeviceSynch> {
    public static final byte DEFAULT_ADDRESS = 23;
    protected static final double DEGREE_TO_RADIAN = 0.017453292519943295d;
    protected static final double INT16_TO_METER = 3.0517578125E-4d;
    protected static final double INT16_TO_MPS = 1.52587890625E-4d;
    protected static final double INT16_TO_MPSS = 0.0047884033203125d;
    protected static final double INT16_TO_RAD = 9.587379924285257E-5d;
    protected static final double INT16_TO_RPS = 0.0010652644360316954d;
    protected static final double INT16_TO_RPSS = 0.09587379924285257d;
    public static final double MAX_SCALAR = 1.127d;
    protected static final double METER_TO_INT16 = 3276.8d;
    public static final double MIN_SCALAR = 0.872d;
    protected static final double MPSS_TO_INT16 = 208.83788041787972d;
    protected static final double MPS_TO_INT16 = 6553.6d;
    protected static final byte PRODUCT_ID = 95;
    protected static final double RADIAN_TO_DEGREE = 57.29577951308232d;
    protected static final double RAD_TO_INT16 = 10430.378350470453d;
    protected static final byte REG_ACC_HH = 49;
    protected static final byte REG_ACC_HL = 48;
    protected static final byte REG_ACC_STD_HH = 67;
    protected static final byte REG_ACC_STD_HL = 66;
    protected static final byte REG_ACC_STD_XH = 63;
    protected static final byte REG_ACC_STD_XL = 62;
    protected static final byte REG_ACC_STD_YH = 65;
    protected static final byte REG_ACC_STD_YL = 64;
    protected static final byte REG_ACC_XH = 45;
    protected static final byte REG_ACC_XL = 44;
    protected static final byte REG_ACC_YH = 47;
    protected static final byte REG_ACC_YL = 46;
    protected static final byte REG_FW_VERSION = 2;
    protected static final byte REG_HW_VERSION = 1;
    protected static final byte REG_IMU_CALIB = 6;
    protected static final byte REG_OFF_HH = 21;
    protected static final byte REG_OFF_HL = 20;
    protected static final byte REG_OFF_XH = 17;
    protected static final byte REG_OFF_XL = 16;
    protected static final byte REG_OFF_YH = 19;
    protected static final byte REG_OFF_YL = 18;
    protected static final byte REG_POS_HH = 37;
    protected static final byte REG_POS_HL = 36;
    protected static final byte REG_POS_STD_HH = 55;
    protected static final byte REG_POS_STD_HL = 54;
    protected static final byte REG_POS_STD_XH = 51;
    protected static final byte REG_POS_STD_XL = 50;
    protected static final byte REG_POS_STD_YH = 53;
    protected static final byte REG_POS_STD_YL = 52;
    protected static final byte REG_POS_XH = 33;
    protected static final byte REG_POS_XL = 32;
    protected static final byte REG_POS_YH = 35;
    protected static final byte REG_POS_YL = 34;
    protected static final byte REG_PRODUCT_ID = 0;
    protected static final byte REG_RESET = 7;
    protected static final byte REG_SCALAR_ANGULAR = 5;
    protected static final byte REG_SCALAR_LINEAR = 4;
    protected static final byte REG_SELF_TEST = 15;
    protected static final byte REG_SIGNAL_PROCESS = 14;
    protected static final byte REG_STATUS = 31;
    protected static final byte REG_VEL_HH = 43;
    protected static final byte REG_VEL_HL = 42;
    protected static final byte REG_VEL_STD_HH = 61;
    protected static final byte REG_VEL_STD_HL = 60;
    protected static final byte REG_VEL_STD_XH = 57;
    protected static final byte REG_VEL_STD_XL = 56;
    protected static final byte REG_VEL_STD_YH = 59;
    protected static final byte REG_VEL_STD_YL = 58;
    protected static final byte REG_VEL_XH = 39;
    protected static final byte REG_VEL_XL = 38;
    protected static final byte REG_VEL_YH = 41;
    protected static final byte REG_VEL_YL = 40;
    protected static final double RPSS_TO_INT16 = 10.430378350470454d;
    protected static final double RPS_TO_INT16 = 938.7340515423407d;
    protected AngleUnit _angularUnit;
    protected DistanceUnit _distanceUnit;

    public static class Pose2D {
        public double h;
        public double x;
        public double y;

        public Pose2D() {
            this.x = LynxServoController.apiPositionFirst;
            this.y = LynxServoController.apiPositionFirst;
            this.h = LynxServoController.apiPositionFirst;
        }

        public Pose2D(double d, double d2, double d3) {
            this.x = d;
            this.y = d2;
            this.h = d3;
        }

        public void set(Pose2D pose2D) {
            this.x = pose2D.x;
            this.y = pose2D.y;
            this.h = pose2D.h;
        }

        public String toString() {
            return "(SparkFunOTOS.Pose2D) X: " + this.x + " Y: " + this.y + " H: " + this.h;
        }
    }

    public static class Version {
        public byte major;
        public byte minor;

        public Version() {
            set((byte) 0);
        }

        public Version(byte b) {
            set(b);
        }

        public void set(byte b) {
            this.minor = (byte) (b & SparkFunOTOS.REG_SELF_TEST);
            this.major = (byte) ((b >> 4) & 15);
        }

        public byte get() {
            return (byte) ((this.major << 4) | this.minor);
        }
    }

    public static class SignalProcessConfig {
        public boolean enAcc;
        public boolean enLut;
        public boolean enRot;
        public boolean enVar;

        public SignalProcessConfig() {
            set((byte) 0);
        }

        public SignalProcessConfig(byte b) {
            set(b);
        }

        public void set(byte b) {
            boolean z = false;
            this.enLut = (b & 1) != 0;
            this.enAcc = (b & 2) != 0;
            this.enRot = (b & 4) != 0;
            if ((b & 8) != 0) {
                z = true;
            }
            this.enVar = z;
        }

        public byte get() {
            char c = 0;
            boolean z = this.enLut | (this.enAcc ? (char) 2 : 0) | (this.enRot ? (char) 4 : 0);
            if (this.enVar) {
                c = 8;
            }
            return z | c ? (byte) 1 : 0;
        }
    }

    public static class SelfTestConfig {
        public boolean fail;
        public boolean inProgress;
        public boolean pass;
        public boolean start;

        public SelfTestConfig() {
            set((byte) 0);
        }

        public SelfTestConfig(byte b) {
            set(b);
        }

        public void set(byte b) {
            boolean z = false;
            this.start = (b & 1) != 0;
            this.inProgress = (b & 2) != 0;
            this.pass = (b & 4) != 0;
            if ((b & 8) != 0) {
                z = true;
            }
            this.fail = z;
        }

        public byte get() {
            char c = 0;
            boolean z = this.start | (this.inProgress ? (char) 2 : 0) | (this.pass ? (char) 4 : 0);
            if (this.fail) {
                c = 8;
            }
            return z | c ? (byte) 1 : 0;
        }
    }

    public static class Status {
        public boolean errorLsm;
        public boolean errorPaa;
        public boolean warnOpticalTracking;
        public boolean warnTiltAngle;

        public Status() {
            set((byte) 0);
        }

        public Status(byte b) {
            set(b);
        }

        public void set(byte b) {
            boolean z = false;
            this.warnTiltAngle = (b & 1) != 0;
            this.warnOpticalTracking = (b & 2) != 0;
            this.errorPaa = (b & 64) != 0;
            if ((b & FtConstants.DCD) != 0) {
                z = true;
            }
            this.errorLsm = z;
        }

        public byte get() {
            char c = 0;
            boolean z = this.warnTiltAngle | (this.warnOpticalTracking ? (char) 2 : 0) | (this.errorPaa ? '@' : 0);
            if (this.errorLsm) {
                c = 128;
            }
            return z | c ? (byte) 1 : 0;
        }
    }

    public SparkFunOTOS(I2cDeviceSynch i2cDeviceSynch) {
        super(i2cDeviceSynch, true);
        i2cDeviceSynch.setI2cAddress(I2cAddr.create7bit(23));
        super.registerArmingStateCallback(false);
        ((I2cDeviceSynch) this.deviceClient).engage();
    }

    /* access modifiers changed from: protected */
    public boolean doInitialize() {
        this._distanceUnit = DistanceUnit.INCH;
        this._angularUnit = AngleUnit.DEGREES;
        return isConnected();
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.SparkFun;
    }

    public String getDeviceName() {
        return "SparkFun Qwiic Optical Tracking Odometry Sensor";
    }

    public boolean begin() {
        return isConnected();
    }

    public boolean isConnected() {
        return ((I2cDeviceSynch) this.deviceClient).read8(0) == 95;
    }

    public void getVersionInfo(Version version, Version version2) {
        byte[] read = ((I2cDeviceSynch) this.deviceClient).read(1, 2);
        version.set(read[0]);
        version2.set(read[1]);
    }

    public boolean selfTest() {
        SelfTestConfig selfTestConfig = new SelfTestConfig();
        selfTestConfig.set((byte) 1);
        ((I2cDeviceSynch) this.deviceClient).write8(15, (int) selfTestConfig.get());
        int i = 0;
        while (i < 10) {
            try {
                Thread.sleep(5);
                selfTestConfig.set(((I2cDeviceSynch) this.deviceClient).read8(15));
                if (!selfTestConfig.inProgress) {
                    break;
                }
                i++;
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return selfTestConfig.pass;
    }

    public boolean calibrateImu() {
        return calibrateImu(255, true);
    }

    public boolean calibrateImu(int i, boolean z) {
        if (i >= 1 && i <= 255) {
            ((I2cDeviceSynch) this.deviceClient).write8(6, i);
            try {
                Thread.sleep(3);
                if (!z) {
                    return true;
                }
                while (i > 0) {
                    if (((I2cDeviceSynch) this.deviceClient).read8(6) == 0) {
                        return true;
                    }
                    try {
                        Thread.sleep(3);
                        i--;
                    } catch (InterruptedException unused) {
                        Thread.currentThread().interrupt();
                    }
                }
                return false;
            } catch (InterruptedException unused2) {
                Thread.currentThread().interrupt();
            }
        }
        return false;
    }

    public int getImuCalibrationProgress() {
        return ((I2cDeviceSynch) this.deviceClient).read8(6) & 255;
    }

    public DistanceUnit getLinearUnit() {
        return this._distanceUnit;
    }

    public void setLinearUnit(DistanceUnit distanceUnit) {
        if (distanceUnit != this._distanceUnit) {
            this._distanceUnit = distanceUnit;
        }
    }

    public AngleUnit getAngularUnit() {
        return this._angularUnit;
    }

    public void setAngularUnit(AngleUnit angleUnit) {
        if (angleUnit != this._angularUnit) {
            this._angularUnit = angleUnit;
        }
    }

    public double getLinearScalar() {
        return (((double) ((I2cDeviceSynch) this.deviceClient).read8(4)) * 0.001d) + 1.0d;
    }

    public boolean setLinearScalar(double d) {
        if (d < 0.872d || d > 1.127d) {
            return false;
        }
        ((I2cDeviceSynch) this.deviceClient).write8(4, (int) (byte) ((int) (((d - 1.0d) * 1000.0d) + 0.5d)));
        return true;
    }

    public double getAngularScalar() {
        return (((double) ((I2cDeviceSynch) this.deviceClient).read8(5)) * 0.001d) + 1.0d;
    }

    public boolean setAngularScalar(double d) {
        if (d < 0.872d || d > 1.127d) {
            return false;
        }
        ((I2cDeviceSynch) this.deviceClient).write8(5, (int) (byte) ((int) (((d - 1.0d) * 1000.0d) + 0.5d)));
        return true;
    }

    public void resetTracking() {
        ((I2cDeviceSynch) this.deviceClient).write8(7, 1);
    }

    public SignalProcessConfig getSignalProcessConfig() {
        return new SignalProcessConfig(((I2cDeviceSynch) this.deviceClient).read8(14));
    }

    public void setSignalProcessConfig(SignalProcessConfig signalProcessConfig) {
        ((I2cDeviceSynch) this.deviceClient).write8(14, (int) signalProcessConfig.get());
    }

    public Status getStatus() {
        return new Status(((I2cDeviceSynch) this.deviceClient).read8(31));
    }

    public Pose2D getOffset() {
        return readPoseRegs((byte) 16, INT16_TO_METER, INT16_TO_RAD);
    }

    public void setOffset(Pose2D pose2D) {
        writePoseRegs((byte) 16, pose2D, METER_TO_INT16, RAD_TO_INT16);
    }

    public Pose2D getPosition() {
        return readPoseRegs((byte) 32, INT16_TO_METER, INT16_TO_RAD);
    }

    public void setPosition(Pose2D pose2D) {
        writePoseRegs((byte) 32, pose2D, METER_TO_INT16, RAD_TO_INT16);
    }

    public Pose2D getVelocity() {
        return readPoseRegs(REG_VEL_XL, INT16_TO_MPS, INT16_TO_RPS);
    }

    public Pose2D getAcceleration() {
        return readPoseRegs(REG_ACC_XL, INT16_TO_MPSS, INT16_TO_RPSS);
    }

    public Pose2D getPositionStdDev() {
        return readPoseRegs(REG_POS_STD_XL, INT16_TO_METER, INT16_TO_RAD);
    }

    public Pose2D getVelocityStdDev() {
        return readPoseRegs(REG_VEL_STD_XL, INT16_TO_MPS, INT16_TO_RPS);
    }

    public Pose2D getAccelerationStdDev() {
        return readPoseRegs(REG_ACC_STD_XL, INT16_TO_MPSS, INT16_TO_RPSS);
    }

    public void getPosVelAcc(Pose2D pose2D, Pose2D pose2D2, Pose2D pose2D3) {
        byte[] read = ((I2cDeviceSynch) this.deviceClient).read(32, 18);
        pose2D.set(regsToPose(Arrays.copyOfRange(read, 0, 6), INT16_TO_METER, INT16_TO_RAD));
        pose2D2.set(regsToPose(Arrays.copyOfRange(read, 6, 12), INT16_TO_MPS, INT16_TO_RPS));
        pose2D3.set(regsToPose(Arrays.copyOfRange(read, 12, 18), INT16_TO_MPSS, INT16_TO_RPSS));
    }

    public void getPosVelAccStdDev(Pose2D pose2D, Pose2D pose2D2, Pose2D pose2D3) {
        byte[] read = ((I2cDeviceSynch) this.deviceClient).read(50, 18);
        pose2D.set(regsToPose(Arrays.copyOfRange(read, 0, 6), INT16_TO_METER, INT16_TO_RAD));
        pose2D2.set(regsToPose(Arrays.copyOfRange(read, 6, 12), INT16_TO_MPS, INT16_TO_RPS));
        pose2D3.set(regsToPose(Arrays.copyOfRange(read, 12, 18), INT16_TO_MPSS, INT16_TO_RPSS));
    }

    public void getPosVelAccAndStdDev(Pose2D pose2D, Pose2D pose2D2, Pose2D pose2D3, Pose2D pose2D4, Pose2D pose2D5, Pose2D pose2D6) {
        byte[] read = ((I2cDeviceSynch) this.deviceClient).read(32, 36);
        Pose2D pose2D7 = pose2D;
        pose2D.set(regsToPose(Arrays.copyOfRange(read, 0, 6), INT16_TO_METER, INT16_TO_RAD));
        Pose2D pose2D8 = pose2D2;
        pose2D2.set(regsToPose(Arrays.copyOfRange(read, 6, 12), INT16_TO_MPS, INT16_TO_RPS));
        Pose2D pose2D9 = pose2D3;
        pose2D3.set(regsToPose(Arrays.copyOfRange(read, 12, 18), INT16_TO_MPSS, INT16_TO_RPSS));
        Pose2D pose2D10 = pose2D4;
        pose2D4.set(regsToPose(Arrays.copyOfRange(read, 18, 24), INT16_TO_METER, INT16_TO_RAD));
        pose2D5.set(regsToPose(Arrays.copyOfRange(read, 24, 30), INT16_TO_MPS, INT16_TO_RPS));
        pose2D6.set(regsToPose(Arrays.copyOfRange(read, 30, 36), INT16_TO_MPSS, INT16_TO_RPSS));
    }

    /* access modifiers changed from: protected */
    public Pose2D readPoseRegs(byte b, double d, double d2) {
        return regsToPose(((I2cDeviceSynch) this.deviceClient).read(b, 6), d, d2);
    }

    /* access modifiers changed from: protected */
    public void writePoseRegs(byte b, Pose2D pose2D, double d, double d2) {
        byte[] bArr = new byte[6];
        poseToRegs(bArr, pose2D, d, d2);
        ((I2cDeviceSynch) this.deviceClient).write((int) b, bArr);
    }

    /* access modifiers changed from: protected */
    public Pose2D regsToPose(byte[] bArr, double d, double d2) {
        ByteBuffer wrap = ByteBuffer.wrap(bArr);
        wrap.order(ByteOrder.LITTLE_ENDIAN);
        short s = wrap.getShort(0);
        short s2 = wrap.getShort(2);
        short s3 = wrap.getShort(4);
        Pose2D pose2D = new Pose2D();
        pose2D.x = this._distanceUnit.fromMeters(((double) s) * d);
        pose2D.y = this._distanceUnit.fromMeters(((double) s2) * d);
        pose2D.h = this._angularUnit.fromRadians(((double) s3) * d2);
        return pose2D;
    }

    /* access modifiers changed from: protected */
    public void poseToRegs(byte[] bArr, Pose2D pose2D, double d, double d2) {
        short meters = (short) ((int) (this._distanceUnit.toMeters(pose2D.x) * d));
        short meters2 = (short) ((int) (this._distanceUnit.toMeters(pose2D.y) * d));
        short radians = (short) ((int) (this._angularUnit.toRadians(pose2D.h) * d2));
        bArr[0] = (byte) (meters & 255);
        bArr[1] = (byte) ((meters >> 8) & 255);
        bArr[2] = (byte) (meters2 & 255);
        bArr[3] = (byte) ((meters2 >> 8) & 255);
        bArr[4] = (byte) (radians & 255);
        bArr[5] = (byte) ((radians >> 8) & 255);
    }
}

package com.qualcomm.hardware;

import com.qualcomm.robotcore.hardware.RobotCoreLynxModule;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;
import org.firstinspires.ftc.robotcore.external.Func;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class HardwareDeviceManager$$ExternalSyntheticLambda0 implements Func {
    public final /* synthetic */ HardwareDeviceManager f$0;
    public final /* synthetic */ RobotCoreLynxModule f$1;
    public final /* synthetic */ DeviceConfiguration.I2cChannel f$2;
    public final /* synthetic */ String f$3;

    public /* synthetic */ HardwareDeviceManager$$ExternalSyntheticLambda0(HardwareDeviceManager hardwareDeviceManager, RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        this.f$0 = hardwareDeviceManager;
        this.f$1 = robotCoreLynxModule;
        this.f$2 = i2cChannel;
        this.f$3 = str;
    }

    public final Object value() {
        return this.f$0.m19lambda$createI2cDeviceInstances$0$comqualcommhardwareHardwareDeviceManager(this.f$1, this.f$2, this.f$3);
    }
}

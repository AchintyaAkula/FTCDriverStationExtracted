package com.qualcomm.hardware.rev;

import com.qualcomm.hardware.R;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055IMUNew;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;

@DeviceProperties(builtIn = true, description = "@string/rev_9_axis_imu_description", name = "@string/rev_9_axis_imu_name", xmlTag = "RevExternalImu")
@I2cDeviceType
public class Rev9AxisImu extends BNO055IMUNew {
    public Rev9AxisImu(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z, BNO055IMU.I2CADDR_ALTERNATE);
    }

    public String getDeviceName() {
        return AppUtil.getDefContext().getString(R.string.rev_9_axis_imu_name);
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.Lynx;
    }
}

package com.qualcomm.hardware.rev;

import com.qualcomm.hardware.lynx.LynxServoController;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;

public class RevHubOrientationOnRobot extends RevImuOrientationOnRobot {

    public enum LogoFacingDirection {
        UP,
        DOWN,
        FORWARD,
        BACKWARD,
        LEFT,
        RIGHT
    }

    public enum UsbFacingDirection {
        UP,
        DOWN,
        FORWARD,
        BACKWARD,
        LEFT,
        RIGHT
    }

    public /* bridge */ /* synthetic */ Quaternion angularVelocityTransform() {
        return super.angularVelocityTransform();
    }

    public /* bridge */ /* synthetic */ Quaternion imuCoordinateSystemOrientationFromPerspectiveOfRobot() {
        return super.imuCoordinateSystemOrientationFromPerspectiveOfRobot();
    }

    public /* bridge */ /* synthetic */ Quaternion imuRotationOffset() {
        return super.imuRotationOffset();
    }

    public RevHubOrientationOnRobot(LogoFacingDirection logoFacingDirection, UsbFacingDirection usbFacingDirection) {
        this(friendlyApiToOrientation(logoFacingDirection, usbFacingDirection));
    }

    public RevHubOrientationOnRobot(Orientation orientation) {
        this(Quaternion.fromMatrix(orientation.getRotationMatrix(), 0));
    }

    public RevHubOrientationOnRobot(Quaternion quaternion) {
        super(quaternion);
    }

    protected static Orientation friendlyApiToOrientation(LogoFacingDirection logoFacingDirection, UsbFacingDirection usbFacingDirection) {
        if (logoFacingDirection == LogoFacingDirection.UP) {
            if (usbFacingDirection == UsbFacingDirection.UP) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.DOWN) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.FORWARD) {
                return zyxOrientation(LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
            } else {
                if (usbFacingDirection == UsbFacingDirection.BACKWARD) {
                    return zyxOrientation(180.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
                }
                if (usbFacingDirection == UsbFacingDirection.LEFT) {
                    return zyxOrientation(90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
                }
                if (usbFacingDirection == UsbFacingDirection.RIGHT) {
                    return zyxOrientation(-90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.DOWN) {
            if (usbFacingDirection == UsbFacingDirection.UP) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.DOWN) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.FORWARD) {
                return zyxOrientation(LynxServoController.apiPositionFirst, 180.0d, LynxServoController.apiPositionFirst);
            } else {
                if (usbFacingDirection == UsbFacingDirection.BACKWARD) {
                    return zyxOrientation(180.0d, 180.0d, LynxServoController.apiPositionFirst);
                }
                if (usbFacingDirection == UsbFacingDirection.LEFT) {
                    return zyxOrientation(90.0d, 180.0d, LynxServoController.apiPositionFirst);
                }
                if (usbFacingDirection == UsbFacingDirection.RIGHT) {
                    return zyxOrientation(-90.0d, 180.0d, LynxServoController.apiPositionFirst);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.FORWARD) {
            if (usbFacingDirection == UsbFacingDirection.UP) {
                return xyzOrientation(90.0d, 180.0d, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.DOWN) {
                return xyzOrientation(-90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.FORWARD) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.BACKWARD) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.LEFT) {
                return xyzOrientation(-90.0d, LynxServoController.apiPositionFirst, 90.0d);
            } else {
                if (usbFacingDirection == UsbFacingDirection.RIGHT) {
                    return xyzOrientation(-90.0d, LynxServoController.apiPositionFirst, -90.0d);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.BACKWARD) {
            if (usbFacingDirection == UsbFacingDirection.UP) {
                return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.DOWN) {
                return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, 180.0d);
            }
            if (usbFacingDirection == UsbFacingDirection.FORWARD) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.BACKWARD) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.LEFT) {
                return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, 90.0d);
            } else {
                if (usbFacingDirection == UsbFacingDirection.RIGHT) {
                    return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, -90.0d);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.LEFT) {
            if (usbFacingDirection == UsbFacingDirection.UP) {
                return xyzOrientation(90.0d, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.DOWN) {
                return xyzOrientation(-90.0d, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.FORWARD) {
                return xyzOrientation(LynxServoController.apiPositionFirst, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.BACKWARD) {
                return xyzOrientation(LynxServoController.apiPositionFirst, -90.0d, 180.0d);
            }
            if (usbFacingDirection == UsbFacingDirection.LEFT) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.RIGHT) {
                throwIllegalHubOrientationException();
            }
        } else if (logoFacingDirection == LogoFacingDirection.RIGHT) {
            if (usbFacingDirection == UsbFacingDirection.UP) {
                return zyxOrientation(90.0d, LynxServoController.apiPositionFirst, 90.0d);
            }
            if (usbFacingDirection == UsbFacingDirection.DOWN) {
                return zyxOrientation(-90.0d, LynxServoController.apiPositionFirst, -90.0d);
            }
            if (usbFacingDirection == UsbFacingDirection.FORWARD) {
                return zyxOrientation(LynxServoController.apiPositionFirst, 90.0d, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.BACKWARD) {
                return zyxOrientation(180.0d, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (usbFacingDirection == UsbFacingDirection.LEFT) {
                throwIllegalHubOrientationException();
            } else if (usbFacingDirection == UsbFacingDirection.RIGHT) {
                throwIllegalHubOrientationException();
            }
        }
        throw new RuntimeException("The FTC SDK developers forgot about this combination, please file a bug report.");
    }

    private static void throwIllegalHubOrientationException() {
        throw new IllegalArgumentException("The specified REV Hub orientation is physically impossible");
    }

    public static Orientation zyxOrientation(double d, double d2, double d3) {
        return RevImuOrientationOnRobot.zyxOrientation(d, d2, d3);
    }

    public static Orientation xyzOrientation(double d, double d2, double d3) {
        return RevImuOrientationOnRobot.xyzOrientation(d, d2, d3);
    }
}

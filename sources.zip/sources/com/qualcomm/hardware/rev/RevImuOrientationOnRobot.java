package com.qualcomm.hardware.rev;

import com.qualcomm.robotcore.hardware.ImuOrientationOnRobot;
import com.qualcomm.robotcore.hardware.QuaternionBasedImuHelper;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;

abstract class RevImuOrientationOnRobot implements ImuOrientationOnRobot {
    private final Quaternion angularVelocityTransform;
    private final Quaternion imuRotationOffset;
    private final Quaternion robotCoordinateSystemFromPerspectiveOfImu;

    protected RevImuOrientationOnRobot(Quaternion quaternion) {
        Quaternion normalized = quaternion.multiply(QuaternionBasedImuHelper.quaternionFromZAxisRotation(-90.0f, AngleUnit.DEGREES), 0).normalized();
        this.angularVelocityTransform = new Quaternion(normalized.w, normalized.x, normalized.y, normalized.z, 0);
        Quaternion normalized2 = new Quaternion(normalized.w, 0.0f, 0.0f, normalized.z, 0).normalized();
        this.robotCoordinateSystemFromPerspectiveOfImu = normalized2;
        this.imuRotationOffset = normalized.multiply(normalized2.inverse(), 0).normalized().inverse().normalized();
    }

    public Quaternion imuCoordinateSystemOrientationFromPerspectiveOfRobot() {
        return this.robotCoordinateSystemFromPerspectiveOfImu;
    }

    public Quaternion imuRotationOffset() {
        return this.imuRotationOffset;
    }

    public Quaternion angularVelocityTransform() {
        return this.angularVelocityTransform;
    }

    static Orientation zyxOrientation(double d, double d2, double d3) {
        return new Orientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES, (float) d, (float) d2, (float) d3, 0);
    }

    static Orientation xyzOrientation(double d, double d2, double d3) {
        return new Orientation(AxesReference.INTRINSIC, AxesOrder.XYZ, AngleUnit.DEGREES, (float) d, (float) d2, (float) d3, 0);
    }
}

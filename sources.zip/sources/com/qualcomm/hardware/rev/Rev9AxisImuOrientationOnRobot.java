package com.qualcomm.hardware.rev;

import com.qualcomm.hardware.lynx.LynxServoController;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;

public class Rev9AxisImuOrientationOnRobot extends RevImuOrientationOnRobot {

    public enum I2cPortFacingDirection {
        UP,
        DOWN,
        FORWARD,
        BACKWARD,
        LEFT,
        RIGHT
    }

    public enum LogoFacingDirection {
        UP,
        DOWN,
        FORWARD,
        BACKWARD,
        LEFT,
        RIGHT
    }

    public /* bridge */ /* synthetic */ Quaternion angularVelocityTransform() {
        return super.angularVelocityTransform();
    }

    public /* bridge */ /* synthetic */ Quaternion imuCoordinateSystemOrientationFromPerspectiveOfRobot() {
        return super.imuCoordinateSystemOrientationFromPerspectiveOfRobot();
    }

    public /* bridge */ /* synthetic */ Quaternion imuRotationOffset() {
        return super.imuRotationOffset();
    }

    public Rev9AxisImuOrientationOnRobot(LogoFacingDirection logoFacingDirection, I2cPortFacingDirection i2cPortFacingDirection) {
        this(friendlyApiToOrientation(logoFacingDirection, i2cPortFacingDirection));
    }

    public Rev9AxisImuOrientationOnRobot(Orientation orientation) {
        this(Quaternion.fromMatrix(orientation.getRotationMatrix(), 0));
    }

    public Rev9AxisImuOrientationOnRobot(Quaternion quaternion) {
        super(quaternion);
    }

    protected static Orientation friendlyApiToOrientation(LogoFacingDirection logoFacingDirection, I2cPortFacingDirection i2cPortFacingDirection) {
        if (logoFacingDirection == LogoFacingDirection.UP) {
            if (i2cPortFacingDirection == I2cPortFacingDirection.UP) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.DOWN) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.FORWARD) {
                return zyxOrientation(LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
            } else {
                if (i2cPortFacingDirection == I2cPortFacingDirection.BACKWARD) {
                    return zyxOrientation(180.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
                }
                if (i2cPortFacingDirection == I2cPortFacingDirection.LEFT) {
                    return zyxOrientation(90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
                }
                if (i2cPortFacingDirection == I2cPortFacingDirection.RIGHT) {
                    return zyxOrientation(-90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.DOWN) {
            if (i2cPortFacingDirection == I2cPortFacingDirection.UP) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.DOWN) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.FORWARD) {
                return zyxOrientation(LynxServoController.apiPositionFirst, 180.0d, LynxServoController.apiPositionFirst);
            } else {
                if (i2cPortFacingDirection == I2cPortFacingDirection.BACKWARD) {
                    return zyxOrientation(180.0d, 180.0d, LynxServoController.apiPositionFirst);
                }
                if (i2cPortFacingDirection == I2cPortFacingDirection.LEFT) {
                    return zyxOrientation(90.0d, 180.0d, LynxServoController.apiPositionFirst);
                }
                if (i2cPortFacingDirection == I2cPortFacingDirection.RIGHT) {
                    return zyxOrientation(-90.0d, 180.0d, LynxServoController.apiPositionFirst);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.FORWARD) {
            if (i2cPortFacingDirection == I2cPortFacingDirection.UP) {
                return xyzOrientation(90.0d, 180.0d, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.DOWN) {
                return xyzOrientation(-90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.FORWARD) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.BACKWARD) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.LEFT) {
                return xyzOrientation(-90.0d, LynxServoController.apiPositionFirst, 90.0d);
            } else {
                if (i2cPortFacingDirection == I2cPortFacingDirection.RIGHT) {
                    return xyzOrientation(-90.0d, LynxServoController.apiPositionFirst, -90.0d);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.BACKWARD) {
            if (i2cPortFacingDirection == I2cPortFacingDirection.UP) {
                return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.DOWN) {
                return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, 180.0d);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.FORWARD) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.BACKWARD) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.LEFT) {
                return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, 90.0d);
            } else {
                if (i2cPortFacingDirection == I2cPortFacingDirection.RIGHT) {
                    return xyzOrientation(90.0d, LynxServoController.apiPositionFirst, -90.0d);
                }
            }
        } else if (logoFacingDirection == LogoFacingDirection.LEFT) {
            if (i2cPortFacingDirection == I2cPortFacingDirection.UP) {
                return xyzOrientation(90.0d, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.DOWN) {
                return xyzOrientation(-90.0d, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.FORWARD) {
                return xyzOrientation(LynxServoController.apiPositionFirst, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.BACKWARD) {
                return xyzOrientation(LynxServoController.apiPositionFirst, -90.0d, 180.0d);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.LEFT) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.RIGHT) {
                throwIllegalImuOrientationException();
            }
        } else if (logoFacingDirection == LogoFacingDirection.RIGHT) {
            if (i2cPortFacingDirection == I2cPortFacingDirection.UP) {
                return zyxOrientation(90.0d, LynxServoController.apiPositionFirst, 90.0d);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.DOWN) {
                return zyxOrientation(-90.0d, LynxServoController.apiPositionFirst, -90.0d);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.FORWARD) {
                return zyxOrientation(LynxServoController.apiPositionFirst, 90.0d, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.BACKWARD) {
                return zyxOrientation(180.0d, -90.0d, LynxServoController.apiPositionFirst);
            }
            if (i2cPortFacingDirection == I2cPortFacingDirection.LEFT) {
                throwIllegalImuOrientationException();
            } else if (i2cPortFacingDirection == I2cPortFacingDirection.RIGHT) {
                throwIllegalImuOrientationException();
            }
        }
        throw new RuntimeException("The FTC SDK developers forgot about this combination, please file a bug report.");
    }

    private static void throwIllegalImuOrientationException() {
        throw new IllegalArgumentException("The specified REV 9-Axis IMU orientation is physically impossible");
    }

    public static Orientation zyxOrientation(double d, double d2, double d3) {
        return RevImuOrientationOnRobot.zyxOrientation(d, d2, d3);
    }

    public static Orientation xyzOrientation(double d, double d2, double d3) {
        return RevImuOrientationOnRobot.xyzOrientation(d, d2, d3);
    }
}

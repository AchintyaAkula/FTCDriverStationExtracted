package com.qualcomm.hardware.gobilda;

import com.qualcomm.hardware.lynx.LynxI2cDeviceSynch;
import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.util.TypeConversion;
import fi.iki.elonen.NanoHTTPD;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose2D;
import org.firstinspires.ftc.robotcore.external.navigation.UnnormalizedAngleUnit;

@I2cDeviceType
@DeviceProperties(description = "goBILDA® Pinpoint Odometry Computer (IMU Sensor Fusion for 2 Wheel Odometry)", name = "goBILDA® Pinpoint Odometry Computer", xmlTag = "goBILDAPinpoint")
public class GoBildaPinpointDriver extends I2cDeviceSynchDevice<I2cDeviceSynchSimple> {
    private static final byte DEFAULT_ADDRESS = 49;
    private static final float goBILDA_4_BAR_POD = 19.894367f;
    private static final float goBILDA_SWINGARM_POD = 13.262912f;
    private int deviceStatus = 0;
    private float hOrientation = 0.0f;
    private float hVelocity = 0.0f;
    private int loopTime = 0;
    private int xEncoderValue = 0;
    private float xPosition = 0.0f;
    private float xVelocity = 0.0f;
    private int yEncoderValue = 0;
    private float yPosition = 0.0f;
    private float yVelocity = 0.0f;

    public enum EncoderDirection {
        FORWARD,
        REVERSED
    }

    public enum GoBildaOdometryPods {
        goBILDA_SWINGARM_POD,
        goBILDA_4_BAR_POD
    }

    public enum ReadData {
        ONLY_UPDATE_HEADING
    }

    public GoBildaPinpointDriver(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z);
        this.deviceClient.setI2cAddress(I2cAddr.create7bit(49));
        super.registerArmingStateCallback(false);
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.GoBilda;
    }

    /* access modifiers changed from: protected */
    public synchronized boolean doInitialize() {
        ((LynxI2cDeviceSynch) this.deviceClient).setBusSpeed(LynxI2cDeviceSynch.BusSpeed.FAST_400K);
        return true;
    }

    public String getDeviceName() {
        return "goBILDA® Pinpoint Odometry Computer";
    }

    private enum Register {
        DEVICE_ID(1),
        DEVICE_VERSION(2),
        DEVICE_STATUS(3),
        DEVICE_CONTROL(4),
        LOOP_TIME(5),
        X_ENCODER_VALUE(6),
        Y_ENCODER_VALUE(7),
        X_POSITION(8),
        Y_POSITION(9),
        H_ORIENTATION(10),
        X_VELOCITY(11),
        Y_VELOCITY(12),
        H_VELOCITY(13),
        TICKS_PER_MM(14),
        X_POD_OFFSET(15),
        Y_POD_OFFSET(16),
        YAW_SCALAR(17),
        BULK_READ(18);
        
        /* access modifiers changed from: private */
        public final int bVal;

        private Register(int i) {
            this.bVal = i;
        }
    }

    public enum DeviceStatus {
        NOT_READY(0),
        READY(1),
        CALIBRATING(2),
        FAULT_X_POD_NOT_DETECTED(4),
        FAULT_Y_POD_NOT_DETECTED(8),
        FAULT_NO_PODS_DETECTED(12),
        FAULT_IMU_RUNAWAY(16),
        FAULT_BAD_READ(32);
        
        /* access modifiers changed from: private */
        public final int status;

        private DeviceStatus(int i) {
            this.status = i;
        }
    }

    private enum DeviceControl {
        RECALIBRATE_IMU(1),
        RESET_POS_AND_IMU(2),
        SET_X_ENCODER_REVERSED(16),
        SET_X_ENCODER_FORWARD(32),
        SET_Y_ENCODER_REVERSED(4),
        SET_Y_ENCODER_FORWARD(8);
        
        public final int value;

        private DeviceControl(int i) {
            this.value = i;
        }
    }

    private void writeInt(Register register, int i) {
        this.deviceClient.write(register.bVal, TypeConversion.intToByteArray(i, ByteOrder.LITTLE_ENDIAN));
    }

    private int readInt(Register register) {
        return TypeConversion.byteArrayToInt(this.deviceClient.read(register.bVal, 4), ByteOrder.LITTLE_ENDIAN);
    }

    private float byteArrayToFloat(byte[] bArr, ByteOrder byteOrder) {
        return ByteBuffer.wrap(bArr).order(byteOrder).getFloat();
    }

    private float readFloat(Register register) {
        return byteArrayToFloat(this.deviceClient.read(register.bVal, 4), ByteOrder.LITTLE_ENDIAN);
    }

    private byte[] floatToByteArray(float f, ByteOrder byteOrder) {
        return ByteBuffer.allocate(4).order(byteOrder).putFloat(f).array();
    }

    private void writeByteArray(Register register, byte[] bArr) {
        this.deviceClient.write(register.bVal, bArr);
    }

    private void writeFloat(Register register, float f) {
        this.deviceClient.write(register.bVal, ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(f).array());
    }

    private DeviceStatus lookupStatus(int i) {
        if ((DeviceStatus.CALIBRATING.status & i) != 0) {
            return DeviceStatus.CALIBRATING;
        }
        boolean z = true;
        boolean z2 = (DeviceStatus.FAULT_X_POD_NOT_DETECTED.status & i) == 0;
        if ((DeviceStatus.FAULT_Y_POD_NOT_DETECTED.status & i) != 0) {
            z = false;
        }
        if (!z2 && !z) {
            return DeviceStatus.FAULT_NO_PODS_DETECTED;
        }
        if (!z2) {
            return DeviceStatus.FAULT_X_POD_NOT_DETECTED;
        }
        if (!z) {
            return DeviceStatus.FAULT_Y_POD_NOT_DETECTED;
        }
        if ((DeviceStatus.FAULT_IMU_RUNAWAY.status & i) != 0) {
            return DeviceStatus.FAULT_IMU_RUNAWAY;
        }
        if ((DeviceStatus.READY.status & i) != 0) {
            return DeviceStatus.READY;
        }
        if ((i & DeviceStatus.FAULT_BAD_READ.status) != 0) {
            return DeviceStatus.FAULT_BAD_READ;
        }
        return DeviceStatus.NOT_READY;
    }

    private Float isPositionCorrupt(float f, float f2, int i, boolean z) {
        if ((!z || this.loopTime >= 1) && !Float.isNaN(f2) && Math.abs(f2 - f) <= ((float) i)) {
            return Float.valueOf(f2);
        }
        this.deviceStatus = DeviceStatus.FAULT_BAD_READ.status;
        return Float.valueOf(f);
    }

    private Float isVelocityCorrupt(float f, float f2, int i) {
        if (!(Float.isNaN(f2) || Math.abs(f2) > ((float) i))) {
            return Float.valueOf(f2);
        }
        this.deviceStatus = DeviceStatus.FAULT_BAD_READ.status;
        return Float.valueOf(f);
    }

    public void update() {
        float f = this.xPosition;
        float f2 = this.yPosition;
        float f3 = this.hOrientation;
        float f4 = this.xVelocity;
        float f5 = this.yVelocity;
        float f6 = this.hVelocity;
        byte[] read = this.deviceClient.read(Register.BULK_READ.bVal, 40);
        this.deviceStatus = TypeConversion.byteArrayToInt(Arrays.copyOfRange(read, 0, 4), ByteOrder.LITTLE_ENDIAN);
        this.loopTime = TypeConversion.byteArrayToInt(Arrays.copyOfRange(read, 4, 8), ByteOrder.LITTLE_ENDIAN);
        this.xEncoderValue = TypeConversion.byteArrayToInt(Arrays.copyOfRange(read, 8, 12), ByteOrder.LITTLE_ENDIAN);
        this.yEncoderValue = TypeConversion.byteArrayToInt(Arrays.copyOfRange(read, 12, 16), ByteOrder.LITTLE_ENDIAN);
        this.xPosition = byteArrayToFloat(Arrays.copyOfRange(read, 16, 20), ByteOrder.LITTLE_ENDIAN);
        this.yPosition = byteArrayToFloat(Arrays.copyOfRange(read, 20, 24), ByteOrder.LITTLE_ENDIAN);
        this.hOrientation = byteArrayToFloat(Arrays.copyOfRange(read, 24, 28), ByteOrder.LITTLE_ENDIAN);
        this.xVelocity = byteArrayToFloat(Arrays.copyOfRange(read, 28, 32), ByteOrder.LITTLE_ENDIAN);
        this.yVelocity = byteArrayToFloat(Arrays.copyOfRange(read, 32, 36), ByteOrder.LITTLE_ENDIAN);
        this.hVelocity = byteArrayToFloat(Arrays.copyOfRange(read, 36, 40), ByteOrder.LITTLE_ENDIAN);
        this.xPosition = isPositionCorrupt(f, this.xPosition, NanoHTTPD.SOCKET_READ_TIMEOUT, true).floatValue();
        this.yPosition = isPositionCorrupt(f2, this.yPosition, NanoHTTPD.SOCKET_READ_TIMEOUT, true).floatValue();
        this.hOrientation = isPositionCorrupt(f3, this.hOrientation, 120, true).floatValue();
        this.xVelocity = isVelocityCorrupt(f4, this.xVelocity, 10000).floatValue();
        this.yVelocity = isVelocityCorrupt(f5, this.yVelocity, 10000).floatValue();
        this.hVelocity = isVelocityCorrupt(f6, this.hVelocity, 120).floatValue();
    }

    public void update(ReadData readData) {
        if (readData == ReadData.ONLY_UPDATE_HEADING) {
            float f = this.hOrientation;
            float byteArrayToFloat = byteArrayToFloat(this.deviceClient.read(Register.H_ORIENTATION.bVal, 4), ByteOrder.LITTLE_ENDIAN);
            this.hOrientation = byteArrayToFloat;
            this.hOrientation = isPositionCorrupt(f, byteArrayToFloat, 120, false).floatValue();
            if (this.deviceStatus == DeviceStatus.FAULT_BAD_READ.status) {
                this.deviceStatus = DeviceStatus.READY.status;
            }
        }
    }

    public void setOffsets(double d, double d2, DistanceUnit distanceUnit) {
        writeFloat(Register.X_POD_OFFSET, (float) distanceUnit.toMm(d));
        writeFloat(Register.Y_POD_OFFSET, (float) distanceUnit.toMm(d2));
    }

    public void recalibrateIMU() {
        writeInt(Register.DEVICE_CONTROL, DeviceControl.RECALIBRATE_IMU.value);
    }

    public void resetPosAndIMU() {
        writeInt(Register.DEVICE_CONTROL, DeviceControl.RESET_POS_AND_IMU.value);
    }

    public void setEncoderDirections(EncoderDirection encoderDirection, EncoderDirection encoderDirection2) {
        if (encoderDirection == EncoderDirection.FORWARD) {
            writeInt(Register.DEVICE_CONTROL, DeviceControl.SET_X_ENCODER_FORWARD.value);
        }
        if (encoderDirection == EncoderDirection.REVERSED) {
            writeInt(Register.DEVICE_CONTROL, DeviceControl.SET_X_ENCODER_REVERSED.value);
        }
        if (encoderDirection2 == EncoderDirection.FORWARD) {
            writeInt(Register.DEVICE_CONTROL, DeviceControl.SET_Y_ENCODER_FORWARD.value);
        }
        if (encoderDirection2 == EncoderDirection.REVERSED) {
            writeInt(Register.DEVICE_CONTROL, DeviceControl.SET_Y_ENCODER_REVERSED.value);
        }
    }

    public void setEncoderResolution(GoBildaOdometryPods goBildaOdometryPods) {
        if (goBildaOdometryPods == GoBildaOdometryPods.goBILDA_SWINGARM_POD) {
            setEncoderResolution(13.262911796569824d, DistanceUnit.MM);
        }
        if (goBildaOdometryPods == GoBildaOdometryPods.goBILDA_4_BAR_POD) {
            setEncoderResolution(19.894367218017578d, DistanceUnit.MM);
        }
    }

    public void setEncoderResolution(double d, DistanceUnit distanceUnit) {
        writeByteArray(Register.TICKS_PER_MM, floatToByteArray((float) distanceUnit.toMm(d), ByteOrder.LITTLE_ENDIAN));
    }

    public void setYawScalar(double d) {
        writeByteArray(Register.YAW_SCALAR, floatToByteArray((float) d, ByteOrder.LITTLE_ENDIAN));
    }

    public void setPosition(Pose2D pose2D) {
        setPosX(pose2D.getX(DistanceUnit.MM), DistanceUnit.MM);
        setPosY(pose2D.getY(DistanceUnit.MM), DistanceUnit.MM);
        setHeading(pose2D.getHeading(AngleUnit.RADIANS), AngleUnit.RADIANS);
    }

    public void setPosX(double d, DistanceUnit distanceUnit) {
        writeByteArray(Register.X_POSITION, floatToByteArray((float) distanceUnit.toMm(d), ByteOrder.LITTLE_ENDIAN));
    }

    public void setPosY(double d, DistanceUnit distanceUnit) {
        writeByteArray(Register.Y_POSITION, floatToByteArray((float) distanceUnit.toMm(d), ByteOrder.LITTLE_ENDIAN));
    }

    public void setHeading(double d, AngleUnit angleUnit) {
        writeByteArray(Register.H_ORIENTATION, floatToByteArray((float) angleUnit.toRadians(d), ByteOrder.LITTLE_ENDIAN));
    }

    public int getDeviceID() {
        return readInt(Register.DEVICE_ID);
    }

    public int getDeviceVersion() {
        return readInt(Register.DEVICE_VERSION);
    }

    public float getYawScalar() {
        return readFloat(Register.YAW_SCALAR);
    }

    public DeviceStatus getDeviceStatus() {
        return lookupStatus(this.deviceStatus);
    }

    public int getLoopTime() {
        return this.loopTime;
    }

    public double getFrequency() {
        int i = this.loopTime;
        return i != 0 ? 1000000.0d / ((double) i) : LynxServoController.apiPositionFirst;
    }

    public int getEncoderX() {
        return this.xEncoderValue;
    }

    public int getEncoderY() {
        return this.yEncoderValue;
    }

    public double getPosX(DistanceUnit distanceUnit) {
        return distanceUnit.fromMm((double) this.xPosition);
    }

    public double getPosY(DistanceUnit distanceUnit) {
        return distanceUnit.fromMm((double) this.yPosition);
    }

    public double getHeading(AngleUnit angleUnit) {
        return (double) angleUnit.fromRadians(this.hOrientation);
    }

    public double getHeading(UnnormalizedAngleUnit unnormalizedAngleUnit) {
        return (double) unnormalizedAngleUnit.fromRadians(this.hOrientation);
    }

    public double getVelX(DistanceUnit distanceUnit) {
        return distanceUnit.fromMm((double) this.xVelocity);
    }

    public double getVelY(DistanceUnit distanceUnit) {
        return distanceUnit.fromMm((double) this.yVelocity);
    }

    public double getHeadingVelocity(UnnormalizedAngleUnit unnormalizedAngleUnit) {
        return (double) unnormalizedAngleUnit.fromRadians(this.hVelocity);
    }

    public float getXOffset(DistanceUnit distanceUnit) {
        return (float) distanceUnit.fromMm((double) readFloat(Register.X_POD_OFFSET));
    }

    public float getYOffset(DistanceUnit distanceUnit) {
        return (float) distanceUnit.fromMm((double) readFloat(Register.Y_POD_OFFSET));
    }

    public Pose2D getPosition() {
        return new Pose2D(DistanceUnit.MM, (double) this.xPosition, (double) this.yPosition, AngleUnit.RADIANS, (double) AngleUnit.normalizeRadians(this.hOrientation));
    }
}

package com.qualcomm.hardware.bosch;

import org.firstinspires.ftc.robotcore.external.function.ThrowingSupplier;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class BHI260IMU$$ExternalSyntheticLambda0 implements ThrowingSupplier {
    public final /* synthetic */ BHI260IMU f$0;

    public /* synthetic */ BHI260IMU$$ExternalSyntheticLambda0(BHI260IMU bhi260imu) {
        this.f$0 = bhi260imu;
    }

    public final Object get() {
        return this.f$0.getRawQuaternion();
    }
}

package com.qualcomm.hardware.bosch;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055IMUImpl;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.I2cWaitControl;
import com.qualcomm.robotcore.hardware.QuaternionBasedImuHelper;
import com.qualcomm.robotcore.hardware.TimestampedData;
import com.qualcomm.robotcore.util.ReadWriteFile;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.TypeConversion;
import java.io.IOException;
import java.nio.ByteOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;

public class BNO055Util {

    public static class InitException extends Exception {
        public InitException(String str) {
            super(str);
        }
    }

    public static void sharedInit(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Parameters parameters) throws InitException {
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.PWR_MODE, BNO055IMUImpl.POWER_MODE.NORMAL.getValue(), I2cWaitControl.WRITTEN);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.PAGE_ID, 0);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.UNIT_SEL, (parameters.pitchMode.bVal << 7) | (parameters.temperatureUnit.bVal << 4) | (parameters.angleUnit.bVal << 2) | (parameters.angleUnit.bVal << 1) | parameters.accelUnit.bVal);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.AXIS_MAP_CONFIG, 36);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.AXIS_MAP_SIGN, 0);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.PAGE_ID, 1);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.ACC_CONFIG, parameters.accelPowerMode.bVal | parameters.accelBandwidth.bVal | parameters.accelRange.bVal);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.MAG_CONFIG, parameters.magPowerMode.bVal | parameters.magOpMode.bVal | parameters.magRate.bVal);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.GYR_CONFIG_0, parameters.gyroBandwidth.bVal | parameters.gyroRange.bVal);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.GYR_CONFIG_1, parameters.gyroPowerMode.bVal);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.PAGE_ID, 0);
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.SYS_TRIGGER, 0);
        if (parameters.calibrationData != null) {
            writeCalibrationData(i2cDeviceSynchSimple, parameters.calibrationData);
        } else if (parameters.calibrationDataFile != null) {
            try {
                writeCalibrationData(i2cDeviceSynchSimple, BNO055IMU.CalibrationData.deserialize(ReadWriteFile.readFileOrThrow(AppUtil.getInstance().getSettingsFile(parameters.calibrationDataFile))));
            } catch (IOException unused) {
            }
        }
        setSensorMode(i2cDeviceSynchSimple, parameters.mode);
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(6:6|7|8|9|10|11) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x001e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean imuIsPresent(com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple r7, boolean r8) {
        /*
            java.lang.String r0 = "Suppressing I2C warnings while we check for a BNO055 IMU"
            java.lang.String r1 = "BNO055"
            com.qualcomm.robotcore.util.RobotLog.vv(r1, r0)
            r0 = 1
            com.qualcomm.robotcore.hardware.I2cWarningManager.suppressNewProblemDeviceWarnings(r0)
            r2 = 0
            com.qualcomm.hardware.bosch.BNO055IMU$Register r3 = com.qualcomm.hardware.bosch.BNO055IMU.Register.CHIP_ID     // Catch:{ all -> 0x003f }
            byte r3 = read8(r7, r3)     // Catch:{ all -> 0x003f }
            r4 = -96
            if (r3 == r4) goto L_0x002b
            if (r8 == 0) goto L_0x002b
            r5 = 650(0x28a, double:3.21E-321)
            java.lang.Thread.sleep(r5)     // Catch:{ InterruptedException -> 0x001e }
            goto L_0x0025
        L_0x001e:
            java.lang.Thread r8 = java.lang.Thread.currentThread()     // Catch:{ all -> 0x003f }
            r8.interrupt()     // Catch:{ all -> 0x003f }
        L_0x0025:
            com.qualcomm.hardware.bosch.BNO055IMU$Register r8 = com.qualcomm.hardware.bosch.BNO055IMU.Register.CHIP_ID     // Catch:{ all -> 0x003f }
            byte r3 = read8(r7, r8)     // Catch:{ all -> 0x003f }
        L_0x002b:
            if (r3 != r4) goto L_0x0036
            java.lang.String r7 = "Found BNO055 IMU"
            com.qualcomm.robotcore.util.RobotLog.vv(r1, r7)     // Catch:{ all -> 0x003f }
            com.qualcomm.robotcore.hardware.I2cWarningManager.suppressNewProblemDeviceWarnings(r2)
            return r0
        L_0x0036:
            java.lang.String r7 = "No BNO055 IMU found"
            com.qualcomm.robotcore.util.RobotLog.vv(r1, r7)     // Catch:{ all -> 0x003f }
            com.qualcomm.robotcore.hardware.I2cWarningManager.suppressNewProblemDeviceWarnings(r2)
            return r2
        L_0x003f:
            r7 = move-exception
            com.qualcomm.robotcore.hardware.I2cWarningManager.suppressNewProblemDeviceWarnings(r2)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.bosch.BNO055Util.imuIsPresent(com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple, boolean):boolean");
    }

    public static BNO055IMU.SystemStatus getSystemStatus(I2cDeviceSynchSimple i2cDeviceSynchSimple, String str) {
        byte read8 = read8(i2cDeviceSynchSimple, BNO055IMU.Register.SYS_STAT);
        BNO055IMU.SystemStatus from = BNO055IMU.SystemStatus.from(read8);
        if (from == BNO055IMU.SystemStatus.UNKNOWN) {
            RobotLog.ww(str, "unknown system status observed: 0x%08x", Byte.valueOf(read8));
        }
        return from;
    }

    public static void writeCalibrationData(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.CalibrationData calibrationData) {
        BNO055IMU.SensorMode sensorMode = getSensorMode(i2cDeviceSynchSimple);
        if (sensorMode != BNO055IMU.SensorMode.CONFIG) {
            setSensorMode(i2cDeviceSynchSimple, BNO055IMU.SensorMode.CONFIG);
        }
        write8(i2cDeviceSynchSimple, BNO055IMU.Register.PAGE_ID, 0);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.ACC_OFFSET_X_LSB, calibrationData.dxAccel);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.ACC_OFFSET_Y_LSB, calibrationData.dyAccel);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.ACC_OFFSET_Z_LSB, calibrationData.dzAccel);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.MAG_OFFSET_X_LSB, calibrationData.dxMag);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.MAG_OFFSET_Y_LSB, calibrationData.dyMag);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.MAG_OFFSET_Z_LSB, calibrationData.dzMag);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.GYR_OFFSET_X_LSB, calibrationData.dxGyro);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.GYR_OFFSET_Y_LSB, calibrationData.dyGyro);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.GYR_OFFSET_Z_LSB, calibrationData.dzGyro);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.ACC_RADIUS_LSB, calibrationData.radiusAccel);
        writeShort(i2cDeviceSynchSimple, BNO055IMU.Register.MAG_RADIUS_LSB, calibrationData.radiusMag);
        if (sensorMode != BNO055IMU.SensorMode.CONFIG) {
            setSensorMode(i2cDeviceSynchSimple, sensorMode);
        }
    }

    public static void setSensorMode(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.SensorMode sensorMode) {
        if (getSensorMode(i2cDeviceSynchSimple) != sensorMode) {
            write8(i2cDeviceSynchSimple, BNO055IMU.Register.OPR_MODE, sensorMode.bVal & 15, I2cWaitControl.WRITTEN);
            try {
                if (sensorMode == BNO055IMU.SensorMode.CONFIG) {
                    Thread.sleep(25);
                } else {
                    Thread.sleep(15);
                }
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static BNO055IMU.SensorMode getSensorMode(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        return BNO055IMU.SensorMode.fromByte(read8(i2cDeviceSynchSimple, BNO055IMU.Register.OPR_MODE));
    }

    public static Quaternion getRawQuaternion(I2cDeviceSynchSimple i2cDeviceSynchSimple) throws QuaternionBasedImuHelper.FailedToRetrieveQuaternionException {
        TimestampedData readTimeStamped = i2cDeviceSynchSimple.readTimeStamped(BNO055IMU.Register.QUA_DATA_W_LSB.bVal, 8);
        for (byte b : readTimeStamped.data) {
            if (b != 0) {
                BNO055IMUImpl.VectorData vectorData = new BNO055IMUImpl.VectorData(readTimeStamped, 16384.0f);
                return new Quaternion(vectorData.next(), vectorData.next(), vectorData.next(), vectorData.next(), vectorData.data.nanoTime);
            }
        }
        throw new QuaternionBasedImuHelper.FailedToRetrieveQuaternionException();
    }

    public static AngularVelocity getRawAngularVelocity(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.AngleUnit angleUnit, AngleUnit angleUnit2) {
        BNO055IMUImpl.VectorData vectorData = new BNO055IMUImpl.VectorData(i2cDeviceSynchSimple.readTimeStamped(BNO055IMUImpl.VECTOR.GYROSCOPE.getValue(), 6), getAngularScale(angleUnit));
        return new AngularVelocity(angleUnit.toAngleUnit(), vectorData.next(), vectorData.next(), vectorData.next(), vectorData.data.nanoTime).toAngleUnit(angleUnit2);
    }

    public static float getAngularScale(BNO055IMU.AngleUnit angleUnit) {
        return angleUnit == BNO055IMU.AngleUnit.DEGREES ? 16.0f : 900.0f;
    }

    public static byte read8(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Register register) {
        return i2cDeviceSynchSimple.read8(register.bVal);
    }

    public static byte[] read(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Register register, int i) {
        return i2cDeviceSynchSimple.read(register.bVal, i);
    }

    public static void write8(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Register register, int i) {
        write8(i2cDeviceSynchSimple, register, i, I2cWaitControl.ATOMIC);
    }

    public static void write8(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Register register, int i, I2cWaitControl i2cWaitControl) {
        i2cDeviceSynchSimple.write8(register.bVal, i, i2cWaitControl);
    }

    public static void write(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Register register, byte[] bArr) {
        i2cDeviceSynchSimple.write((int) register.bVal, bArr);
    }

    public static void writeShort(I2cDeviceSynchSimple i2cDeviceSynchSimple, BNO055IMU.Register register, short s) {
        write(i2cDeviceSynchSimple, register, TypeConversion.shortToByteArray(s, ByteOrder.LITTLE_ENDIAN));
    }
}

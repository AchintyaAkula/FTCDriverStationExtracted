package com.qualcomm.hardware.bosch;

import org.firstinspires.ftc.robotcore.external.function.ThrowingSupplier;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class BNO055IMUNew$$ExternalSyntheticLambda4 implements ThrowingSupplier {
    public final /* synthetic */ BNO055IMUNew f$0;

    public /* synthetic */ BNO055IMUNew$$ExternalSyntheticLambda4(BNO055IMUNew bNO055IMUNew) {
        this.f$0 = bNO055IMUNew;
    }

    public final Object get() {
        return this.f$0.m21lambda$getRobotOrientationAsQuaternion$4$comqualcommhardwareboschBNO055IMUNew();
    }
}

package com.qualcomm.hardware.bosch;

import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import org.firstinspires.ftc.robotcore.external.function.ThrowingSupplier;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class BNO055IMUNew$$ExternalSyntheticLambda0 implements ThrowingSupplier {
    public final /* synthetic */ I2cDeviceSynchSimple f$0;

    public /* synthetic */ BNO055IMUNew$$ExternalSyntheticLambda0(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        this.f$0 = i2cDeviceSynchSimple;
    }

    public final Object get() {
        return BNO055Util.getRawQuaternion(this.f$0);
    }
}

package com.qualcomm.hardware.bosch;

import com.qualcomm.hardware.R;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055Util;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDeviceWithParameters;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.ImuOrientationOnRobot;
import com.qualcomm.robotcore.hardware.QuaternionBasedImuHelper;
import com.qualcomm.robotcore.util.RobotLog;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.opencv.videoio.Videoio;

public abstract class BNO055IMUNew extends I2cDeviceSynchDeviceWithParameters<I2cDeviceSynchSimple, IMU.Parameters> implements IMU {
    /* access modifiers changed from: private */
    public static final BNO055IMU.AngleUnit INTERNAL_ANGLE_UNIT = BNO055IMU.AngleUnit.DEGREES;
    private static final String TAG = "BNO055IMU (new)";
    private final I2cAddr guaranteedAddress;
    private final QuaternionBasedImuHelper helper;

    public abstract String getDeviceName();

    public abstract HardwareDevice.Manufacturer getManufacturer();

    public /* bridge */ /* synthetic */ boolean initialize(IMU.Parameters parameters) {
        return super.initialize(parameters);
    }

    public BNO055IMUNew(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        this(i2cDeviceSynchSimple, z, (I2cAddr) null);
    }

    public BNO055IMUNew(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z, I2cAddr i2cAddr) {
        super(i2cDeviceSynchSimple, z, new Parameters((ImuOrientationOnRobot) new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.UP, RevHubOrientationOnRobot.UsbFacingDirection.FORWARD)));
        QuaternionBasedImuHelper quaternionBasedImuHelper = new QuaternionBasedImuHelper(((IMU.Parameters) this.parameters).imuOrientationOnRobot);
        this.helper = quaternionBasedImuHelper;
        this.guaranteedAddress = i2cAddr;
        i2cDeviceSynchSimple.setI2cAddress(i2cAddr == null ? BNO055IMU.I2CADDR_DEFAULT : i2cAddr);
        if (BNO055Util.imuIsPresent(i2cDeviceSynchSimple, false) && initialize((IMU.Parameters) this.parameters)) {
            quaternionBasedImuHelper.resetYaw(TAG, new BNO055IMUNew$$ExternalSyntheticLambda0(i2cDeviceSynchSimple), Videoio.CAP_QT);
        }
    }

    /* access modifiers changed from: protected */
    public boolean internalInitialize(IMU.Parameters parameters) {
        Parameters parameters2;
        IMU.Parameters copy = parameters.copy();
        if (copy instanceof Parameters) {
            parameters2 = (Parameters) copy;
        } else {
            if (!copy.getClass().equals(IMU.Parameters.class)) {
                RobotLog.addGlobalWarningMessage(AppUtil.getDefContext().getString(R.string.parametersForOtherDeviceUsed));
            }
            parameters2 = new Parameters(copy);
        }
        this.parameters = parameters2;
        this.helper.setImuOrientationOnRobot(parameters2.imuOrientationOnRobot);
        if (this.guaranteedAddress == null) {
            this.deviceClient.setI2cAddress(parameters2.i2cAddr);
        } else {
            this.deviceClient.setI2cAddress(this.guaranteedAddress);
        }
        try {
            if (BNO055Util.imuIsPresent(this.deviceClient, true)) {
                BNO055Util.setSensorMode(this.deviceClient, BNO055IMU.SensorMode.CONFIG);
                BNO055Util.sharedInit(this.deviceClient, parameters2.toOldParameters());
                if (BNO055Util.getSystemStatus(this.deviceClient, TAG) == BNO055IMU.SystemStatus.RUNNING_FUSION) {
                    return true;
                }
                return false;
            }
            throw new BNO055Util.InitException("IMU appears to not be present");
        } catch (BNO055Util.InitException e) {
            RobotLog.ee(TAG, (Throwable) e, "Failed to initialize BNO055 IMU");
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$resetYaw$1$com-qualcomm-hardware-bosch-BNO055IMUNew  reason: not valid java name */
    public /* synthetic */ Quaternion m23lambda$resetYaw$1$comqualcommhardwareboschBNO055IMUNew() throws QuaternionBasedImuHelper.FailedToRetrieveQuaternionException {
        return BNO055Util.getRawQuaternion(this.deviceClient);
    }

    public void resetYaw() {
        this.helper.resetYaw(TAG, new BNO055IMUNew$$ExternalSyntheticLambda3(this), 100);
    }

    public YawPitchRollAngles getRobotYawPitchRollAngles() {
        return this.helper.getRobotYawPitchRollAngles(TAG, new BNO055IMUNew$$ExternalSyntheticLambda1(this));
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$getRobotYawPitchRollAngles$2$com-qualcomm-hardware-bosch-BNO055IMUNew  reason: not valid java name */
    public /* synthetic */ Quaternion m22lambda$getRobotYawPitchRollAngles$2$comqualcommhardwareboschBNO055IMUNew() throws QuaternionBasedImuHelper.FailedToRetrieveQuaternionException {
        return BNO055Util.getRawQuaternion(this.deviceClient);
    }

    public Orientation getRobotOrientation(AxesReference axesReference, AxesOrder axesOrder, AngleUnit angleUnit) {
        return this.helper.getRobotOrientation(TAG, new BNO055IMUNew$$ExternalSyntheticLambda2(this), axesReference, axesOrder, angleUnit);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$getRobotOrientation$3$com-qualcomm-hardware-bosch-BNO055IMUNew  reason: not valid java name */
    public /* synthetic */ Quaternion m20lambda$getRobotOrientation$3$comqualcommhardwareboschBNO055IMUNew() throws QuaternionBasedImuHelper.FailedToRetrieveQuaternionException {
        return BNO055Util.getRawQuaternion(this.deviceClient);
    }

    public Quaternion getRobotOrientationAsQuaternion() {
        return this.helper.getRobotOrientationAsQuaternion(TAG, new BNO055IMUNew$$ExternalSyntheticLambda4(this), true);
    }

    /* access modifiers changed from: package-private */
    /* renamed from: lambda$getRobotOrientationAsQuaternion$4$com-qualcomm-hardware-bosch-BNO055IMUNew  reason: not valid java name */
    public /* synthetic */ Quaternion m21lambda$getRobotOrientationAsQuaternion$4$comqualcommhardwareboschBNO055IMUNew() throws QuaternionBasedImuHelper.FailedToRetrieveQuaternionException {
        return BNO055Util.getRawQuaternion(this.deviceClient);
    }

    public AngularVelocity getRobotAngularVelocity(AngleUnit angleUnit) {
        QuaternionBasedImuHelper quaternionBasedImuHelper = this.helper;
        I2cDeviceSynchSimple i2cDeviceSynchSimple = this.deviceClient;
        BNO055IMU.AngleUnit angleUnit2 = INTERNAL_ANGLE_UNIT;
        return quaternionBasedImuHelper.getRobotAngularVelocity(BNO055Util.getRawAngularVelocity(i2cDeviceSynchSimple, angleUnit2, angleUnit2.toAngleUnit()), angleUnit);
    }

    public static class Parameters extends IMU.Parameters {
        public BNO055IMU.CalibrationData calibrationData;
        public String calibrationDataFile;
        public I2cAddr i2cAddr;

        public Parameters(ImuOrientationOnRobot imuOrientationOnRobot) {
            super(imuOrientationOnRobot);
            this.i2cAddr = BNO055IMU.I2CADDR_DEFAULT;
            this.calibrationData = null;
            this.calibrationDataFile = null;
        }

        private Parameters(IMU.Parameters parameters) {
            super(parameters.imuOrientationOnRobot);
            this.i2cAddr = BNO055IMU.I2CADDR_DEFAULT;
            this.calibrationData = null;
            this.calibrationDataFile = null;
        }

        public Parameters copy() {
            Parameters parameters = new Parameters(this.imuOrientationOnRobot);
            parameters.i2cAddr = this.i2cAddr;
            parameters.calibrationData = this.calibrationData;
            parameters.calibrationDataFile = this.calibrationDataFile;
            return parameters;
        }

        /* access modifiers changed from: private */
        public BNO055IMU.Parameters toOldParameters() {
            BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
            parameters.angleUnit = BNO055IMUNew.INTERNAL_ANGLE_UNIT;
            parameters.calibrationData = this.calibrationData;
            parameters.calibrationDataFile = this.calibrationDataFile;
            return parameters;
        }
    }
}

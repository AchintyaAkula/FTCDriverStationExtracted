package com.qualcomm.hardware.bosch;

import androidx.core.os.EnvironmentCompat;
import com.qualcomm.hardware.R;
import com.qualcomm.hardware.lynx.LynxI2cDeviceSynch;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.lynx.commands.core.LynxFirmwareVersionManager;
import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.eventloop.SyncdDevice;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.EmbeddedControlHubModule;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.HardwareDeviceHealth;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDeviceWithParameters;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.I2cWaitControl;
import com.qualcomm.robotcore.hardware.I2cWarningManager;
import com.qualcomm.robotcore.hardware.IMU;
import com.qualcomm.robotcore.hardware.QuaternionBasedImuHelper;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.ReadWriteFile;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.TypeConversion;
import java.io.IOException;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantLock;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Quaternion;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;
import org.firstinspires.ftc.robotcore.internal.hardware.android.AndroidBoard;
import org.firstinspires.ftc.robotcore.internal.hardware.android.GpioPin;
import org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier;
import org.firstinspires.ftc.robotcore.internal.system.AppUtil;
import org.firstinspires.ftc.robotcore.internal.system.SystemProperties;
import org.firstinspires.ftc.robotcore.internal.ui.ProgressParameters;
import org.firstinspires.ftc.robotcore.internal.ui.UILocation;
import org.opencv.videoio.Videoio;

@I2cDeviceType
@DeviceProperties(builtIn = true, description = "@string/lynx_embedded_imu_description", name = "@string/lynx_embedded_bhi260ap_imu_name", xmlTag = "ControlHubImuBHI260AP")
public class BHI260IMU extends I2cDeviceSynchDeviceWithParameters<I2cDeviceSynchSimple, IMU.Parameters> implements IMU {
    private static final int BOOT_FROM_FLASH_TIMEOUT_MS = 2000;
    private static final int BUNDLED_FW_VERSION = 20;
    private static final int COMMAND_ERROR_RESPONSE = 15;
    private static final int COMMAND_HEADER_LENGTH = 4;
    private static final boolean DEBUG_FW_FLASHING = false;
    public static final boolean DIAGNOSTIC_MODE = false;
    public static final boolean DIAGNOSTIC_MODE_FIFO_PARSING = false;
    private static final int ERASE_FLASH_TIMEOUT_MS = 14000;
    private static final int FW_RESOURCE = R.raw.rev_bhi260_ap_fw_20;
    private static final int FW_START_ADDRESS = 8068;
    /* access modifiers changed from: private */
    public static final I2cAddr I2C_ADDR = I2cAddr.create7bit(40);
    private static final int MAX_ANGULAR_VELOCITY_DEG_PER_S = 2000;
    private static final int MAX_READ_I2C_BYTES = 100;
    private static final int MAX_SEND_I2C_BYTES_NO_REGISTER = 100;
    private static final int MAX_SEND_I2C_BYTES_WITH_REGISTER = 99;
    private static final int MAX_WRITE_FLASH_FIRMWARE_AND_PADDING_BYTES = 91;
    private static final int MAX_WRITE_FLASH_FIRMWARE_BYTES = 88;
    private static final int PRODUCT_ID = 137;
    private static final double QUATERNION_SCALE_FACTOR = Math.pow(2.0d, -14.0d);
    private static final String TAG = "BHI260IMU";
    private static final int WRITE_FLASH_COMMAND_HEADER_LENGTH = 8;
    private static final int WRITE_FLASH_RESPONSE_TIMEOUT_MS = 1000;
    private static volatile Thread diagnosticModeThread;
    private static final Object genPurposeRegisterDataRetrievalLock = new Object();
    private static final Object i2cLock = new Object();
    private static final StatusAndDebugFifoModeManager statusAndDebugFifoModeManager = new StatusAndDebugFifoModeManager();
    private DigitalChannel correctedGyroRequestGpio;
    private int fwVersion = 0;
    private DigitalChannel gameRVRequestGpio;
    private final QuaternionBasedImuHelper helper;

    private enum BootStatusFlag {
        FLASH_DETECTED,
        FLASH_VERIFY_DONE,
        FLASH_VERIFY_ERROR,
        NO_FLASH,
        HOST_INTERFACE_READY,
        FIRMWARE_VERIFY_DONE,
        FIRMWARE_VERIFY_ERROR,
        FIRMWARE_HALTED
    }

    private enum HostInterfaceControlFlag {
        ABORT_TRANSFER_CHANNEL_0,
        ABORT_TRANSFER_CHANNEL_1,
        ABORT_TRANSFER_CHANNEL_2,
        ABORT_TRANSFER_CHANNEL_3,
        APPLICATION_PROCESSOR_SUSPENDED,
        RESERVED,
        TIMESTAMP_EVENT_REQUEST,
        ASYNC_STATUS_CHANNEL
    }

    private enum InterruptStatusFlag {
        HOST_INTERRUPT_ASSERTED,
        WAKE_UP_FIFO_STATUS_1,
        WAKE_UP_FIFO_STATUS_2,
        NON_WAKE_UP_FIFO_STATUS_1,
        NON_WAKE_UP_FIFO_STATUS_2,
        STATUS_STATUS,
        DEBUG_STATUS,
        RESET_OR_FAULT
    }

    private enum StatusAndDebugFifoMode {
        SYNCHRONOUS,
        ASYNCHRONOUS
    }

    public /* bridge */ /* synthetic */ boolean initialize(IMU.Parameters parameters) {
        return super.initialize(parameters);
    }

    public static boolean imuIsPresent(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        i2cDeviceSynchSimple.setI2cAddress(I2C_ADDR);
        RobotLog.vv(TAG, "Suppressing I2C warnings while we check for a BHI260AP IMU");
        I2cWarningManager.suppressNewProblemDeviceWarnings(true);
        try {
            if (read8(i2cDeviceSynchSimple, Register.PRODUCT_IDENTIFIER) == 137) {
                RobotLog.vv(TAG, "Found BHI260AP IMU");
                return true;
            }
            RobotLog.vv(TAG, "No BHI260AP IMU found");
            I2cWarningManager.suppressNewProblemDeviceWarnings(false);
            return false;
        } finally {
            I2cWarningManager.suppressNewProblemDeviceWarnings(false);
        }
    }

    public static void flashFirmwareIfNecessary(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        i2cDeviceSynchSimple.setI2cAddress(I2C_ADDR);
        try {
            waitForHostInterface(i2cDeviceSynchSimple);
            checkForFlashPresence(i2cDeviceSynchSimple);
            boolean waitForFlashVerification = waitForFlashVerification(i2cDeviceSynchSimple);
            int i = 0;
            int read16 = waitForFlashVerification ? read16(i2cDeviceSynchSimple, Register.USER_VERSION) : 0;
            RobotLog.vv(TAG, "flashFirmwareIfNecessary() alreadyFlashed=%b firmwareVersion=%d", Boolean.valueOf(waitForFlashVerification), Integer.valueOf(read16));
            if (read16 != 20) {
                try {
                    if (SystemProperties.getBoolean("persist.bhi260.flash400khz", false)) {
                        RobotLog.vv(TAG, "Setting I2C bus speed to 400KHz for firmware flashing");
                        ((LynxI2cDeviceSynch) i2cDeviceSynchSimple).setBusSpeed(LynxI2cDeviceSynch.BusSpeed.FAST_400K);
                    } else {
                        RobotLog.vv(TAG, "Setting I2C bus speed to 100KHz for firmware flashing");
                        ((LynxI2cDeviceSynch) i2cDeviceSynchSimple).setBusSpeed(LynxI2cDeviceSynch.BusSpeed.STANDARD_100K);
                    }
                    RobotLog.ii(TAG, "Flashing IMU firmware version %d", 20);
                    ElapsedTime elapsedTime = new ElapsedTime();
                    ByteBuffer wrap = ByteBuffer.wrap(ReadWriteFile.readRawResourceBytesOrThrow(FW_RESOURCE));
                    int remaining = wrap.remaining();
                    RobotLog.vv(TAG, "Resetting IMU");
                    write8(i2cDeviceSynchSimple, Register.RESET_REQUEST, 1, I2cWaitControl.WRITTEN);
                    waitForHostInterface(i2cDeviceSynchSimple);
                    RobotLog.dd(TAG, "Flash device's JDEC manufacturer ID: 0x%X", Integer.valueOf(read8(i2cDeviceSynchSimple, Register.GEN_PURPOSE_READ)));
                    RobotLog.vv(TAG, "Wiping IMU flash memory");
                    AppUtil.getInstance().showProgress(UILocation.BOTH, AppUtil.getDefContext().getString(R.string.flashingControlHubImu), new ProgressParameters(0, remaining));
                    ByteBuffer order = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
                    int i2 = FW_START_ADDRESS;
                    sendCommandAndWaitForResponse(i2cDeviceSynchSimple, CommandType.ERASE_FLASH, order.putInt(FW_START_ADDRESS).putInt(remaining + FW_START_ADDRESS).array(), ERASE_FLASH_TIMEOUT_MS);
                    AppAliveNotifier.getInstance().notifyAppAlive();
                    RobotLog.ii(TAG, "Sending firmware data");
                    while (wrap.hasRemaining()) {
                        int min = Math.min(wrap.remaining(), 88);
                        sendWriteFlashCommandAndWaitForResponse(i2cDeviceSynchSimple, i2, min, wrap);
                        i2 += min;
                        i += min;
                        AppUtil.getInstance().showProgress(UILocation.BOTH, AppUtil.getDefContext().getString(R.string.flashingControlHubImu), new ProgressParameters(i, remaining));
                    }
                    RobotLog.vv(TAG, "Booting into newly-flashed firmware");
                    sendCommand(i2cDeviceSynchSimple, CommandType.BOOT_FLASH, (byte[]) null);
                    waitForHostInterface(i2cDeviceSynchSimple);
                    checkForFlashPresence(i2cDeviceSynchSimple);
                    if (waitForFlashVerification(i2cDeviceSynchSimple)) {
                        RobotLog.vv(TAG, "Successfully flashed Control Hub IMU firmware in %.2f seconds", Double.valueOf(elapsedTime.seconds()));
                        AppUtil.getInstance().dismissProgress(UILocation.BOTH);
                        return;
                    }
                    RobotLog.ee(TAG, "IMU flash verification failed after flashing firmware");
                    throw new InitException();
                } catch (IOException e) {
                    RobotLog.ee(TAG, (Throwable) e, "Failed to read IMU firmware file");
                    throw new InitException();
                } catch (CommandFailureException e2) {
                    RobotLog.ee(TAG, (Throwable) e2, "IMU flash erase failed");
                    throw new InitException();
                } catch (CommandFailureException e3) {
                    RobotLog.ee(TAG, (Throwable) e3, "Write Flash command failed");
                    throw new InitException();
                } catch (Throwable th) {
                    AppUtil.getInstance().dismissProgress(UILocation.BOTH);
                    throw th;
                }
            }
        } catch (InitException unused) {
            RobotLog.addGlobalWarningMessage(AppUtil.getDefContext().getString(R.string.controlHubImuFwFlashFailed));
        }
    }

    public BHI260IMU(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z, new IMU.Parameters(new RevHubOrientationOnRobot(RevHubOrientationOnRobot.LogoFacingDirection.UP, RevHubOrientationOnRobot.UsbFacingDirection.FORWARD)));
        QuaternionBasedImuHelper quaternionBasedImuHelper = new QuaternionBasedImuHelper(((IMU.Parameters) this.parameters).imuOrientationOnRobot);
        this.helper = quaternionBasedImuHelper;
        if (imuIsPresent(this.deviceClient) && internalInitialize((IMU.Parameters) this.parameters)) {
            quaternionBasedImuHelper.resetYaw(TAG, new BHI260IMU$$ExternalSyntheticLambda0(this), Videoio.CAP_QT);
        }
    }

    /* access modifiers changed from: protected */
    public boolean internalInitialize(IMU.Parameters parameters) {
        if (!parameters.getClass().equals(IMU.Parameters.class)) {
            RobotLog.addGlobalWarningMessage(AppUtil.getDefContext().getString(R.string.parametersForOtherDeviceUsed));
        }
        IMU.Parameters copy = parameters.copy();
        this.parameters = copy;
        this.gameRVRequestGpio = AndroidBoard.getInstance().getBhi260Gpio5();
        this.correctedGyroRequestGpio = AndroidBoard.getInstance().getBhi260Gpio6();
        this.gameRVRequestGpio.setMode(DigitalChannel.Mode.OUTPUT);
        this.correctedGyroRequestGpio.setMode(DigitalChannel.Mode.OUTPUT);
        this.helper.setImuOrientationOnRobot(copy.imuOrientationOnRobot);
        this.deviceClient.setI2cAddress(I2C_ADDR);
        if (!imuIsPresent(this.deviceClient)) {
            RobotLog.ee(TAG, "Could not find Control Hub IMU (BHI260AP)");
            return false;
        }
        try {
            waitForHostInterface(this.deviceClient);
            checkForFlashPresence(this.deviceClient);
            if (!waitForFlashVerification(this.deviceClient)) {
                RobotLog.ee(TAG, "IMU flash contents were not verified");
                throw new InitException();
            } else if (readBootStatusFlags(this.deviceClient).contains(BootStatusFlag.FIRMWARE_HALTED)) {
                RobotLog.ee(TAG, "IMU reports that its firmware is not running");
                return false;
            } else {
                disableFifoTimestamps(this.deviceClient);
                int read16 = read16(this.deviceClient, Register.USER_VERSION);
                this.fwVersion = read16;
                if (read16 == 20) {
                    RobotLog.dd(TAG, "Firmware version: %d", Integer.valueOf(read16));
                    write8(this.deviceClient, Register.HOST_CONTROL, 0, I2cWaitControl.ATOMIC);
                    setSensorDynamicRange(Sensor.GYROSCOPE_CORRECTED_DATA_HOLDER, Videoio.CAP_IMAGES);
                    configureSensor(Sensor.GAME_ROTATION_VECTOR_DATA_HOLDER, 800.0f, 0);
                    configureSensor(Sensor.GAME_ROTATION_VECTOR_GPIO_HANDLER, 800.0f, 0);
                    configureSensor(Sensor.GYROSCOPE_CORRECTED_DATA_HOLDER, 800.0f, 0);
                    configureSensor(Sensor.GYROSCOPE_CORRECTED_GPIO_HANDLER, 800.0f, 0);
                    return true;
                }
                RobotLog.ee(TAG, "Firmware version is incorrect. expected=%d actual=%d", 20, Integer.valueOf(this.fwVersion));
                throw new InitException();
            }
        } catch (InitException unused) {
            return false;
        }
    }

    public void resetYaw() {
        this.helper.resetYaw(TAG, new BHI260IMU$$ExternalSyntheticLambda0(this), 50);
    }

    public YawPitchRollAngles getRobotYawPitchRollAngles() {
        return this.helper.getRobotYawPitchRollAngles(TAG, new BHI260IMU$$ExternalSyntheticLambda0(this));
    }

    public Orientation getRobotOrientation(AxesReference axesReference, AxesOrder axesOrder, AngleUnit angleUnit) {
        return this.helper.getRobotOrientation(TAG, new BHI260IMU$$ExternalSyntheticLambda0(this), axesReference, axesOrder, angleUnit);
    }

    public Quaternion getRobotOrientationAsQuaternion() {
        return this.helper.getRobotOrientationAsQuaternion(TAG, new BHI260IMU$$ExternalSyntheticLambda0(this), true);
    }

    public AngularVelocity getRobotAngularVelocity(AngleUnit angleUnit) {
        return this.helper.getRobotAngularVelocity(getRawAngularVelocity(), angleUnit);
    }

    /* access modifiers changed from: protected */
    public Quaternion getRawQuaternion() throws QuaternionBasedImuHelper.FailedToRetrieveQuaternionException {
        long nanoTime;
        ByteBuffer readMultiple;
        if (this.gameRVRequestGpio instanceof GpioPin) {
            synchronized (genPurposeRegisterDataRetrievalLock) {
                this.gameRVRequestGpio.setState(true);
                nanoTime = System.nanoTime();
                readMultiple = readMultiple(this.deviceClient, Register.GEN_PURPOSE_READ, 8);
                this.gameRVRequestGpio.setState(false);
            }
            short s = readMultiple.getShort();
            short s2 = readMultiple.getShort();
            short s3 = readMultiple.getShort();
            short s4 = readMultiple.getShort();
            if (s == 0 && s2 == 0 && s3 == 0 && s4 == 0) {
                throw new QuaternionBasedImuHelper.FailedToRetrieveQuaternionException();
            }
            double d = QUATERNION_SCALE_FACTOR;
            return new Quaternion((float) (((double) s4) * d), (float) (((double) s) * d), (float) (((double) s2) * d), (float) (((double) s3) * d), nanoTime);
        }
        throw new QuaternionBasedImuHelper.FailedToRetrieveQuaternionException();
    }

    /* access modifiers changed from: protected */
    public AngularVelocity getRawAngularVelocity() {
        long nanoTime;
        ByteBuffer readMultiple;
        if (!(this.correctedGyroRequestGpio instanceof GpioPin)) {
            return new AngularVelocity(AngleUnit.DEGREES, 0.0f, 0.0f, 0.0f, 0);
        }
        synchronized (genPurposeRegisterDataRetrievalLock) {
            this.correctedGyroRequestGpio.setState(true);
            nanoTime = System.nanoTime();
            readMultiple = readMultiple(this.deviceClient, Register.GEN_PURPOSE_READ, 6);
            this.correctedGyroRequestGpio.setState(false);
        }
        short s = readMultiple.getShort();
        short s2 = readMultiple.getShort();
        return new AngularVelocity(AngleUnit.DEGREES, (float) (((double) s) * 0.08415029242226617d), (float) (((double) s2) * 0.08415029242226617d), (float) (((double) readMultiple.getShort()) * 0.08415029242226617d), nanoTime);
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.Lynx;
    }

    public String getDeviceName() {
        return AppUtil.getDefContext().getString(R.string.lynx_embedded_bhi260ap_imu_name);
    }

    public String getConnectionInfo() {
        return String.format("BHI260 IMU on %s", new Object[]{this.deviceClient.getConnectionInfo()});
    }

    public int getFirmwareVersion() {
        return this.fwVersion;
    }

    /* access modifiers changed from: private */
    public static int read8(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register) {
        int unsignedByteToInt;
        synchronized (i2cLock) {
            unsignedByteToInt = TypeConversion.unsignedByteToInt(i2cDeviceSynchSimple.read8(register.address));
        }
        return unsignedByteToInt;
    }

    private static int read16(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register) {
        short byteArrayToShort;
        synchronized (i2cLock) {
            byteArrayToShort = TypeConversion.byteArrayToShort(i2cDeviceSynchSimple.read(register.address, 2), ByteOrder.LITTLE_ENDIAN);
        }
        return byteArrayToShort;
    }

    private static ByteBuffer readMultiple(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register, int i) {
        ByteBuffer order;
        synchronized (i2cLock) {
            order = ByteBuffer.wrap(i2cDeviceSynchSimple.read(register.address, i)).order(ByteOrder.LITTLE_ENDIAN);
        }
        return order;
    }

    private static ByteBuffer readMultiple(I2cDeviceSynchSimple i2cDeviceSynchSimple, int i) {
        ByteBuffer order;
        synchronized (i2cLock) {
            order = ByteBuffer.wrap(i2cDeviceSynchSimple.read(i)).order(ByteOrder.LITTLE_ENDIAN);
        }
        return order;
    }

    /* access modifiers changed from: private */
    public static <T extends Enum<T>> EnumSet<T> read8Flags(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register, Class<T> cls) {
        EnumSet<T> convertIntToEnumSet;
        synchronized (i2cLock) {
            convertIntToEnumSet = convertIntToEnumSet(read8(i2cDeviceSynchSimple, register), cls);
        }
        return convertIntToEnumSet;
    }

    private static EnumSet<BootStatusFlag> readBootStatusFlags(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        EnumSet<BootStatusFlag> read8Flags;
        synchronized (i2cLock) {
            read8Flags = read8Flags(i2cDeviceSynchSimple, Register.BOOT_STATUS, BootStatusFlag.class);
        }
        return read8Flags;
    }

    private static void write8(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register, int i, I2cWaitControl i2cWaitControl) {
        synchronized (i2cLock) {
            i2cDeviceSynchSimple.write8(register.address, i, i2cWaitControl);
        }
    }

    /* access modifiers changed from: private */
    public static <T extends Enum<T>> void write8Flags(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register, EnumSet<T> enumSet, I2cWaitControl i2cWaitControl) {
        synchronized (i2cLock) {
            write8(i2cDeviceSynchSimple, register, convertEnumSetToInt(enumSet), i2cWaitControl);
        }
    }

    private static void writeMultiple(I2cDeviceSynchSimple i2cDeviceSynchSimple, Register register, byte[] bArr) {
        synchronized (i2cLock) {
            i2cDeviceSynchSimple.write(register.address, bArr);
        }
    }

    private static void waitForHostInterface(I2cDeviceSynchSimple i2cDeviceSynchSimple) throws InitException {
        ElapsedTime elapsedTime = new ElapsedTime();
        EnumSet<BootStatusFlag> readBootStatusFlags = readBootStatusFlags(i2cDeviceSynchSimple);
        while (!readBootStatusFlags.contains(BootStatusFlag.HOST_INTERFACE_READY) && elapsedTime.milliseconds() < 2000.0d) {
            try {
                Thread.sleep(10);
                readBootStatusFlags = readBootStatusFlags(i2cDeviceSynchSimple);
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                throw new InitException();
            }
        }
        if (!readBootStatusFlags.contains(BootStatusFlag.HOST_INTERFACE_READY)) {
            RobotLog.ee(TAG, "Timeout expired while waiting for IMU host interface to become ready. bootStatusFlags=%s", readBootStatusFlags);
            throw new InitException();
        }
    }

    private static void checkForFlashPresence(I2cDeviceSynchSimple i2cDeviceSynchSimple) throws InitException {
        EnumSet<BootStatusFlag> readBootStatusFlags = readBootStatusFlags(i2cDeviceSynchSimple);
        if (!readBootStatusFlags.contains(BootStatusFlag.FLASH_DETECTED) || readBootStatusFlags.contains(BootStatusFlag.NO_FLASH)) {
            RobotLog.ee(TAG, "IMU did not detect flash chip");
            throw new InitException();
        }
    }

    private static boolean waitForFlashVerification(I2cDeviceSynchSimple i2cDeviceSynchSimple) throws InitException {
        ElapsedTime elapsedTime = new ElapsedTime();
        EnumSet<BootStatusFlag> readBootStatusFlags = readBootStatusFlags(i2cDeviceSynchSimple);
        AppAliveNotifier.getInstance().notifyAppAlive();
        while (!readBootStatusFlags.contains(BootStatusFlag.FLASH_VERIFY_DONE)) {
            try {
                if (elapsedTime.milliseconds() >= 1500.0d) {
                    break;
                } else if (readBootStatusFlags.contains(BootStatusFlag.FLASH_VERIFY_ERROR)) {
                    RobotLog.ee(TAG, "Error verifying IMU firmware");
                    return false;
                } else {
                    Thread.sleep(10);
                    readBootStatusFlags = readBootStatusFlags(i2cDeviceSynchSimple);
                }
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                throw new InitException();
            }
        }
        if (!readBootStatusFlags.contains(BootStatusFlag.FLASH_VERIFY_DONE)) {
            RobotLog.ww(TAG, "Timeout expired while waiting for IMU to load its firmware from flash");
            return false;
        } else if (!readBootStatusFlags.contains(BootStatusFlag.FLASH_VERIFY_ERROR)) {
            return true;
        } else {
            RobotLog.ee(TAG, "Error verifying IMU firmware");
            return false;
        }
    }

    /* access modifiers changed from: private */
    public static void disableFifoTimestamps(I2cDeviceSynchSimple i2cDeviceSynchSimple) {
        sendCommand(i2cDeviceSynchSimple, CommandType.CONTROL_FIFO_FORMAT, new byte[]{3});
    }

    private static void sendCommand(I2cDeviceSynchSimple i2cDeviceSynchSimple, CommandType commandType, byte[] bArr) {
        int i = 0;
        if (bArr == null) {
            bArr = new byte[0];
        }
        int length = bArr.length + 4;
        if (length % 4 != 0) {
            i = 4 - (bArr.length % 4);
            length += i;
        }
        if (length <= 99) {
            ByteBuffer put = ByteBuffer.allocate(length).order(ByteOrder.LITTLE_ENDIAN).putShort((short) commandType.id).putShort((short) (length - 4)).put(bArr);
            if (i > 0) {
                put.put(new byte[i]);
            }
            writeMultiple(i2cDeviceSynchSimple, Register.COMMAND_INPUT, put.array());
            return;
        }
        throw new IllegalArgumentException("sendCommand() called with too large of a payload. Update sendCommand() to break into multiple I2C writes");
    }

    private static StatusPacket sendCommandAndWaitForResponse(I2cDeviceSynchSimple i2cDeviceSynchSimple, CommandType commandType, byte[] bArr, int i) throws CommandFailureException {
        StatusAndDebugFifoModeManager statusAndDebugFifoModeManager2 = statusAndDebugFifoModeManager;
        statusAndDebugFifoModeManager2.lockStatusAndDebugFifoMode(i2cDeviceSynchSimple, StatusAndDebugFifoMode.SYNCHRONOUS);
        try {
            sendCommand(i2cDeviceSynchSimple, commandType, bArr);
            StatusPacket waitForCommandResponse = waitForCommandResponse(i2cDeviceSynchSimple, commandType, i);
            statusAndDebugFifoModeManager2.unlockStatusAndDebugFifoMode();
            return waitForCommandResponse;
        } catch (Throwable th) {
            statusAndDebugFifoModeManager.unlockStatusAndDebugFifoMode();
            throw th;
        }
    }

    private static void sendWriteFlashCommandAndWaitForResponse(I2cDeviceSynchSimple i2cDeviceSynchSimple, int i, int i2, ByteBuffer byteBuffer) throws CommandFailureException {
        int i3;
        int i4;
        if (i2 <= 88) {
            AppAliveNotifier.getInstance().notifyAppAlive();
            int i5 = i2 + 8;
            if (i5 % 4 != 0) {
                i4 = 4 - (i2 % 4);
                i3 = i5 + i4;
            } else {
                i4 = 0;
                i3 = i5;
            }
            ByteBuffer putShort = ByteBuffer.allocate(i3).order(ByteOrder.LITTLE_ENDIAN).putShort((short) CommandType.WRITE_FLASH.id);
            putShort.putShort((short) (i3 - 4));
            putShort.putInt(i);
            byteBuffer.get(putShort.array(), putShort.position(), i2);
            putShort.position(i5);
            if (i4 > 0) {
                putShort.put(new byte[i4]);
            }
            StatusAndDebugFifoModeManager statusAndDebugFifoModeManager2 = statusAndDebugFifoModeManager;
            statusAndDebugFifoModeManager2.lockStatusAndDebugFifoMode(i2cDeviceSynchSimple, StatusAndDebugFifoMode.SYNCHRONOUS);
            try {
                writeMultiple(i2cDeviceSynchSimple, Register.COMMAND_INPUT, putShort.array());
                waitForCommandResponse(i2cDeviceSynchSimple, CommandType.WRITE_FLASH, 1000);
                statusAndDebugFifoModeManager2.unlockStatusAndDebugFifoMode();
            } catch (Throwable th) {
                statusAndDebugFifoModeManager.unlockStatusAndDebugFifoMode();
                throw th;
            }
        } else {
            throw new IllegalArgumentException("Tried to write too many bytes in a single Write Flash command");
        }
    }

    /* JADX WARNING: type inference failed for: r10v8, types: [com.qualcomm.hardware.bosch.BHI260IMU$CommandError] */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static com.qualcomm.hardware.bosch.BHI260IMU.StatusPacket waitForCommandResponse(com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple r11, com.qualcomm.hardware.bosch.BHI260IMU.CommandType r12, int r13) throws com.qualcomm.hardware.bosch.BHI260IMU.CommandFailureException {
        /*
            com.qualcomm.robotcore.util.ElapsedTime r0 = new com.qualcomm.robotcore.util.ElapsedTime
            r0.<init>()
            com.qualcomm.robotcore.util.ElapsedTime r1 = new com.qualcomm.robotcore.util.ElapsedTime
            r1.<init>()
            org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier r2 = org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier.getInstance()
            r2.notifyAppAlive()
        L_0x0011:
            double r2 = r1.seconds()
            r4 = 4620693217682128896(0x4020000000000000, double:8.0)
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 <= 0) goto L_0x0025
            org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier r2 = org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier.getInstance()
            r2.notifyAppAlive()
            r1.reset()
        L_0x0025:
            double r2 = r0.milliseconds()
            double r6 = (double) r13
            int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x019e
            com.qualcomm.hardware.bosch.BHI260IMU$Register r2 = com.qualcomm.hardware.bosch.BHI260IMU.Register.INTERRUPT_STATUS
            java.lang.Class<com.qualcomm.hardware.bosch.BHI260IMU$InterruptStatusFlag> r3 = com.qualcomm.hardware.bosch.BHI260IMU.InterruptStatusFlag.class
            java.util.EnumSet r2 = read8Flags(r11, r2, r3)
            com.qualcomm.hardware.bosch.BHI260IMU$InterruptStatusFlag r3 = com.qualcomm.hardware.bosch.BHI260IMU.InterruptStatusFlag.RESET_OR_FAULT
            boolean r3 = r2.contains(r3)
            if (r3 == 0) goto L_0x006d
            com.qualcomm.hardware.bosch.BHI260IMU$CommandType r3 = com.qualcomm.hardware.bosch.BHI260IMU.CommandType.ERASE_FLASH
            if (r12 == r3) goto L_0x006d
            java.lang.String r3 = "BHI260IMU"
            java.lang.String r8 = "Reset or Fault interrupt status was set while waiting for %s response"
            java.lang.Object[] r9 = new java.lang.Object[]{r12}
            com.qualcomm.robotcore.util.RobotLog.ww((java.lang.String) r3, (java.lang.String) r8, (java.lang.Object[]) r9)
            java.lang.String r3 = "BHI260IMU"
            java.lang.String r8 = "Interrupt status: %s"
            java.lang.Object[] r9 = new java.lang.Object[]{r2}
            com.qualcomm.robotcore.util.RobotLog.ww((java.lang.String) r3, (java.lang.String) r8, (java.lang.Object[]) r9)
            java.lang.String r3 = "BHI260IMU"
            java.lang.String r8 = "Error value: 0x%X"
            com.qualcomm.hardware.bosch.BHI260IMU$Register r9 = com.qualcomm.hardware.bosch.BHI260IMU.Register.ERROR_VALUE
            int r9 = read8(r11, r9)
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)
            java.lang.Object[] r9 = new java.lang.Object[]{r9}
            com.qualcomm.robotcore.util.RobotLog.ww((java.lang.String) r3, (java.lang.String) r8, (java.lang.Object[]) r9)
        L_0x006d:
            com.qualcomm.hardware.bosch.BHI260IMU$InterruptStatusFlag r3 = com.qualcomm.hardware.bosch.BHI260IMU.InterruptStatusFlag.STATUS_STATUS
            boolean r2 = r2.contains(r3)
            if (r2 == 0) goto L_0x0011
        L_0x0075:
            double r2 = r1.seconds()
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 <= 0) goto L_0x0087
            org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier r2 = org.firstinspires.ftc.robotcore.internal.system.AppAliveNotifier.getInstance()
            r2.notifyAppAlive()
            r1.reset()
        L_0x0087:
            double r2 = r0.milliseconds()
            int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r2 >= 0) goto L_0x0188
            java.lang.Object r2 = i2cLock
            monitor-enter(r2)
            com.qualcomm.hardware.bosch.BHI260IMU$Register r3 = com.qualcomm.hardware.bosch.BHI260IMU.Register.STATUS_AND_DEBUG_FIFO_OUTPUT     // Catch:{ all -> 0x0185 }
            r8 = 3
            java.nio.ByteBuffer r3 = readMultiple(r11, r3, r8)     // Catch:{ all -> 0x0185 }
            short r9 = r3.getShort()     // Catch:{ all -> 0x0185 }
            int r9 = com.qualcomm.robotcore.util.TypeConversion.unsignedShortToInt(r9)     // Catch:{ all -> 0x0185 }
            byte r3 = r3.get()     // Catch:{ all -> 0x0185 }
            int r3 = com.qualcomm.robotcore.util.TypeConversion.unsignedByteToInt(r3)     // Catch:{ all -> 0x0185 }
            r10 = 100
            if (r3 > r10) goto L_0x016f
            if (r3 != 0) goto L_0x00b3
            r3 = 0
            byte[] r3 = new byte[r3]     // Catch:{ all -> 0x0185 }
            goto L_0x00bb
        L_0x00b3:
            java.nio.ByteBuffer r3 = readMultiple(r11, r3)     // Catch:{ all -> 0x0185 }
            byte[] r3 = r3.array()     // Catch:{ all -> 0x0185 }
        L_0x00bb:
            monitor-exit(r2)     // Catch:{ all -> 0x0185 }
            int r2 = r12.successStatusCode
            r10 = 0
            if (r9 == r2) goto L_0x0169
            if (r9 != 0) goto L_0x00cd
            java.lang.String r2 = "BHI260IMU"
            java.lang.String r3 = "Received status code 0, trying again"
            com.qualcomm.robotcore.util.RobotLog.ww(r2, r3)
            goto L_0x0075
        L_0x00cd:
            r11 = 15
            if (r9 != r11) goto L_0x0151
            int r11 = r3.length
            if (r11 < r8) goto L_0x00f3
            java.nio.ByteBuffer r11 = java.nio.ByteBuffer.wrap(r3)
            java.nio.ByteOrder r13 = java.nio.ByteOrder.LITTLE_ENDIAN
            java.nio.ByteBuffer r11 = r11.order(r13)
            short r13 = r11.getShort()
            int r13 = com.qualcomm.robotcore.util.TypeConversion.unsignedShortToInt(r13)
            byte r11 = r11.get()
            int r11 = com.qualcomm.robotcore.util.TypeConversion.unsignedByteToInt(r11)
            com.qualcomm.hardware.bosch.BHI260IMU$CommandError r10 = com.qualcomm.hardware.bosch.BHI260IMU.CommandError.fromInt(r11)
            goto L_0x00f5
        L_0x00f3:
            r13 = -1
            r11 = r13
        L_0x00f5:
            int r0 = r12.id
            if (r13 != r0) goto L_0x010f
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            java.lang.StringBuilder r13 = r13.append(r12)
            java.lang.String r0 = " command"
            java.lang.StringBuilder r13 = r13.append(r0)
            java.lang.String r13 = r13.toString()
            goto L_0x0132
        L_0x010f:
            com.qualcomm.hardware.bosch.BHI260IMU$CommandType r0 = com.qualcomm.hardware.bosch.BHI260IMU.CommandType.findById(r13)
            if (r0 != 0) goto L_0x0126
            java.util.Locale r0 = java.util.Locale.US
            java.lang.String r1 = "unknown command 0x%4X (just sent %s command)"
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            java.lang.Object[] r13 = new java.lang.Object[]{r13, r12}
            java.lang.String r13 = java.lang.String.format(r0, r1, r13)
            goto L_0x0132
        L_0x0126:
            java.util.Locale r13 = java.util.Locale.US
            java.lang.String r1 = "%s command (just sent %s command)"
            java.lang.Object[] r0 = new java.lang.Object[]{r0, r12}
            java.lang.String r13 = java.lang.String.format(r13, r1, r0)
        L_0x0132:
            if (r10 != 0) goto L_0x0145
            java.util.Locale r0 = java.util.Locale.US
            java.lang.String r1 = "Received unknown Command Error code 0x%2X in response to %s"
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
            java.lang.Object[] r11 = new java.lang.Object[]{r11, r13}
            java.lang.String r10 = java.lang.String.format(r0, r1, r11)
            goto L_0x0151
        L_0x0145:
            java.util.Locale r11 = java.util.Locale.US
            java.lang.String r0 = "Received Command Error %s in response to %s"
            java.lang.Object[] r13 = new java.lang.Object[]{r10, r13}
            java.lang.String r10 = java.lang.String.format(r11, r0, r13)
        L_0x0151:
            if (r10 != 0) goto L_0x0163
            java.util.Locale r11 = java.util.Locale.US
            java.lang.String r13 = "Received unexpected response status 0x%X for %s command"
            java.lang.Integer r0 = java.lang.Integer.valueOf(r9)
            java.lang.Object[] r12 = new java.lang.Object[]{r0, r12}
            java.lang.String r10 = java.lang.String.format(r11, r13, r12)
        L_0x0163:
            com.qualcomm.hardware.bosch.BHI260IMU$CommandFailureException r11 = new com.qualcomm.hardware.bosch.BHI260IMU$CommandFailureException
            r11.<init>(r10)
            throw r11
        L_0x0169:
            com.qualcomm.hardware.bosch.BHI260IMU$StatusPacket r11 = new com.qualcomm.hardware.bosch.BHI260IMU$StatusPacket
            r11.<init>(r9, r3)
            return r11
        L_0x016f:
            java.lang.RuntimeException r11 = new java.lang.RuntimeException     // Catch:{ all -> 0x0185 }
            java.util.Locale r12 = java.util.Locale.ENGLISH     // Catch:{ all -> 0x0185 }
            java.lang.String r13 = "IMU sent payload that was too long (%d bytes)"
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)     // Catch:{ all -> 0x0185 }
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch:{ all -> 0x0185 }
            java.lang.String r12 = java.lang.String.format(r12, r13, r0)     // Catch:{ all -> 0x0185 }
            r11.<init>(r12)     // Catch:{ all -> 0x0185 }
            throw r11     // Catch:{ all -> 0x0185 }
        L_0x0185:
            r11 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x0185 }
            throw r11
        L_0x0188:
            com.qualcomm.hardware.bosch.BHI260IMU$CommandFailureException r11 = new com.qualcomm.hardware.bosch.BHI260IMU$CommandFailureException
            java.util.Locale r12 = java.util.Locale.ENGLISH
            java.lang.String r0 = "%dms timeout expired while waiting for response"
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            java.lang.Object[] r13 = new java.lang.Object[]{r13}
            java.lang.String r12 = java.lang.String.format(r12, r0, r13)
            r11.<init>(r12)
            throw r11
        L_0x019e:
            com.qualcomm.hardware.bosch.BHI260IMU$CommandFailureException r11 = new com.qualcomm.hardware.bosch.BHI260IMU$CommandFailureException
            java.util.Locale r12 = java.util.Locale.ENGLISH
            java.lang.String r0 = "%dms timeout expired while waiting for response"
            java.lang.Integer r13 = java.lang.Integer.valueOf(r13)
            java.lang.Object[] r13 = new java.lang.Object[]{r13}
            java.lang.String r12 = java.lang.String.format(r12, r0, r13)
            r11.<init>(r12)
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.bosch.BHI260IMU.waitForCommandResponse(com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple, com.qualcomm.hardware.bosch.BHI260IMU$CommandType, int):com.qualcomm.hardware.bosch.BHI260IMU$StatusPacket");
    }

    private void configureSensor(Sensor sensor, float f, int i) {
        if (i <= 16777215) {
            ByteBuffer putFloat = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).put((byte) sensor.id).putFloat(f);
            putFloat.put(TypeConversion.intToByteArray(i, ByteOrder.LITTLE_ENDIAN), 0, 3);
            sendCommand(this.deviceClient, CommandType.CONFIGURE_SENSOR, putFloat.array());
            return;
        }
        throw new IllegalArgumentException("Sensor latency must be less than 1,6777,215 milliseconds");
    }

    private void setSensorDynamicRange(Sensor sensor, int i) {
        if (i <= 65535) {
            sendCommand(this.deviceClient, CommandType.CHANGE_SENSOR_DYNAMIC_RANGE, ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).put((byte) sensor.id).putShort((short) i).put((byte) 0).array());
            return;
        }
        throw new IllegalArgumentException("Sensor dynamic range must be less than 65,535");
    }

    private static <T extends Enum<T>> EnumSet<T> convertIntToEnumSet(int i, Class<T> cls) {
        EnumSet<T> noneOf = EnumSet.noneOf(cls);
        for (Enum enumR : (Enum[]) cls.getEnumConstants()) {
            if (((1 << enumR.ordinal()) & i) == (1 << enumR.ordinal())) {
                noneOf.add(enumR);
            }
        }
        return noneOf;
    }

    private static <T extends Enum<T>> int convertEnumSetToInt(EnumSet<T> enumSet) {
        Iterator it = enumSet.iterator();
        int i = 0;
        while (it.hasNext()) {
            i |= 1 << ((Enum) it.next()).ordinal();
        }
        return i;
    }

    private static void printByteBuffer(String str, ByteBuffer byteBuffer, boolean z) {
        String str2;
        int position = byteBuffer.position();
        if (z) {
            byteBuffer.position(0);
        }
        int remaining = byteBuffer.remaining();
        if (remaining > 0) {
            StringBuilder sb = new StringBuilder(String.format("%X", new Object[]{Byte.valueOf(byteBuffer.get())}));
            while (byteBuffer.hasRemaining()) {
                sb.append(String.format("-%X", new Object[]{Byte.valueOf(byteBuffer.get())}));
            }
            str2 = sb.toString();
        } else {
            str2 = "[]";
        }
        RobotLog.dd(TAG, "%s (%d bytes): %s", str, Integer.valueOf(remaining), str2);
        byteBuffer.position(position);
    }

    private static void printByteBuffer(String str, ByteBuffer byteBuffer) {
        printByteBuffer(str, byteBuffer, true);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0077, code lost:
        if (r7.hasRemaining() == false) goto L_0x00df;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0079, code lost:
        r0 = com.qualcomm.robotcore.util.TypeConversion.unsignedByteToInt(r7.get());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0081, code lost:
        if (r0 == 0) goto L_0x0092;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0085, code lost:
        if (r0 >= 224) goto L_0x0092;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0087, code lost:
        com.qualcomm.robotcore.util.RobotLog.ww(TAG, "%s FIFO contained sensor data", r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0092, code lost:
        r1 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.findById(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0096, code lost:
        if (r1 != null) goto L_0x00a8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0098, code lost:
        com.qualcomm.robotcore.util.RobotLog.ee(TAG, "%s FIFO contained unknown event ID %d. Unable to process the rest of the FIFO's contents", r8, java.lang.Integer.valueOf(r0));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00a7, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x00b0, code lost:
        switch(com.qualcomm.hardware.bosch.BHI260IMU.AnonymousClass2.$SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType[r1.ordinal()]) {
            case 1: goto L_0x00c9;
            case 2: goto L_0x00c5;
            case 3: goto L_0x00c1;
            case 4: goto L_0x00bb;
            case 5: goto L_0x00b7;
            case 6: goto L_0x0073;
            case 7: goto L_0x00b6;
            default: goto L_0x00b3;
        };
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x00b6, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x00b7, code lost:
        parseMetaEvent(r7, r8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00bb, code lost:
        r7.get(new byte[5]);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00c1, code lost:
        r7.getShort();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x00c5, code lost:
        r7.get();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00c9, code lost:
        printDebugData(r7);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00cd, code lost:
        com.qualcomm.robotcore.util.RobotLog.ee(TAG, "No handler is defined for event type %s", r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00d6, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x00d7, code lost:
        r7 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00d8, code lost:
        com.qualcomm.robotcore.util.RobotLog.ee(TAG, (java.lang.Throwable) r7, "BufferUnderflowException was caught at the top level of readFifo(). It should be caught closer to where it was thrown so that it can be handled more intelligently.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void readFifo(com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple r7, com.qualcomm.hardware.bosch.BHI260IMU.Fifo r8) {
        /*
            java.lang.Object r0 = i2cLock
            monitor-enter(r0)
            com.qualcomm.hardware.bosch.BHI260IMU$Register r1 = r8.register     // Catch:{ all -> 0x00e0 }
            r2 = 3
            java.nio.ByteBuffer r1 = readMultiple(r7, r1, r2)     // Catch:{ all -> 0x00e0 }
            short r1 = r1.getShort()     // Catch:{ all -> 0x00e0 }
            int r1 = com.qualcomm.robotcore.util.TypeConversion.unsignedShortToInt(r1)     // Catch:{ all -> 0x00e0 }
            if (r1 != 0) goto L_0x0023
            java.lang.String r7 = "BHI260IMU"
            java.lang.String r1 = "Attempted to read empty %s FIFO"
            java.lang.Object[] r8 = new java.lang.Object[]{r8}     // Catch:{ all -> 0x00e0 }
            com.qualcomm.robotcore.util.RobotLog.ww((java.lang.String) r7, (java.lang.String) r1, (java.lang.Object[]) r8)     // Catch:{ all -> 0x00e0 }
            monitor-exit(r0)     // Catch:{ all -> 0x00e0 }
            return
        L_0x0023:
            int r2 = r1 + -4
            r3 = 5
            r4 = 100
            if (r2 > r4) goto L_0x0030
            int r1 = r1 - r3
            java.nio.ByteBuffer r7 = readMultiple(r7, r1)     // Catch:{ all -> 0x00e0 }
            goto L_0x0072
        L_0x0030:
            java.nio.ByteBuffer r1 = readMultiple(r7, r4)     // Catch:{ all -> 0x00e0 }
            java.lang.String r2 = "BHI260IMU"
            java.lang.String r4 = "FIFO was too large. Aborting transfer and discarding data."
            com.qualcomm.robotcore.util.RobotLog.ww(r2, r4)     // Catch:{ all -> 0x00e0 }
            int[] r2 = com.qualcomm.hardware.bosch.BHI260IMU.AnonymousClass2.$SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$Fifo     // Catch:{ all -> 0x00e0 }
            int r4 = r8.ordinal()     // Catch:{ all -> 0x00e0 }
            r2 = r2[r4]     // Catch:{ all -> 0x00e0 }
            r4 = 1
            if (r2 == r4) goto L_0x0051
            r4 = 2
            if (r2 == r4) goto L_0x004d
            com.qualcomm.hardware.bosch.BHI260IMU$HostInterfaceControlFlag r2 = com.qualcomm.hardware.bosch.BHI260IMU.HostInterfaceControlFlag.ABORT_TRANSFER_CHANNEL_3     // Catch:{ all -> 0x00e0 }
            r4 = -7
            goto L_0x0054
        L_0x004d:
            com.qualcomm.hardware.bosch.BHI260IMU$HostInterfaceControlFlag r2 = com.qualcomm.hardware.bosch.BHI260IMU.HostInterfaceControlFlag.ABORT_TRANSFER_CHANNEL_2     // Catch:{ all -> 0x00e0 }
            r4 = -6
            goto L_0x0054
        L_0x0051:
            com.qualcomm.hardware.bosch.BHI260IMU$HostInterfaceControlFlag r2 = com.qualcomm.hardware.bosch.BHI260IMU.HostInterfaceControlFlag.ABORT_TRANSFER_CHANNEL_1     // Catch:{ all -> 0x00e0 }
            r4 = -5
        L_0x0054:
            com.qualcomm.hardware.bosch.BHI260IMU$Register r5 = com.qualcomm.hardware.bosch.BHI260IMU.Register.HOST_INTERFACE_CONTROL     // Catch:{ all -> 0x00e0 }
            java.lang.Class<com.qualcomm.hardware.bosch.BHI260IMU$HostInterfaceControlFlag> r6 = com.qualcomm.hardware.bosch.BHI260IMU.HostInterfaceControlFlag.class
            java.util.EnumSet r5 = read8Flags(r7, r5, r6)     // Catch:{ all -> 0x00e0 }
            r5.add(r2)     // Catch:{ all -> 0x00e0 }
            com.qualcomm.hardware.bosch.BHI260IMU$Register r2 = com.qualcomm.hardware.bosch.BHI260IMU.Register.HOST_INTERFACE_CONTROL     // Catch:{ all -> 0x00e0 }
            com.qualcomm.robotcore.hardware.I2cWaitControl r6 = com.qualcomm.robotcore.hardware.I2cWaitControl.ATOMIC     // Catch:{ all -> 0x00e0 }
            write8Flags(r7, r2, r5, r6)     // Catch:{ all -> 0x00e0 }
            r2 = 4
            byte[] r2 = new byte[r2]     // Catch:{ all -> 0x00e0 }
            r5 = 0
            r2[r5] = r4     // Catch:{ all -> 0x00e0 }
            com.qualcomm.hardware.bosch.BHI260IMU$CommandType r4 = com.qualcomm.hardware.bosch.BHI260IMU.CommandType.FIFO_FLUSH     // Catch:{ all -> 0x00e0 }
            sendCommand(r7, r4, r2)     // Catch:{ all -> 0x00e0 }
            r7 = r1
        L_0x0072:
            monitor-exit(r0)     // Catch:{ all -> 0x00e0 }
        L_0x0073:
            boolean r0 = r7.hasRemaining()
            if (r0 == 0) goto L_0x00df
            byte r0 = r7.get()
            int r0 = com.qualcomm.robotcore.util.TypeConversion.unsignedByteToInt(r0)
            if (r0 == 0) goto L_0x0092
            r1 = 224(0xe0, float:3.14E-43)
            if (r0 >= r1) goto L_0x0092
            java.lang.String r1 = "BHI260IMU"
            java.lang.String r2 = "%s FIFO contained sensor data"
            java.lang.Object[] r4 = new java.lang.Object[]{r8}
            com.qualcomm.robotcore.util.RobotLog.ww((java.lang.String) r1, (java.lang.String) r2, (java.lang.Object[]) r4)
        L_0x0092:
            com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r1 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.findById(r0)
            if (r1 != 0) goto L_0x00a8
            java.lang.String r7 = "BHI260IMU"
            java.lang.String r1 = "%s FIFO contained unknown event ID %d. Unable to process the rest of the FIFO's contents"
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            java.lang.Object[] r8 = new java.lang.Object[]{r8, r0}
            com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r7, (java.lang.String) r1, (java.lang.Object[]) r8)
            return
        L_0x00a8:
            int[] r0 = com.qualcomm.hardware.bosch.BHI260IMU.AnonymousClass2.$SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ BufferUnderflowException -> 0x00d7 }
            int r2 = r1.ordinal()     // Catch:{ BufferUnderflowException -> 0x00d7 }
            r0 = r0[r2]     // Catch:{ BufferUnderflowException -> 0x00d7 }
            switch(r0) {
                case 1: goto L_0x00c9;
                case 2: goto L_0x00c5;
                case 3: goto L_0x00c1;
                case 4: goto L_0x00bb;
                case 5: goto L_0x00b7;
                case 6: goto L_0x0073;
                case 7: goto L_0x00b6;
                default: goto L_0x00b3;
            }     // Catch:{ BufferUnderflowException -> 0x00d7 }
        L_0x00b3:
            java.lang.String r7 = "BHI260IMU"
            goto L_0x00cd
        L_0x00b6:
            return
        L_0x00b7:
            parseMetaEvent(r7, r8)     // Catch:{ BufferUnderflowException -> 0x00d7 }
            goto L_0x0073
        L_0x00bb:
            byte[] r0 = new byte[r3]     // Catch:{ BufferUnderflowException -> 0x00d7 }
            r7.get(r0)     // Catch:{ BufferUnderflowException -> 0x00d7 }
            goto L_0x0073
        L_0x00c1:
            r7.getShort()     // Catch:{ BufferUnderflowException -> 0x00d7 }
            goto L_0x0073
        L_0x00c5:
            r7.get()     // Catch:{ BufferUnderflowException -> 0x00d7 }
            goto L_0x0073
        L_0x00c9:
            printDebugData(r7)     // Catch:{ BufferUnderflowException -> 0x00d7 }
            goto L_0x0073
        L_0x00cd:
            java.lang.String r8 = "No handler is defined for event type %s"
            java.lang.Object[] r0 = new java.lang.Object[]{r1}     // Catch:{ BufferUnderflowException -> 0x00d7 }
            com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r7, (java.lang.String) r8, (java.lang.Object[]) r0)     // Catch:{ BufferUnderflowException -> 0x00d7 }
            return
        L_0x00d7:
            r7 = move-exception
            java.lang.String r8 = "BHI260IMU"
            java.lang.String r0 = "BufferUnderflowException was caught at the top level of readFifo(). It should be caught closer to where it was thrown so that it can be handled more intelligently."
            com.qualcomm.robotcore.util.RobotLog.ee((java.lang.String) r8, (java.lang.Throwable) r7, (java.lang.String) r0)
        L_0x00df:
            return
        L_0x00e0:
            r7 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00e0 }
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.bosch.BHI260IMU.readFifo(com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple, com.qualcomm.hardware.bosch.BHI260IMU$Fifo):void");
    }

    /* renamed from: com.qualcomm.hardware.bosch.BHI260IMU$2  reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$Fifo;
        static final /* synthetic */ int[] $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType;

        /* JADX WARNING: Can't wrap try/catch for region: R(22:0|(2:1|2)|3|(2:5|6)|7|9|10|11|12|13|14|15|16|(2:17|18)|19|21|22|23|24|25|26|28) */
        /* JADX WARNING: Can't wrap try/catch for region: R(24:0|1|2|3|(2:5|6)|7|9|10|11|12|13|14|15|16|17|18|19|21|22|23|24|25|26|28) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:11:0x0028 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:13:0x0033 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x003e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:17:0x0049 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0065 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x006f */
        static {
            /*
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType[] r0 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType = r0
                r1 = 1
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r2 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.DEBUG_DATA     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ NoSuchFieldError -> 0x001d }
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r3 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.TIMESTAMP_SMALL_DELTA     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r2 = 3
                int[] r3 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r4 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.TIMESTAMP_LARGE_DELTA     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                int[] r3 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ NoSuchFieldError -> 0x0033 }
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r4 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.TIMESTAMP_FULL     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r5 = 4
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                int[] r3 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ NoSuchFieldError -> 0x003e }
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r4 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.META_EVENT     // Catch:{ NoSuchFieldError -> 0x003e }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x003e }
                r5 = 5
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x003e }
            L_0x003e:
                int[] r3 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ NoSuchFieldError -> 0x0049 }
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r4 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.FILLER     // Catch:{ NoSuchFieldError -> 0x0049 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0049 }
                r5 = 6
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0049 }
            L_0x0049:
                int[] r3 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$NonSensorEventType     // Catch:{ NoSuchFieldError -> 0x0054 }
                com.qualcomm.hardware.bosch.BHI260IMU$NonSensorEventType r4 = com.qualcomm.hardware.bosch.BHI260IMU.NonSensorEventType.PADDING     // Catch:{ NoSuchFieldError -> 0x0054 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0054 }
                r5 = 7
                r3[r4] = r5     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                com.qualcomm.hardware.bosch.BHI260IMU$Fifo[] r3 = com.qualcomm.hardware.bosch.BHI260IMU.Fifo.values()
                int r3 = r3.length
                int[] r3 = new int[r3]
                $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$Fifo = r3
                com.qualcomm.hardware.bosch.BHI260IMU$Fifo r4 = com.qualcomm.hardware.bosch.BHI260IMU.Fifo.WAKE_UP     // Catch:{ NoSuchFieldError -> 0x0065 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0065 }
                r3[r4] = r1     // Catch:{ NoSuchFieldError -> 0x0065 }
            L_0x0065:
                int[] r1 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$Fifo     // Catch:{ NoSuchFieldError -> 0x006f }
                com.qualcomm.hardware.bosch.BHI260IMU$Fifo r3 = com.qualcomm.hardware.bosch.BHI260IMU.Fifo.NON_WAKE_UP     // Catch:{ NoSuchFieldError -> 0x006f }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x006f }
                r1[r3] = r0     // Catch:{ NoSuchFieldError -> 0x006f }
            L_0x006f:
                int[] r0 = $SwitchMap$com$qualcomm$hardware$bosch$BHI260IMU$Fifo     // Catch:{ NoSuchFieldError -> 0x0079 }
                com.qualcomm.hardware.bosch.BHI260IMU$Fifo r1 = com.qualcomm.hardware.bosch.BHI260IMU.Fifo.STATUS_AND_DEBUG     // Catch:{ NoSuchFieldError -> 0x0079 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0079 }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0079 }
            L_0x0079:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.bosch.BHI260IMU.AnonymousClass2.<clinit>():void");
        }
    }

    private static void startDiagnosticMode() {
        if (diagnosticModeThread == null) {
            diagnosticModeThread = new Thread(new Runnable() {
                private I2cDeviceSynchSimple deviceClient;

                public void run() {
                    RobotLog.vv(BHI260IMU.TAG, "Diagnostic mode thread started");
                    boolean z = false;
                    int i = 0;
                    while (!Thread.currentThread().isInterrupted()) {
                        try {
                            Thread.sleep(100);
                            if (refreshDeviceClient()) {
                                if (!z) {
                                    BHI260IMU.disableFifoTimestamps(this.deviceClient);
                                    z = true;
                                }
                                int access$900 = BHI260IMU.read8(this.deviceClient, Register.ERROR_VALUE);
                                if (access$900 != i) {
                                    if (access$900 == 0) {
                                        RobotLog.vv(BHI260IMU.TAG, "Error cleared");
                                    } else {
                                        RobotLog.ww(BHI260IMU.TAG, "Error value: 0x%X", Integer.valueOf(access$900));
                                    }
                                }
                                i = access$900;
                            }
                        } catch (InterruptedException unused) {
                            return;
                        }
                    }
                }

                private boolean refreshDeviceClient() {
                    I2cDeviceSynchSimple i2cDeviceSynchSimple = this.deviceClient;
                    if (i2cDeviceSynchSimple != null && i2cDeviceSynchSimple.getHealthStatus() != HardwareDeviceHealth.HealthStatus.CLOSED) {
                        return true;
                    }
                    LynxModule lynxModule = (LynxModule) EmbeddedControlHubModule.get();
                    if (lynxModule == null || !lynxModule.isOpen()) {
                        this.deviceClient = null;
                        return false;
                    }
                    LynxI2cDeviceSynch createLynxI2cDeviceSynch = LynxFirmwareVersionManager.createLynxI2cDeviceSynch(AppUtil.getDefContext(), lynxModule, 0);
                    this.deviceClient = createLynxI2cDeviceSynch;
                    createLynxI2cDeviceSynch.setI2cAddress(BHI260IMU.I2C_ADDR);
                    return true;
                }
            });
            diagnosticModeThread.setName("Diagnostic mode thread");
            diagnosticModeThread.start();
        }
    }

    private static void printDebugData(ByteBuffer byteBuffer) {
        int unsignedByteToInt = TypeConversion.unsignedByteToInt(byteBuffer.get());
        int unsignedByteToInt2 = TypeConversion.unsignedByteToInt(byteBuffer.get());
        int i = unsignedByteToInt2 & 63;
        boolean z = (unsignedByteToInt2 & 64) > 0;
        byte[] bArr = new byte[16];
        byteBuffer.get(bArr);
        byte[] copyOfRange = Arrays.copyOfRange(bArr, 0, i);
        String format = String.format(Locale.ENGLISH, "Debug data (sensor %d)", new Object[]{Integer.valueOf(unsignedByteToInt)});
        if (z) {
            printByteBuffer(format, ByteBuffer.wrap(copyOfRange));
        } else {
            RobotLog.dd(TAG, "%s: %s", format, new String(copyOfRange, StandardCharsets.UTF_8));
        }
    }

    private static void parseMetaEvent(ByteBuffer byteBuffer, Fifo fifo) {
        int unsignedByteToInt = TypeConversion.unsignedByteToInt(byteBuffer.get());
        byte[] bArr = new byte[2];
        boolean z = false;
        try {
            byteBuffer.get(bArr);
        } catch (BufferUnderflowException unused) {
            bArr = new byte[]{byteBuffer.get(), -1};
        }
        int unsignedByteToInt2 = TypeConversion.unsignedByteToInt(bArr[0]);
        int unsignedByteToInt3 = TypeConversion.unsignedByteToInt(bArr[1]);
        String str = EnvironmentCompat.MEDIA_UNKNOWN;
        switch (unsignedByteToInt) {
            case 1:
                RobotLog.vv(TAG, "Sensor %d flush complete", Integer.valueOf(unsignedByteToInt2));
                return;
            case 2:
                RobotLog.vv(TAG, "Sensor %d sample rate changed", Integer.valueOf(unsignedByteToInt2));
                return;
            case 3:
                RobotLog.vv(TAG, "Sensor %d power mode is now %d", Integer.valueOf(unsignedByteToInt2), Integer.valueOf(unsignedByteToInt3));
                return;
            case 4:
                RobotLog.vv(TAG, "IMU system error. errorCode=0x%X interruptStatus=%s", Integer.valueOf(unsignedByteToInt2), convertIntToEnumSet(unsignedByteToInt3, InterruptStatusFlag.class));
                return;
            case 6:
                if (unsignedByteToInt3 == 0) {
                    str = "unreliable";
                } else if (unsignedByteToInt3 == 1) {
                    str = "low";
                } else if (unsignedByteToInt3 == 2) {
                    str = "medium";
                } else if (unsignedByteToInt3 == 3) {
                    str = "high";
                }
                RobotLog.vv(TAG, "Sensor %d accuracy is now \"%s\"", Integer.valueOf(unsignedByteToInt2), str);
                return;
            case 11:
                RobotLog.vv(TAG, "Sensor %d experienced an error. errorCode=0x%X", Integer.valueOf(unsignedByteToInt2), Integer.valueOf(unsignedByteToInt3));
                return;
            case 12:
                RobotLog.vv(TAG, "FIFO %s overflowed", fifo);
                byteBuffer.get(new byte[5]);
                return;
            case 13:
                RobotLog.vv(TAG, "Sensor %d dynamic range changed", Integer.valueOf(unsignedByteToInt2));
                return;
            case 14:
                RobotLog.ww(TAG, "FIFO %s has reached its watermark level", fifo);
                return;
            case 16:
                RobotLog.vv(TAG, "Firmware has finished initializing");
                return;
            case 17:
                RobotLog.ww(TAG, "Unexpectedly received a Transfer Cause event for sensor %d", Integer.valueOf(unsignedByteToInt2));
                return;
            case 18:
                if (unsignedByteToInt3 == 1) {
                    str = "Trigger was delayed";
                } else if (unsignedByteToInt3 == 2) {
                    str = "Trigger was dropped";
                } else if (unsignedByteToInt3 == 3) {
                    str = "Hang detection disabled";
                } else if (unsignedByteToInt3 == 4) {
                    str = "Parent is not enabled";
                }
                RobotLog.ww(TAG, "Software Framework error for sensor %d: %s", Integer.valueOf(unsignedByteToInt2), str);
                return;
            case 19:
                if (unsignedByteToInt3 == 0) {
                    str = "Power-on reset";
                } else if (unsignedByteToInt3 == 1) {
                    str = "External reset";
                } else if (unsignedByteToInt3 == 2) {
                    str = "Host commanded reset";
                } else if (unsignedByteToInt3 == 4) {
                    str = "Watchdog reset";
                    z = true;
                }
                if (z) {
                    RobotLog.ww(TAG, "IMU was reset: %s", str);
                    return;
                } else {
                    RobotLog.vv(TAG, "IMU was reset: %s", str);
                    return;
                }
            case 20:
                return;
            default:
                RobotLog.ww(TAG, "Received unknown meta event type %d", Integer.valueOf(unsignedByteToInt));
                return;
        }
    }

    private enum Register {
        COMMAND_INPUT(0),
        WAKE_UP_FIFO_OUTPUT(1),
        NON_WAKE_UP_FIFO_OUTPUT(2),
        STATUS_AND_DEBUG_FIFO_OUTPUT(3),
        CHIP_CONTROL(5),
        HOST_INTERFACE_CONTROL(6),
        HOST_INTERRUPT_CONTROL(7),
        RESET_REQUEST(20),
        TIMESTAMP_EVENT_REQUEST(21),
        HOST_CONTROL(22),
        HOST_STATUS(23),
        PRODUCT_IDENTIFIER(28),
        REVISION_IDENTIFIER(29),
        ROM_VERSION(30),
        KERNEL_VERSION(32),
        USER_VERSION(34),
        FEATURE_STATUS(36),
        BOOT_STATUS(37),
        CHIP_ID(43),
        INTERRUPT_STATUS(45),
        ERROR_VALUE(46),
        GEN_PURPOSE_READ(50);
        
        /* access modifiers changed from: private */
        public final int address;

        private Register(int i) {
            this.address = i;
        }
    }

    private enum Fifo {
        WAKE_UP(Register.WAKE_UP_FIFO_OUTPUT),
        NON_WAKE_UP(Register.NON_WAKE_UP_FIFO_OUTPUT),
        STATUS_AND_DEBUG(Register.STATUS_AND_DEBUG_FIFO_OUTPUT);
        
        /* access modifiers changed from: private */
        public final Register register;

        private Fifo(Register register2) {
            this.register = register2;
        }
    }

    private enum NonSensorEventType {
        DEBUG_DATA(SyncdDevice.msAbnormalReopenInterval, -1),
        TIMESTAMP_SMALL_DELTA(251, 245),
        TIMESTAMP_LARGE_DELTA(252, 246),
        TIMESTAMP_FULL(253, 247),
        META_EVENT(254, 248),
        FILLER(255, 255),
        PADDING(0, 0);
        
        final int nonWakeUpId;
        final int wakeUpId;

        private NonSensorEventType(int i, int i2) {
            this.wakeUpId = i2;
            this.nonWakeUpId = i;
        }

        public static NonSensorEventType findById(int i) {
            for (NonSensorEventType nonSensorEventType : values()) {
                if (nonSensorEventType.nonWakeUpId == i || nonSensorEventType.wakeUpId == i) {
                    return nonSensorEventType;
                }
            }
            return null;
        }
    }

    private enum CommandType {
        ERASE_FLASH(4, 10),
        WRITE_FLASH(5, 11),
        BOOT_FLASH(6, 0),
        FIFO_FLUSH(9, 0),
        CONFIGURE_SENSOR(13, 0),
        CHANGE_SENSOR_DYNAMIC_RANGE(14, 0),
        CONTROL_FIFO_FORMAT(21, 0);
        
        /* access modifiers changed from: private */
        public final int id;
        /* access modifiers changed from: private */
        public final int successStatusCode;

        private CommandType(int i, int i2) {
            this.id = i;
            this.successStatusCode = i2;
        }

        public static CommandType findById(int i) {
            for (CommandType commandType : values()) {
                if (commandType.id == i) {
                    return commandType;
                }
            }
            return null;
        }
    }

    private enum CommandError {
        INCORRECT_LENGTH(1),
        TOO_LONG(2),
        PARAM_WRITE_ERROR(3),
        PARAM_READ_ERROR(4),
        INVALID_COMMAND(5),
        INVALID_PARAM(6),
        COMMAND_FAILED(255);
        
        private final int value;

        private CommandError(int i) {
            this.value = i;
        }

        public static CommandError fromInt(int i) {
            for (CommandError commandError : values()) {
                if (i == commandError.value) {
                    return commandError;
                }
            }
            return null;
        }
    }

    private enum Sensor {
        GAME_ROTATION_VECTOR_WAKE_UP(38),
        GAME_ROTATION_VECTOR_DATA_HOLDER(176),
        GAME_ROTATION_VECTOR_GPIO_HANDLER(177),
        GYROSCOPE_CORRECTED_DATA_HOLDER(178),
        GYROSCOPE_CORRECTED_GPIO_HANDLER(179);
        
        /* access modifiers changed from: private */
        public final int id;

        private Sensor(int i) {
            this.id = i;
        }
    }

    private static class InitException extends Exception {
        private InitException() {
        }
    }

    private static class CommandFailureException extends Exception {
        public CommandFailureException(String str) {
            super(str);
        }
    }

    private static class StatusPacket {
        public final byte[] payload;
        public final int statusCode;

        private StatusPacket(int i, byte[] bArr) {
            this.statusCode = i;
            this.payload = bArr;
        }
    }

    private static class StatusAndDebugFifoModeManager {
        private final boolean DEBUG;
        private final ReentrantLock operationInProgressLock;
        private StatusAndDebugFifoMode statusAndDebugFifoMode;

        private StatusAndDebugFifoModeManager() {
            this.DEBUG = false;
            this.statusAndDebugFifoMode = null;
            this.operationInProgressLock = new ReentrantLock();
        }

        public void lockStatusAndDebugFifoMode(I2cDeviceSynchSimple i2cDeviceSynchSimple, StatusAndDebugFifoMode statusAndDebugFifoMode2) {
            this.operationInProgressLock.lock();
            if (this.statusAndDebugFifoMode == null) {
                if (BHI260IMU.read8Flags(i2cDeviceSynchSimple, Register.HOST_INTERFACE_CONTROL, HostInterfaceControlFlag.class).contains(HostInterfaceControlFlag.ASYNC_STATUS_CHANNEL)) {
                    this.statusAndDebugFifoMode = StatusAndDebugFifoMode.ASYNCHRONOUS;
                } else {
                    this.statusAndDebugFifoMode = StatusAndDebugFifoMode.SYNCHRONOUS;
                }
                RobotLog.vv(BHI260IMU.TAG, "Initial Status and Debug FIFO mode: %s", this.statusAndDebugFifoMode);
            }
            if (this.statusAndDebugFifoMode != statusAndDebugFifoMode2) {
                this.statusAndDebugFifoMode = statusAndDebugFifoMode2;
                EnumSet<E> noneOf = EnumSet.noneOf(HostInterfaceControlFlag.class);
                if (statusAndDebugFifoMode2 == StatusAndDebugFifoMode.ASYNCHRONOUS) {
                    noneOf.add(HostInterfaceControlFlag.ASYNC_STATUS_CHANNEL);
                }
                BHI260IMU.write8Flags(i2cDeviceSynchSimple, Register.HOST_INTERFACE_CONTROL, noneOf, I2cWaitControl.ATOMIC);
            }
        }

        public void unlockStatusAndDebugFifoMode() {
            this.operationInProgressLock.unlock();
        }
    }
}

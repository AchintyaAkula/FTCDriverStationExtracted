package com.qualcomm.hardware.andymark;

import com.qualcomm.hardware.lynx.LynxServoController;
import com.qualcomm.robotcore.hardware.ColorRangeSensor;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cAddr;
import com.qualcomm.robotcore.hardware.I2cDeviceSynch;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchDevice;
import com.qualcomm.robotcore.hardware.NormalizedRGBA;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;
import com.qualcomm.robotcore.util.Range;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

@I2cDeviceType
@DeviceProperties(description = "AndyMark Proximity & Color Sensor", name = "AndyMark Proximity & Color Sensor", xmlTag = "AndyMarkColor")
public class AndyMarkColorSensor extends I2cDeviceSynchDevice<I2cDeviceSynch> implements ColorRangeSensor, DistanceSensor, ColorSensor {
    private static final int ALS_BLUE_HIGH = 155;
    private static final int ALS_BLUE_LOW = 154;
    private static final int ALS_CLEAR_HIGH = 149;
    private static final int ALS_CLEAR_LOW = 148;
    private static final int ALS_GREEN_HIGH = 153;
    private static final int ALS_GREEN_LOW = 152;
    private static final int ALS_RED_HIGH = 151;
    private static final int ALS_RED_LOW = 150;
    private static final int ATIME_REGISTER = 129;
    private static final int CONTROL_REGISTER = 143;
    private static final int ENABLE_REGISTER = 128;
    private static final int EXPECTED_ID = 228;
    private static final I2cAddr I2C_ADDRESS = I2cAddr.create7bit(57);
    private static final int ID_REGISTER = 146;
    private static final int PROXIMITY_DATA = 156;
    private static final int REG_PCFG0 = 142;
    private static final int REG_PCFG1 = 143;
    private static final int STATUS_REGISTER = 147;
    private static final int WTIME_REGISTER = 131;

    public void enableLed(boolean z) {
    }

    public float getGain() {
        return 1.0f;
    }

    public double getRawLightDetectedMax() {
        return 65535.0d;
    }

    public void setGain(float f) {
    }

    public enum ProximityGain {
        GAIN_1X(0),
        GAIN_2X(64),
        GAIN_4X(128),
        GAIN_8X(192);
        
        public final int bits;

        private ProximityGain(int i) {
            this.bits = i;
        }
    }

    public enum ProximityPulseLength {
        LENGTH_4US(0),
        LENGTH_8US(64),
        LENGTH_16US(128),
        LENGTH_32US(192);
        
        public final int bits;

        private ProximityPulseLength(int i) {
            this.bits = i;
        }
    }

    public AndyMarkColorSensor(I2cDeviceSynch i2cDeviceSynch, boolean z) {
        super(i2cDeviceSynch, z);
        ((I2cDeviceSynch) this.deviceClient).setI2cAddress(I2C_ADDRESS);
        ((I2cDeviceSynch) this.deviceClient).engage();
    }

    public String getDeviceName() {
        return "AndyMark Proximity & Color Sensor";
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.AMS;
    }

    public void setI2cAddress(I2cAddr i2cAddr) {
        ((I2cDeviceSynch) this.deviceClient).setI2cAddress(i2cAddr);
    }

    public I2cAddr getI2cAddress() {
        return ((I2cDeviceSynch) this.deviceClient).getI2cAddress();
    }

    /* access modifiers changed from: protected */
    public boolean doInitialize() {
        writeRegister(128, 15);
        writeRegister(129, 255);
        writeRegister(131, 255);
        writeRegister(143, 111);
        return readRegister(146) == EXPECTED_ID;
    }

    public String classifyColor() {
        int alpha = alpha();
        int red = red();
        int green = green();
        int blue = blue();
        int i = red + green + blue;
        if (alpha >= 50 && i >= 50) {
            if (i < 90) {
                return "Black";
            }
            if (i > 450) {
                return "White";
            }
            if (red > 115 && green > 90 && blue < 45) {
                return "Yellow";
            }
            if (green > 45 && blue > 38 && red < 40) {
                return "Cyan";
            }
            if (red > 65 && green < 30 && blue < 30) {
                return "Magenta";
            }
            int i2 = green + 10;
            if (red > i2 && red > blue + 10) {
                return "Red";
            }
            int i3 = red + 10;
            if (green > i3 && green > blue + 10) {
                return "Green";
            }
            if (blue <= i3 || blue <= i2) {
                return "Unknown";
            }
            return "Blue";
        }
        return "Unknown";
    }

    public int argb() {
        return ((alpha() & 255) << 24) | ((red() & 255) << 16) | ((green() & 255) << 8) | (blue() & 255);
    }

    public NormalizedRGBA getNormalizedColors() {
        NormalizedRGBA normalizedRGBA = new NormalizedRGBA();
        normalizedRGBA.alpha = Range.clip(((float) alpha()) / 65535.0f, 0.0f, 1.0f);
        normalizedRGBA.red = Range.clip(((float) red()) / 65535.0f, 0.0f, 1.0f);
        normalizedRGBA.green = Range.clip(((float) green()) / 65535.0f, 0.0f, 1.0f);
        normalizedRGBA.blue = Range.clip(((float) blue()) / 65535.0f, 0.0f, 1.0f);
        return normalizedRGBA;
    }

    public int alpha() {
        return read16BitRegister(148, 149);
    }

    public double getRawLightDetected() {
        return Range.clip(((double) alpha()) / 65535.0d, (double) LynxServoController.apiPositionFirst, 1.0d);
    }

    public double getLightDetected() {
        return getRawLightDetected();
    }

    public int red() {
        return read16BitRegister(150, 151);
    }

    public int green() {
        return read16BitRegister(152, 153);
    }

    public int blue() {
        return read16BitRegister(154, 155);
    }

    public double getDistance(DistanceUnit distanceUnit) {
        return distanceUnit.fromUnit(DistanceUnit.INCH, inFromProximity(getProximity()));
    }

    private double inFromProximity(int i) {
        return Math.max(0.25d, Math.min(6.0d, Math.pow(Math.max(((double) i) - LynxServoController.apiPositionFirst, 1.0d) / 250.0d, -0.8d) / 25.4d));
    }

    public int getProximity() {
        return readRegister(PROXIMITY_DATA);
    }

    public void setProximityGain(ProximityGain proximityGain) {
        writeRegister(143, (proximityGain.bits & 192) | (readRegister(143) & 63));
    }

    public void setProximityLedPulses(int i) {
        if (i < 1 || i > 64) {
            throw new IllegalArgumentException("Pulses must be between 1 and 64.");
        }
        writeRegister(142, ((i - 1) & 63) | (readRegister(142) & 192));
    }

    public void setProximityLedPulseLength(ProximityPulseLength proximityPulseLength) {
        writeRegister(142, (proximityPulseLength.bits & 192) | (readRegister(142) & 63));
    }

    public void configureProximitySettings(ProximityGain proximityGain, int i, ProximityPulseLength proximityPulseLength) {
        setProximityGain(proximityGain);
        setProximityLedPulses(i);
        setProximityLedPulseLength(proximityPulseLength);
    }

    public String status() {
        return getDeviceName() + " connected";
    }

    private void writeRegister(int i, int i2) {
        ((I2cDeviceSynch) this.deviceClient).write8(i, i2);
    }

    private int readRegister(int i) {
        return ((I2cDeviceSynch) this.deviceClient).read8(i) & 255;
    }

    private int read16BitRegister(int i, int i2) {
        return readRegister(i) | (readRegister(i2) << 8);
    }
}

package com.qualcomm.hardware.andymark;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.BNO055IMUNew;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;

@DeviceProperties(builtIn = true, description = "AndyMark External IMU", name = "AndyMark 9-Axis IMU", xmlTag = "AndyMarkIMU")
@I2cDeviceType
public class AndyMarkIMU extends BNO055IMUNew {
    public AndyMarkIMU(I2cDeviceSynchSimple i2cDeviceSynchSimple, boolean z) {
        super(i2cDeviceSynchSimple, z, BNO055IMU.I2CADDR_DEFAULT);
    }

    public String getDeviceName() {
        return "AndyMark 9-Axis IMU";
    }

    public HardwareDevice.Manufacturer getManufacturer() {
        return HardwareDevice.Manufacturer.Lynx;
    }
}

package com.qualcomm.hardware.andymark;

import com.qualcomm.hardware.stmicroelectronics.VL53L0X;
import com.qualcomm.robotcore.hardware.I2cDeviceSynch;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.I2cDeviceType;

@DeviceProperties(builtIn = true, description = "AndyMark 2m TOF Lidar", name = "AndyMark TOF Lidar", xmlTag = "AndyMarkTOF")
@I2cDeviceType
public class AndyMarkTOF extends VL53L0X {
    public AndyMarkTOF(I2cDeviceSynch i2cDeviceSynch, boolean z) {
        super(i2cDeviceSynch, z);
    }

    public String getDeviceName() {
        return "AndyMark TOF Lidar";
    }
}

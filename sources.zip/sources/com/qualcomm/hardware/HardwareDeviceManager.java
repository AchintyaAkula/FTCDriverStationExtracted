package com.qualcomm.hardware;

import android.content.Context;
import android.text.TextUtils;
import android.util.Pair;
import com.qualcomm.hardware.adafruit.AdafruitI2cColorSensor;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.lynx.LynxI2cColorRangeSensor;
import com.qualcomm.hardware.lynx.LynxI2cDeviceSynch;
import com.qualcomm.hardware.lynx.LynxModule;
import com.qualcomm.hardware.lynx.LynxUsbDeviceImpl;
import com.qualcomm.hardware.lynx.commands.core.LynxFirmwareVersionManager;
import com.qualcomm.hardware.modernrobotics.ModernRoboticsI2cColorSensor;
import com.qualcomm.hardware.modernrobotics.ModernRoboticsI2cGyro;
import com.qualcomm.hardware.modernrobotics.ModernRoboticsI2cIrSeekerSensorV3;
import com.qualcomm.hardware.modernrobotics.ModernRoboticsTouchSensor;
import com.qualcomm.robotcore.eventloop.SyncdDevice;
import com.qualcomm.robotcore.exception.RobotCoreException;
import com.qualcomm.robotcore.hardware.AnalogInputController;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.CRServoImplEx;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorController;
import com.qualcomm.robotcore.hardware.DcMotorImpl;
import com.qualcomm.robotcore.hardware.DcMotorImplEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DeviceManager;
import com.qualcomm.robotcore.hardware.DigitalChannelController;
import com.qualcomm.robotcore.hardware.GyroSensor;
import com.qualcomm.robotcore.hardware.HardwareDevice;
import com.qualcomm.robotcore.hardware.I2cDeviceSynch;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchImplOnSimple;
import com.qualcomm.robotcore.hardware.I2cDeviceSynchSimple;
import com.qualcomm.robotcore.hardware.IrSeekerSensor;
import com.qualcomm.robotcore.hardware.LED;
import com.qualcomm.robotcore.hardware.PWMOutput;
import com.qualcomm.robotcore.hardware.PWMOutputController;
import com.qualcomm.robotcore.hardware.PWMOutputImpl;
import com.qualcomm.robotcore.hardware.RobotCoreLynxModule;
import com.qualcomm.robotcore.hardware.RobotCoreLynxUsbDevice;
import com.qualcomm.robotcore.hardware.ScannedDevices;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.ServoControllerEx;
import com.qualcomm.robotcore.hardware.ServoImplEx;
import com.qualcomm.robotcore.hardware.TouchSensor;
import com.qualcomm.robotcore.hardware.configuration.DeviceConfiguration;
import com.qualcomm.robotcore.hardware.configuration.LynxConstants;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.AnalogSensorConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.DigitalIoDeviceConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.I2cDeviceConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.MotorConfigurationType;
import com.qualcomm.robotcore.hardware.configuration.typecontainers.ServoConfigurationType;
import com.qualcomm.robotcore.hardware.usb.RobotUsbDevice;
import com.qualcomm.robotcore.hardware.usb.RobotUsbDeviceImplBase;
import com.qualcomm.robotcore.hardware.usb.RobotUsbManager;
import com.qualcomm.robotcore.hardware.usb.RobotUsbManagerCombining;
import com.qualcomm.robotcore.hardware.usb.RobotUsbModule;
import com.qualcomm.robotcore.hardware.usb.ftdi.RobotUsbManagerFtdi;
import com.qualcomm.robotcore.hardware.usb.serial.RobotUsbManagerTty;
import com.qualcomm.robotcore.util.RobotLog;
import com.qualcomm.robotcore.util.SerialNumber;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.internal.camera.CameraManagerInternal;
import org.firstinspires.ftc.robotcore.internal.hardware.UserNameable;
import org.firstinspires.ftc.robotcore.internal.hardware.usb.ArmableUsbDevice;
import org.firstinspires.ftc.robotcore.internal.usb.EthernetOverUsbSerialNumber;
import org.firstinspires.ftc.robotcore.internal.usb.VendorProductSerialNumber;
import org.firstinspires.inspection.InspectionState;

public class HardwareDeviceManager implements DeviceManager {
    public static final String TAG = "HardwareDeviceManager";
    public static final String TAG_USB_SCAN = "USBScan";
    public static final Object scanDevicesLock = new Object();
    private final Context context;
    private final SyncdDevice.Manager manager;
    /* access modifiers changed from: private */
    public RobotUsbManager usbManager = createUsbManager();

    public HardwareDeviceManager(Context context2, SyncdDevice.Manager manager2) {
        this.context = context2;
        this.manager = manager2;
    }

    public static RobotUsbManager createUsbManager() {
        RobotUsbManagerFtdi robotUsbManagerFtdi = new RobotUsbManagerFtdi();
        if (!LynxConstants.isRevControlHub()) {
            return robotUsbManagerFtdi;
        }
        RobotUsbManagerCombining robotUsbManagerCombining = new RobotUsbManagerCombining();
        robotUsbManagerCombining.addManager(robotUsbManagerFtdi);
        robotUsbManagerCombining.addManager(new RobotUsbManagerTty());
        return robotUsbManagerCombining;
    }

    /*  JADX ERROR: StackOverflow in pass: MarkFinallyVisitor
        jadx.core.utils.exceptions.JadxOverflowException: 
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:47)
        	at jadx.core.utils.ErrorsCounter.methodError(ErrorsCounter.java:81)
        */
    public com.qualcomm.robotcore.hardware.ScannedDevices scanForUsbDevices() throws com.qualcomm.robotcore.exception.RobotCoreException {
        /*
            r13 = this;
            java.lang.Object r0 = scanDevicesLock
            monitor-enter(r0)
            long r1 = java.lang.System.nanoTime()     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.hardware.ScannedDevices r3 = new com.qualcomm.robotcore.hardware.ScannedDevices     // Catch:{ all -> 0x013b }
            r3.<init>()     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.hardware.usb.RobotUsbManager r4 = r13.usbManager     // Catch:{ all -> 0x013b }
            java.util.List r4 = r4.scanForDevices()     // Catch:{ all -> 0x013b }
            int r5 = r4.size()     // Catch:{ all -> 0x013b }
            java.lang.String r6 = "USBScan"
            java.lang.String r7 = "device count=%d"
            java.lang.Integer r8 = java.lang.Integer.valueOf(r5)     // Catch:{ all -> 0x013b }
            java.lang.Object[] r8 = new java.lang.Object[]{r8}     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r6, (java.lang.String) r7, (java.lang.Object[]) r8)     // Catch:{ all -> 0x013b }
            if (r5 <= 0) goto L_0x0112
            java.lang.String r6 = "hw mgr usb scan"
            java.util.concurrent.ExecutorService r7 = com.qualcomm.robotcore.util.ThreadPool.newFixedThreadPool(r5, r6)     // Catch:{ all -> 0x013b }
            java.util.concurrent.ConcurrentHashMap r5 = new java.util.concurrent.ConcurrentHashMap     // Catch:{ all -> 0x013b }
            r5.<init>()     // Catch:{ all -> 0x013b }
            java.util.Iterator r4 = r4.iterator()     // Catch:{ all -> 0x00e3 }
        L_0x0036:
            boolean r6 = r4.hasNext()     // Catch:{ all -> 0x00e3 }
            if (r6 == 0) goto L_0x004b
            java.lang.Object r6 = r4.next()     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.util.SerialNumber r6 = (com.qualcomm.robotcore.util.SerialNumber) r6     // Catch:{ all -> 0x00e3 }
            com.qualcomm.hardware.HardwareDeviceManager$1 r8 = new com.qualcomm.hardware.HardwareDeviceManager$1     // Catch:{ all -> 0x00e3 }
            r8.<init>(r6, r5)     // Catch:{ all -> 0x00e3 }
            r7.execute(r8)     // Catch:{ all -> 0x00e3 }
            goto L_0x0036
        L_0x004b:
            r7.shutdown()     // Catch:{ all -> 0x00e3 }
            java.util.concurrent.TimeUnit r10 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ all -> 0x00e3 }
            java.lang.String r11 = "USB Scanning Service"
            java.lang.String r12 = "internal error"
            r8 = 30
            com.qualcomm.robotcore.util.ThreadPool.awaitTerminationOrExitApplication(r7, r8, r10, r11, r12)     // Catch:{ all -> 0x00e3 }
            java.util.Set r4 = r5.entrySet()     // Catch:{ all -> 0x00e3 }
            java.util.Iterator r4 = r4.iterator()     // Catch:{ all -> 0x00e3 }
        L_0x0061:
            boolean r6 = r4.hasNext()     // Catch:{ all -> 0x00e3 }
            if (r6 == 0) goto L_0x007d
            java.lang.Object r6 = r4.next()     // Catch:{ all -> 0x00e3 }
            java.util.Map$Entry r6 = (java.util.Map.Entry) r6     // Catch:{ all -> 0x00e3 }
            java.lang.Object r7 = r6.getValue()     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice r7 = (com.qualcomm.robotcore.hardware.usb.RobotUsbDevice) r7     // Catch:{ all -> 0x00e3 }
            java.lang.Object r6 = r6.getKey()     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.util.SerialNumber r6 = (com.qualcomm.robotcore.util.SerialNumber) r6     // Catch:{ all -> 0x00e3 }
            r13.determineDeviceType(r7, r6, r3)     // Catch:{ all -> 0x00e3 }
            goto L_0x0061
        L_0x007d:
            java.util.Collection r4 = com.qualcomm.robotcore.hardware.usb.RobotUsbDeviceImplBase.getExtantDevices()     // Catch:{ all -> 0x00e3 }
            java.util.Iterator r4 = r4.iterator()     // Catch:{ all -> 0x00e3 }
        L_0x0085:
            boolean r6 = r4.hasNext()     // Catch:{ all -> 0x00e3 }
            if (r6 == 0) goto L_0x00b6
            java.lang.Object r6 = r4.next()     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice r6 = (com.qualcomm.robotcore.hardware.usb.RobotUsbDevice) r6     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.util.SerialNumber r7 = r6.getSerialNumber()     // Catch:{ all -> 0x00e3 }
            boolean r8 = r5.containsKey(r7)     // Catch:{ all -> 0x00e3 }
            if (r8 != 0) goto L_0x0085
            com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r6 = r6.getDeviceType()     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.hardware.DeviceManager$UsbDeviceType r8 = com.qualcomm.robotcore.hardware.DeviceManager.UsbDeviceType.FTDI_USB_UNKNOWN_DEVICE     // Catch:{ all -> 0x00e3 }
            if (r6 == r8) goto L_0x0085
            java.lang.String r8 = "USBScan"
            java.lang.String r9 = "added extant device %s type=%s"
            java.lang.String r10 = r6.toString()     // Catch:{ all -> 0x00e3 }
            java.lang.Object[] r10 = new java.lang.Object[]{r7, r10}     // Catch:{ all -> 0x00e3 }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r8, (java.lang.String) r9, (java.lang.Object[]) r10)     // Catch:{ all -> 0x00e3 }
            r3.put(r7, r6)     // Catch:{ all -> 0x00e3 }
            goto L_0x0085
        L_0x00b6:
            java.util.Set r4 = r5.entrySet()     // Catch:{ all -> 0x013b }
            java.util.Iterator r4 = r4.iterator()     // Catch:{ all -> 0x013b }
        L_0x00be:
            boolean r5 = r4.hasNext()     // Catch:{ all -> 0x013b }
            if (r5 == 0) goto L_0x0112
            java.lang.Object r5 = r4.next()     // Catch:{ all -> 0x013b }
            java.util.Map$Entry r5 = (java.util.Map.Entry) r5     // Catch:{ all -> 0x013b }
            java.lang.String r6 = "USBScan"
            java.lang.String r7 = "closing %s"
            java.lang.Object r8 = r5.getKey()     // Catch:{ all -> 0x013b }
            java.lang.Object[] r8 = new java.lang.Object[]{r8}     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r6, (java.lang.String) r7, (java.lang.Object[]) r8)     // Catch:{ all -> 0x013b }
            java.lang.Object r5 = r5.getValue()     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice r5 = (com.qualcomm.robotcore.hardware.usb.RobotUsbDevice) r5     // Catch:{ all -> 0x013b }
            r5.close()     // Catch:{ all -> 0x013b }
            goto L_0x00be
        L_0x00e3:
            r1 = move-exception
            java.util.Set r2 = r5.entrySet()     // Catch:{ all -> 0x013b }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ all -> 0x013b }
        L_0x00ec:
            boolean r3 = r2.hasNext()     // Catch:{ all -> 0x013b }
            if (r3 == 0) goto L_0x0111
            java.lang.Object r3 = r2.next()     // Catch:{ all -> 0x013b }
            java.util.Map$Entry r3 = (java.util.Map.Entry) r3     // Catch:{ all -> 0x013b }
            java.lang.String r4 = "USBScan"
            java.lang.String r5 = "closing %s"
            java.lang.Object r6 = r3.getKey()     // Catch:{ all -> 0x013b }
            java.lang.Object[] r6 = new java.lang.Object[]{r6}     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r4, (java.lang.String) r5, (java.lang.Object[]) r6)     // Catch:{ all -> 0x013b }
            java.lang.Object r3 = r3.getValue()     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.hardware.usb.RobotUsbDevice r3 = (com.qualcomm.robotcore.hardware.usb.RobotUsbDevice) r3     // Catch:{ all -> 0x013b }
            r3.close()     // Catch:{ all -> 0x013b }
            goto L_0x00ec
        L_0x0111:
            throw r1     // Catch:{ all -> 0x013b }
        L_0x0112:
            r13.scanForWebcams(r3)     // Catch:{ all -> 0x013b }
            r13.scanForEthernetOverUsbDevices(r3)     // Catch:{ all -> 0x013b }
            long r4 = java.lang.System.nanoTime()     // Catch:{ all -> 0x013b }
            java.lang.String r6 = "USBScan"
            java.lang.String r7 = "scanForUsbDevices() took %dms count=%d"
            long r4 = r4 - r1
            r1 = 1000000(0xf4240, double:4.940656E-318)
            long r4 = r4 / r1
            int r1 = (int) r4     // Catch:{ all -> 0x013b }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ all -> 0x013b }
            int r2 = r3.size()     // Catch:{ all -> 0x013b }
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ all -> 0x013b }
            java.lang.Object[] r1 = new java.lang.Object[]{r1, r2}     // Catch:{ all -> 0x013b }
            com.qualcomm.robotcore.util.RobotLog.vv((java.lang.String) r6, (java.lang.String) r7, (java.lang.Object[]) r1)     // Catch:{ all -> 0x013b }
            monitor-exit(r0)     // Catch:{ all -> 0x013b }
            return r3
        L_0x013b:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x013b }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.qualcomm.hardware.HardwareDeviceManager.scanForUsbDevices():com.qualcomm.robotcore.hardware.ScannedDevices");
    }

    /* access modifiers changed from: package-private */
    public Integer countVidPid(Map<Pair<Integer, Integer>, Integer> map, VendorProductSerialNumber vendorProductSerialNumber) {
        Integer num = map.get(new Pair(Integer.valueOf(vendorProductSerialNumber.getVendorId()), Integer.valueOf(vendorProductSerialNumber.getProductId())));
        if (num != null) {
            return num;
        }
        return 0;
    }

    /* access modifiers changed from: package-private */
    public void addVidPid(Map<Pair<Integer, Integer>, Integer> map, VendorProductSerialNumber vendorProductSerialNumber, int i) {
        map.put(new Pair(Integer.valueOf(vendorProductSerialNumber.getVendorId()), Integer.valueOf(vendorProductSerialNumber.getProductId())), Integer.valueOf(countVidPid(map, vendorProductSerialNumber).intValue() + i));
    }

    /* access modifiers changed from: protected */
    public void scanForEthernetOverUsbDevices(ScannedDevices scannedDevices) {
        synchronized (scanDevicesLock) {
            try {
                Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
                while (networkInterfaces.hasMoreElements()) {
                    NetworkInterface nextElement = networkInterfaces.nextElement();
                    if (nextElement.getName().startsWith("eth")) {
                        Enumeration<InetAddress> inetAddresses = nextElement.getInetAddresses();
                        while (inetAddresses.hasMoreElements()) {
                            InetAddress nextElement2 = inetAddresses.nextElement();
                            if (nextElement2.getAddress().length == 4) {
                                RobotLog.dd(TAG, "IP Address: " + nextElement2.getHostAddress());
                                scannedDevices.put(EthernetOverUsbSerialNumber.fromIpAddress(nextElement2.getHostAddress(), nextElement.getName()), DeviceManager.UsbDeviceType.ETHERNET_DEVICE);
                            }
                        }
                    }
                }
            } catch (SocketException e) {
                RobotLog.e(TAG, "Error getting network interfaces", e);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void scanForWebcams(ScannedDevices scannedDevices) {
        synchronized (scanDevicesLock) {
            List<WebcamName> allWebcams = ClassFactory.getInstance().getCameraManager().getAllWebcams();
            HashMap hashMap = new HashMap();
            HashMap hashMap2 = new HashMap();
            for (WebcamName serialNumber : allWebcams) {
                SerialNumber serialNumber2 = serialNumber.getSerialNumber();
                if (serialNumber2.isVendorProduct()) {
                    VendorProductSerialNumber vendorProductSerialNumber = (VendorProductSerialNumber) serialNumber2;
                    if (TextUtils.isEmpty(vendorProductSerialNumber.getConnectionPath())) {
                        addVidPid(hashMap2, vendorProductSerialNumber, 1);
                    } else {
                        addVidPid(hashMap, vendorProductSerialNumber, 1);
                    }
                }
            }
            for (WebcamName serialNumber3 : allWebcams) {
                SerialNumber serialNumber4 = serialNumber3.getSerialNumber();
                if (serialNumber4.isVendorProduct()) {
                    VendorProductSerialNumber vendorProductSerialNumber2 = (VendorProductSerialNumber) serialNumber4;
                    int intValue = countVidPid(hashMap2, vendorProductSerialNumber2).intValue();
                    if (intValue > 1) {
                        RobotLog.ee(TAG, "%d serialnumless webcams w/o connection info; ignoring", Integer.valueOf(intValue), vendorProductSerialNumber2);
                    } else if (countVidPid(hashMap2, vendorProductSerialNumber2).intValue() == 0 && countVidPid(hashMap, vendorProductSerialNumber2).intValue() == 1) {
                        serialNumber4 = SerialNumber.fromVidPid(vendorProductSerialNumber2.getVendorId(), vendorProductSerialNumber2.getProductId(), InspectionState.NO_VERSION);
                    }
                }
                RobotLog.vv(TAG, "scanned webcam serial=%s", serialNumber4);
                scannedDevices.put(serialNumber4, DeviceManager.UsbDeviceType.WEBCAM);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void determineDeviceType(RobotUsbDevice robotUsbDevice, SerialNumber serialNumber, ScannedDevices scannedDevices) {
        DeviceManager.UsbDeviceType deviceType = RobotUsbDeviceImplBase.getDeviceType(serialNumber);
        if (deviceType == DeviceManager.UsbDeviceType.UNKNOWN_DEVICE) {
            if (robotUsbDevice.getUsbIdentifiers().isLynxDevice()) {
                RobotLog.vv(TAG_USB_SCAN, "%s is a lynx device", serialNumber);
                deviceType = getLynxDeviceType(robotUsbDevice);
            } else {
                return;
            }
        }
        scannedDevices.put(serialNumber, deviceType);
    }

    /* access modifiers changed from: package-private */
    public DeviceManager.UsbDeviceType getLynxDeviceType(RobotUsbDevice robotUsbDevice) {
        DeviceManager.UsbDeviceType usbDeviceType = DeviceManager.UsbDeviceType.LYNX_USB_DEVICE;
        robotUsbDevice.setDeviceType(usbDeviceType);
        return usbDeviceType;
    }

    public RobotCoreLynxUsbDevice createLynxUsbDevice(SerialNumber serialNumber, String str) throws RobotCoreException, InterruptedException {
        Context context2 = this.context;
        HardwareFactory.noteSerialNumberType(context2, serialNumber, context2.getString(R.string.moduleDisplayNameLynxUsbDevice));
        RobotLog.v("Creating %s", HardwareFactory.getDeviceDisplayName(this.context, serialNumber));
        return LynxUsbDeviceImpl.findOrCreateAndArm(this.context, serialNumber, this.manager, this.usbManager);
    }

    public DcMotor createDcMotor(DcMotorController dcMotorController, int i, MotorConfigurationType motorConfigurationType, String str) {
        return new DcMotorImpl(dcMotorController, i, DcMotorSimple.Direction.FORWARD, motorConfigurationType);
    }

    public DcMotor createDcMotorEx(DcMotorController dcMotorController, int i, MotorConfigurationType motorConfigurationType, String str) {
        return new DcMotorImplEx(dcMotorController, i, DcMotorSimple.Direction.FORWARD, motorConfigurationType);
    }

    public Servo createServoEx(ServoControllerEx servoControllerEx, int i, String str, ServoConfigurationType servoConfigurationType) {
        return new ServoImplEx(servoControllerEx, i, Servo.Direction.FORWARD, servoConfigurationType);
    }

    public CRServo createCRServoEx(ServoControllerEx servoControllerEx, int i, String str, ServoConfigurationType servoConfigurationType) {
        return new CRServoImplEx(servoControllerEx, i, DcMotorSimple.Direction.FORWARD, servoConfigurationType);
    }

    public List<HardwareDevice> createCustomServoDeviceInstances(ServoControllerEx servoControllerEx, int i, ServoConfigurationType servoConfigurationType) {
        return servoConfigurationType.createInstances(servoControllerEx, i);
    }

    public WebcamName createWebcamName(final SerialNumber serialNumber, String str) throws RobotCoreException, InterruptedException {
        Context context2 = this.context;
        HardwareFactory.noteSerialNumberType(context2, serialNumber, context2.getString(R.string.moduleDisplayNameWebcam));
        RobotLog.v("Creating %s", HardwareFactory.getDeviceDisplayName(this.context, serialNumber));
        WebcamName webcamNameFromSerialNumber = ((CameraManagerInternal) ClassFactory.getInstance().getCameraManager()).webcamNameFromSerialNumber(serialNumber, new ArmableUsbDevice.OpenRobotUsbDevice() {
            public RobotUsbDevice open() throws RobotCoreException {
                if (((CameraManagerInternal) ClassFactory.getInstance().getCameraManager()).isWebcamAttached(serialNumber)) {
                    return null;
                }
                RobotLog.logAndThrow("Unable to find webcam with serial number " + serialNumber);
                return null;
            }
        }, this.manager);
        if (webcamNameFromSerialNumber instanceof UserNameable) {
            ((UserNameable) webcamNameFromSerialNumber).setUserName(str);
        }
        ((RobotUsbModule) webcamNameFromSerialNumber).armOrPretend();
        return webcamNameFromSerialNumber;
    }

    public TouchSensor createMRDigitalTouchSensor(DigitalChannelController digitalChannelController, int i, String str) {
        RobotLog.v("Creating Modern Robotics digital Touch Sensor - Port: " + i);
        return new ModernRoboticsTouchSensor(digitalChannelController, i);
    }

    public IrSeekerSensor createMRI2cIrSeekerSensorV3(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        RobotLog.v("Creating Modern Robotics I2C IR Seeker Sensor V3 - mod=%d bus=%d", Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return new ModernRoboticsI2cIrSeekerSensorV3(createI2cDeviceSynch(robotCoreLynxModule, i2cChannel, str), true);
    }

    public List<HardwareDevice> createAnalogSensorInstances(AnalogInputController analogInputController, int i, AnalogSensorConfigurationType analogSensorConfigurationType) {
        RobotLog.v("Creating Analog Sensor - Type: " + analogSensorConfigurationType.getName() + " - Port: " + i);
        return analogSensorConfigurationType.createInstances(analogInputController, i);
    }

    public List<HardwareDevice> createDigitalDeviceInstances(DigitalChannelController digitalChannelController, int i, DigitalIoDeviceConfigurationType digitalIoDeviceConfigurationType) {
        RobotLog.v("Creating Digital Channel Device - Type: " + digitalIoDeviceConfigurationType.getName() + " - Port: " + i);
        return digitalIoDeviceConfigurationType.createInstances(digitalChannelController, i);
    }

    public PWMOutput createPwmOutputDevice(PWMOutputController pWMOutputController, int i, String str) {
        RobotLog.v("Creating PWM Output Device - Port: " + i);
        return new PWMOutputImpl(pWMOutputController, i);
    }

    public List<HardwareDevice> createI2cDeviceInstances(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, I2cDeviceConfigurationType i2cDeviceConfigurationType, String str) {
        RobotLog.v("Creating user sensor %s - on Lynx module=%d bus=%d", i2cDeviceConfigurationType.getName(), Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return i2cDeviceConfigurationType.createInstances(new HardwareDeviceManager$$ExternalSyntheticLambda0(this, robotCoreLynxModule, i2cChannel, str));
    }

    public HardwareDevice createLimelight3A(SerialNumber serialNumber, String str, InetAddress inetAddress) {
        RobotLog.v("Creating Limelight3A named %s at %s", str, serialNumber.getString());
        return new Limelight3A(serialNumber, str, inetAddress);
    }

    public ColorSensor createAdafruitI2cColorSensor(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        RobotLog.v("Creating Adafruit Color Sensor (Lynx) - mod=%d bus=%d", Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return new AdafruitI2cColorSensor(m19lambda$createI2cDeviceInstances$0$comqualcommhardwareHardwareDeviceManager(robotCoreLynxModule, i2cChannel, str), true);
    }

    public ColorSensor createLynxColorRangeSensor(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        RobotLog.v("Creating Lynx Color/Range Sensor - mod=%d bus=%d", Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return new LynxI2cColorRangeSensor(m19lambda$createI2cDeviceInstances$0$comqualcommhardwareHardwareDeviceManager(robotCoreLynxModule, i2cChannel, str), true);
    }

    public ColorSensor createModernRoboticsI2cColorSensor(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        RobotLog.v("Creating Modern Robotics I2C Color Sensor - mod=%d bus=%d", Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return new ModernRoboticsI2cColorSensor(createI2cDeviceSynch(robotCoreLynxModule, i2cChannel, str), true);
    }

    public GyroSensor createModernRoboticsI2cGyroSensor(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        RobotLog.v("Creating Modern Robotics I2C Gyro Sensor - mod=%d bus=%d", Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return new ModernRoboticsI2cGyro(createI2cDeviceSynch(robotCoreLynxModule, i2cChannel, str), true);
    }

    public LED createLED(DigitalChannelController digitalChannelController, int i, String str) {
        RobotLog.v("Creating LED - Port: " + i);
        return new LED(digitalChannelController, i);
    }

    public I2cDeviceSynch createI2cDeviceSynch(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        RobotLog.v("Creating I2cDeviceSynch (Lynx) - mod=%d bus=%d", Integer.valueOf(robotCoreLynxModule.getModuleAddress()), Integer.valueOf(i2cChannel.channel));
        return new I2cDeviceSynchImplOnSimple(m19lambda$createI2cDeviceInstances$0$comqualcommhardwareHardwareDeviceManager(robotCoreLynxModule, i2cChannel, str), true);
    }

    /* access modifiers changed from: protected */
    /* renamed from: createI2cDeviceSynchSimple */
    public I2cDeviceSynchSimple m19lambda$createI2cDeviceInstances$0$comqualcommhardwareHardwareDeviceManager(RobotCoreLynxModule robotCoreLynxModule, DeviceConfiguration.I2cChannel i2cChannel, String str) {
        LynxI2cDeviceSynch createLynxI2cDeviceSynch = LynxFirmwareVersionManager.createLynxI2cDeviceSynch(this.context, (LynxModule) robotCoreLynxModule, i2cChannel.channel);
        createLynxI2cDeviceSynch.setUserConfiguredName(str);
        return createLynxI2cDeviceSynch;
    }

    private RobotUsbDevice.FirmwareVersion getModernRoboticsFirmwareVersion(byte[] bArr) {
        return new RobotUsbDevice.FirmwareVersion(bArr[0]);
    }
}

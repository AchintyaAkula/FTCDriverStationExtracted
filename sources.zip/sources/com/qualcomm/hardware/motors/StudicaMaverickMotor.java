package com.qualcomm.hardware.motors;

import com.qualcomm.robotcore.hardware.configuration.DistributorInfo;
import com.qualcomm.robotcore.hardware.configuration.annotations.DeviceProperties;
import com.qualcomm.robotcore.hardware.configuration.annotations.MotorType;
import org.firstinspires.ftc.robotcore.external.navigation.Rotation;

@DeviceProperties(builtIn = true, name = "Studica Maverick", xmlTag = "StudicaMaverick")
@DistributorInfo(distributor = "Studica", model = "75001", url = "https://www.studica.co/maverick-12v-dc-gear-motor-wencoder")
@MotorType(gearing = 61.0d, maxRPM = 100.0d, orientation = Rotation.CW, ticksPerRev = 1464.0d)
public interface StudicaMaverickMotor {
}

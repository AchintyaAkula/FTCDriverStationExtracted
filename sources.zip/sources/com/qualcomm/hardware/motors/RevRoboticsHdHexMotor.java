package com.qualcomm.hardware.motors;

@Deprecated
public interface RevRoboticsHdHexMotor extends RevRobotics40HdHexMotor {
}
